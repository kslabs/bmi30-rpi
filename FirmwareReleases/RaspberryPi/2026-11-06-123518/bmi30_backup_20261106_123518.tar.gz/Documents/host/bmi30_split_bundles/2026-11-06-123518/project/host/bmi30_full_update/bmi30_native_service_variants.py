"""Select one reviewed public Network service for two known native CM5s only.

No identity adoption, config/credential access or writes. The caller reads the
physical serial afresh before installation and owns native-medium guards.
"""
import ast
import hashlib
from pathlib import Path, PurePosixPath
import re

BOARDS = {'366b6f101fa60500': ('M02', None, None), 'abdd2dbc9775fbae': ('S07', '2026-10-30-085518', '9c03c75ba74b12773b8df77c54619aa80f19fb00211498e97fe208c0ecf2bd20')}
NATIVE_CIDS = {'366b6f101fa60500': '150100424a54443452030f7c4ad57b00', 'abdd2dbc9775fbae': '150100424a54443452030f7c4acd7b00'}


def require(value, message):
    if not value:
        raise ValueError(message)


def constants(data):
    result = {}
    tree = ast.parse(data)
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in ('BOUND_BUNDLE', 'GUARD_SHA', 'VERSION'):
                    require(target.id not in result, 'Duplicate public service identity')
                    result[target.id] = ast.literal_eval(node.value)
    return result


def descriptor_rows(descriptor):
    require(isinstance(descriptor, dict) and set(descriptor) == {'schema', 'variants'}
            and descriptor['schema'] == 1 and isinstance(descriptor['variants'], dict)
            and set(descriptor['variants']) == set(BOARDS), 'Wrong native service cohort')
    rows = {}
    for serial, (board, bound, guard) in BOARDS.items():
        row = descriptor['variants'][serial]
        require(isinstance(row, dict) and set(row) == {'path', 'sha256'}, 'Invalid public service descriptor')
        relative = PurePosixPath(row['path'])
        require(str(relative) == 'variants/network-service/' + board + '.py'
                and isinstance(row['sha256'], str) and re.fullmatch('[0-9a-f]{64}', row['sha256']),
                'Unsafe native service variant path')
        rows[serial] = row
    return rows


def validate_variant_data(data_by_path, descriptor, expected_version):
    rows = descriptor_rows(descriptor)
    require(isinstance(data_by_path, dict) and set(data_by_path) == {row['path'] for row in rows.values()},
            'Incomplete native service variant bytes')
    verified = {}
    for serial, row in rows.items():
        board, bound, guard = BOARDS[serial]
        data = data_by_path[row['path']]
        require(isinstance(data, bytes) and len(data) <= 1024 * 1024, 'Invalid public service source bytes')
        require(hashlib.sha256(data).hexdigest() == row['sha256'], 'Native service variant checksum mismatch')
        expected = {'VERSION': expected_version}
        if bound is not None:
            expected.update(BOUND_BUNDLE=bound, GUARD_SHA=guard)
        require(constants(data) == expected, 'Wrong own native service binding')
        verified[serial] = data
    return verified


def validate_variants(payload, descriptor, expected_version):
    payload = Path(payload).resolve()
    rows = descriptor_rows(descriptor)
    paths, data = {}, {}
    for serial, row in rows.items():
        path = payload.joinpath(*PurePosixPath(row['path']).parts)
        current = path
        while current != payload:
            require(not current.is_symlink(), 'Native service variant symlink')
            current = current.parent
        require(path.is_file(), 'Native service variant missing')
        paths[serial] = path
        data[row['path']] = path.read_bytes()
    validate_variant_data(data, descriptor, expected_version)
    return paths


def service_bytes(data_by_path, descriptor, physical_serial, expected_version):
    require(isinstance(physical_serial, str) and re.fullmatch('[0-9a-f]{16}', physical_serial)
            and physical_serial in BOARDS, 'Unsupported native physical CM5')
    return validate_variant_data(data_by_path, descriptor, expected_version)[physical_serial]


def service_source(payload, descriptor, physical_serial, expected_version):
    require(isinstance(physical_serial, str) and re.fullmatch('[0-9a-f]{16}', physical_serial)
            and physical_serial in BOARDS, 'Unsupported native physical CM5')
    return validate_variants(payload, descriptor, expected_version)[physical_serial]


def physical_serial(root='/'):
    # This exact live physical source cannot be replaced by an adopted marker.
    root = Path(root)
    serial = (root / 'proc/device-tree/serial-number').read_text().strip('\0\r\n ').lower()
    require(serial in NATIVE_CIDS, 'Unsupported native physical CM5')
    require((root / 'sys/block/mmcblk0/device/cid').read_text().strip().lower() == NATIVE_CIDS[serial],
            'Wrong own native eMMC CID')
    mounts = {}
    for line in (root / 'proc/self/mountinfo').read_text().splitlines():
        before, separator, after = line.partition(' - ')
        if not separator:
            continue
        fields, filesystem = before.split(), after.split()
        if len(fields) > 4 and len(filesystem) > 1 and fields[4] in ('/', '/boot/firmware'):
            require(fields[4] not in mounts, 'Ambiguous native mount')
            mounts[fields[4]] = (filesystem[0], filesystem[1])
    require(mounts.get('/') == ('ext4', '/dev/mmcblk0p2')
            and mounts.get('/boot/firmware') == ('vfat', '/dev/mmcblk0p1'), 'Known-native eMMC boot required')
    return serial
