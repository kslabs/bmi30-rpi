"""Moving one unchanged USB configuration must identify its current CM5."""
import copy
import importlib.util
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

BASE = Path(__file__).resolve().parents[3]
SOURCE = Path(os.getenv('BMI30_NETWORK_TEST_SOURCE', BASE/'HostTools/bmi30_network'))
sys.path.insert(0, str(SOURCE))
import network
SERVICE = SOURCE/'service.py' if os.getenv('BMI30_NETWORK_TEST_SOURCE') else Path(__file__).with_name('service.py')
spec = importlib.util.spec_from_file_location('portable_service', SERVICE)
service = importlib.util.module_from_spec(spec)
spec.loader.exec_module(service)


def hardware_files(values):
    def read(path, *args, **kwargs):
        try:
            return values[path.as_posix()]
        except KeyError:
            raise FileNotFoundError(str(path))
    return patch.object(Path, 'read_text', autospec=True, side_effect=read)


class HardwareIdentityTests(unittest.TestCase):
    def test_device_tree_serials_define_two_physical_devices(self):
        for serial, expected in [('241b7cbd5eb8f26c', 'BMI30-D5EB8F26C'),
                                 ('6cb77396922a5a0d', 'BMI30-6922A5A0D')]:
            with self.subTest(serial=serial), hardware_files({'/proc/device-tree/serial-number':serial+'\x00\n'}):
                self.assertEqual(network.hardware_identity(), expected)

    def test_alternate_device_tree_and_cpuinfo_sources(self):
        cases = [{'/sys/firmware/devicetree/base/serial-number':'6cb77396922a5a0d\x00'},
                 {'/proc/cpuinfo':'Hardware\t: BCM2712\nSerial\t\t: 6cb77396922a5a0d\nRevision\t: d04170\n'}]
        for values in cases:
            with self.subTest(values=values), hardware_files(values):
                self.assertEqual(network.hardware_identity(), 'BMI30-6922A5A0D')

    def test_invalid_or_missing_hardware_never_uses_cloned_state(self):
        for serial in ['', '0000000000000000', '6cb77396922a5a0dgarbage', 'zz6cb77396922a5a0d', '6922a5a0d']:
            values={'/proc/device-tree/serial-number':serial,
                    '/etc/hostname':'BMI30-D5EB8F26C', '/etc/machine-id':'a'*32,
                    '/proc/cpuinfo':'Serial: '+serial+'\n'}
            with self.subTest(serial=serial), hardware_files(values), patch('socket.gethostname', side_effect=AssertionError('Hostname is not hardware')):
                with self.assertRaises(RuntimeError):
                    network.hardware_identity()


class PortableAgentTests(unittest.TestCase):
    def test_same_configuration_on_two_cm5_boards_binds_all_network_consumers(self):
        with patch.object(Path, 'exists', return_value=False):
            state='/tmp/bmi30-portable-identity-test'
            config={'id':'BMI30-D5EB8F26C', 'fleet_key':'19'*32, 'state_dir':state,
                    'portal_config':'/home/techaid/Documents/host/bmi30_config.json',
                    'ap_address':'10.77.113.1/24', 'automatic':True, 'peers':['192.168.0.114']}
            original=copy.deepcopy(config)
            agents=[]
            for identity in ['BMI30-D5EB8F26C', 'BMI30-6922A5A0D']:
                with patch('network.hardware_identity', return_value=identity), patch.object(service.network, 'Network') as net, patch.object(service.group, 'Group') as group:
                    agent=service.Agent(config)
                    self.assertEqual(agent.config['id'], identity)
                    self.assertEqual(net.call_args.args[0]['id'], identity)
                    self.assertIs(group.call_args.args[0], agent)
                    self.assertEqual({**agent.config, 'id':original['id']}, original)
                    self.assertEqual(config, original)
                    agents.append(agent)
            self.assertNotEqual(agents[0].config['id'], agents[1].config['id'])

    def test_hardware_failure_stops_before_network_or_group_construction(self):
        with patch('network.hardware_identity', side_effect=RuntimeError('missing hardware')), patch.object(service.network, 'Network') as net, patch.object(service.group, 'Group') as group:
            with self.assertRaises(RuntimeError):
                service.Agent({'id':'BMI30-D5EB8F26C'})
            net.assert_not_called()
            group.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
