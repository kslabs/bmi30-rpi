import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import bmi30_portable_assets as assets


class PortableAssetsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.base = Path(self.temp.name)
        self.bundle = self.base / 'bundle'
        self.root = self.base / 'root'
        self.backup = self.base / 'backup'
        self.records = {}
        self.original = {}
        for name in sorted(assets.REQUIRED):
            source = self.bundle / 'system' / name
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_text('VERSION = "new"\n' if name.endswith('.py') else '[Service]\nExecStart=/usr/bin/python3 /opt/bmi30-network/service.py\n')
            self.records[name] = assets.digest(source)
            target = self.root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(b'original\n')
            self.original[name] = target.read_bytes()
        self.meta = self.bundle / assets.META
        self.meta.parent.mkdir(parents=True)
        self.save_manifest()
        self.config = self.root / 'var/lib/bmi30-network/config.json'
        self.config.parent.mkdir(parents=True)
        self.config.write_text('{"id": "physical-board", "fleet_key": "preserve-this-local-value"}')
        self.token = self.root / 'var/lib/bmi30-agent/device_api_token'
        self.token.parent.mkdir(parents=True)
        self.token.write_text('local-test-credential-stays-unchanged')

    def tearDown(self):
        self.temp.cleanup()

    def save_manifest(self):
        self.meta.write_text(json.dumps({'schema': 1, 'assets': self.records}))

    def test_unknown_install_path_is_rejected_before_any_write(self):
        self.records['etc/shadow'] = '0' * 64
        self.save_manifest()
        with self.assertRaisesRegex(ValueError, 'Unexpected portable asset path'):
            assets.apply(self.bundle, self.backup, self.root, restart=False)
        for name, data in self.original.items():
            self.assertEqual((self.root / name).read_bytes(), data)
        self.assertFalse(self.backup.exists())

    def test_install_preserves_device_config_and_cloud_credentials(self):
        config, token = self.config.read_bytes(), self.token.read_bytes()
        result = assets.apply(self.bundle, self.backup, self.root, restart=False)
        self.assertEqual(set(result), assets.REQUIRED)
        for name in result:
            self.assertEqual((self.root / name).read_bytes(), (self.bundle / 'system' / name).read_bytes())
        self.assertEqual(self.config.read_bytes(), config)
        self.assertEqual(self.token.read_bytes(), token)
        assets.restore(self.backup, self.root, restart=False)
        for name, data in self.original.items():
            self.assertEqual((self.root / name).read_bytes(), data)

    def test_failed_second_write_restores_prior_system_files(self):
        real_copy = assets.atomic_copy
        writes = 0
        def fail_once(source, target, mode, uid=0, gid=0):
            nonlocal writes
            writes += 1
            if writes == 2:
                raise OSError('simulated interrupted write')
            return real_copy(source, target, mode, uid, gid)
        with mock.patch.object(assets, 'atomic_copy', side_effect=fail_once):
            with self.assertRaisesRegex(OSError, 'simulated interrupted write'):
                assets.apply(self.bundle, self.backup, self.root, restart=False)
        for name, data in self.original.items():
            self.assertEqual((self.root / name).read_bytes(), data)

    def test_rollback_removes_only_new_allowlisted_files(self):
        target = self.root / 'opt/bmi30-network/network.py'
        target.unlink()
        config = self.config.read_bytes()
        assets.apply(self.bundle, self.backup, self.root, restart=False)
        self.assertTrue(target.exists())
        assets.restore(self.backup, self.root, restart=False)
        self.assertFalse(target.exists())
        self.assertEqual(self.config.read_bytes(), config)

    def test_copied_host_guard_is_rejected(self):
        name = 'etc/systemd/system/bmi30-communication-recovery.service'
        path = self.bundle / 'system' / name
        path.write_text('[Service]\nExecStart=/usr/bin/python3 recovery.py --expected-host BMI30-6922A5A0D\n')
        self.records[name] = assets.digest(path)
        self.save_manifest()
        with self.assertRaisesRegex(ValueError, 'Host-specific guard'):
            assets.validate(self.bundle)

    def test_collection_prefers_new_project_code_over_old_installed_code(self):
        project = self.base / 'project'
        source = project / 'utilities/bmi30_communication/network.py'
        source.parent.mkdir(parents=True)
        source.write_text('VERSION = "portable"\n')
        # Other required modules/units can come from the existing system root.
        for name in assets.REQUIRED:
            original = self.root / name
            original.write_bytes((self.bundle / 'system' / name).read_bytes())
        collected = self.base / 'collected'
        names = assets.collect(project, self.root, collected)
        self.assertEqual((collected / 'system/opt/bmi30-network/network.py').read_bytes(), source.read_bytes())
        self.assertNotIn('var/lib/bmi30-network/config.json', names)
        self.assertNotIn('var/lib/bmi30-agent/device_api_token', names)

    def test_historical_bundle_without_system_assets_is_unchanged(self):
        historical = self.base / 'historical'
        historical.mkdir()
        self.assertEqual(assets.apply(historical, self.backup, self.root, restart=False), {})
        self.assertFalse(self.backup.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
