"""Linux fixture tests for private settings restored after failed activation."""
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest import mock

import bmi30_server_update as backend


class BackendPrivacyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='bmi30-private-restore-')
        self.base = Path(self.temp.name)
        self.updater = backend.Updater.__new__(backend.Updater)
        self.updater.root = self.base / 'project'
        self.updater.bundles = self.updater.root / 'host/bmi30_split_bundles'
        self.updater.state = self.updater.root / '.bmi30_cloud_sync/server'
        self.updater.private = self.updater.state / 'private'
        self.updater.private.mkdir(parents=True)
        (self.updater.root / 'host').mkdir(exist_ok=True)
        self.updater.current = lambda: {'bundle_id': 'fixture', 'version': 'fixture'}
        self.updater.activate = mock.Mock()
        self.config = self.updater.root / 'host/bmi30_config.json'

    def tearDown(self):
        self.temp.cleanup()

    def test_snapshot_and_failed_restore_keep_private_mode_and_owner(self):
        for mode in (0o600, 0o640):
            with self.subTest(mode=oct(mode)):
                self.config.write_bytes(b'{"setting":"fixture-original"}')
                os.chown(self.config, 1000, 1000)
                self.config.chmod(mode)
                directory = self.base / ('snapshot-' + oct(mode))
                with mock.patch.object(backend, 'verify_bundle'), \
                     mock.patch.object(backend.portable_assets, 'snapshot'):
                    record = self.updater.snapshot(directory)
                self.assertEqual(record['file_metadata']['bmi30_config.json'],
                                 {'mode': mode, 'uid': 1000, 'gid': 1000})
                self.config.write_bytes(b'{"setting":"failed-change"}')
                os.chown(self.config, 0, 0)
                self.config.chmod(0o644)
                with mock.patch.object(backend.portable_assets, 'restore'):
                    self.updater.restore(record, failed=True)
                self.assertEqual(self.config.read_bytes(), b'{"setting":"fixture-original"}')
                info = self.config.stat()
                self.assertEqual(stat.S_IMODE(info.st_mode), mode)
                self.assertEqual((info.st_uid, info.st_gid), (1000, 1000))

    def test_old_snapshot_preserves_existing_private_destination(self):
        directory = self.base / 'legacy'
        directory.mkdir()
        (directory / 'bmi30_config.json').write_bytes(b'original-fixture')
        self.config.write_bytes(b'changed-fixture')
        os.chown(self.config, 1000, 1000)
        self.config.chmod(0o600)
        self.updater.restore_snapshot_file({'snapshot': str(directory)}, 'bmi30_config.json',
                                          self.config, private_config=True)
        info = self.config.stat()
        self.assertEqual(self.config.read_bytes(), b'original-fixture')
        self.assertEqual(stat.S_IMODE(info.st_mode), 0o600)
        self.assertEqual((info.st_uid, info.st_gid), (1000, 1000))

    def test_old_snapshot_missing_config_uses_private_mode_and_workspace_owner(self):
        directory = self.base / 'legacy-missing'
        directory.mkdir()
        (directory / 'bmi30_config.json').write_bytes(b'original-fixture')
        os.chown(self.config.parent, 1000, 1000)
        self.updater.restore_snapshot_file({'snapshot': str(directory)}, 'bmi30_config.json',
                                          self.config, private_config=True)
        info = self.config.stat()
        self.assertEqual(stat.S_IMODE(info.st_mode), 0o600)
        self.assertEqual((info.st_uid, info.st_gid), (1000, 1000))

    def test_legacy_public_config_is_restored_with_private_permissions(self):
        directory = self.base / 'legacy-public'
        directory.mkdir()
        (directory / 'bmi30_config.json').write_bytes(b'original-fixture')
        self.config.write_bytes(b'changed-fixture')
        self.config.chmod(0o644)
        self.updater.restore_snapshot_file({'snapshot': str(directory)}, 'bmi30_config.json',
                                          self.config, private_config=True)
        self.assertEqual(stat.S_IMODE(self.config.stat().st_mode), 0o640)


if __name__ == '__main__':
    unittest.main()
