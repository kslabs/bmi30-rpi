import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const here=path.dirname(fileURLToPath(import.meta.url));
const defaultSource=fs.existsSync(path.join(here,'hotspot_info_server.py'))
  ?path.join(here,'hotspot_info_server.py'):path.join(here,'..','hotspot_info_server.py');
const source=fs.readFileSync(process.env.BMI30_PORTAL_TEST_SOURCE||defaultSource,'utf8');
const start=source.indexOf('    function _shortStm32DisplayId(');
const end=source.indexOf('    function _setRemoteSensors(',start);
assert(start>=0&&end>start,'Both deployed identity formatters must be present');
const code=source.slice(start,end).replaceAll('{{','{').replaceAll('}}','}');
const context=vm.createContext({});
vm.runInContext(code,context);
const format=context._formatStm32Identity;
const info={uid96_words:'33363534 30325117 000F002E',fw_version:'1.2.55',build_date:'2026-10-07',build_time:'17:00:52'};
assert.equal(format({identity:{stm32:info}}),'7000F002E / FW 1.2.55 (2026-10-07 17:00:52)');
assert.equal(format({events:{fw_info:info}}),'7000F002E / FW 1.2.55 (2026-10-07 17:00:52)');
assert.equal(format({identity:{stm32:info},rs485_ident:{local:{short_id:'ABC123456'}}}),
  'ABC123456 / FW 1.2.55 (2026-10-07 17:00:52)');
assert.equal(format({identity:{stm32:{fw_version:'1.2.56',build_date:'2026-10-07'}}}),
  'FW 1.2.56 (2026-10-07)');
assert.equal(format({identity:{stm32:{fw_version:'1.2.55'}}}),'FW 1.2.55');
assert.equal(format({identity:{stm32:{build_date:'2026-10-07',build_time:'17:00:52'}}}),'FW 2026-10-07 17:00:52');
assert.equal(format({identity:{stm32:{uid96_words:'33363534 30325117 000F002E'}}}),'7000F002E');
assert.equal(format({}),'---');
console.log(JSON.stringify({passed:8,scope:'Actual deployed JavaScript header identity formatter; semver/build, event fallback and physical short ID retained'}));
