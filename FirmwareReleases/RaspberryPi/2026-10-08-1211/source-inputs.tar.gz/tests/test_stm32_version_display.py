"""Display the reported STM32 version without losing hardware/build identity."""
import ast
import os
from pathlib import Path
import re
import typing
import unittest

HERE = Path(__file__).resolve().parent
DEFAULT_SOURCE = HERE / 'hotspot_info_server.py'
if not DEFAULT_SOURCE.exists():
    DEFAULT_SOURCE = HERE.parent / 'hotspot_info_server.py'
SOURCE = Path(os.getenv('BMI30_PORTAL_TEST_SOURCE', DEFAULT_SOURCE))
NAMES = {'_short_stm32_display_id', 'format_stm32_identity',
         '_stm32_identity_from_cache', 'detect_stm32_firmware_version'}
tree = ast.parse(SOURCE.read_text(encoding='utf8'))
selected = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in NAMES]
assert {node.name for node in selected} == NAMES
namespace = {'re': re, 'Any': typing.Any}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(SOURCE), 'exec'), namespace)
format_identity = namespace['format_stm32_identity']
firmware_version = namespace['detect_stm32_firmware_version']


class Stm32VersionDisplayTests(unittest.TestCase):
    def test_current_s09_report_keeps_uid_version_and_build_timestamp(self):
        info = {'uid96_words': '33363534 30325117 000F002E',
                'fw_version': '1.2.55', 'build_date': '2026-10-07', 'build_time': '17:00:52'}
        self.assertEqual(format_identity(info), '7000F002E / FW 1.2.55 (2026-10-07 17:00:52)')

    def test_firmware_version_is_not_guessed_from_date(self):
        info = {'short_id': '123456789', 'fw_version': '1.2.56',
                'build_date': '2026-10-07', 'build_time': '17:00:52'}
        self.assertEqual(format_identity(info), '123456789 / FW 1.2.56 (2026-10-07 17:00:52)')

    def test_version_without_build_metadata_remains_supported(self):
        self.assertEqual(format_identity({'fw_version': '1.2.55'}), 'FW 1.2.55')

    def test_older_firmware_without_semver_keeps_its_build_timestamp(self):
        self.assertEqual(format_identity({'build_date': '2026-10-07', 'build_time': '17:00:52'}),
                         'FW 2026-10-07 17:00:52')

    def test_uid_only_and_empty_reports_keep_previous_fallbacks(self):
        self.assertEqual(format_identity({'short_id': 'ABC123456'}), 'ABC123456')
        self.assertEqual(format_identity({}), '---')

    def test_api_version_comes_from_current_identity_and_stale_cache_is_empty(self):
        current = {'identity': {'stm32': {'fw_version': '1.2.55'}},
                   'events': {'fw_info': {'fw_version': '1.2.55'}}}
        self.assertEqual(firmware_version(current), '1.2.55')
        self.assertEqual(firmware_version({'events': {'fw_info': {'fw_version': '1.2.55'}}}), '1.2.55')
        self.assertEqual(firmware_version({**current, '_stale': True}), '')


if __name__ == '__main__':
    unittest.main(verbosity=2)
