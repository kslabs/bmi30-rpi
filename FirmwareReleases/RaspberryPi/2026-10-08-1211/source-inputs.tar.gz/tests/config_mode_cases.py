
import json,sys,tempfile,pathlib,subprocess,os,stat
p=json.load(sys.stdin);results=[]
with tempfile.TemporaryDirectory(prefix='bmi30-config-mode-test-') as directory:
 root=pathlib.Path(directory);private=root/'private.json';runtime=root/'runtime.json';other=root/'other.json'
 private.write_text('{"private":"unchanged"}');other.write_text('{}')
 for mode in [0o600,0o640]:
  private.chmod(mode);runtime.symlink_to(private)
  result=subprocess.run(['bash','-c',p['function']+'\nPERSISTENT_CONFIG_PATH="$1"\nsecure_runtime_config_mode "$2"','test',str(private),str(runtime)],capture_output=True,text=True)
  assert result.returncode==0,result.stderr
  assert stat.S_IMODE(private.stat().st_mode)==mode
  assert private.read_text()=='{"private":"unchanged"}'
  results.append({'kind':'persistent-symlink','before':oct(mode),'after':oct(stat.S_IMODE(private.stat().st_mode))});runtime.unlink()
 for before,expected in [(0o600,0o600),(0o640,0o640),(0o644,0o640)]:
  runtime.write_text('{}');runtime.chmod(before)
  result=subprocess.run(['bash','-c',p['function']+'\nPERSISTENT_CONFIG_PATH="$1"\nsecure_runtime_config_mode "$2"','test',str(private),str(runtime)],capture_output=True,text=True)
  assert result.returncode==0,result.stderr
  assert stat.S_IMODE(runtime.stat().st_mode)==expected
  results.append({'kind':'regular-runtime','before':oct(before),'after':oct(stat.S_IMODE(runtime.stat().st_mode))});runtime.unlink()
 runtime.symlink_to(other)
 result=subprocess.run(['bash','-c',p['function']+'\nPERSISTENT_CONFIG_PATH="$1"\nsecure_runtime_config_mode "$2"','test',str(private),str(runtime)],capture_output=True,text=True)
 assert result.returncode!=0
 results.append({'kind':'unexpected-config-symlink','rejected':True})
print(json.dumps({'ok':True,'passed':len(results),'cases':results,'installed_files_changed':False}))
