import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path('.tmp/warnings-memory-20261007').resolve()))
from fleet_remote import remote

base = Path('.tmp/s09-portal-repair-20261008/portable')
files = {name: (base / name).read_text(encoding='utf8') for name in
         ('switch_bmi30_split_versions.sh', 'create_bmi30_split_bundle.sh',
          'bmi30_server_files.py', 'bmi30_server_update.py',
          'bmi30_portable_assets.py', 'test_backend_privacy.py')}

SCRIPT = r'''
import json,os,pathlib,re,shlex,subprocess,sys,tempfile
p=json.load(sys.stdin);results={}
with tempfile.TemporaryDirectory(prefix='bmi30-offline-privacy-test-') as directory:
 root=pathlib.Path(directory)
 for name,text in p.items(): (root/name).write_text(text)
 for name in ('switch_bmi30_split_versions.sh','create_bmi30_split_bundle.sh'):
  result=subprocess.run(['bash','-n',str(root/name)],capture_output=True,text=True)
  assert result.returncode==0,result.stderr
 results['bash_syntax']=True
 result=subprocess.run([sys.executable,str(root/'test_backend_privacy.py'),'-v'],capture_output=True,text=True)
 assert result.returncode==0,result.stdout+result.stderr
 results['backend_privacy_tests']=result.stderr
 source=p['switch_bmi30_split_versions.sh']
 invocations=re.findall(r'(sudo[^\n]*?python3) "\$PORTABLE_ASSETS" (apply|restore|validate)',source)
 assert {action for _,action in invocations}=={'apply','restore'},invocations
 results['sudo_offline_flag_checks']=[]
 env=dict(os.environ,BMI30_OFFLINE_ACTIVATION='1',BMI30_TEST_PRIVATE_DROP='fixture-value')
 probe="import os,sys;sys.path.insert(0,sys.argv[1]);import bmi30_portable_assets as a;from unittest import mock;" + \
       "guard=mock.patch.object(a.subprocess,'run',side_effect=AssertionError('unexpected systemctl'));guard.start();" + \
       "a.restart_active('/',[]);assert os.environ.get('BMI30_OFFLINE_ACTIVATION')=='1';" + \
       "assert os.environ.get('BMI30_TEST_PRIVATE_DROP') is None;print('offline preserved; other variable dropped')"
 for prefix,action in invocations:
  assert '--preserve-env=BMI30_OFFLINE_ACTIVATION' in prefix,prefix
  command=shlex.split(prefix)+['-c',probe,str(root)]
  result=subprocess.run(command,env=env,capture_output=True,text=True)
  assert result.returncode==0,result.stderr
  results['sudo_offline_flag_checks'].append({'action':action,'ok':True,'systemctl_called':False})
 start=source.index('install_private_config_mirror() {')
 end=source.index('\n}\n',start)+3
 function=source[start:end]
 original=root/'source.json';original.write_text('{"fixture":true}')
 results['private_mirrors']=[]
 for before,expected in ((None,0o640),(0o600,0o600),(0o640,0o640),(0o644,0o640)):
  target=root/('mirror-'+str(before)+'.json')
  if before is not None: target.write_text('{}');target.chmod(before)
  result=subprocess.run(['bash','-c',function+'\ninstall_private_config_mirror "$1" "$2"','test',str(original),str(target)],capture_output=True,text=True)
  assert result.returncode==0,result.stderr
  assert target.read_bytes()==original.read_bytes()
  assert target.stat().st_mode&0o777==expected
  results['private_mirrors'].append({'before':oct(before) if before is not None else 'absent','after':oct(expected)})
results.update(ok=True,installed_files_changed=False)
print(json.dumps(results))
'''
result = remote('S10', SCRIPT, files, timeout=45)
(base / 'offline-privacy-patch-tests.json').write_text(json.dumps(result, indent=2), encoding='utf8')
print(json.dumps(result))
