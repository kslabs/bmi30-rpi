"""Fleet-authenticated discovery and AES-256-GCM private exchanges.

The installation key is provisioned over already authenticated SSH, never
derived from SSID, hostname, serial number or a public factory password.
"""
import base64
import hashlib
import hmac
import json
import math
import os
import re
import time

MAX_NODES = 128
MAX_PACKET = 512 * 1024
ID = re.compile(r"BMI30-[A-Z0-9-]{1,50}\Z")


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


class Protocol:
    def __init__(self, key):
        self.key = bytes.fromhex(key)
        if len(self.key) != 32:
            raise ValueError("Fleet key must contain 256 random bits")
        self.replays = {}

    def sign(self, data):
        raw = encode(data)
        return {"data": data, "mac": hmac.new(self.key, b"discovery-v1" + raw, hashlib.sha256).hexdigest()}

    def verify(self, record, now=None):
        now = time.time() if now is None else now
        data = record["data"]
        if not hmac.compare_digest(self.sign(data)["mac"], str(record["mac"])):
            raise ValueError("Invalid authentication")
        if not ID.fullmatch(data["id"]) or not -15 <= now - data["issued"] <= 100:
            raise ValueError("Invalid identity or expired advertisement")
        if not isinstance(data["seq"], int) or not isinstance(data["boot"], str):
            raise ValueError("Invalid sequence")
        if not math.isfinite(data.get("cost", 10000)) or len(data.get("path", [])) > 4:
            raise ValueError("Invalid path")
        if len(data.get("visible", [])) > 256 or len(data.get("addresses", [])) > 16:
            raise ValueError("Record exceeds limits")
        return data

    def seal(self, data):
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        nonce = os.urandom(12)
        body = encode({"at": time.time(), "payload": data})
        return base64.b64encode(nonce + AESGCM(self.key).encrypt(nonce, body, b"bmi30-network-v1"))

    def open(self, raw):
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        if len(raw) > MAX_PACKET:
            raise ValueError("Packet too large")
        binary = base64.b64decode(raw, validate=True)
        if len(binary) < 29:
            raise ValueError("Short packet")
        nonce, body = binary[:12], binary[12:]
        data = json.loads(AESGCM(self.key).decrypt(nonce, body, b"bmi30-network-v1"))
        now = time.time()
        if not -15 <= now - data["at"] <= 90 or nonce in self.replays:
            raise ValueError("Expired or replayed packet")
        self.replays = {n: expiry for n, expiry in self.replays.items() if expiry > now}
        if len(self.replays) > 4096:
            raise ValueError("Replay window capacity exceeded")
        self.replays[nonce] = now + 110
        return data["payload"]


class Records:
    def __init__(self, protocol):
        self.protocol, self.records = protocol, {}

    def merge(self, records):
        if len(records) > MAX_NODES:
            raise ValueError("Too many devices")
        now = time.time()
        self.records = {k: v for k, v in self.records.items() if now - v["data"]["issued"] <= 100}
        for record in records:
            try:
                data = self.protocol.verify(record)
            except (ValueError, KeyError, TypeError):
                continue
            old = self.records.get(data["id"], {}).get("data")
            if old and ((old["boot"] == data["boot"] and old["seq"] >= data["seq"])
                        or old["issued"] > data["issued"]):
                continue
            if data["id"] not in self.records and len(self.records) >= MAX_NODES:
                continue
            self.records[data["id"]] = record

    def nodes(self):
        self.merge([])
        return [r["data"] for r in self.records.values()]
