"""Standard runtime-only delivery: no full-system migration is included."""

def start():
    """Portal startup compatibility entry point; no background installer."""
    return None
