BMI30 portable release source inputs 2026-10-08-1131

Runtime inputs preserve the exact bytes from the verified final server archive.
The empty runtime configuration template, compiled C outputs and historical USB
command output are omitted here; the unchanged official package retains them.
Public tag response profiles and all 25 portable runtime assets are retained.
metadata/portable-assets.json and source-inputs.json record their exact hashes.

On a test Linux/ARM machine, extract this source archive and set:
  PYTHONPATH="$PWD/system/opt/bmi30-network:$PWD/utilities:$PWD/tests"
  BMI30_NETWORK_TEST_SOURCE="$PWD/system/opt/bmi30-network"
  BMI30_PORTABLE_TEST_UNIT_ROOT="$PWD/system/etc/systemd/system"
  BMI30_PORTAL_TEST_SOURCE="$PWD/project/hotspot_info_server.py"
Then run (export the four variables above):
  python3 -m unittest test_network test_group test_stability test_communication_recovery test_portable_identity
  python3 -m unittest test_portable_assets test_stm32_version_display
  node tests/test_stm32_version_display.mjs
  bash -n utilities/create_bmi30_split_bundle.sh switch_bmi30_split_versions.sh

tests/input_check_config_mode_preservation.py is the exact original inventory
harness, included as an input record. Do not run that remote harness here.
Its exact temporary-files-only six-case SCRIPT body is tests/config_mode_cases.py.
To run the six cases locally, send JSON {"function": "..."} on stdin with the
secure_runtime_config_mode function extracted from switch_bmi30_split_versions.sh.
No installed runtime files or devices are required by that case body.

The exact offline privacy inventory harness is retained as
tests/input_check_offline_privacy_patch.py; do not run that remote harness here.
Its exact temporary-files-only SCRIPT body is tests/offline_privacy_cases.py.
On a Linux test host, the body accepts JSON source contents on stdin for
switch_bmi30_split_versions.sh, create_bmi30_split_bundle.sh,
bmi30_server_files.py, bmi30_server_update.py, bmi30_portable_assets.py,
and test_backend_privacy.py. It checks Bash syntax, four private snapshot/restore
cases, two sudo environment checks, and four private mirror cases in temporary
directories. These Linux fixtures require root privileges for ownership tests
and sudo availability; they do not change installed runtime files or services.

The final package is an application/service update, not a full disk image.
Existing configuration, fleet credentials, calibration and scope Python environment
are preserved by the normal update/install path. Do not unpack these inputs over a
live project; use the bundled canonical server updater and version switcher.
