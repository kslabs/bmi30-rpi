/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32h7xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32h7xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stdio.h>  /* для printf в диагностике TIM2 IRQ */
#include "lcd.h" // добавлено для вывода на экран при HardFault
#include "adc_stream.h"
#include "usb_vendor_app.h"
#include "ws2812_spi.h"
extern volatile uint32_t systick_heartbeat; // добавлено: глобальный счётчик из main.c
/* Прототип низкоуровневого вывода UART1 из main.c */
extern void uart1_raw_putc(char c);
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
// Переменная для подсчета прерываний SPI2
static volatile uint32_t spi2_interrupt_counter = 0;

// Счётчик вызовов USB ISR для диагностики
volatile uint32_t usb_isr_counter = 0;

// Диагностика HardFault (определения)
volatile uint32_t hardfault_r0=0, hardfault_r1=0, hardfault_r2=0, hardfault_r3=0;
volatile uint32_t hardfault_r12=0, hardfault_lr=0, hardfault_pc=0, hardfault_psr=0;
volatile uint32_t hardfault_cfsr=0, hardfault_hfsr=0, hardfault_bfar=0, hardfault_mmfar=0; // добавлено
volatile uint32_t hardfault_active = 0; // 1 когда данные заполнены
// Прототип обработчика захвата стека
void HardFault_Capture(uint32_t *stack_addr);
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

#ifndef SYNC_ACTIONS_ENABLE
#define SYNC_ACTIONS_ENABLE 0u
#endif

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern PCD_HandleTypeDef hpcd_USB_OTG_HS;
extern DMA_HandleTypeDef hdma_adc1;
extern DMA_HandleTypeDef hdma_adc2;
extern DMA_HandleTypeDef hdma_spi3_tx;
extern DAC_HandleTypeDef hdac1;
extern SPI_HandleTypeDef hspi3;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim6;
extern TIM_HandleTypeDef htim15;
extern TIM_HandleTypeDef htim16;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern void rs485_usart2_irq_rx_service(void);
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */
  __asm volatile(
    "tst lr, #4            \n"
    "ite eq                \n"
    "mrseq r0, msp         \n"
    "mrsne r0, psp         \n"
    "b HardFault_Capture   \n"
  );
  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/* TIM16 IRQHandler removed - now using TIM5 (32-bit) instead */

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */
  extern volatile uint32_t systick_heartbeat; // локальное extern для совместимости
  systick_heartbeat++; // инкремент счётчика
  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32H7xx Peripheral Interrupt Handlers                                    */
/**
  * @brief This function handles USART1 global interrupt.
  */
void USART1_IRQHandler(void)
{
  /* USER CODE BEGIN USART1_IRQn 0 */
  /* USER CODE END USART1_IRQn 0 */
  HAL_UART_IRQHandler(&huart1);
  /* USER CODE BEGIN USART1_IRQn 1 */
  /* USER CODE END USART1_IRQn 1 */
}

/**
  * @brief This function handles USART2 global interrupt.
  */
__attribute__((optimize("O2"))) void USART2_IRQHandler(void)
{
  uint32_t isr = huart2.Instance->ISR;

  if ((isr & (USART_ISR_PE | USART_ISR_FE | USART_ISR_NE | USART_ISR_ORE | USART_ISR_RXNE_RXFNE)) != 0u) {
    rs485_usart2_irq_rx_service();
    isr = huart2.Instance->ISR;
  }

  if (((isr & USART_ISR_TC) != 0u) &&
      ((huart2.Instance->CR1 & USART_CR1_TCIE) != 0u)) {
    huart2.Instance->ICR = USART_ICR_TCCF;
    HAL_UART_TxCpltCallback(&huart2);
  }
}
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32h7xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles DMA1 stream0 global interrupt.
  */
extern volatile uint32_t g_rs485_irq_timing[8];

static inline __attribute__((always_inline)) void rs485_note_adc_irq_end(uint32_t started)
{
  uint32_t ended = DWT->CYCCNT;
  uint32_t elapsed = ended - started;
  g_rs485_irq_timing[0] = started;
  g_rs485_irq_timing[1] = ended;
  g_rs485_irq_timing[2] = elapsed;
  if (elapsed > g_rs485_irq_timing[3]) g_rs485_irq_timing[3] = elapsed;
  g_rs485_irq_timing[4] = USART2->ISR;
}

__attribute__((optimize("O2"))) void DMA1_Stream0_IRQHandler(void)
{
  uint32_t started = DWT->CYCCNT;
  /* USER CODE BEGIN DMA1_Stream0_IRQn 0 */
  /* minimized: no UART in IRQ */
  /* USER CODE END DMA1_Stream0_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_adc1);
  rs485_note_adc_irq_end(started);
  /* USER CODE BEGIN DMA1_Stream0_IRQn 1 */

  /* USER CODE END DMA1_Stream0_IRQn 1 */
}

/**
  * @brief This function handles DMA1 stream1 global interrupt.
  */
__attribute__((optimize("O2"))) void DMA1_Stream1_IRQHandler(void)
{
  uint32_t started = DWT->CYCCNT;
  /* USER CODE BEGIN DMA1_Stream1_IRQn 0 */
  /* minimized: no UART in IRQ */
  /* USER CODE END DMA1_Stream1_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_adc2);
  rs485_note_adc_irq_end(started);
  /* USER CODE BEGIN DMA1_Stream1_IRQn 1 */

  /* USER CODE END DMA1_Stream1_IRQn 1 */
}

/**
  * @brief This function handles DMA1 stream7 global interrupt.
  */
void DMA1_Stream7_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Stream7_IRQn 0 */
  ws2812_spi_dma_irq_trace();
  /* USER CODE END DMA1_Stream7_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_spi3_tx);
  /* USER CODE BEGIN DMA1_Stream7_IRQn 1 */

  /* USER CODE END DMA1_Stream7_IRQn 1 */
}

/**
  * @brief This function handles SPI3 global interrupt.
  */
void SPI3_IRQHandler(void)
{
  /* USER CODE BEGIN SPI3_IRQn 0 */
  ws2812_spi_spi_irq_trace();
  /* USER CODE END SPI3_IRQn 0 */
  HAL_SPI_IRQHandler(&hspi3);
  /* USER CODE BEGIN SPI3_IRQn 1 */

  /* USER CODE END SPI3_IRQn 1 */
}

/**
  * @brief This function handles EXTI line0 interrupt.
  */
void EXTI0_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI0_IRQn 0 */

  /* USER CODE END EXTI0_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(OPTIC_RX_Pin);
  /* USER CODE BEGIN EXTI0_IRQn 1 */

  /* USER CODE END EXTI0_IRQn 1 */
}

/**
  * @brief This function handles TIM2 global interrupt.
  */
void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */
  static uint8_t first_irq = 1;
  if (first_irq) {
    printf("[TIM2][IRQ] FIRST IRQ! SR=0x%08lX CNT=%lu\r\n", 
           (unsigned long)TIM2->SR, (unsigned long)TIM2->CNT);
    first_irq = 0;
  }
  /* USER CODE END TIM2_IRQn 0 */
  HAL_TIM_IRQHandler(&htim2);
  /* USER CODE BEGIN TIM2_IRQn 1 */

  /* USER CODE END TIM2_IRQn 1 */
}

/**
  * @brief This function handles TIM6 global interrupt, DAC1_CH1 and DAC1_CH2 underrun error interrupts.
  */
void TIM6_DAC_IRQHandler(void)
{
  /* USER CODE BEGIN TIM6_DAC_IRQn 0 */
  /* minimized: no UART in IRQ */
  /* USER CODE END TIM6_DAC_IRQn 0 */
  HAL_DAC_IRQHandler(&hdac1);
  HAL_TIM_IRQHandler(&htim6);
  /* USER CODE BEGIN TIM6_DAC_IRQn 1 */

  /* USER CODE END TIM6_DAC_IRQn 1 */
}

/**
  * @brief This function handles TIM15 global interrupt.
  */
__attribute__((optimize("O2"))) void TIM15_IRQHandler(void)
{
  uint32_t started = DWT->CYCCNT;
  /* USER CODE BEGIN TIM15_IRQn 0 */

  /* USER CODE END TIM15_IRQn 0 */
  HAL_TIM_IRQHandler(&htim15);
  uint32_t ended = DWT->CYCCNT;
  uint32_t elapsed = ended - started;
  g_rs485_irq_timing[5] = ended;
  g_rs485_irq_timing[6] = elapsed;
  if (elapsed > g_rs485_irq_timing[7]) g_rs485_irq_timing[7] = elapsed;
  /* USER CODE BEGIN TIM15_IRQn 1 */

  /* USER CODE END TIM15_IRQn 1 */
}

/**
  * @brief This function handles USB On The Go HS global interrupt.
  */
void OTG_HS_IRQHandler(void)
{
  /* USER CODE BEGIN OTG_HS_IRQn 0 */
  /* Счётчик вызовов ISR для диагностики */
  usb_isr_counter++;
  /* USER CODE END OTG_HS_IRQn 0 */
  HAL_PCD_IRQHandler(&hpcd_USB_OTG_HS);
  /* USER CODE BEGIN OTG_HS_IRQn 1 */

  /* USER CODE END OTG_HS_IRQn 1 */
}

/* USER CODE BEGIN 1 */
#ifndef HARDFAULT_VERBOSE_PRINTF
#define HARDFAULT_VERBOSE_PRINTF 0u
#endif

static void hf_delay(volatile uint32_t cycles)
{
  while(cycles-- != 0u){ __NOP(); }
}

static uint32_t hf_pin_shift(uint32_t pin)
{
  uint32_t shift = 0u;
  while(((pin >> shift) & 1u) == 0u && shift < 16u){ shift++; }
  return shift * 2u;
}

static void hf_gpio_output(GPIO_TypeDef *port, uint32_t pin)
{
  uint32_t shift = hf_pin_shift(pin);
  port->MODER = (port->MODER & ~(3u << shift)) | (1u << shift);
  port->OTYPER &= ~pin;
  port->OSPEEDR = (port->OSPEEDR & ~(3u << shift)) | (2u << shift);
  port->PUPDR &= ~(3u << shift);
}

static void hf_fault_indicator_init(void)
{
#if defined(RCC_AHB4ENR_GPIOEEN)
  RCC->AHB4ENR |= RCC_AHB4ENR_GPIOEEN;
  (void)RCC->AHB4ENR;
#else
  __HAL_RCC_GPIOE_CLK_ENABLE();
#endif
  hf_gpio_output(Led_Test_GPIO_Port, Led_Test_Pin);
  hf_gpio_output(LCD_Led_GPIO_Port, LCD_Led_Pin);
}

static void hf_fault_indicator_set(uint8_t on)
{
  if(on != 0u){
    Led_Test_GPIO_Port->BSRR = Led_Test_Pin;
    LCD_Led_GPIO_Port->BSRR = (uint32_t)LCD_Led_Pin << 16; /* active-low backlight */
  } else {
    Led_Test_GPIO_Port->BSRR = (uint32_t)Led_Test_Pin << 16;
    LCD_Led_GPIO_Port->BSRR = LCD_Led_Pin;
  }
}

static void hf_fault_blink_forever(void) __attribute__((noreturn));
static void hf_fault_blink_forever(void)
{
  __disable_irq();
  hf_fault_indicator_init();
  for(;;){
    hf_fault_indicator_set(1u);
    hf_delay(12000000u);
    hf_fault_indicator_set(0u);
    hf_delay(12000000u);
  }
}

// Вспомогательная функция форматирования 32-битного значения в HEX (8 символов)
static void hf_hex(char *dst, uint32_t v){
    static const char *hx = "0123456789ABCDEF";
    for(int i=0;i<8;i++){ dst[7-i] = hx[v & 0xF]; v >>= 4; }
    dst[8] = 0;
}

static void hf_raw_puts(const char *s)
{
  while(*s != 0){ uart1_raw_putc(*s++); }
}

static void hf_raw_hex_line(const char *label, uint32_t val)
{
  char hex[9];
  hf_hex(hex, val);
  hf_raw_puts(label);
  hf_raw_puts(":");
  hf_raw_puts(hex);
  hf_raw_puts("\r\n");
}

// Печать регистра на заданной строке: label + ':' + hex
static void hf_print_line(uint16_t y, const char *label, uint32_t val){
    char buf[20];
    char hex[9];
    hf_hex(hex,val);
    // Формат: LBL:XXXXXXXX
    int i=0; while(label[i] && i<5){ buf[i]=label[i]; i++; }
    buf[i++]=':'; for(int j=0;j<8 && i<sizeof(buf)-1;j++) buf[i++]=hex[j];
    buf[i]=0;
    LCD_ShowString_Size(0,y,buf,12,WHITE,BLACK);
}
static void HardFault_Display(void) __attribute__((unused));
static void HardFault_Display(void){
    // очистим область
    LCD_FillRect(0,0,160,80,BLACK);
    LCD_ShowString_Size(0,0,"HARDFAULT",12,RED,BLACK);
    hf_print_line(12,"PC",hardfault_pc);
    hf_print_line(24,"LR",hardfault_lr);
    hf_print_line(36,"CFSR",hardfault_cfsr);
    hf_print_line(48,"BFAR",hardfault_bfar);
    hf_print_line(60,"HFSR",hardfault_hfsr);
}
// Реализация захвата контекста HardFault
void HardFault_Capture(uint32_t *stack_addr)
{
  hf_fault_indicator_init();
  hf_fault_indicator_set(1u);

  hardfault_r0  = stack_addr[0];
  hardfault_r1  = stack_addr[1];
  hardfault_r2  = stack_addr[2];
  hardfault_r3  = stack_addr[3];
  hardfault_r12 = stack_addr[4];
  hardfault_lr  = stack_addr[5];
  hardfault_pc  = stack_addr[6];
  hardfault_psr = stack_addr[7];
  // Чтение системных регистров Fault
  hardfault_cfsr = SCB->CFSR;
  hardfault_hfsr = SCB->HFSR;
  hardfault_bfar = SCB->BFAR;
  hardfault_mmfar= SCB->MMFAR;
  /* An ECC-corrupted word in the append-only DC/role journal raises a precise
     BusFault on the first read. Record it in .noinit and reboot immediately;
     the next boot erases only the reserved journal sector. Previously the MCU
     blinked forever here and required a manual second reset. */
  if(vnd_dc_note_flash_fault(hardfault_bfar, hardfault_cfsr) != 0u){
    __DSB();
    NVIC_SystemReset();
  }
  hardfault_active = 1;

  hf_raw_puts("\r\nHARDFAULT\r\n");
  hf_raw_hex_line("PC", hardfault_pc);
  hf_raw_hex_line("LR", hardfault_lr);
  hf_raw_hex_line("CFSR", hardfault_cfsr);
  hf_raw_hex_line("BFAR", hardfault_bfar);
  hf_raw_hex_line("HFSR", hardfault_hfsr);
  hf_raw_puts("LCD backlight blink active\r\n");

#if HARDFAULT_VERBOSE_PRINTF
  // ========== ВЫВОД ДИАГНОСТИКИ В COM4 (USART1) ==========
  // Используем printf который перенаправлен на huart1 в syscalls.c
  printf("\r\n");
  printf("======================================================================\r\n");
  printf("                       *** HARDFAULT EXCEPTION ***\r\n");
  printf("======================================================================\r\n");
  printf("\r\n");
  printf("[STACK REGISTERS]\r\n");
  printf("  R0  = 0x%08lX\r\n", hardfault_r0);
  printf("  R1  = 0x%08lX\r\n", hardfault_r1);
  printf("  R2  = 0x%08lX\r\n", hardfault_r2);
  printf("  R3  = 0x%08lX\r\n", hardfault_r3);
  printf("  R12 = 0x%08lX\r\n", hardfault_r12);
  printf("  LR  = 0x%08lX  (return address)\r\n", hardfault_lr);
  printf("  PC  = 0x%08lX  (fault address)\r\n", hardfault_pc);
  printf("  PSR = 0x%08lX\r\n", hardfault_psr);
  printf("\r\n");
  printf("[FAULT STATUS REGISTERS]\r\n");
  printf("  CFSR  = 0x%08lX  (Configurable Fault Status Register)\r\n", hardfault_cfsr);
  printf("  HFSR  = 0x%08lX  (HardFault Status Register)\r\n", hardfault_hfsr);
  printf("  BFAR  = 0x%08lX  (Bus Fault Address Register)\r\n", hardfault_bfar);
  printf("  MMFAR = 0x%08lX  (MemManage Fault Address Register)\r\n", hardfault_mmfar);
  printf("\r\n");
  
  // Расшифровка CFSR (объединяет MMFSR, BFSR, UFSR)
  printf("[FAULT ANALYSIS]\r\n");
  uint32_t mmfsr = hardfault_cfsr & 0xFF;           // MemManage [7:0]
  uint32_t bfsr  = (hardfault_cfsr >> 8) & 0xFF;    // BusFault [15:8]
  uint32_t ufsr  = (hardfault_cfsr >> 16) & 0xFFFF; // UsageFault [31:16]
  
  if (mmfsr) {
    printf("  MemManage Fault (MMFSR=0x%02lX):\r\n", mmfsr);
    if (mmfsr & 0x01) printf("    - IACCVIOL: Instruction access violation\r\n");
    if (mmfsr & 0x02) printf("    - DACCVIOL: Data access violation\r\n");
    if (mmfsr & 0x08) printf("    - MUNSTKERR: Unstacking error\r\n");
    if (mmfsr & 0x10) printf("    - MSTKERR: Stacking error\r\n");
    if (mmfsr & 0x20) printf("    - MLSPERR: FP lazy state preservation\r\n");
    if (mmfsr & 0x80) printf("    - MMARVALID: MMFAR contains valid address (0x%08lX)\r\n", hardfault_mmfar);
  }
  
  if (bfsr) {
    printf("  Bus Fault (BFSR=0x%02lX):\r\n", bfsr);
    if (bfsr & 0x01) printf("    - IBUSERR: Instruction bus error\r\n");
    if (bfsr & 0x02) printf("    - PRECISERR: Precise data bus error\r\n");
    if (bfsr & 0x04) printf("    - IMPRECISERR: Imprecise data bus error\r\n");
    if (bfsr & 0x08) printf("    - UNSTKERR: Unstacking error\r\n");
    if (bfsr & 0x10) printf("    - STKERR: Stacking error\r\n");
    if (bfsr & 0x20) printf("    - LSPERR: FP lazy state preservation\r\n");
    if (bfsr & 0x80) printf("    - BFARVALID: BFAR contains valid address (0x%08lX)\r\n", hardfault_bfar);
  }
  
  if (ufsr) {
    printf("  Usage Fault (UFSR=0x%04lX):\r\n", ufsr);
    if (ufsr & 0x0001) printf("    - UNDEFINSTR: Undefined instruction\r\n");
    if (ufsr & 0x0002) printf("    - INVSTATE: Invalid state\r\n");
    if (ufsr & 0x0004) printf("    - INVPC: Invalid PC load\r\n");
    if (ufsr & 0x0008) printf("    - NOCP: No coprocessor\r\n");
    if (ufsr & 0x0010) printf("    - STKOF: Stack overflow\r\n");
    if (ufsr & 0x0100) printf("    - UNALIGNED: Unaligned access\r\n");
    if (ufsr & 0x0200) printf("    - DIVBYZERO: Divide by zero\r\n");
  }
  
  if (hardfault_hfsr & 0x40000000) {
    printf("  FORCED: HardFault escalated from configurable fault\r\n");
  }
  if (hardfault_hfsr & 0x80000000) {
    printf("  DEBUGEVT: Debug event\r\n");
  }
  
  printf("\r\n");
  printf("======================================================================\r\n");
  printf("System halted. LED will blink to indicate HardFault state.\r\n");
  printf("======================================================================\r\n");
  printf("\r\n");
#endif

  // Пытаемся вывести на LCD (если инициализирован)
  if(lcd_ready != 0u){
    HardFault_Display();
  }

  hf_fault_blink_forever();
}
/* USER CODE END 1 */
