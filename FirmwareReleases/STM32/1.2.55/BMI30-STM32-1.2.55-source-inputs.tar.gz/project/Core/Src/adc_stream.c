/* Прежде чем использовать типы/API — подключаем необходимые заголовки */
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "main.h"
#include "adc_stream.h"
#include "usb_vendor_app.h"
#include "ws2812_spi.h"
#include "rx_phase_detector.h"

/* Управление логированием этого модуля: по умолчанию выключено, чтобы не спамить из ISR */
#ifndef ADC_LOG_ENABLE
#define ADC_LOG_ENABLE 0
#endif
#if ADC_LOG_ENABLE
#define ADC_LOGF(...)    printf(__VA_ARGS__)
#else
/* Compile-check diagnostics without evaluating arguments or printing in ISR. */
#define ADC_LOGF(...)    do { if (0) { (void)(printf)(__VA_ARGS__); } } while (0)
#endif

/* ВАЖНО: никакого printf в ISR по умолчанию.
    DMA/ADC callbacks должны быть максимально короткими, иначе растёт джиттер и появляются
    «нулевые»/рваные кадры из-за задержек перезапуска DMA в NORMAL mode. */
#ifndef ADC_ISR_LOG_ENABLE
#define ADC_ISR_LOG_ENABLE 0  // Диагностика DMA callbacks отключена
#endif

/* Ранние forward-declare для локальных (в этом модуле) переменных,
   используемых в вспомогательных функциях ниже */
extern ADC_HandleTypeDef* s_adc1;
extern ADC_HandleTypeDef* s_adc2;
extern volatile uint32_t s_next_ring_index;

// Выводит count семплов из последнего доступного кадра в терминал (ch2 — если true, то второй канал)
void adc_stream_print_samples(uint32_t count, bool ch2) {
    ADC_LOGF("Старт вывода семплов\r\n");
    uint32_t seq = frame_wr_seq ? (frame_wr_seq - 1) : 0;
    uint32_t index = seq & (FIFO_FRAMES - 1u);
    #if ADC_USB_STAGE_ENABLE
    uint16_t *buf = ch2 ? adc2_buffers[index] : usb_stage_bufA;
    #else
    uint16_t *buf = ch2 ? adc2_buffers[index] : adc1_buffers[index];
    #endif
    ADC_LOGF("[ADC][SAMPLES] ch%d seq=%lu index=%lu: ", ch2 ? 2 : 1, (unsigned long)seq, (unsigned long)index);
    uint16_t max = adc_stream_get_active_samples();
    for (uint32_t i = 0; i < count && i < max; ++i) {
        ADC_LOGF("%u ", buf[i]);
    }
    ADC_LOGF("\r\n");
}
/* Public legacy hook. Runtime consumers are not allowed to stop acquisition:
   USB STOP/reset only discards pending consumer data. Hardware rearm is owned
   by watchdog/profile change or MCU reset; DBM advances normal frames in hardware. */
void adc_stream_stop(void) {
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    frame_rd_seq = frame_wr_seq;
    adc_ch_rd_seq[0] = adc_ch_wr_seq[0];
    adc_ch_rd_seq[1] = adc_ch_wr_seq[1];
    adc_stream_paused = 0u;
    if (primask == 0u) {
        __enable_irq();
    }
    ADC_LOGF("[ADC][STOP] ignored: continuous acquisition remains active\r\n");
}

// Debug: DMA event counters

#include <string.h>

/* Диагностический флаг: отключить фактический запуск DMA для проверки, что зависание
    основного цикла вызвано штормом прерываний DMA (IRQ 11 = DMA1_Stream0). */
#ifndef DIAG_DISABLE_ADC_DMA
#define DIAG_DISABLE_ADC_DMA 0   /* включаем DMA, чтобы публиковать кадры */
#endif

/* Запускать только ADC1 (вторая DMA не стартует) — 0 = использовать оба АЦП.
    Для нормальной работы нужно 0; установить 1 только при диагностике. */
#ifndef DIAG_SINGLE_ADC1
#define DIAG_SINGLE_ADC1 0  /* Норма: используем оба АЦП, чтобы не замедлять поток */
#endif

/* Включить промежуточный буфер для USB (staging) чтобы исключить гонку DMA↔USB */
#ifndef ADC_USB_STAGE_ENABLE
#define ADC_USB_STAGE_ENABLE 0  // DISABLED: memcpy + CRC + flush @ 200Hz = massive overhead (1.92 MB/sec copy + CRC calculation)
#endif

/* Диагностический режим: выключить ADC/DMA и публиковать статический staging с маркерами */
#ifndef DIAG_STATIC_STAGE_MODE
#define DIAG_STATIC_STAGE_MODE 0
#endif

/* Диагностический лимит количества half/full callback (для отлова runaway).
    0 = отключено (не останавливать DMA). При необходимости теста задать >0. */
#ifndef DIAG_DMA_CALLBACK_LIMIT
#define DIAG_DMA_CALLBACK_LIMIT 0u
#endif

/* Сокращение IRQ: не обрабатывать Half-Complete для ADC1 (добавлять кадры только по Full).
    1 = включено (уменьшить IRQ ADC1 в 2 раза), 0 = учитывать half + full как раньше. */
#ifndef ADC1_DISABLE_HALF_IRQ
#define ADC1_DISABLE_HALF_IRQ 1
#endif

/* Сокращение IRQ: отключить прерывания HT/TC у DMA потока ADC2 целиком, DMA продолжается.
    1 = выключить IRQ ADC2, 0 = оставить как есть.
   ВАЖНО: для корректной синхронизации пар A/B оставляем IRQ ВКЛЮЧЕННЫМИ (0). */
#ifndef ADC2_DISABLE_DMA_IRQS
#define ADC2_DISABLE_DMA_IRQS 0  /* ВКЛЮЧАЕМ IRQ ADC2: оба TC используются для синхронизации завершения кадра */
#endif

/* Диагностика DMA буфера: проверка первых 10 значений после TC callback */
typedef struct {
    uint32_t callback_num;
    char channel;  // 'A' or 'B'
    uint32_t zeros;
    uint32_t nonzeros;
    uint16_t vmin;
    uint16_t vmax;
    uint16_t first10[10];
} adc_dma_diag_t;

volatile adc_dma_diag_t g_adc_dma_diag_a = {0};
volatile adc_dma_diag_t g_adc_dma_diag_b = {0};

/* Включить крайне редкий вывод первых 8 значений из буфера ADC2 прямо в ISR ADC1.
    ВНИМАНИЕ: Любой printf в ISR может привести к стопору потока, поэтому по умолчанию ВЫКЛ. */
#ifndef ADC2_DBG_FIRST8
#define ADC2_DBG_FIRST8 0  /* печать в ISR отключена для стабильности */
#endif

// Глобальный флаг готовности данных (используется вместо frame_wr_seq в TC-driven режиме)
volatile uint32_t adc_data_ready_flag = 0;

static volatile uint32_t dbg_dma1_half_count = 0, dbg_dma1_full_count = 0;
extern DMA_HandleTypeDef hdma_adc1; /* из auto-generated кода */
extern DMA_HandleTypeDef hdma_adc2;

/* Диагностический дамп регистров B-пути (DMA/ADC/TIM) для расследования застойных ситуаций ADC2 */
static void dump_b_path_regs(uint32_t ndtrA, uint32_t ndtrB)
{
    DMA_Stream_TypeDef *dma1_stream = (DMA_Stream_TypeDef*)hdma_adc1.Instance;
    DMA_Stream_TypeDef *dma2_stream = (DMA_Stream_TypeDef*)hdma_adc2.Instance;
    /* DMA */
    ADC_LOGF("[ADC][WDDBG] DMA1_S0: CR=0x%08lX NDTR=%lu M0AR=0x%08lX FCR=0x%08lX | DMA1_S1: CR=0x%08lX NDTR=%lu M0AR=0x%08lX FCR=0x%08lX\r\n",
        (unsigned long)dma1_stream->CR, (unsigned long)ndtrA, (unsigned long)dma1_stream->M0AR, (unsigned long)dma1_stream->FCR,
        (unsigned long)dma2_stream->CR, (unsigned long)ndtrB, (unsigned long)dma2_stream->M0AR, (unsigned long)dma2_stream->FCR);
    /* ADC2 ключевые регистры */
    ADC_LOGF("[ADC][WDDBG] ADC2: CR=0x%08lX CFGR=0x%08lX ISR=0x%08lX\r\n",
        (unsigned long)ADC2->CR, (unsigned long)ADC2->CFGR, (unsigned long)ADC2->ISR);
    /* TIM15 (источник TRGO) */
    ADC_LOGF("[ADC][WDDBG] TIM15: CR1=0x%08lX CR2=0x%08lX SMCR=0x%08lX SR=0x%08lX CNT=%lu PSC=%lu ARR=%lu\r\n",
        (unsigned long)TIM15->CR1, (unsigned long)TIM15->CR2, (unsigned long)TIM15->SMCR,
        (unsigned long)TIM15->SR, (unsigned long)TIM15->CNT, (unsigned long)TIM15->PSC, (unsigned long)TIM15->ARR);
}

// --- Профили ---
static const adc_stream_profile_t g_profiles[ADC_PROFILE_COUNT] = {
    { .samples_per_buf = 600, .buf_rate_hz = 400, .fs_hz = 240000u }, // 0: 600 samples @ 200Hz, fs=120kHz (DEFAULT & FIXED)
    { .samples_per_buf = 600, .buf_rate_hz = 300, .fs_hz = 240000u }, // 1: Overridden to 600
    { .samples_per_buf = 600, .buf_rate_hz = 300, .fs_hz = 240000u }, // 2: Overridden to 600
    { .samples_per_buf = 600, .buf_rate_hz = 300, .fs_hz = 240000u }, // 3: Overridden to 600
    { .samples_per_buf = 600, .buf_rate_hz = 400, .fs_hz = 240000u }, // 4: Overridden to 600
};
static uint8_t g_active_profile = 0;  // Default profile 0
static uint16_t g_active_samples = 600; // runtime N для GATED mode

// --- DMA buffers ---
// ВАЖНО: ранее использовалась схема "guard words вокруг полезных данных" через каст
// указателя на 2D-массив с ДРУГИМ шагом строки. Это ломало адресацию: adc*_buffers[idx]
// указывали не на тот буфер (stride mismatch), что приводило к "нули", артефактам и сбоям.
// Для стабильности используем корректно размеченные 2D массивы с шагом ровно MAX_FRAME_SAMPLES.
__attribute__((aligned(32))) static uint16_t s_adc1_storage[FIFO_FRAMES][MAX_FRAME_SAMPLES];
__attribute__((aligned(32))) static uint16_t s_adc2_storage[FIFO_FRAMES][MAX_FRAME_SAMPLES];
uint16_t (*adc1_buffers)[MAX_FRAME_SAMPLES] = s_adc1_storage;
uint16_t (*adc2_buffers)[MAX_FRAME_SAMPLES] = s_adc2_storage;

// TEMPORARILY DISABLED for performance testing (guard check overhead: 19200 ops/sec)
#if 0
static uint8_t adc_check_guard_idx(uint32_t idx, const char *phase) {
    bool bad = false;
    static uint32_t guard_log_last_ms = 0;
    static uint32_t guard_log_budget = 0;
    uint32_t now_ms = HAL_GetTick();
    if (now_ms - guard_log_last_ms >= 1000U) {
        guard_log_last_ms = now_ms;
        guard_log_budget = 6; /* макс 6 логов в секунду, чтобы не душить UART */
    }
    for (uint32_t i = 0; i < ADC_GUARD_WORDS; ++i) {
        if (adc_guard_pre(adc1_raw, idx)[i] != adc_guard_pattern(idx, i) ||
            adc_guard_post(adc1_raw, idx)[i] != adc_guard_pattern(idx, ADC_GUARD_WORDS + i)) {
            bad = true;
        }
        if (adc_guard_pre(adc2_raw, idx)[i] != adc_guard_pattern(idx, 0x20u + i) ||
            adc_guard_post(adc2_raw, idx)[i] != adc_guard_pattern(idx, 0x20u + ADC_GUARD_WORDS + i)) {
            bad = true;
        }
    }
    if (bad) {
        adc_guard_bad[idx] = 1;
        if (guard_log_budget == 0) {
            adc_fill_guard_for_idx(idx);
            return 1u; /* лимит логов на этот интервал исчерпан */
        }
        guard_log_budget--;
        /* Логируем соседние данные для анализа смещения/переписывания */
        uint16_t *a = adc1_buffers[idx];
        uint16_t *b = adc2_buffers[idx];
        uint16_t a0=a[0], a1=a[1], a2=a[2], a3=a[3];
        uint16_t b0=b[0], b1=b[1], b2=b[2], b3=b[3];
        uint16_t a_last3=0, a_last2=0, a_last1=0, a_last0=0;
        uint16_t b_last3=0, b_last2=0, b_last1=0, b_last0=0;
        if(g_active_samples >= 4){
            uint32_t last = (uint32_t)g_active_samples;
            a_last3 = a[last-4]; a_last2 = a[last-3]; a_last1 = a[last-2]; a_last0 = a[last-1];
            b_last3 = b[last-4]; b_last2 = b[last-3]; b_last1 = b[last-2]; b_last0 = b[last-1];
        }
        // ОТКЛЮЧЕНО: избыточный UART вывод тормозит USB @ 200Hz
        // printf("[ADC_WARN] DMA guard mismatch idx=%lu phase=%s preA=%04x postA=%04x preB=%04x postB=%04x...\r\n", ...);
        // dump_b_path_regs(...);
        adc_fill_guard_for_idx(idx); // восстановить паттерн, чтобы последующие проверки были валидны
        return 1u;
    }
    adc_guard_bad[idx] = 0;
    return 0u;
}
#endif

// Убраны тестовые переменные - используем только реальный ADC+DMA

volatile uint32_t frame_wr_seq = 0;      // сколько кадров записано (ISR)
volatile uint32_t frame_rd_seq = 0;      // сколько кадров прочитано потребителем
volatile uint32_t frame_overflow_drops = 0; // отброшено при переполнении
volatile uint32_t frame_sent_seq = 0;    // успешно отправлено по USB (увеличивается вызывающим кодом)
volatile uint32_t frame_backlog_max = 0; // максимальный (wr-rd)
volatile uint32_t adc_last_full0_ms = 0; // время последнего полного DMA ADC1
volatile uint32_t adc_last_full1_ms = 0; // время последнего полного DMA ADC2
// Новые метрики публикации и перезапусков (v4 debug)
volatile uint32_t adc_publish_count = 0;      // число инкрементов frame_wr_seq (парных публикаций)
volatile uint32_t adc_last_publish_ms = 0;     // метка времени последней публикации пары
volatile uint32_t adc_publish_gap_max_ms = 0;  // максимальная пауза между публикациями
volatile uint32_t adc_publish_gap_over_10ms = 0; // паузы публикации больше 10 ms
volatile uint32_t adc_restart_attempts = 0;    // суммарные попытки перезапуска через внешний вотчдог
volatile uint32_t adc_restart_success = 0;     // перезапуски, после которых реально опубликован новый кадр
static volatile uint32_t s_adc_restart_suppressed_live = 0;
static volatile uint32_t s_adc_restart_reason = 0;
static volatile uint32_t s_adc_restart_ndtr_a = 0;
static volatile uint32_t s_adc_restart_ndtr_b = 0;
static volatile uint32_t s_adc_restart_publish_age_ms = 0;
static volatile uint32_t s_adc_tc_rearm_failures = 0;
static volatile uint8_t s_adc_dbm_fault_pending = 0u;
/* Explicitly initialized before the first start: .ram_dtcm is NOLOAD. */
__attribute__((section(".ram_dtcm"), aligned(4)))
static volatile uint32_t s_capture_generation;
__attribute__((section(".ram_dtcm")))
static volatile uint8_t s_snapshot_copy_busy;
/* HAL_OK от HAL_ADC_Start_DMA означает только, что DMA был вооружён. Это ещё не
   доказывает наличие триггеров/TC и публикацию пары. Храним отдельную точку
   старта, чтобы watchdog подтверждал восстановление только по новому кадру. */
static volatile uint32_t s_dma_arm_ms = 0;
static volatile uint32_t s_dma_arm_publish_snapshot = 0;
static volatile uint8_t  s_watchdog_recovery_pending = 0;
static volatile uint32_t s_watchdog_recovery_publish_snapshot = 0;
static volatile uint32_t s_watchdog_recovery_started_ms = 0;

// Новые независимые счётчики по каналам (A=0, B=1)
volatile uint32_t adc_ch_wr_seq[2] = {0,0};     // записано буферов (ISR) по каждому каналу
volatile uint32_t adc_ch_rd_seq[2] = {0,0};     // выдано потребителю по каналу
volatile uint32_t adc_ch_overflow_drops[2] = {0,0}; // переполнения по каналу

/* ADC acquisition is continuous. A slow/disconnected USB consumer may lose the
   oldest pending frame, but it must never stop ADC/DMA, the phase marker or
   master SYNC. Kept for ABI/diagnostics; paused is always zero in production. */
volatile uint8_t  adc_stream_paused = 0;
volatile uint32_t adc_stream_pause_events = 0;

// ДИАГНОСТИКА: счётчики нулевых буферов (детектируем проблемы с ADC/триггером)
volatile uint32_t adc_ch_zero_buffers[2] = {0,0}; // количество буферов с нулевым содержимым (по каналу A/B)

/* Диагностика амплитуд: последний минимум/максимум и индекс максимума по кадру (обновляется каждый буфер) */
volatile uint16_t adc_last_min[2] = {0,0};
volatile uint16_t adc_last_max[2] = {0,0};
volatile uint16_t adc_last_max_idx[2] = {0,0};
volatile uint32_t adc_last_max_tick[2] = {0,0};

// Debug: DMA event counters
static volatile uint32_t dma_half0 = 0, dma_full0 = 0, dma_half1 = 0, dma_full1 = 0;
/* Одноразовый дамп первых 8 значений из первого завершенного буфера ADC2 после селективного рестарта.
    Включается флагом из adc_restart_channel_b() и печатается в следующем TC IRQ канала B. */
static volatile uint8_t s_dbg_dump_b_first8_once = 0;

// Current acquisition slot after the most recently published pair (diagnostics).
volatile uint32_t s_next_ring_index = 0; // всегда < FIFO_FRAMES
static volatile uint32_t s_last_started_idx = 0; // индекс буфера, на который запущен DMA сейчас
static volatile uint8_t  s_tc_mask = 0;        // bit0=ADC1 TC seen, bit1=ADC2 TC seen
static volatile uint32_t s_frame_parity_counter = 0;  // Счётчик чётности кадров @ 400Hz (bit0: 0=even, 1=odd)
static volatile uint32_t s_global_buffer_counter = 0; // Глобальный счётчик буферов (инкрементируется при каждом захвате)
static volatile uint8_t  s_buffer_parity[FIFO_FRAMES] = {0};  // Номер буфера % 8 для каждого слота в FIFO
static volatile uint8_t  s_pb8_state = 0;  // Logical sync phase; independent of physical TX polarity
volatile uint32_t s_buffers_since_restart = 0;  // Счётчик буферов после последнего restart (для детерминированного parity, используется в usb_vendor_app.c)
static volatile uint8_t  s_frame_buffer_idx[FIFO_FRAMES] = {0};  // buffer_index (0-7) для каждого ОПУБЛИКОВАННОГО frame

/* Диагностика синхронизации ADC/DMA */
static volatile uint32_t s_adc1_alone = 0;  // ADC1 завершился без ADC2
static volatile uint32_t s_adc2_alone = 0;  // ADC2 завершился без ADC1
static volatile uint32_t s_both_ready = 0;  // Оба ADC завершились синхронно

// DEBUG: trace последних N записей в s_buffer_parity[] (без printf из ISR)
#define DBG_TRACE_SIZE 64
static volatile uint32_t s_dbg_trace_seq[DBG_TRACE_SIZE];      // done_idx
static volatile uint8_t  s_dbg_trace_bufidx[DBG_TRACE_SIZE];   // buffer_index
static volatile uint32_t s_dbg_trace_global[DBG_TRACE_SIZE];   // s_global_buffer_counter
static volatile uint32_t s_dbg_trace_wr_pos = 0;               // write position

ADC_HandleTypeDef* s_adc1 = NULL;
ADC_HandleTypeDef* s_adc2 = NULL;

/* Новый механизм: считаем кадр готовым (frame_wr_seq++) только когда ОДИНАКОВЫЙ индекс
   в кольце завершён у обоих АЦП. Для этого отмечаем готовность по индексам:
   bit0=ADC1 complete, bit1=ADC2 complete. Продвигаем «готовый» индекс строго по порядку. */
static volatile uint8_t s_pair_ready_mask[FIFO_FRAMES];
static volatile uint32_t s_pair_ready_idx = 0; /* следующий индекс, который ждём к публикации */
static const uint8_t READY_MASK_FULL = DIAG_SINGLE_ADC1 ? 0x01u : 0x03u;
// static const uint8_t TC_REQUIRED_MASK = DIAG_SINGLE_ADC1 ? 0x01u : 0x03u;  // UNUSED

/* Stable CPU snapshots decouple readers from the rolling DMA ring. When RPI
   stops consuming, DMA is allowed to overwrite the oldest ring slot; pointers
   returned to the USB task must therefore never refer to that live slot. */
/* CPU-only snapshots: USB packet builders copy from here into their own DMA
   buffers.  Keep these 5.4 KiB in DTCM to leave a real stack reserve in D1. */
__attribute__((section(".ram_dtcm"), aligned(32)))
static uint16_t s_consumer_snapshot[2][MAX_FRAME_SAMPLES];

#if ADC_USB_STAGE_ENABLE
__attribute__((aligned(32))) uint16_t usb_stage_bufA[MAX_FRAME_SAMPLES];
__attribute__((aligned(32))) uint16_t usb_stage_bufB[MAX_FRAME_SAMPLES];
volatile uint16_t adc_stage_crc_a = 0;
volatile uint32_t adc_stage_crc_seq = 0;
#endif

/* Флаг активного статического режима (без реального DMA) */
static uint8_t s_static_stage_mode = 0;

/* Вспомогательная функция: вычислить индекс кольца по адресу M0AR/M1AR */
static inline uint32_t adc_addr_to_index(uint32_t addr, uint16_t buf[FIFO_FRAMES][MAX_FRAME_SAMPLES])
{
    uint32_t base = (uint32_t)&buf[0][0];
    uint32_t stride = (uint32_t)(MAX_FRAME_SAMPLES * sizeof(uint16_t));
    if(addr < base) return 0;
    uint32_t diff = addr - base;
    return (diff / stride) & (FIFO_FRAMES - 1u);
}

#ifndef ADC_MARKER_PA3_ENABLE
#define ADC_MARKER_PA3_ENABLE 1
#endif

#ifndef ADC_MARKER_PA3_DIV
#define ADC_MARKER_PA3_DIV 1u
#endif

#define ADC_MARKER_PORT_A GPIOA
#define ADC_MARKER_PIN_A  GPIO_PIN_2
#define ADC_MARKER_PORT_C GPIOC
#define ADC_MARKER_PIN_C  GPIO_PIN_7
#define ADC_TX_GATE_PORT  GPIOA
#define ADC_TX_GATE_PIN   GPIO_PIN_1

/* bit0 = TX1 (active-low PA1), bit1 = TX2 (active-high PA2).
   Zero preserves the existing waveform on every pin. PC7 remains the marker.
   Requests never write GPIO; only the regular marker boundary latches them. */
static volatile uint8_t s_tx_phase_requested_mask = 0u;
static volatile uint8_t s_tx_phase_applied_mask = 0u;

static inline void adc_marker_set_level_b(uint8_t level_high)
{
    ADC_MARKER_PORT_C->BSRR = level_high ? (uint32_t)ADC_MARKER_PIN_C : ((uint32_t)ADC_MARKER_PIN_C << 16);
}

static inline uint8_t adc_marker_output_allowed(void)
{
    extern uint8_t vnd_is_tx_enabled(void);
    return (uint8_t)(vnd_is_tx_enabled() ? 1u : 0u);
}

static inline __attribute__((always_inline)) uint8_t adc_marker_get_level(void)
{
    return (uint8_t)(s_pb8_state & 1u);
}

static inline void adc_marker_write_outputs(uint8_t level_high)
{
    uint8_t output_allowed = adc_marker_output_allowed();
    uint8_t phases = s_tx_phase_applied_mask;
    uint8_t tx1_active = (uint8_t)(output_allowed && (level_high ^ (phases & 1u)));
    uint8_t tx2_active = (uint8_t)(output_allowed && (level_high ^ ((phases >> 1) & 1u)));
    uint8_t marker_high = (uint8_t)(output_allowed && level_high);

    /* Update the two TX pins in one atomic port write. Disable always clamps
       PA1 HIGH and PA2 LOW, regardless of phase. PC7 keeps its old waveform. */
    ADC_MARKER_PORT_A->BSRR =
        (tx1_active ? ((uint32_t)ADC_TX_GATE_PIN << 16) : (uint32_t)ADC_TX_GATE_PIN) |
        (tx2_active ? (uint32_t)ADC_MARKER_PIN_A : ((uint32_t)ADC_MARKER_PIN_A << 16));
    adc_marker_set_level_b(marker_high);
}

static inline void adc_marker_set_level(uint8_t level_high)
{
    /* RS485, ADC parity and the LED timing all continue to use this one
       logical phase. Per-channel polarity exists only in the GPIO writer. */
    s_pb8_state = (uint8_t)(level_high ? 1u : 0u);
    adc_marker_write_outputs(s_pb8_state);
}

static inline void adc_marker_pa3_toggle(void)
{
#if ADC_MARKER_PA3_ENABLE
    static uint32_t pa3_divider = 0;

    pa3_divider++;
    if (pa3_divider >= ADC_MARKER_PA3_DIV) {
        pa3_divider = 0;
        /* Apply host polarity only at this existing 400 Hz boundary. */
        s_tx_phase_applied_mask = s_tx_phase_requested_mask;
        uint8_t next_level_high = (uint8_t)(adc_marker_get_level() ? 0u : 1u);
        adc_marker_set_level(next_level_high);
    }
#endif
}

/* ADC parity follows logical sync, never the independently inverted TX pins. */
static inline uint8_t adc_parity_from_pa3(void)
{
    uint8_t marker_level = adc_marker_get_level();
    return (uint8_t)((marker_level ^ 1u) & 1u);
}

uint8_t __attribute__((optimize("O2"))) adc_stream_get_marker_level(void)
{
    return adc_marker_get_level();
}

void adc_stream_refresh_marker_output(void)
{
    /* A DMA interrupt between reading the phase and writing GPIO could replay
       an old half-cycle. Refresh is physical-only and preserves IRQ state. */
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    adc_marker_write_outputs(adc_marker_get_level());
    __set_PRIMASK(primask);
}

uint8_t adc_stream_set_tx_phase(uint8_t channel, uint8_t phase)
{
    if(channel < 1u || channel > 2u || phase > 1u) return 0u;
    uint8_t bit = (uint8_t)(1u << (channel - 1u));
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    s_tx_phase_requested_mask = (uint8_t)((s_tx_phase_requested_mask & ~bit) |
                                          (phase ? bit : 0u));
    __set_PRIMASK(primask);
    return 1u;
}

void adc_stream_get_tx_phase_masks(uint8_t *requested, uint8_t *applied)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    *requested = s_tx_phase_requested_mask;
    *applied = s_tx_phase_applied_mask;
    __set_PRIMASK(primask);
}

static void adc_stream_reset_capture_phase_state(void)
{
    s_frame_parity_counter = 0u;
    s_global_buffer_counter = 0u;
    s_buffers_since_restart = 0u;
    s_last_started_idx = 0u;
    s_tc_mask = 0u;
    s_adc_dbm_fault_pending = 0u;
    memset((void*)s_buffer_parity, 0, sizeof(s_buffer_parity));
    memset((void*)s_frame_buffer_idx, 0, sizeof(s_frame_buffer_idx));
    adc_marker_set_level(0u);
}

void adc_stream_invert_phase_polarity(void)
{
    __disable_irq();

#if ADC_MARKER_PA3_ENABLE
    /* Жёстко инвертируем именно физический маркер; s_pb8_state обновится внутри set_level(). */
    uint8_t next_level_high = (uint8_t)(adc_marker_get_level() ? 0u : 1u);
    adc_marker_set_level(next_level_high);
#else
    s_pb8_state ^= 1u;
#endif

    __enable_irq();
}

extern volatile uint32_t sync_tim5_cnt_at_buffer;
extern volatile uint32_t sync_tim5_buffer_phase_seq;

static inline void adc_trim_reader_backlog(volatile uint32_t *rd_seq,
                                           uint32_t wr_seq,
                                           volatile uint32_t *drop_counter)
{
    /* Hardware DBM owns the current and prearmed next slot even while CPU
       IRQs are masked for a consumer snapshot. Keep both outside the FIFO. */
    const uint32_t max_pending = (FIFO_FRAMES > 2u) ? (FIFO_FRAMES - 2u) : 0u;
    uint32_t pending = wr_seq - *rd_seq;

    if (pending > max_pending) {
        uint32_t drop = pending - max_pending;
        *rd_seq += drop;
        *drop_counter += drop;
    }
}

/* Отметить готовность канала и, если пара на очередном индексе готова, опубликовать её */
/* Bound the software marker latency even in the otherwise -O0 debug build. */
__attribute__((optimize("O2"))) static inline void adc_mark_ready_and_publish(uint8_t ch_bit)
{
    extern TIM_HandleTypeDef htim5;
    extern volatile uint32_t adc_stream_total_buffer_count;
    /* Попробуем публиковать подряд готовые пары (в правильном порядке) */
    while (s_pair_ready_mask[s_pair_ready_idx] == READY_MASK_FULL) {
        /* Очередная пара полностью готова */
        s_pair_ready_mask[s_pair_ready_idx] = 0;
        
        // ВАЖНО: Сохраняем buffer_index ДЛЯ ТЕКУЩЕГО frame_wr_seq (до инкремента)
        uint32_t frame_idx = frame_wr_seq % FIFO_FRAMES;
        uint8_t buffer_index = s_buffer_parity[s_pair_ready_idx] & 0x07;
        s_frame_buffer_idx[frame_idx] = buffer_index;
        
        s_pair_ready_idx = (s_pair_ready_idx + 1u) & (FIFO_FRAMES - 1u);
        /* публикуем + уведомляем верхний уровень */
        uint32_t publish_now_ms = HAL_GetTick();
        uint32_t previous_publish_ms = adc_last_publish_ms;
        if(previous_publish_ms != 0u){
            uint32_t publish_gap_ms = publish_now_ms - previous_publish_ms;
            if(publish_gap_ms > adc_publish_gap_max_ms){
                adc_publish_gap_max_ms = publish_gap_ms;
            }
            if(publish_gap_ms > 10u){
                adc_publish_gap_over_10ms++;
            }
        }
        frame_wr_seq += 1u;
        adc_publish_count++;
        adc_last_publish_ms = publish_now_ms;
        sync_tim5_cnt_at_buffer = htim5.Instance->CNT;
        sync_tim5_buffer_phase_seq++;
        uint32_t phase_start_cycles = DWT->CYCCNT;
        adc_marker_pa3_toggle();
        /* Жёсткая привязка sync к моменту смены маркера: запускаем сразу после toggle,
           а не позже из общего DMA callback, где набегает программный джиттер. */
        adc_stream_total_buffer_count++;
        rs485_sync_on_buffer_complete(adc_parity_from_pa3());
        /* LED color encoding/cache maintenance has variable cost. It must
           follow the timing marker and RS485 boundary, never shift them. */
        ws2812_spi_prepare_phase_frame();
        /* LED DMA is phase-locked to the same edge as TX/sync. Its driver
           rejects a late start, so SPI activity cannot enter the final two
           thirds of the half-period. */
        ws2812_spi_on_phase_start(phase_start_cycles);
        uint32_t backlog = frame_wr_seq - frame_rd_seq;
        if (backlog > frame_backlog_max) frame_backlog_max = backlog;
        /* Continuous acquisition: reserve both DMA banks by discarding only the
           oldest unread USB frame. Never pause ADC because the host is slow. */
        adc_trim_reader_backlog(&frame_rd_seq, frame_wr_seq, &frame_overflow_drops);
        adc_trim_reader_backlog(&adc_ch_rd_seq[0], adc_ch_wr_seq[0],
                                &adc_ch_overflow_drops[0]);
#if !DIAG_SINGLE_ADC1
        adc_trim_reader_backlog(&adc_ch_rd_seq[1], adc_ch_wr_seq[1],
                                &adc_ch_overflow_drops[1]);
#endif
        adc_stream_paused = 0u;
        adc_stream_on_new_frames(1u);
    }
    (void)ch_bit; /* параметр оставлен на будущее для расширенной диагностики */
}

/* Быстрый проход по буферу для min/max и индекса максимума */
static inline void adc_scan_minmax(const uint16_t *buf, uint16_t samples, uint16_t *out_min, uint16_t *out_max, uint16_t *out_max_idx)
{
    uint16_t vmin = 0xFFFFu; uint16_t vmax = 0; uint16_t imax = 0;
    for(uint16_t i=0;i<samples;i++){
        uint16_t v = buf[i];
        if(v < vmin) vmin = v;
        if(v > vmax){ vmax = v; imax = i; }
    }
    *out_min = vmin; *out_max = vmax; *out_max_idx = imax;
}

/* Инвалидация D-Cache для буфера DMA (STM32H7: адрес и длина должны быть кратны 32 байтам) */
static inline void adc_invalidate_cache_for_buffer(void *buf, uint32_t samples)
{
#ifndef ADC_DMA_CACHE_MAINT_ENABLE
#define ADC_DMA_CACHE_MAINT_ENABLE 1
#endif
#if ADC_DMA_CACHE_MAINT_ENABLE
#if defined (SCB_InvalidateDCache_by_Addr)
    if (!buf || samples == 0) return;
    uintptr_t addr = (uintptr_t)buf;
    uintptr_t start = addr & ~(uintptr_t)31u; /* выравнивание вниз до 32 байт */
    uint32_t bytes = samples * (uint32_t)sizeof(uint16_t);
    uint32_t extra = (uint32_t)(addr - start);
    uint32_t total = bytes + extra;
    uint32_t total_aligned = (total + 31u) & ~31u; /* кратность 32 */
    SCB_InvalidateDCache_by_Addr((uint32_t*)start, (int32_t)total_aligned);
#else
    (void)buf; (void)samples;
#endif
#else
    (void)buf; (void)samples;
#endif
}

void adc_stream_print_sample95_all_buffers(void)
{
    const uint16_t probe_idx = 95u;
    uint16_t ns = adc_stream_get_active_samples();
    if (ns <= probe_idx) {
        ADC_LOGF("[S95] skip: active_samples=%u (need >=%u)\r\n", (unsigned)ns, (unsigned)(probe_idx + 1u));
        return;
    }

    ADC_LOGF("[S95] A95:");
    for (uint32_t i = 0; i < FIFO_FRAMES; ++i) {
        adc_invalidate_cache_for_buffer(adc1_buffers[i], (uint32_t)(probe_idx + 1u));
        uint16_t v = adc1_buffers[i][probe_idx];
        ADC_LOGF("%u", (unsigned)v);
        if (i + 1u < FIFO_FRAMES) ADC_LOGF(" ");
    }
    ADC_LOGF(" | B95:");
    for (uint32_t i = 0; i < FIFO_FRAMES; ++i) {
        adc_invalidate_cache_for_buffer(adc2_buffers[i], (uint32_t)(probe_idx + 1u));
        uint16_t v = adc2_buffers[i][probe_idx];
        ADC_LOGF("%u", (unsigned)v);
        if (i + 1u < FIFO_FRAMES) ADC_LOGF(" ");
    }
    ADC_LOGF("\r\n");
}

static inline void adc_flush_cache_for_buffer(void *buf, uint32_t samples)
{
/* STM32H7: при DMA write в cacheable RAM нужно:
   - перед стартом DMA: Clean (если CPU мог оставлять dirty линии, например после BSS init/memset)
   - перед чтением CPU: Invalidate (делается в adc_get_frame_ch)
   Иначе возможны «залипшие нули», паттерны 0xAAAA/0xBBBB и случайные артефакты.
*/
#ifndef ADC_DMA_CACHE_MAINT_ENABLE
#define ADC_DMA_CACHE_MAINT_ENABLE 1
#endif
#if ADC_DMA_CACHE_MAINT_ENABLE
#if defined (SCB_CleanDCache_by_Addr)
    if (!buf || samples == 0) return;
    uintptr_t addr = (uintptr_t)buf;
    uintptr_t start = addr & ~(uintptr_t)31u; /* align down to 32 */
    uint32_t bytes = samples * (uint32_t)sizeof(uint16_t);
    uint32_t extra = (uint32_t)(addr - start);
    uint32_t total = bytes + extra;
    uint32_t total_aligned = (total + 31u) & ~31u;
    SCB_CleanDCache_by_Addr((uint32_t*)start, (int32_t)total_aligned);
#else
    (void)buf; (void)samples;
#endif
#else
    (void)buf; (void)samples;
#endif
}

#if ADC_USB_STAGE_ENABLE
/* CRC16-CCITT (0x1021, init 0xFFFF) по лоу-байту/хи-байту выборок */
static uint16_t adc_crc16_le(const uint16_t *data, uint16_t samples)
{
    uint16_t crc = 0xFFFFu;
    for (uint16_t i = 0; i < samples; ++i) {
        uint16_t v = data[i];
        uint8_t bytes[2] = { (uint8_t)(v & 0xFFu), (uint8_t)(v >> 8) };
        for (int b = 0; b < 2; ++b) {
            crc ^= (uint16_t)bytes[b] << 8;
            for (uint8_t bit = 0; bit < 8; ++bit) {
                crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
            }
        }
    }
    return crc;
}
#endif

#if ADC_USB_STAGE_ENABLE
/* Единая установка маркеров в staging-буфер */
void adc_stage_write_markers(uint16_t *buf, uint16_t samples, uint16_t buf_idx)
{
    (void)buf; (void)samples; (void)buf_idx; /* маркеры отключены */
}
#endif

uint8_t adc_stream_static_mode_enabled(void){ return s_static_stage_mode; }

// Fine frequency tuning: override для buf_rate_hz (0 = use profile default)
static uint16_t g_fine_buf_rate_override = 0;

// Fine ARR offset: ручная подстройка ARR для точной частоты (например -4 для 200→200.35 Гц)
static int32_t g_arr_fine_offset = 0;  // По умолчанию БЕЗ коррекции

// Флаг: отключить автоматическое переопределение ARR (для ручного тестирования)
// По умолчанию ARR задаётся только из профиля в adc_stream_apply_timing().
volatile uint8_t g_arr_manual_mode = 0;

static uint8_t g_auto_freq_sync_enable = 0;  // RS485 sync не меняет частоту/ARR автоматически


// Диагностика
volatile uint32_t g_auto_freq_regulation_count = 0;
volatile uint32_t g_auto_freq_last_phase = 0;
volatile int32_t g_auto_freq_last_drift = 0;
volatile uint32_t g_auto_freq_last_delta = 0;     // Последнее значение abs_delta
volatile uint32_t g_auto_freq_last_threshold = 0; // Последний порог

// Флаги для аппаратной коррекции TIM15 через Update Event
volatile uint8_t g_tim15_correction_pending = 0;  // 1 = нужно восстановить ARR-1
volatile uint32_t g_tim15_baseline_arr = 0;       // Базовое значение ARR для восстановления
volatile uint32_t g_tim15_periods_elapsed = 0;    // Счетчик периодов до восстановления

// DMA-буфер для 2 значений ARR: [ARR+1, ARR] - NORMAL авто-остановка, шаг ~8мкс
__attribute__((aligned(4))) volatile uint32_t g_tim15_arr_dma_buffer[2] = {0};
static uint8_t g_tim15_dma_initialized = 0;

/* Настройка DMA для автоматической записи TIM15->ARR: 2 значения через 1 период */
void adc_stream_setup_tim15_arr_dma(void)
{
    extern DMA_HandleTypeDef hdma_tim15_up;
    extern TIM_HandleTypeDef htim15;
    
    if (g_tim15_dma_initialized) return;  // Уже настроен
    
    hdma_tim15_up.Instance = DMA1_Stream5;
    hdma_tim15_up.Init.Request = DMA_REQUEST_TIM15_UP;
    hdma_tim15_up.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_tim15_up.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_tim15_up.Init.MemInc = DMA_MINC_ENABLE;  // Автоинкремент: ARR+1, затем ARR-1
    hdma_tim15_up.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_tim15_up.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_tim15_up.Init.Mode = DMA_NORMAL;  // NORMAL: авто-остановка после 2 трансферов
    hdma_tim15_up.Init.Priority = DMA_PRIORITY_HIGH;
    hdma_tim15_up.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    
    if (HAL_DMA_Init(&hdma_tim15_up) != HAL_OK) {
        printf("[TIM15_DMA] ERROR: DMA init failed!\r\n");
        return;
    }
    
    __HAL_LINKDMA(&htim15, hdma[TIM_DMA_ID_UPDATE], hdma_tim15_up);
    g_tim15_dma_initialized = 1;
    printf("[TIM15_DMA] DMA configured (NORMAL mode, 2-element buffer, auto-stop)\r\n");
}

/* Запуск однократной коррекции: DMA передаст [ARR+1, ARR-1] через 2 периода TIM15 */
void adc_stream_push_tim15_phase(int32_t correction_ticks)
{
    (void)correction_ticks;
    /* Runtime phase push through TIM15->ARR is intentionally disabled. */
}

// Legacy wrapper used by old code
void adc_stream_trigger_tim15_correction(void) {
    adc_stream_push_tim15_phase(1);
}

/* === TIM16 phase sync (slave) === */
static volatile uint8_t sync_pd5_adjust_pending = 0;
static volatile int8_t  sync_pd5_adjust_dir = 0; /* -1 снизить, +1 повысить */
// static uint32_t sync_pd5_last_adjust_ms = 0;  // Неиспользуется
#define SYNC_PD5_ADJUST_MIN_MS 10u
#define SYNC_PD5_ADJUST_STEP_HZ 1u
#define SYNC_PD5_ADJUST_MAX_DELTA 5u
#define SYNC_PD5_FREQ_ADJUST_ENABLE 0u
#define SYNC_PD5_RESTART_MIN_MS 200u
// static int8_t sync_phase_dir = 1; /* направление подстройки (+1/-1) */
// static uint16_t sync_phase_prev_dist = 0;
// static uint8_t sync_phase_has_prev = 0;
#define SYNC_PHASE_EDGE_WINDOW 8u
#define SYNC_BUF_RATE_NOMINAL 400u

/* === Счетчик буферов для синхронизации === */
volatile uint32_t adc_stream_total_buffer_count = 0;
volatile uint32_t sync_buffer_count_at_edge = 0;
volatile uint32_t sync_buffers_between_edges = 0;  /* Реальное количество буферов между спадами PD5 */
volatile uint32_t sync_tim15_cnt_at_pd5 = 0;        /* TIM15->CNT при спаде PD5 (фаза внутри семпла) */
volatile uint32_t sync_tim5_cnt_at_buffer = 0;      /* TIM5->CNT в момент локального завершения буфера */
volatile uint32_t sync_tim5_buffer_phase_seq = 0;   /* Счетчик обновлений локальной фазовой выборки */

/* Диагностика: индекс сэмпла TIM15 на конце буфера */
volatile uint16_t adc_sync_dbg_last_idx = 0;
volatile uint16_t adc_sync_dbg_last_samples = 0;
volatile uint32_t adc_sync_dbg_last_buf = 0;
volatile uint32_t adc_sync_dbg_last_ms = 0;
volatile uint8_t  adc_sync_dbg_updated = 0;

volatile int32_t g_tim5_avg_phase = 0;  // Глобальная переменная для отображения на LCD

volatile uint16_t sync_phase_last_dist = 0;
volatile uint32_t sync_restart_requests = 0;

static inline void adc_sync_phase_on_buffer(void)
{
    uint32_t now_ms = HAL_GetTick();
    
    /* ВСЕГДА инкрементируем счетчик буферов */
    adc_stream_total_buffer_count++;
    
    uint32_t target = adc_stream_get_active_samples();
    
    /* Остальная логика только в режиме SLAVE */
    extern volatile uint8_t vnd_sync_mode_public;
    if (vnd_sync_mode_public != VND_SYNC_MODE_SLAVE) {
        return;
    }
    
    if (target < 2u) {
        return;
    }
    
    extern TIM_HandleTypeDef htim15;
    
    /* Читаем TIM15->CNT на момент буфера для фазы */
    uint32_t tim15_cnt_now = htim15.Instance->CNT;
    uint32_t cnt_mod = (tim15_cnt_now % target);
    
    /* Обновляем диагностические значения */
    adc_sync_dbg_last_idx = cnt_mod;
    adc_sync_dbg_last_samples = target;
    adc_sync_dbg_last_ms = now_ms;
    adc_sync_dbg_last_buf++;
    adc_sync_dbg_updated = 1u;
    
    /* Диагностический вывод отключен - printf сбивает синхронизацию */
    /* Блокирующий UART вывод может занимать миллисекунды и нарушать timing */
    #if 0
    static uint32_t diag_cnt = 0;
    
    if ((++diag_cnt % 200) == 0) {
        uint32_t buffers_per_pd5 = sync_buffers_between_edges;
        
        /* Ожидаем ровно 2 буфера между спадами PD5 (1200 семплов / 600 = 2) */
        uint32_t expected_buffers = 2;
        int32_t error_buffers = (int32_t)buffers_per_pd5 - (int32_t)expected_buffers;
        
        uint16_t tim15_arr = htim15.Instance->ARR;
        uint32_t tim15_phase = sync_tim15_cnt_at_pd5;
        
        printf("[TIM15_SYNC] PD5_edges=%lu bufs=%lu expected=%lu error=%ld ARR=%u phase=%lu\r\n",
               (unsigned long)sync_edge_count,
               (unsigned long)buffers_per_pd5,
               (unsigned long)expected_buffers,
               (long)error_buffers,
               (unsigned)tim15_arr,
               (unsigned long)tim15_phase);
    }
    #endif
    
    /* Автокоррекция TIM15.ARR отключена в режиме SLAVE */
    /* В SLAVE мы принудительно синхронизируемся через перезапуск ADC/DMA */
    /* Коррекция ARR и TIM_EGR_UG могут кратковременно сбивать фазу */
    #if 0  /* Отключено для SLAVE mode */
    /* Коррекция каждые 2 секунды (800 буферов) */
    if ((diag_cnt % 800) == 0 && sync_buffers_between_edges == 2) {
        uint16_t tim15_arr = htim15.Instance->ARR;
        uint32_t tim15_phase = sync_tim15_cnt_at_pd5;
        
        /* Нормализуем фазу: 0.0 - 1.0 относительно текущего ARR */
        float phase_norm = (float)tim15_phase / (float)tim15_arr;
        
        static float prev_phase_norm = 0.0f;
        static uint8_t phase_init = 0;
        
        if (!phase_init) {
            prev_phase_norm = phase_norm;
            phase_init = 1;
        } else {
            /* Вычисляем тренд нормализованной фазы */
            float phase_delta = phase_norm - prev_phase_norm;
            
            /* Обрабатываем переход через 0 (wrap around) */
            if (phase_delta > 0.5f) phase_delta -= 1.0f;
            if (phase_delta < -0.5f) phase_delta += 1.0f;
            
            /* Коррекция только если дельта > 0.01 (1% от периода ARR, ~11 тиков) */
            int32_t arr_correction = 0;
            
            if (phase_delta > 0.01f) {
                /* Фаза растет → TIM15 отстает → ускорить (уменьшить ARR) */
                arr_correction = -1;
            } else if (phase_delta < -0.01f) {
                /* Фаза падает → TIM15 спешит → замедлить (увеличить ARR) */
                arr_correction = +1;
            }
            
            if (arr_correction != 0) {
                uint16_t new_arr = (uint16_t)((int32_t)tim15_arr + arr_correction);
                
                /* Защита от выхода за пределы ±5% от номинала 1145 */
                if (new_arr >= 1088 && new_arr <= 1202) {
                    htim15.Instance->ARR = new_arr;
                    htim15.Instance->EGR = TIM_EGR_UG;
                    
                    printf("[TIM15_CORR] ARR: %u -> %u (phase_delta=%.4f, phase_norm=%.3f->%.3f)\r\n",
                           tim15_arr, new_arr, phase_delta,
                           prev_phase_norm, phase_norm);
                }
            } else {
                /* Фаза стабильна */
                static uint32_t stable_count = 0;
                if ((++stable_count % 5) == 0) {
                    printf("[SYNC_OK] Phase stable: delta=%.4f phase_norm=%.3f ARR=%u (%lu checks)\r\n",
                           phase_delta, phase_norm, 
                           tim15_arr, (unsigned long)stable_count);
                }
            }
            
            prev_phase_norm = phase_norm;
        }
    }
    #endif  /* Коррекция ARR отключена в SLAVE mode */
}

void adc_sync_pd5_apply_adjustment(void)
{
#if !SYNC_PD5_FREQ_ADJUST_ENABLE
    return;
#else
    if (!sync_pd5_adjust_pending) return;
    sync_pd5_adjust_pending = 0u;

    int8_t dir = sync_pd5_adjust_dir;
    if (dir == 0) return;

    uint16_t cur = adc_stream_get_buf_rate();
    if (cur == 0u) cur = SYNC_BUF_RATE_NOMINAL;
    uint16_t min_rate = (SYNC_BUF_RATE_NOMINAL > SYNC_PD5_ADJUST_MAX_DELTA) ?
                        (uint16_t)(SYNC_BUF_RATE_NOMINAL - SYNC_PD5_ADJUST_MAX_DELTA) : 1u;
    uint16_t max_rate = (uint16_t)(SYNC_BUF_RATE_NOMINAL + SYNC_PD5_ADJUST_MAX_DELTA);
    int32_t next = (int32_t)cur + ((dir > 0) ? (int32_t)SYNC_PD5_ADJUST_STEP_HZ : -(int32_t)SYNC_PD5_ADJUST_STEP_HZ);
    if (next < (int32_t)min_rate) next = (int32_t)min_rate;
    if (next > (int32_t)max_rate) next = (int32_t)max_rate;
    if ((uint16_t)next != cur) {
        adc_stream_set_buf_rate_external((uint16_t)next);
    }
#endif
}

// Публичные функции профиля
uint8_t adc_stream_get_profile(void) { return g_active_profile; }
uint16_t adc_stream_get_active_samples(void) { return g_active_samples; }
uint16_t adc_stream_get_buf_rate(void) { 
    // Если установлен fine tuning override, используем его
    return (g_fine_buf_rate_override != 0) ? g_fine_buf_rate_override : g_profiles[g_active_profile].buf_rate_hz; 
}
uint32_t adc_stream_get_fs(void) { return g_profiles[g_active_profile].fs_hz; }

/* Применить актуальные настройки частоты к TIM15 и TIM2 (независимо от профиля) */
static void adc_stream_apply_timing(void)
{
    extern TIM_HandleTypeDef htim15;
    uint16_t samples = adc_stream_get_active_samples();
    uint16_t buf_rate_hz = adc_stream_get_buf_rate();
    if (samples == 0u || buf_rate_hz == 0u) {
        return;
    }

    /* Fs = buf_rate * N */
    uint32_t sample_rate = (uint32_t)buf_rate_hz * (uint32_t)samples;

    /* TIM15 тактируется от APB2 timer clock (с удвоением при делителе != 1) */
    uint32_t tim_clk = HAL_RCC_GetPCLK2Freq();
    uint32_t d2ppre2 = (RCC->D2CFGR & RCC_D2CFGR_D2PPRE2_Msk) >> RCC_D2CFGR_D2PPRE2_Pos;
    if (d2ppre2 != 0u) {
        tim_clk *= 2u;
    }
    
    /* TIM15: триггер ADC с частотой sample_rate (использует исходный PSC из Init) */
    uint32_t tick_hz = tim_clk / (htim15.Init.Prescaler + 1u);
    if (tick_hz == 0u || sample_rate == 0u) {
        return;
    }

    uint32_t tim15_arr = (tick_hz / sample_rate);
    if (tim15_arr == 0u) tim15_arr = 1u;
    tim15_arr -= 1u;

    /* ПРОПУСКАЕМ переписывание ARR если включен ручной режим тестирования */
    extern volatile uint8_t g_arr_manual_mode;
    if (g_arr_manual_mode) {
        // Ручной режим - не переписываем ARR, используем значение из main loop
        return;
    }

    if (g_arr_fine_offset != 0) {
        int32_t tuned_arr = (int32_t)tim15_arr + g_arr_fine_offset;
        if (tuned_arr < 1) {
            tuned_arr = 1;
        }
        tim15_arr = (uint32_t)tuned_arr;
    }

    /* Commit the profile value as the real nominal ARR and cancel any
       transient phase pulse based on the previous rate. Otherwise a pulse
       started before the RPI rate command can later restore the boot ARR and
       leave ADC sampling at the wrong frequency. */
    tim15_sync_apply_nominal_arr(tim15_arr);

    /* TIM5: 32-битный счётчик фазы без предделителя для максимальной точности
     * PSC = 0 → без предделителя → частота счёта 275 МГц
     * При sample_rate=240kHz получаем ~1146 тиков на семпл ADC (отличная точность!)
     * ARR = 0xFFFFFFFF (максимум 32-bit) → переполнение через 15.6 секунд
     * За буфер 2.5ms: ~687500 тиков | За период PD5 5ms: ~1375000 тиков
     */
    {
        extern TIM_HandleTypeDef htim5;
        const uint16_t tim5_psc = 0u;  /* Без предделителя - максимальная точность */
        
        htim5.Instance->PSC = tim5_psc;
        htim5.Instance->ARR = 0xFFFFFFFFu;  /* Максимум 32-bit */
        htim5.Instance->EGR = TIM_EGR_UG;  /* Update generation для применения PSC/ARR */
        
        uint32_t actual_tick_rate = tim_clk;  /* Полная частота без предделителя */
        uint32_t ticks_per_sample = actual_tick_rate / sample_rate;
        uint32_t ticks_per_buf = (actual_tick_rate / buf_rate_hz);  /* Тиков за буфер */
        (void)actual_tick_rate;
        (void)ticks_per_sample;
        (void)ticks_per_buf;

        /* Never print timing unconditionally from a host-command path. A reconnect
           loop can repeat the same rate command and starve Vendor USB with blocking
           UART output. Detailed timing remains available with ADC_LOG_ENABLE=1. */
        ADC_LOGF("[SYNC_TIMING] TIM5 (32-bit): PSC=%u ARR=0xFFFFFFFF tick_rate=%lu Hz\r\n",
                 (unsigned)tim5_psc, (unsigned long)actual_tick_rate);
        ADC_LOGF("[SYNC_TIMING] TIM5: per_ADC_sample=%lu ticks | per_buffer=%lu ticks (%.1f ms)\r\n",
                 (unsigned long)ticks_per_sample, (unsigned long)ticks_per_buf,
                 (float)(1000.0f / buf_rate_hz));
        ADC_LOGF("[SYNC_TIMING] TIM15: ARR=%lu sample_rate=%lu Hz | APB2=%lu MHz\r\n",
                 (unsigned long)tim15_arr, (unsigned long)sample_rate, (unsigned long)(tim_clk / 1000000u));
    }

    /* Обновляем TIM2 (маркеры/окно) */
    extern uint32_t tim2_apply_profile_window(void);
    tim2_apply_profile_window();

    ADC_LOGF("[ADC][RATE] Apply timing: buf_rate=%u Hz samples=%u Fs=%lu Hz TIM15_CLK=%lu ARR=%lu\r\n",
             (unsigned)buf_rate_hz, (unsigned)samples,
             (unsigned long)sample_rate, (unsigned long)tick_hz, (unsigned long)tim15_arr);
}

/* TIM15 is the common external trigger for both ADCs. During a DMA rearm its
   TRGO output is gated until both channels are ready. The counter itself must
   keep running: stopping and resetting it at every frame made the frame period
   depend on HAL rearm execution time and defeated the RS-485 phase PLL. */
static uint8_t adc_stream_pause_common_trigger(void)
{
    extern TIM_HandleTypeDef htim15;
    if (htim15.Instance == NULL) return 0u;

    uint8_t was_running = ((htim15.Instance->CR1 & TIM_CR1_CEN) != 0u) ? 1u : 0u;
    if (was_running) {
        MODIFY_REG(htim15.Instance->CR2, TIM_CR2_MMS, TIM_TRGO_RESET);
    }
    return was_running;
}

static void adc_stream_restore_common_trigger(uint8_t was_running)
{
    extern TIM_HandleTypeDef htim15;
    if (!was_running || htim15.Instance == NULL) return;

    MODIFY_REG(htim15.Instance->CR2, TIM_CR2_MMS, TIM_TRGO_UPDATE);
}

static void adc_stream_clear_dma_irq_state(void)
{
    __HAL_DMA_CLEAR_FLAG(&hdma_adc1, __HAL_DMA_GET_TC_FLAG_INDEX(&hdma_adc1));
    __HAL_DMA_CLEAR_FLAG(&hdma_adc1, __HAL_DMA_GET_HT_FLAG_INDEX(&hdma_adc1));
    __HAL_DMA_CLEAR_FLAG(&hdma_adc1, __HAL_DMA_GET_TE_FLAG_INDEX(&hdma_adc1));
    __HAL_DMA_CLEAR_FLAG(&hdma_adc1, __HAL_DMA_GET_DME_FLAG_INDEX(&hdma_adc1));
    __HAL_DMA_CLEAR_FLAG(&hdma_adc1, __HAL_DMA_GET_FE_FLAG_INDEX(&hdma_adc1));
    HAL_NVIC_ClearPendingIRQ(DMA1_Stream0_IRQn);
#if !DIAG_SINGLE_ADC1
    __HAL_DMA_CLEAR_FLAG(&hdma_adc2, __HAL_DMA_GET_TC_FLAG_INDEX(&hdma_adc2));
    __HAL_DMA_CLEAR_FLAG(&hdma_adc2, __HAL_DMA_GET_HT_FLAG_INDEX(&hdma_adc2));
    __HAL_DMA_CLEAR_FLAG(&hdma_adc2, __HAL_DMA_GET_TE_FLAG_INDEX(&hdma_adc2));
    __HAL_DMA_CLEAR_FLAG(&hdma_adc2, __HAL_DMA_GET_DME_FLAG_INDEX(&hdma_adc2));
    __HAL_DMA_CLEAR_FLAG(&hdma_adc2, __HAL_DMA_GET_FE_FLAG_INDEX(&hdma_adc2));
    HAL_NVIC_ClearPendingIRQ(DMA1_Stream1_IRQn);
#endif
}

/* The caller gates TIM15 TRGO until BOTH ADC streams have been armed. HAL's
   ADC start installs its private ADC completion/error callbacks, but its DMA
   start clears DBM. Upgrade the freshly armed, trigger-idle stream only after
   disabling EN: CT/DBM/CIRC and NDTR must not be configured on a live stream.
   This helper is used on profile starts and watchdog recovery, never per TC. */
static HAL_StatusTypeDef adc_stream_start_dbm(ADC_HandleTypeDef *hadc,
                                            uint16_t buffers[FIFO_FRAMES][MAX_FRAME_SAMPLES],
                                            uint32_t start_idx,
                                            uint32_t samples)
{
    if ((hadc == NULL) || (hadc->DMA_Handle == NULL) ||
        (samples == 0u) || (samples > MAX_FRAME_SAMPLES) ||
        (FIFO_FRAMES < 4u)) {
        return HAL_ERROR;
    }
    start_idx &= (FIFO_FRAMES - 1u);
    HAL_StatusTypeDef rc = HAL_ADC_Start_DMA(hadc, (uint32_t*)buffers[start_idx], samples);
    if (rc != HAL_OK) {
        s_adc_tc_rearm_failures++;
        (void)HAL_ADC_Stop_DMA(hadc);
        return rc;
    }

    DMA_HandleTypeDef *hdma = hadc->DMA_Handle;
    DMA_Stream_TypeDef *stream = (DMA_Stream_TypeDef*)hdma->Instance;
    __HAL_DMA_DISABLE(hdma);
    uint32_t timeout = 10000u;
    while (((stream->CR & DMA_SxCR_EN) != 0u) && (timeout != 0u)) {
        timeout--;
    }
    if ((stream->CR & DMA_SxCR_EN) != 0u) {
        s_adc_tc_rearm_failures++;
        (void)HAL_ADC_Stop_DMA(hadc);
        return HAL_TIMEOUT;
    }

    stream->M0AR = (uint32_t)buffers[start_idx];
    stream->M1AR = (uint32_t)buffers[(start_idx + 1u) & (FIFO_FRAMES - 1u)];
    stream->NDTR = samples;
    MODIFY_REG(stream->CR, DMA_SxCR_CT | DMA_SxCR_DBM | DMA_SxCR_CIRC,
               DMA_SxCR_DBM | DMA_SxCR_CIRC);
    hdma->XferM1CpltCallback = hdma->XferCpltCallback;
    hdma->XferM1HalfCpltCallback = NULL;
    __HAL_DMA_CLEAR_FLAG(hdma, __HAL_DMA_GET_TC_FLAG_INDEX(hdma) |
                              __HAL_DMA_GET_HT_FLAG_INDEX(hdma) |
                              __HAL_DMA_GET_TE_FLAG_INDEX(hdma) |
                              __HAL_DMA_GET_DME_FLAG_INDEX(hdma) |
                              __HAL_DMA_GET_FE_FLAG_INDEX(hdma));
    __HAL_DMA_DISABLE_IT(hdma, DMA_IT_HT);
    __HAL_DMA_ENABLE_IT(hdma, DMA_IT_TC | DMA_IT_TE | DMA_IT_DME);
    __DSB();
    __HAL_DMA_ENABLE(hdma);
    return HAL_OK;
}

static HAL_StatusTypeDef adc_stream_apply_profile(void) {
    if (!s_adc1 || (!DIAG_SINGLE_ADC1 && !s_adc2)) {
        ADC_LOGF("[ADC][APPLY_PROFILE] ERROR: s_adc1/s_adc2 не инициализированы!\r\n");
        return HAL_ERROR;
    }
    uint32_t total_samples = (uint32_t)g_active_samples;
    ++s_capture_generation;
    uint8_t tim15_was_running = adc_stream_pause_common_trigger();
    ADC_LOGF("[ADC][APPLY_PROFILE] profile=%u samples=%u\r\n", (unsigned)g_active_profile, (unsigned)g_active_samples);
    // Остановить DMA перед запуском с новым размером
        HAL_ADC_Stop_DMA(s_adc1);
        /* NDTR страховка перед стартом: указываем фактическое N */
        ((DMA_Stream_TypeDef*)s_adc1->DMA_Handle->Instance)->NDTR = total_samples;
        HAL_ADC_Stop_DMA(s_adc2);
        ((DMA_Stream_TypeDef*)s_adc2->DMA_Handle->Instance)->NDTR = total_samples;
    adc_stream_clear_dma_irq_state();
    ADC_LOGF("[ADC][APPLY_PROFILE] DMA остановлен, подготовка к запуску\r\n");
    frame_wr_seq = frame_rd_seq = 0;
    frame_overflow_drops = 0;
    frame_backlog_max = 0;
    adc_stream_paused = 0;
    /* Сброс независимых счётчиков по каналам */
    adc_ch_wr_seq[0] = adc_ch_wr_seq[1] = 0;
    adc_ch_rd_seq[0] = adc_ch_rd_seq[1] = 0;
    adc_ch_overflow_drops[0] = adc_ch_overflow_drops[1] = 0;
    adc_ch_zero_buffers[0] = adc_ch_zero_buffers[1] = 0; // ДИАГНОСТИКА: сброс счётчиков нулевых буферов
    /* Сброс новой синхронизации пар */
    for (unsigned i = 0; i < FIFO_FRAMES; ++i) s_pair_ready_mask[i] = 0;
    s_pair_ready_idx = 0;
    s_next_ring_index = 0;  // Начинаем с buf[0], после TC перейдём на buf[1], потом buf[2]... buf[31]→buf[0]
    adc_stream_reset_capture_phase_state();
    #if ADC_USB_STAGE_ENABLE
    adc_stage_crc_a = 0; adc_stage_crc_seq = 0;
    #endif

    /* Активируем статический режим, если задан компиляционным флагом */
    s_static_stage_mode = DIAG_STATIC_STAGE_MODE ? 1u : 0u;
    if(s_static_stage_mode){
        uint32_t stage_ns = total_samples; if(stage_ns > MAX_FRAME_SAMPLES) stage_ns = MAX_FRAME_SAMPLES;
        #if ADC_USB_STAGE_ENABLE
        memset(usb_stage_bufA, 0, stage_ns * sizeof(uint16_t));
        adc_stage_crc_a = adc_crc16_le(usb_stage_bufA, (uint16_t)stage_ns);
        adc_stage_crc_seq = 1u;
        adc_flush_cache_for_buffer(usb_stage_bufA, (uint32_t)stage_ns);
        #endif
        if(!DIAG_SINGLE_ADC1){ memset(adc2_buffers[0], 0, stage_ns * sizeof(uint16_t)); adc_flush_cache_for_buffer(adc2_buffers[0], (uint32_t)stage_ns); }
        ADC_LOGF("[ADC][STATIC] mode: DMA disabled, staged markers cleared (samples=%lu)\r\n", (unsigned long)stage_ns);
        adc_stream_restore_common_trigger(tim15_was_running);
        return HAL_OK;
    }

    /* Применяем тайминги (TIM15/TIM2) под текущий профиль/override до старта DMA */
    adc_stream_apply_timing();
    
    #if DIAG_DISABLE_ADC_DMA
        ADC_LOGF("[ADC][DIAG] DMA start suppressed (DIAG_DISABLE_ADC_DMA=1) total_samples=%lu\r\n", (unsigned long)total_samples);
        adc_stream_restore_common_trigger(tim15_was_running);
        return HAL_OK;
        s_last_started_idx = 0;
        s_last_started_idx = 0;
        s_tc_mask = 0;
    #else
    /* КРИТИЧНО: Принудительная установка external trigger ПЕРЕД стартом DMA.
       Проблема: HAL_ADC_Init не всегда корректно пишет EXTSEL/EXTEN в CFGR.
       Решение: Останавливаем ADC (если запущен), устанавливаем CFGR, затем запускаем DMA. */
    
    // Останавливаем ADC1 если он уже запущен (ADSTART=1)
    if (ADC1->CR & ADC_CR_ADSTART) {
        ADC1->CR |= ADC_CR_ADSTP;  // Запрос остановки
        uint32_t timeout = 10000;
        while ((ADC1->CR & ADC_CR_ADSTP) && (timeout-- > 0)) { /* ждём */ }
    }
    
    // Устанавливаем EXTSEL/EXTEN в CFGR (можно менять только при ADSTART=0)
    // ВАЖНО: не хардкодим EXTSEL, т.к. у STM32H7 кодировка зависит от семейства/инстанса.
    // Берём значения из HAL init (CubeMX), иначе легко получить триггер не от TIM15 и
    // «задушить» частоту до 200 Гц.
    MODIFY_REG(ADC1->CFGR, ADC_CFGR_EXTSEL | ADC_CFGR_EXTEN,
               (s_adc1->Init.ExternalTrigConv & ADC_CFGR_EXTSEL) |
               (s_adc1->Init.ExternalTrigConvEdge & ADC_CFGR_EXTEN));
    
    // КРИТИЧНО: Включаем ADC явно если он выключен (ADEN=0)
    if (!(ADC1->CR & ADC_CR_ADEN)) {
        ADC1->CR |= ADC_CR_ADEN;  // Включаем ADC
        uint32_t timeout = 10000;
        // Ждём установки бита ADRDY (ADC ready)
        while (!(ADC1->ISR & ADC_ISR_ADRDY) && (timeout-- > 0)) { /* ждём */ }
    }
    
    #if !DIAG_SINGLE_ADC1
    // То же для ADC2
    if (ADC2->CR & ADC_CR_ADSTART) {
        ADC2->CR |= ADC_CR_ADSTP;
        uint32_t timeout = 10000;
        while ((ADC2->CR & ADC_CR_ADSTP) && (timeout-- > 0)) { /* ждём */ }
    }
    MODIFY_REG(ADC2->CFGR, ADC_CFGR_EXTSEL | ADC_CFGR_EXTEN,
               (s_adc2->Init.ExternalTrigConv & ADC_CFGR_EXTSEL) |
               (s_adc2->Init.ExternalTrigConvEdge & ADC_CFGR_EXTEN));
    
    // Включаем ADC2 если выключен
    if (!(ADC2->CR & ADC_CR_ADEN)) {
        ADC2->CR |= ADC_CR_ADEN;
        uint32_t timeout = 10000;
        while (!(ADC2->ISR & ADC_ISR_ADRDY) && (timeout-- > 0)) { /* ждём */ }
    }
    #endif
    
        /* Одноразовая расширенная диагностика старта DMA: очень шумит в UART.
        Включать только при расследовании проблем со стартом/IRQ. */
    #ifndef ADC_START_VERBOSE_DIAG
    #define ADC_START_VERBOSE_DIAG 0
    #endif
    #if ADC_START_VERBOSE_DIAG
        printf("[ADC][DIAG] Before DMA start: ADC1->CR=0x%08lX DMA1_Stream0->CR=0x%08lX NDTR=%lu\r\n",
            (unsigned long)ADC1->CR, (unsigned long)DMA1_Stream0->CR, (unsigned long)DMA1_Stream0->NDTR);
        printf("[ADC][DIAG] ADC1->CFGR=0x%08lX (ExtTrig=0x%lX Edge=0x%lX)\r\n",
            (unsigned long)ADC1->CFGR,
            (unsigned long)((ADC1->CFGR >> 5) & 0x1F),  // EXTSEL[4:0]
            (unsigned long)((ADC1->CFGR >> 10) & 0x3)); // EXTEN[1:0]
    #endif
    
    /* КРИТИЧНО (STM32H7 D-cache): перед первым использованием буферов под DMA
       очищаем (Clean) кэш-строки для всех кольцевых буферов.
       Это предотвращает ситуацию, когда dirty-линии (например после init .bss/memset)
       позже write-back'ом затирают данные, записанные DMA.
    */
    for (uint32_t i = 0; i < FIFO_FRAMES; i++) {
        adc_flush_cache_for_buffer(adc1_buffers[i], total_samples);
        #if !DIAG_SINGLE_ADC1
        adc_flush_cache_for_buffer(adc2_buffers[i], total_samples);
        #endif
    }

    /* Опционально: диагностический паттерн в первый буфер (по умолчанию выключено).
       Если включить, обязательно Clean после записи, иначе паттерн может затирать DMA-данные.
    */
#ifndef ADC_DMA_PRESET_PATTERN
#define ADC_DMA_PRESET_PATTERN 0
#endif
#if ADC_DMA_PRESET_PATTERN
    for (uint32_t i = 0; i < total_samples; i++) {
        adc1_buffers[0][i] = 0xAAAA;
        #if !DIAG_SINGLE_ADC1
        adc2_buffers[0][i] = 0xBBBB;
        #endif
    }
    adc_flush_cache_for_buffer(adc1_buffers[0], total_samples);
    #if !DIAG_SINGLE_ADC1
    adc_flush_cache_for_buffer(adc2_buffers[0], total_samples);
    #endif
#endif
    
    // Старт ADC1 DMA на буфер[0] длиной N
    HAL_StatusTypeDef rc1 = adc_stream_start_dbm(s_adc1, adc1_buffers, 0u, total_samples);
    ADC_LOGF("[ADC][APPLY_PROFILE] HAL_ADC_Start_DMA ADC1 rc=%d\r\n", (int)rc1);

    /* ВАЖНО: для работы пайплайна нам нужен TC interrupt по завершению DMA.
       HAL может перезаписывать CR при старте DMA, поэтому включаем IT ПОСЛЕ Start_DMA. */
    __HAL_DMA_ENABLE_IT(&hdma_adc1, DMA_IT_TC);
    __HAL_DMA_ENABLE_IT(&hdma_adc1, DMA_IT_TE);
    __HAL_DMA_DISABLE_IT(&hdma_adc1, DMA_IT_HT);
    
    #if ADC_START_VERBOSE_DIAG
        printf("[ADC][DIAG] After DMA start: ADC1->CR=0x%08lX (ADEN=%lu ADSTART=%lu)\r\n",
            (unsigned long)ADC1->CR,
            (unsigned long)((ADC1->CR >> 0) & 1),  // ADEN
            (unsigned long)((ADC1->CR >> 2) & 1)); // ADSTART

        printf("[ADC][DIAG] After DMA start: ADC1->CR=0x%08lX DMA1_Stream0->CR=0x%08lX NDTR=%lu\r\n",
            (unsigned long)ADC1->CR, (unsigned long)DMA1_Stream0->CR, (unsigned long)DMA1_Stream0->NDTR);

        uint32_t dma_cr = DMA1_Stream0->CR;
        uint32_t dma_ndtr = DMA1_Stream0->NDTR;
        uint32_t dma_par = DMA1_Stream0->PAR;
        uint32_t dma_m0ar = DMA1_Stream0->M0AR;
        uint32_t dma_fcr = DMA1_Stream0->FCR;

        printf("[DMA1_S0] CR=0x%08lX: EN=%lu TCIE=%lu HTIE=%lu TEIE=%lu DIR=%lu CIRC=%lu\r\n",
            (unsigned long)dma_cr,
            (unsigned long)((dma_cr >> 0) & 1),
            (unsigned long)((dma_cr >> 4) & 1),
            (unsigned long)((dma_cr >> 3) & 1),
            (unsigned long)((dma_cr >> 2) & 1),
            (unsigned long)((dma_cr >> 6) & 3),
            (unsigned long)((dma_cr >> 8) & 1));

        printf("[DMA1_S0] NDTR=%lu PAR=0x%08lX M0AR=0x%08lX FCR=0x%08lX\r\n",
            (unsigned long)dma_ndtr, (unsigned long)dma_par, (unsigned long)dma_m0ar, (unsigned long)dma_fcr);

        uint32_t adc_isr = ADC1->ISR;
        uint32_t adc_ier = ADC1->IER;
        printf("[ADC1] ISR=0x%08lX (ADRDY=%lu EOC=%lu EOS=%lu OVR=%lu)\r\n",
            (unsigned long)adc_isr,
            (unsigned long)((adc_isr >> 0) & 1),
            (unsigned long)((adc_isr >> 2) & 1),
            (unsigned long)((adc_isr >> 3) & 1),
            (unsigned long)((adc_isr >> 4) & 1));

        printf("[ADC1] IER=0x%08lX (EOCIE=%lu EOSIE=%lu OVRIE=%lu)\r\n",
            (unsigned long)adc_ier,
            (unsigned long)((adc_ier >> 2) & 1),
            (unsigned long)((adc_ier >> 3) & 1),
            (unsigned long)((adc_ier >> 4) & 1));

        uint32_t nvic_iser = NVIC->ISER[DMA1_Stream0_IRQn >> 5];
        uint32_t nvic_bit = 1UL << (DMA1_Stream0_IRQn & 0x1F);
        printf("[NVIC] DMA1_Stream0_IRQn=%d enabled=%lu\r\n",
            DMA1_Stream0_IRQn, (unsigned long)((nvic_iser & nvic_bit) ? 1 : 0));
    #endif
    
    if (rc1 != HAL_OK) {
        adc_stream_restore_common_trigger(tim15_was_running);
        return HAL_ERROR;
    }
        #if !DIAG_SINGLE_ADC1
    HAL_StatusTypeDef rc2 = adc_stream_start_dbm(s_adc2, adc2_buffers, 0u, total_samples);
    ADC_LOGF("[ADC][APPLY_PROFILE] HAL_ADC_Start_DMA ADC2 rc=%d\r\n", (int)rc2);

    __HAL_DMA_ENABLE_IT(&hdma_adc2, DMA_IT_TC);
    __HAL_DMA_ENABLE_IT(&hdma_adc2, DMA_IT_TE);
    __HAL_DMA_DISABLE_IT(&hdma_adc2, DMA_IT_HT);
    
    if (rc2 != HAL_OK) {
        (void)HAL_ADC_Stop_DMA(s_adc1);
        adc_stream_clear_dma_irq_state();
        adc_stream_restore_common_trigger(tim15_was_running);
        return HAL_ERROR;
    }
        #if ADC2_DISABLE_DMA_IRQS
            /* (не используется) */
        #else
            /* Убедимся, что IRQ для ADC2 DMA включены (Half/Full не требуем, достаточно TC) */
            HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
        #endif
        #endif
        /* Only completed DBM banks are published; half-transfer IRQ is unused. */
        
        /* Одноразовый вывод регистров DMA для ADC1 */
        {
            DMA_Stream_TypeDef *st = (DMA_Stream_TypeDef*)hdma_adc1.Instance;
            ADC_LOGF("[ADC][DMA1S0] CR=0x%08lX NDTR=%lu PAR=0x%08lX M0AR=0x%08lX FCR=0x%08lX single=%u\r\n",
                   (unsigned long)st->CR,
                   (unsigned long)st->NDTR,
                   (unsigned long)st->PAR,
                   (unsigned long)st->M0AR,
                   (unsigned long)st->FCR,
                   (unsigned)DIAG_SINGLE_ADC1);
        }
        /* Одноразовый вывод регистров DMA для ADC2 */
        #if !DIAG_SINGLE_ADC1
        {
            DMA_Stream_TypeDef *st2 = (DMA_Stream_TypeDef*)hdma_adc2.Instance;
            ADC_LOGF("[ADC][DMA1S1] CR=0x%08lX NDTR=%lu PAR=0x%08lX M0AR=0x%08lX FCR=0x%08lX\r\n",
                   (unsigned long)st2->CR,
                   (unsigned long)st2->NDTR,
                   (unsigned long)st2->PAR,
                   (unsigned long)st2->M0AR,
                   (unsigned long)st2->FCR);
        }
        #endif
    #endif
    s_dma_arm_ms = HAL_GetTick();
    s_dma_arm_publish_snapshot = adc_publish_count;
    adc_stream_restore_common_trigger(tim15_was_running);
    return HAL_OK;
}

int adc_stream_set_profile(uint8_t prof_id) {
    uint16_t previous_samples;
    uint16_t previous_buf_rate;
    uint16_t next_buf_rate;

    if (prof_id >= ADC_PROFILE_COUNT) return -1;
    if (prof_id == g_active_profile) {
        ADC_LOGF("[ADC][PROF] prof=%u ALREADY active, g_active_samples=%u\r\n", prof_id, g_active_samples);
        return 0; // уже
    }

    previous_samples = g_active_samples;
    previous_buf_rate = adc_stream_get_buf_rate();
    g_active_profile = prof_id;
    g_active_samples = g_profiles[prof_id].samples_per_buf;
    next_buf_rate = adc_stream_get_buf_rate();
    ADC_LOGF("[ADC][PROF] SET prof=%u -> g_active_samples=%u, adc_ready=%d\r\n", prof_id, g_active_samples, (s_adc1 && s_adc2)?1:0);

    /* Different host profile IDs can describe the same active acquisition.
       This is especially common after SET_BUF_RATE_FINE: the override owns the
       effective buffer rate and all current profiles use the same 600-sample
       DMA geometry. Restarting both ADC DMAs in that case resets the local
       marker parity on only one board and makes an otherwise locked slave run
       a needless full anti-phase slew. Treat an unchanged effective geometry
       as a metadata-only profile update. */
    if ((previous_samples == g_active_samples) &&
        (previous_buf_rate == next_buf_rate)) {
        ADC_LOGF("[ADC][PROF] effective geometry unchanged (%u @ %u Hz), no DMA restart\r\n",
                 (unsigned)g_active_samples,
                 (unsigned)next_buf_rate);
        return 0;
    }

    if (s_adc1 && s_adc2) {
        if (adc_stream_apply_profile() != HAL_OK) {
            ADC_LOGF("[ADC][PROF] apply_profile FAILED!\r\n");
            return -2;
        }
        ADC_LOGF("[ADC][PROF] apply_profile OK\r\n");
        /* Обновляем тайминги (TIM15/TIM2) под новый профиль/override */
        adc_stream_apply_timing();
    } else {
        /* Даже без активных ADC применяем тайминги для маркеров */
        adc_stream_apply_timing();
    }
    return 0;
}

void adc_stream_init(void) {
    frame_wr_seq = frame_rd_seq = 0;
    frame_overflow_drops = 0;
    frame_backlog_max = 0;
}

HAL_StatusTypeDef adc_stream_start(ADC_HandleTypeDef* a1, ADC_HandleTypeDef* a2) {
    if (s_adc1 == NULL) {
        s_capture_generation = 0u;
        s_snapshot_copy_busy = 0u;
    }
    s_adc1 = a1; s_adc2 = a2;
    
    // Диагностика начального состояния ADC
    printf("[ADC][DIAG] adc_stream_start: ADC1->CR=0x%08lX ADC2->CR=0x%08lX\r\n",
           (unsigned long)ADC1->CR, (unsigned long)ADC2->CR);
    
    // КРИТИЧНО: Сброс ADCAL перед новой калибровкой (может остаться после предыдущего старта)
    if (ADC1->CR & ADC_CR_ADCAL) {
        ADC1->CR &= ~ADC_CR_ADCAL;  // Очистить бит калибровки
        printf("[ADC][CALIB] ADC1: Cleared stale ADCAL bit\r\n");
    }
    #if !DIAG_SINGLE_ADC1
    if (ADC2->CR & ADC_CR_ADCAL) {
        ADC2->CR &= ~ADC_CR_ADCAL;
        printf("[ADC][CALIB] ADC2: Cleared stale ADCAL bit\r\n");
    }
    #endif
    
    // КРИТИЧЕСКИ ВАЖНО: Калибровка ADC перед запуском DMA для точности данных
    ADC_LOGF("[ADC][CALIB] Starting ADC1 calibration...\r\n");
    if (HAL_ADCEx_Calibration_Start(a1, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED) != HAL_OK) {
        ADC_LOGF("[ADC][CALIB] ADC1 calibration FAILED!\r\n");
        return HAL_ERROR;
    }
    ADC_LOGF("[ADC][CALIB] ADC1 calibration OK\r\n");
    
    #if !DIAG_SINGLE_ADC1
    ADC_LOGF("[ADC][CALIB] Starting ADC2 calibration...\r\n");
    if (HAL_ADCEx_Calibration_Start(a2, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED) != HAL_OK) {
        ADC_LOGF("[ADC][CALIB] ADC2 calibration FAILED!\r\n");
        return HAL_ERROR;
    }
    ADC_LOGF("[ADC][CALIB] ADC2 calibration OK\r\n");
    #endif
    
    /* Не переустанавливаем профиль по умолчанию здесь.
       Используем текущий g_active_profile (может быть задан хостом через SET_PROFILE до START).
       При инициализации по умолчанию он уже установлен в ADC_PROFILE_B_DEFAULT. */
    g_active_samples = g_profiles[g_active_profile].samples_per_buf;
    adc_stream_init();
    ADC_LOGF("[ADC][START] profile=%u samples=%u\r\n", (unsigned)g_active_profile, (unsigned)g_active_samples);
    HAL_StatusTypeDef rc = adc_stream_apply_profile();
    ADC_LOGF("[ADC][START] adc_stream_apply_profile rc=%d\r\n", (int)rc);
    return rc;
}

HAL_StatusTypeDef adc_stream_restart(ADC_HandleTypeDef* a1, ADC_HandleTypeDef* a2) {
    if (a1) s_adc1 = a1;
    if (a2) s_adc2 = a2;
    return adc_stream_apply_profile();
}

/* Watchdog recovery differs from a host START/profile change: already published
   FIFO frames and their sequence numbers must survive. Only the incomplete DMA
   pair is discarded and both channels are armed atomically from the next
   unpublished ring slot. */
static HAL_StatusTypeDef adc_stream_recover_dma_pair(void)
{
    if (s_adc1 == NULL || (!DIAG_SINGLE_ADC1 && s_adc2 == NULL)) return HAL_ERROR;

    uint32_t total_samples = (uint32_t)g_active_samples;
    if (total_samples == 0u) return HAL_ERROR;

    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    ++s_capture_generation;
    uint8_t tim15_was_running = adc_stream_pause_common_trigger();

    (void)HAL_ADC_Stop_DMA(s_adc1);
#if !DIAG_SINGLE_ADC1
    (void)HAL_ADC_Stop_DMA(s_adc2);
#endif
    adc_stream_clear_dma_irq_state();

    uint32_t start_idx = frame_wr_seq & (FIFO_FRAMES - 1u);
    memset((void*)s_pair_ready_mask, 0, sizeof(s_pair_ready_mask));
    s_pair_ready_idx = start_idx;
    s_next_ring_index = start_idx;
    s_last_started_idx = start_idx;
    s_tc_mask = 0u;
    s_adc_dbm_fault_pending = 0u;
    adc_stream_paused = 0u;

    /* Drop only incomplete per-channel completions. Keep the public pair FIFO
       sequence continuous so USB and DC consumers do not see a role-like reset. */
    adc_ch_wr_seq[0] = frame_wr_seq;
    adc_ch_rd_seq[0] = frame_rd_seq;
#if !DIAG_SINGLE_ADC1
    adc_ch_wr_seq[1] = frame_wr_seq;
    adc_ch_rd_seq[1] = frame_rd_seq;
#endif

    HAL_StatusTypeDef rc2 = HAL_OK;
#if !DIAG_SINGLE_ADC1
    /* Arm B first and A last. TIM15 TRGO remains gated, therefore neither channel
       can consume a trigger before both DMA streams are configured. */
    rc2 = adc_stream_start_dbm(s_adc2, adc2_buffers, start_idx, total_samples);
    if (rc2 == HAL_OK) {
        __HAL_DMA_ENABLE_IT(&hdma_adc2, DMA_IT_TC);
        __HAL_DMA_ENABLE_IT(&hdma_adc2, DMA_IT_TE);
        __HAL_DMA_DISABLE_IT(&hdma_adc2, DMA_IT_HT);
    }
#endif

    HAL_StatusTypeDef rc1 = HAL_ERROR;
    if (rc2 == HAL_OK) {
        rc1 = adc_stream_start_dbm(s_adc1, adc1_buffers, start_idx, total_samples);
        if (rc1 == HAL_OK) {
            __HAL_DMA_ENABLE_IT(&hdma_adc1, DMA_IT_TC);
            __HAL_DMA_ENABLE_IT(&hdma_adc1, DMA_IT_TE);
            __HAL_DMA_DISABLE_IT(&hdma_adc1, DMA_IT_HT);
        }
    }

    HAL_StatusTypeDef result = (rc1 == HAL_OK && rc2 == HAL_OK) ? HAL_OK : HAL_ERROR;
    if (result != HAL_OK) {
        (void)HAL_ADC_Stop_DMA(s_adc1);
#if !DIAG_SINGLE_ADC1
        (void)HAL_ADC_Stop_DMA(s_adc2);
#endif
        adc_stream_clear_dma_irq_state();
    } else {
        s_dma_arm_ms = HAL_GetTick();
        s_dma_arm_publish_snapshot = adc_publish_count;
    }

    adc_stream_restore_common_trigger(tim15_was_running);
    __set_PRIMASK(primask);
    return result;
}

/* Legacy helper retained for source compatibility. RS-485 phase/role handling
   must never interrupt the continuous ADC/DMA acquisition. */
void adc_stream_restart_sync(void) {
    adc_stream_paused = 0u;
    ADC_LOGF("[ADC][SYNC] restart request ignored: continuous acquisition\r\n");
}

// Проверка буфера на нулевое содержимое (для диагностики проблем ADC)
static inline uint8_t is_buffer_all_zeros(uint16_t *buf, uint16_t samples) {
    for (uint16_t i = 0; i < samples; i++) {
        if (buf[i] != 0) return 0; // найден ненулевой элемент
    }
    return 1; // все нули
}

/* Called with IRQs masked. A source must remain a completed, retained slot and
   outside BOTH DMA banks: hardware keeps running even while IRQs are masked.
   Rechecking after an unmasked copy detects recycling, restart and a nested
   consumer. The caller leaves its sequence pending when validation fails. */
static inline uint8_t __attribute__((always_inline, optimize("O2"))) adc_snapshot_channel_valid(uint8_t ch, uint32_t seq,
                                          uint32_t generation)
{
    if (generation != s_capture_generation || s_adc_dbm_fault_pending != 0u) return 0u;
    uint32_t pending = adc_ch_wr_seq[ch] - seq;
    if (pending == 0u || pending > (FIFO_FRAMES - 2u)) return 0u;
    ADC_HandleTypeDef *hadc = (ch == 0u) ? s_adc1 : s_adc2;
    if (hadc == NULL || hadc->DMA_Handle == NULL) return 0u;
    DMA_Stream_TypeDef *stream = (DMA_Stream_TypeDef*)hadc->DMA_Handle->Instance;
    if (stream == NULL) return 0u;
    uint32_t index = seq & (FIFO_FRAMES - 1u);
    uint32_t source = (uint32_t)((ch == 0u) ? adc1_buffers[index] : adc2_buffers[index]);
    return (uint8_t)((stream->M0AR != source) && (stream->M1AR != source));
}

static inline uint8_t __attribute__((always_inline, optimize("O2"))) adc_snapshot_pair_valid(uint32_t seq, uint32_t generation)
{
    uint32_t pending = frame_wr_seq - seq;
    if (frame_rd_seq != seq || pending == 0u || pending > (FIFO_FRAMES - 2u)) return 0u;
    if (!adc_snapshot_channel_valid(0u, seq, generation)) return 0u;
#if !DIAG_SINGLE_ADC1
    if (!adc_snapshot_channel_valid(1u, seq, generation)) return 0u;
#endif
    return 1u;
}

// Получить один кадр конкретного канала (независимая модель). Возвращает 1 если кадр получен.
uint8_t __attribute__((optimize("O2"))) adc_get_frame_ch(uint8_t ch, uint16_t **buf, uint16_t *samples, uint32_t *seq_out) {
    if (ch > 1 || !buf || !samples) return 0;
    uint32_t primask = __get_PRIMASK();
    uint32_t seq = 0u;
    uint32_t index = 0u;
    uint32_t generation = 0u;
    uint16_t snapshot_samples = 0u;

    __disable_irq();
    seq = adc_ch_rd_seq[ch];
    generation = s_capture_generation;
    if (s_snapshot_copy_busy || !adc_snapshot_channel_valid(ch, seq, generation)) {
        __set_PRIMASK(primask);
        return 0;
    }
    index = seq & (FIFO_FRAMES - 1u);
    snapshot_samples = g_active_samples;
    if (snapshot_samples > MAX_FRAME_SAMPLES) {
        snapshot_samples = MAX_FRAME_SAMPLES;
    }

    s_snapshot_copy_busy = 1u;
    __set_PRIMASK(primask);
    /* Keep ADC marker and SYNC IRQs responsive during the full frame copy. */
    {
        uint16_t *src = (ch == 0u) ? adc1_buffers[index] : adc2_buffers[index];
        adc_invalidate_cache_for_buffer(src, snapshot_samples);
        memcpy(s_consumer_snapshot[ch], src,
               (size_t)snapshot_samples * sizeof(uint16_t));
    }
    __disable_irq();
    uint8_t valid = (uint8_t)((adc_ch_rd_seq[ch] == seq) &&
                             adc_snapshot_channel_valid(ch, seq, generation));
    s_snapshot_copy_busy = 0u;
    __set_PRIMASK(primask);
    if (!valid) return 0;
    if (seq_out) { *seq_out = seq; }

    *buf = s_consumer_snapshot[ch];
    *samples = snapshot_samples;
    
    // DEBUG: Проверка лестницы отключена
    #if 0  // ОТКЛЮЧЕНО: маркеры убраны
    static uint32_t last_read_check_ms = 0;
    static uint32_t read_counter = 0;
    uint32_t now_read_ms = HAL_GetTick();
    if (now_read_ms - last_read_check_ms >= 1000 && ch == 0) {  // Только для канала A
        last_read_check_ms = now_read_ms;
        read_counter++;
        uint16_t *pbuf = *buf;
        uint16_t r0 = (g_active_samples > 0) ? pbuf[0] : 0;
        uint16_t r100 = (g_active_samples > 100) ? pbuf[100] : 0;
        uint16_t r200 = (g_active_samples > 200) ? pbuf[200] : 0;
        uint16_t r300 = (g_active_samples > 300) ? pbuf[300] : 0;
        uint16_t r400 = (g_active_samples > 400) ? pbuf[400] : 0;
        printf("[MCU_READ#%lu] CH%u idx=%lu: [0]=%u [100]=%u [200]=%u [300]=%u [400]=%u\r\n",
               (unsigned long)read_counter, ch, (unsigned long)index, r0, r100, r200, r300, r400);
    }
    #endif
    
    // ДИАГНОСТИКА: проверяем буфер на нулевое содержимое (троттлинг логов)
    if (is_buffer_all_zeros(*buf, *samples)) {
        adc_ch_zero_buffers[ch]++;
        static uint32_t last_zero_log_ms[2] = {0,0};
        uint32_t now_ms = HAL_GetTick();
        if ((now_ms - last_zero_log_ms[ch]) >= 1000u) {
            last_zero_log_ms[ch] = now_ms;
            ADC_LOGF("[ADC][DIAG] CH%u: zero buffer detected! seq=%lu idx=%lu zeros_total=%lu\r\n",
                     ch, (unsigned long)seq, (unsigned long)index, (unsigned long)adc_ch_zero_buffers[ch]);
        }
    }
    
    return 1;
}

uint8_t adc_consume_frame_ch(uint8_t ch, uint32_t seq)
{
    if (ch > 1) return 0;
    uint8_t ok = 0;
    __disable_irq();
    if (adc_ch_rd_seq[ch] != adc_ch_wr_seq[ch] && adc_ch_rd_seq[ch] == seq) {
        adc_ch_rd_seq[ch]++;
        ok = 1;
    }
    __enable_irq();
    return ok;
}

uint8_t adc_get_frame(uint16_t **ch1, uint16_t **ch2, uint16_t *samples) {
    if (!ch1 || !ch2 || !samples) {
        ADC_LOGF("[ADC][GET_FRAME] ERROR: ch1/ch2/samples NULL\r\n");
        return 0;
    }
    __disable_irq();
    if (frame_rd_seq == frame_wr_seq) {
        __enable_irq();
        ADC_LOGF("[ADC][GET_FRAME] Нет новых кадров: frame_wr_seq=%lu frame_rd_seq=%lu\r\n", (unsigned long)frame_wr_seq, (unsigned long)frame_rd_seq);
        return 0;
    }
    uint32_t seq = frame_rd_seq++;
    __enable_irq();
    uint32_t index = seq & (FIFO_FRAMES - 1u);
    #if ADC_USB_STAGE_ENABLE
    *ch1 = usb_stage_bufA;
    *ch2 = adc2_buffers[index];
    #else
    *ch1 = adc1_buffers[index];
    *ch2 = adc2_buffers[index];
    #endif
    *samples = g_active_samples;
    ADC_LOGF("[ADC][GET_FRAME] OK: seq=%lu index=%lu samples=%u\r\n", (unsigned long)seq, (unsigned long)index, (unsigned)g_active_samples);
    return 1;
}

// Парный интерфейс + seq (pair seq согласован с frame_wr_seq и s_frame_buffer_idx[])
uint8_t adc_get_frame_pair(uint16_t **ch1, uint16_t **ch2, uint16_t *samples, uint32_t *seq_out) {
    if (!ch1 || !ch2 || !samples) {
        ADC_LOGF("[ADC][GET_FRAME_PAIR] ERROR: ch1/ch2/samples NULL\r\n");
        return 0;
    }
    __disable_irq();
    if (frame_rd_seq == frame_wr_seq) {
        __enable_irq();
        return 0;
    }
    uint32_t seq = frame_rd_seq++;
    if (adc_ch_rd_seq[0] == seq) { adc_ch_rd_seq[0]++; }
    if (adc_ch_rd_seq[1] == seq) { adc_ch_rd_seq[1]++; }
    __enable_irq();
    if (seq_out) { *seq_out = seq; }

    uint32_t index = seq & (FIFO_FRAMES - 1u);
    #if ADC_USB_STAGE_ENABLE
    *ch1 = usb_stage_bufA;
    *ch2 = adc2_buffers[index];
    #else
    *ch1 = adc1_buffers[index];
    *ch2 = adc2_buffers[index];
    #endif
    *samples = g_active_samples;
    return 1;
}

// Строго FIFO-версия парного pop (без usb_stage_bufA)
uint8_t adc_get_frame_pair_fifo(uint16_t **ch1, uint16_t **ch2, uint16_t *samples, uint32_t *seq_out) {
    if (!ch1 || !ch2 || !samples) {
        ADC_LOGF("[ADC][GET_FRAME_PAIR_FIFO] ERROR: ch1/ch2/samples NULL\r\n");
        return 0;
    }
    __disable_irq();
    if (frame_rd_seq == frame_wr_seq) {
        __enable_irq();
        return 0;
    }
    uint32_t seq = frame_rd_seq++;
    if (adc_ch_rd_seq[0] == seq) { adc_ch_rd_seq[0]++; }
    if (adc_ch_rd_seq[1] == seq) { adc_ch_rd_seq[1]++; }
    __enable_irq();
    if (seq_out) { *seq_out = seq; }

    uint32_t index = seq & (FIFO_FRAMES - 1u);
    *ch1 = adc1_buffers[index];
    *ch2 = adc2_buffers[index];
    *samples = g_active_samples;
    return 1;
}

uint8_t __attribute__((optimize("O2"))) adc_peek_frame_pair_fifo(uint16_t **ch1, uint16_t **ch2, uint16_t *samples, uint32_t *seq_out)
{
    if (!ch1 || !ch2 || !samples) {
        ADC_LOGF("[ADC][PEEK_FRAME_PAIR_FIFO] ERROR: ch1/ch2/samples NULL\r\n");
        return 0;
    }
    uint32_t primask = __get_PRIMASK();
    uint32_t seq = 0u;
    uint32_t index = 0u;
    uint32_t generation = 0u;
    uint16_t snapshot_samples = 0u;

    __disable_irq();
    seq = frame_rd_seq;
    generation = s_capture_generation;
    if (s_snapshot_copy_busy || !adc_snapshot_pair_valid(seq, generation)) {
        __set_PRIMASK(primask);
        return 0;
    }
    index = seq & (FIFO_FRAMES - 1u);
    snapshot_samples = g_active_samples;
    if (snapshot_samples > MAX_FRAME_SAMPLES) {
        snapshot_samples = MAX_FRAME_SAMPLES;
    }

    s_snapshot_copy_busy = 1u;
    __set_PRIMASK(primask);
    adc_invalidate_cache_for_buffer(adc1_buffers[index], snapshot_samples);
    adc_invalidate_cache_for_buffer(adc2_buffers[index], snapshot_samples);
    memcpy(s_consumer_snapshot[0], adc1_buffers[index],
           (size_t)snapshot_samples * sizeof(uint16_t));
    memcpy(s_consumer_snapshot[1], adc2_buffers[index],
           (size_t)snapshot_samples * sizeof(uint16_t));
    __disable_irq();
    uint8_t valid = adc_snapshot_pair_valid(seq, generation);
    s_snapshot_copy_busy = 0u;
    __set_PRIMASK(primask);
    if (!valid) return 0;
    if (seq_out) { *seq_out = seq; }

    *ch1 = s_consumer_snapshot[0];
    *ch2 = s_consumer_snapshot[1];
    *samples = snapshot_samples;
    return 1;
}

uint8_t adc_consume_frame_pair_fifo(uint32_t seq)
{
    uint8_t ok = 0;
    __disable_irq();
    if (frame_rd_seq != frame_wr_seq && frame_rd_seq == seq) {
        frame_rd_seq++;
        if (adc_ch_rd_seq[0] == seq) { adc_ch_rd_seq[0]++; }
        if (adc_ch_rd_seq[1] == seq) { adc_ch_rd_seq[1]++; }
        ok = 1;
    }
    __enable_irq();
    return ok;
}

// Peek последнего опубликованного кадра (FIFO), НЕ потребляя FIFO.
// Возвращает самый свежий кадр: seq = frame_wr_seq-1.
uint8_t adc_peek_latest_frame_pair_fifo(uint16_t **ch1, uint16_t **ch2, uint16_t *samples, uint32_t *seq_out) {
    if (!ch1 || !ch2 || !samples) {
        ADC_LOGF("[ADC][PEEK_LATEST_PAIR_FIFO] ERROR: ch1/ch2/samples NULL\r\n");
        return 0;
    }
    __disable_irq();
    uint32_t wr = frame_wr_seq;
    __enable_irq();
    if (wr == 0u) {
        return 0;
    }
    uint32_t seq = wr - 1u;
    if (seq_out) { *seq_out = seq; }

    uint32_t index = seq & (FIFO_FRAMES - 1u);
    *ch1 = adc1_buffers[index];
    *ch2 = adc2_buffers[index];
    *samples = g_active_samples;
    return 1;
}

/* Low priority receiver polarity analysis. All storage is private: diagnostic
   sampling never advances a stream read pointer or pins a rolling DMA slot. */
typedef struct {
    rx_phase_detector_t detector;
    rx_phase_status_t published[2];
    uint16_t samples[2][600];
    int32_t accum[2][6];
    rx_phase_sample_stats_t stats[2];
    uint32_t generation, next_sample_ms, last_publish_ms, last_seq;
    uint32_t frames, drops, last_frame_ms, cycles, max_cycles, serial;
    uint16_t cursor;
    uint8_t wanted_parity, parity, busy, active, was_enabled, have_seq;
} rx_phase_service_t;
__attribute__((section(".ram_dtcm"), aligned(4)))
static rx_phase_service_t s_rx_phase;
__attribute__((section(".ram_dtcm"), aligned(4)))
volatile rx_phase_status_t g_rx_phase_status;
/* Diagnostic profiling switch; default enabled, never changes ADC or TX. */
volatile uint32_t g_rx_phase_enabled=1u;
static uint8_t s_rx_phase_initialized=0u;

static void __attribute__((optimize("O2"))) rx_phase_publish(uint32_t now)
{
    rx_phase_service_t *s=&s_rx_phase;
    rx_phase_status_t *p=&s->published[s->active^1u];
    memset(p,0,sizeof(*p));
    p->magic=RX_PHASE_MAGIC; p->version=1u; p->channels=2u; p->size=sizeof(*p);
    s->serial+=2u; p->seq_begin=s->serial; p->seq_end=s->serial;
    p->uptime_ms=now; p->capture_generation=s->generation;
    p->frames=s->frames; p->drops=s->drops; p->last_frame_ms=s->last_frame_ms;
    p->max_service_cycles=s->max_cycles; p->total_service_cycles=s->cycles;
    p->enabled=g_rx_phase_enabled!=0u;
    memcpy(p->channel,s->detector.channel,sizeof(p->channel));
    for (unsigned ch=0; ch<2; ++ch) {
        /* A low-priority sampler can legitimately yield for part of a block.
           Use the publication period as the freshness bound, rather than
           declaring a coherent 1.5 s estimate stale after only 250 ms. */
        if (!p->enabled || (uint32_t)(now-s->last_frame_ms)>RX_PHASE_BLOCK_MS) {
            p->channel[ch].valid=0;
            p->channel[ch].flags|=RX_PHASE_STALE;
        }
    }
    __DMB();
    s->active^=1u; /* IRQ reader uses the completed, immutable bank. */
    /* Separate seqlock copy for non-halting external SWD inspection. */
    g_rx_phase_status.seq_begin=s->serial|1u;
    __DMB();
    memcpy((void*)&g_rx_phase_status,p,8u);
    memcpy((uint8_t*)(void*)&g_rx_phase_status+12u,(const uint8_t*)p+12u,sizeof(*p)-16u);
    g_rx_phase_status.seq_end=s->serial;
    __DMB();
    g_rx_phase_status.seq_begin=s->serial;
    s->last_publish_ms=now;
}

uint16_t __attribute__((optimize("O2"))) adc_rx_phase_get_status(uint8_t *dst, uint16_t max_len)
{
    if (!dst || max_len<RX_PHASE_STATUS_SIZE) return 0;
    if (!s_rx_phase_initialized) {
        memset(dst,0,RX_PHASE_STATUS_SIZE);
        memcpy(dst,"RXP1",4u); dst[4]=1; dst[5]=2; dst[6]=RX_PHASE_STATUS_SIZE;
        dst[40]=dst[72]=RX_PHASE_UNKNOWN;
        dst[43]=dst[75]=RX_PHASE_COLLECTING;
        return RX_PHASE_STATUS_SIZE;
    }
    memcpy(dst,&s_rx_phase.published[s_rx_phase.active],RX_PHASE_STATUS_SIZE);
    return RX_PHASE_STATUS_SIZE;
}

static uint8_t __attribute__((optimize("O2"))) rx_phase_capture(void)
{
    rx_phase_service_t *s=&s_rx_phase;
    uint32_t generation=s_capture_generation;
    uint32_t wr=frame_wr_seq;
    if (wr<3u || generation!=s->generation) return 0;
    uint32_t seq=wr-1u;
    uint32_t index=seq&(FIFO_FRAMES-1u);
    if ((s_frame_buffer_idx[index]&1u)!=s->wanted_parity) {
        --seq; index=seq&(FIFO_FRAMES-1u);
    }
    uint8_t parity=s_frame_buffer_idx[index]&1u;
    if (s->have_seq && (int32_t)(seq-s->last_seq)<=0) return 0;
    if (!adc_snapshot_channel_valid(0u,seq,generation) ||
        !adc_snapshot_channel_valid(1u,seq,generation)) return 0;
    __DMB();
    adc_invalidate_cache_for_buffer(adc1_buffers[index],600u);
    adc_invalidate_cache_for_buffer(adc2_buffers[index],600u);
    memcpy(s->samples[0],adc1_buffers[index],sizeof(s->samples[0]));
    memcpy(s->samples[1],adc2_buffers[index],sizeof(s->samples[1]));
    __DMB();
    if (!adc_snapshot_channel_valid(0u,seq,generation) ||
        !adc_snapshot_channel_valid(1u,seq,generation) ||
        parity!=(s_frame_buffer_idx[index]&1u)) return 0;
    s->parity=parity; s->wanted_parity=parity^1u;
    s->last_seq=seq; s->have_seq=1u;
    memset(s->accum,0,sizeof(s->accum));
    memset(s->stats,0,sizeof(s->stats));
    s->stats[0].roi_min=s->stats[1].roi_min=65535u;
    s->cursor=20u; s->busy=1u;
    return 1;
}

void __attribute__((optimize("O2"))) adc_rx_phase_service(void)
{
    /* No IRQ masking, waits, USB calls or TX-control dependencies here. */
    uint32_t now=HAL_GetTick();
    rx_phase_service_t *s=&s_rx_phase;
    if (!s_rx_phase_initialized) {
        memset(s,0,sizeof(*s));
        memset((void*)&g_rx_phase_status,0,sizeof(g_rx_phase_status));
        s->generation=s_capture_generation;
        s->was_enabled=(g_rx_phase_enabled!=0u);
        rx_phase_detector_reset(&s->detector,now);
        rx_phase_publish(now);
        s_rx_phase_initialized=1u;
    }
    uint8_t enabled=g_rx_phase_enabled!=0u;
    if (s->generation!=s_capture_generation || enabled!=s->was_enabled) {
        s->generation=s_capture_generation; s->was_enabled=enabled;
        s->busy=0; s->have_seq=0; s->next_sample_ms=now;
        rx_phase_detector_reset(&s->detector,now);
        rx_phase_publish(now);
    }
    uint16_t rate=adc_stream_get_buf_rate();
    uint8_t supported=(g_active_samples==600u && rate>=399u && rate<=401u);
    if (!enabled || !supported) {
        s->busy=0;
        if ((uint32_t)(now-s->last_publish_ms)>=500u) {
            rx_phase_detector_reset(&s->detector,now);
            if (!supported)
                for (unsigned ch=0; ch<2; ++ch)
                    s->detector.channel[ch].flags|=RX_PHASE_UNSUPPORTED;
            rx_phase_publish(now);
        }
        return;
    }
    if (!s->busy && (int32_t)(now-s->next_sample_ms)<0 &&
        (uint32_t)(now-s->detector.block_start_ms)<500u) return;
    uint32_t started=DWT->CYCCNT;
    uint8_t publish=rx_phase_detector_tick(&s->detector,now);
    if (s->busy) {
        uint16_t stop=s->cursor+24u;
        if (s->cursor<240u) {
            if (stop>240u) stop=240u;
            rx_phase_project_chunk(s->samples,s->cursor,stop,s->accum);
            for (unsigned ch=0; ch<2; ++ch)
                for (unsigned i=s->cursor; i<stop; ++i)
                    if (s->samples[ch][i]==0u || s->samples[ch][i]==65535u) ++s->stats[ch].clipped;
        } else {
            if (stop>500u) stop=500u;
            for (unsigned ch=0; ch<2; ++ch)
                for (unsigned i=s->cursor; i<stop; ++i) {
                    uint16_t value=s->samples[ch][i];
                    if (value==0u || value==65535u) ++s->stats[ch].roi_clipped;
                    if (value<s->stats[ch].roi_min) s->stats[ch].roi_min=value;
                    if (value>s->stats[ch].roi_max) s->stats[ch].roi_max=value;
                }
        }
        s->cursor=stop;
        if (stop==240u) s->cursor=300u;
        if (stop==500u) {
            rx_phase_detector_add(&s->detector,s->accum,s->parity,s->stats);
            ++s->frames; s->last_frame_ms=now; s->busy=0;
        }
    } else if ((int32_t)(now-s->next_sample_ms)>=0) {
        s->next_sample_ms=now+25u;
        if (!rx_phase_capture()) ++s->drops;
    }
    /* Include publication in the measured work; published cycle counters
       include all completed earlier invocations, including their IRQ time. */
    if (publish) rx_phase_publish(now);
    uint32_t elapsed=DWT->CYCCNT-started;
    s->cycles+=elapsed;
    if (elapsed>s->max_cycles) s->max_cycles=elapsed;
}

void adc_stream_get_debug(adc_stream_debug_t *out) {
    if (!out) return;
    out->frame_wr_seq = frame_wr_seq;
    out->frame_rd_seq = frame_rd_seq;
    out->frame_overflow_drops = frame_overflow_drops;
    out->frame_backlog_max = frame_backlog_max;
    out->dma_half0 = dma_half0; out->dma_full0 = dma_full0;
    out->dma_half1 = dma_half1; out->dma_full1 = dma_full1;
    out->ch_wr_seq[0] = adc_ch_wr_seq[0];
    out->ch_wr_seq[1] = adc_ch_wr_seq[1];
    out->ch_rd_seq[0] = adc_ch_rd_seq[0];
    out->ch_rd_seq[1] = adc_ch_rd_seq[1];
    out->ch_overflow_drops[0] = adc_ch_overflow_drops[0];
    out->ch_overflow_drops[1] = adc_ch_overflow_drops[1];
    out->ch_zero_buffers[0] = adc_ch_zero_buffers[0];
    out->ch_zero_buffers[1] = adc_ch_zero_buffers[1];
    out->last_full0_ms = adc_last_full0_ms;
    out->publish_count = adc_publish_count;
    out->last_publish_ms = adc_last_publish_ms;
    out->restart_attempts = adc_restart_attempts;
    out->restart_success = adc_restart_success;
    out->restart_suppressed_live = s_adc_restart_suppressed_live;
    out->restart_reason = s_adc_restart_reason;
    out->restart_ndtr_a = s_adc_restart_ndtr_a;
    out->restart_ndtr_b = s_adc_restart_ndtr_b;
    out->restart_publish_age_ms = s_adc_restart_publish_age_ms;
    out->tc_rearm_failures = s_adc_tc_rearm_failures;
    out->publish_gap_max_ms = adc_publish_gap_max_ms;
    out->publish_gap_over_10ms = adc_publish_gap_over_10ms;
    out->active_samples = g_active_samples;
    out->reserved = 0;
}

// Получить номер буфера по seq для передачи в GUI (0-7)
// ВАЖНО: seq здесь используется как «dma_seq» (поканальный или парный),
// и должен маппиться на тот же FIFO слот, что и adc_get_frame_ch()/adc_get_frame_pair(): index = seq & (FIFO_FRAMES-1).
uint8_t adc_get_buffer_parity(uint32_t seq) {
    uint32_t index = seq & (FIFO_FRAMES - 1u);
    /* Возвращаем метку опубликованной пары, сохранённую вместе с frame_wr_seq.
       Не читаем s_buffer_parity[] напрямую: этот DMA-ring может быть уже перезаписан,
       если USB/AVG обработчик временно отстал от входного потока. */
    return (uint8_t)(s_frame_buffer_idx[index] & 0x07u);
}

// DEBUG: dump trace из non-ISR контекста
void adc_dump_buffer_trace(void) {
    printf("\r\n=== BUFFER TRACE (first %lu writes) ===\r\n", (unsigned long)s_dbg_trace_wr_pos);
    uint32_t limit = (s_dbg_trace_wr_pos < DBG_TRACE_SIZE) ? s_dbg_trace_wr_pos : DBG_TRACE_SIZE;
    for (uint32_t i = 0; i < limit; i++) {
        printf("[%lu] safe_idx=%lu buf_idx=%u global=%lu\r\n",
               (unsigned long)i,
               (unsigned long)s_dbg_trace_seq[i],
               s_dbg_trace_bufidx[i],
               (unsigned long)s_dbg_trace_global[i]);
    }
    printf("\r\n=== s_buffer_parity[] array (ring-indexed, FIFO_FRAMES=%u) ===\r\n", FIFO_FRAMES);
    for (uint32_t i = 0; i < FIFO_FRAMES; i++) {
        printf("s_buffer_parity[%lu] = %u\r\n", (unsigned long)i, s_buffer_parity[i]);
    }
    
    /* s_frame_buffer_idx[] вывод отключён: слишком шумит в COM4 */
    
    printf("s_global_buffer_counter = %lu\r\n", (unsigned long)s_global_buffer_counter);
    printf("\r\n");
}

// Weak hook (can be overridden in higher-level module, e.g. USB)
void __attribute__((weak)) adc_stream_on_new_frames(uint32_t frames_added) { (void)frames_added; }

// --- HAL callbacks ---
/* Общий обработчик TC: DMA CIRCULAR автоматически переключил буфер, публикуем кадр @ 400Hz.
   Чётность кадра (even/odd) записывается в поканальные метаданные для USB передачи. */
/* TC-DRIVEN MODE function (not used in TIM2-DRIVEN mode) */
#if 0  // Отключено: используется только в TC-DRIVEN режиме
static void adc_handle_tc(uint8_t tc_bit) {
    /* TC_DRIVEN MODE: DMA NORMAL останавливается после TC, перезапускаем на следующий буфер */
    
    /* счётчик TC событий (для статистики/диагностики) */
    static uint32_t tc_call_count = 0;
    tc_call_count++;

#if ADC_ISR_LOG_ENABLE
    // ДИАГНОСТИКА: логируем первые 10 вызовов (только если включено)
    if (tc_call_count <= 10) {
        printf("[ADC][TC_HANDLE] #%lu tc_bit=0x%02X\r\n", (unsigned long)(tc_call_count-1u), tc_bit);
    }
#endif
    
    // Определяем готовый индекс буфера и следующий для перезапуска
    uint32_t done_idx = s_next_ring_index;
    uint32_t next_idx = (done_idx + 1u) & (FIFO_FRAMES - 1u);
    
    /* buffer_index уже сохранён в TIM2 callback для этого буфера, просто читаем */
    uint8_t buffer_index = s_buffer_parity[done_idx] & 0x07;  // Ограничиваем 0-7 на всякий случай
    
    // DEBUG: Временная диагностика для первых 80 кадров
    static uint32_t diag_count[8] = {0};  // Счётчики для каждого буфера
    if (diag_count[buffer_index] < 10) {
        printf("[ADC_TC] buf#%lu buffer_index=%u tc_bit=0x%02X\r\n", 
               (unsigned long)done_idx, (unsigned)buffer_index, (unsigned)tc_bit);
        diag_count[buffer_index]++;
    }
    
    uint32_t total_samples = (uint32_t)g_active_samples;
    
    // Публикуем кадры для каждого канала с маркером чётности
    uint32_t frames_added = 0;
    if (tc_bit & 0x01u) {  // ADC1 (Channel A)
        // Перезапуск DMA на следующий буфер (минимум printf в ISR!)
        HAL_ADC_Stop_DMA(s_adc1);
        HAL_StatusTypeDef st = HAL_ADC_Start_DMA(s_adc1, (uint32_t*)adc1_buffers[next_idx], total_samples);
        if (st == HAL_OK) {
            frames_added++;
            adc_ch_wr_seq[0]++;  // Инкремент ПОСЛЕ успешного перезапуска
        }
        // Диагностика только при явном включении (ISR)
#if ADC_ISR_LOG_ENABLE
        if (tc_call_count <= 3) {
            printf("[ADC][TC] ADC1 buf#%lu st=%d\r\n", (unsigned long)next_idx, (int)st);
        }
#endif
    }
    
    #if !DIAG_SINGLE_ADC1
    if (tc_bit & 0x02u) {  // ADC2 (Channel B)
        // Перезапуск DMA на следующий буфер
        HAL_ADC_Stop_DMA(s_adc2);
        HAL_StatusTypeDef st = HAL_ADC_Start_DMA(s_adc2, (uint32_t*)adc2_buffers[next_idx], total_samples);
        if (st == HAL_OK) {
            frames_added++;
            adc_ch_wr_seq[1]++;  // Инкремент ПОСЛЕ успешного перезапуска
        }
        // Диагностика только при явном включении (ISR)
#if ADC_ISR_LOG_ENABLE
        if (tc_call_count <= 3) {
            printf("[ADC][TC] ADC2 buf#%lu st=%d\r\n", (unsigned long)next_idx, (int)st);
        }
#endif
    }
    #endif
    
    /* 1 Гц диагностика перенесена в adc_stream_watchdog() (main context). */
    
    // Переключаем на следующий буфер ПОСЛЕ перезапуска DMA
    s_next_ring_index = next_idx;
    
    // Cache invalidation НЕЛЬЗЯ использовать - вызывает HardFault
    // TODO: Использовать некэшируемую память или отключить D-cache
    
    // Уведомляем USB о новых кадрах
    adc_stream_on_new_frames(frames_added);
}
#endif  // #if 0 (TC-DRIVEN mode function)

void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc) {
    (void)hadc; // Half не используем
    return;
    
    #if 0  // Старый код с обработкой Half Transfer (не нужен в NORMAL mode)
    if (hadc->Instance == (s_adc1 ? s_adc1->Instance : NULL)) {
    dma_half0++; dbg_dma1_half_count++;
#if DIAG_DMA_CALLBACK_LIMIT
    if(dbg_dma1_half_count > DIAG_DMA_CALLBACK_LIMIT){
        HAL_ADC_Stop_DMA(s_adc1);
        printf("[ADC][WARN] HALF limit reached -> stop DMA (half=%lu full=%lu)\r\n",
           (unsigned long)dbg_dma1_half_count,
           (unsigned long)dbg_dma1_full_count);
        return; /* не продолжаем обработку */
    }
#endif
        /* Half-Complete игнорируем (IRQ отключён), оставлено для счётчиков */
        (void)0;
    } else if (hadc->Instance == (s_adc2 ? s_adc2->Instance : NULL)) {
        dma_half1++; // используем только для диагностики
    }
    #endif  // #if 0
}

/* ========================================================================
   TIM2 callback: переключение буферов строго по окну TIM2 (CH1 FALL)
   ======================================================================== */
void adc_stream_tim2_switch_buffers(void) {
    /* TIM2-DRIVEN MODE: переключение буферов синхронизировано с TIM2 (спадающий фронт CH1).
       Это обеспечивает что каждый буфер начинается с одной и той же фазы сигнала,
       устраняя "плывущую" осциллограмму. */
    
    /* Счётчики для диагностики */
    static uint32_t tim2_switch_call_count = 0;
    static uint32_t tim2_switch_ok_count = 0;
    static uint32_t tim2_switch_busy_count = 0;
    static uint32_t last_log_ms = 0;
    static uint8_t first_call_logged = 0;
    static uint32_t last_busy_ndtr_a = 0;
    static uint32_t last_busy_ndtr_b = 0;
    
    // ДИАГНОСТИКА: логируем ПЕРВЫЙ вызов чтобы убедиться что функция вызывается
    if (!first_call_logged) {
        printf("[TIM2] FIRST switch_buffers call!\r\n");
        first_call_logged = 1;
    }
    
    tim2_switch_call_count++;
    uint32_t now_ms = HAL_GetTick();
    if (now_ms - last_log_ms >= 1000) {
        last_log_ms = now_ms;
        ADC_LOGF("[TIM2] switch_buffers calls/sec: %lu ok/sec: %lu busy/sec: %lu (last busy NDTR A=%lu B=%lu)\r\n",
                 (unsigned long)tim2_switch_call_count,
                 (unsigned long)tim2_switch_ok_count,
                 (unsigned long)tim2_switch_busy_count,
                 (unsigned long)last_busy_ndtr_a,
                 (unsigned long)last_busy_ndtr_b);
        tim2_switch_call_count = 0;
        tim2_switch_ok_count = 0;
        tim2_switch_busy_count = 0;
    }
    
    /* ЛОГИКА TIM2-DRIVEN (восстановлена для синхронизации осциллограммы) */
    #if 1

    DMA_Stream_TypeDef *dma1 = (DMA_Stream_TypeDef*)s_adc1->DMA_Handle->Instance;
    #if !DIAG_SINGLE_ADC1
    DMA_Stream_TypeDef *dma2 = (DMA_Stream_TypeDef*)s_adc2->DMA_Handle->Instance;
    #endif

    const uint32_t done_idx = s_next_ring_index;
    const uint32_t next_idx = (done_idx + 1u) & (FIFO_FRAMES - 1u);
    const uint32_t total_samples = (uint32_t)g_active_samples;
    
    /* Переключаемся только когда оба DMA завершили текущий буфер (NDTR==0).
       ВАЖНО: не трогаем счётчики фаз/буферов, если DMA ещё занят — иначе получаем «дрожание» фаз. */
    if (dma1->NDTR != 0) {
        tim2_switch_busy_count++;
        last_busy_ndtr_a = dma1->NDTR;
        #if !DIAG_SINGLE_ADC1
        last_busy_ndtr_b = dma2->NDTR;
        #endif
        return;
    }
    #if !DIAG_SINGLE_ADC1
    if (dma2->NDTR != 0) {
        tim2_switch_busy_count++;
        last_busy_ndtr_a = dma1->NDTR;
        last_busy_ndtr_b = dma2->NDTR;
        return;
    }
    #endif

    /* УСПЕХ: пара готова → фиксируем событие и только теперь двигаем фазовый счётчик */
    tim2_switch_ok_count++;
    s_global_buffer_counter++;
    // DEBUG: Выводим каждые 200 успешных переключений
    static uint32_t dbg_tim2_ok_counter = 0;
    if (++dbg_tim2_ok_counter % 200 == 0) {
        printf("[TIM2][OK] global_counter=%lu, buf_idx=%u\r\n",
               s_global_buffer_counter, (uint8_t)(s_global_buffer_counter & 0x07));
    }

    // ВРЕМЕННО ОТКЛЮЧЕНО: guard проверка и заполнение тормозят @ 200Hz
    uint8_t guard_bad_done = 0; // adc_check_guard_idx(done_idx, "tim2-done");
    // adc_check_guard_idx(next_idx, "tim2-pre");
    // adc_fill_guard_for_idx(next_idx);  // 32 записи × 200Hz = 6400 операций/сек

    /* DMA завершил текущий буфер (NDTR==0). Фиксируем кадр как готовый и решаем: продолжать или пауза. */
    HAL_ADC_Stop_DMA(s_adc1);
    #if !DIAG_SINGLE_ADC1
    HAL_ADC_Stop_DMA(s_adc2);
    #endif

    /* Обновляем поканальные счётчики (для USB таска) */
    adc_ch_wr_seq[0]++;
    #if !DIAG_SINGLE_ADC1
    adc_ch_wr_seq[1]++;
    #endif

     /* Метаданные для GUI/USB: номер DMA-буфера 0..7 для этого FIFO слота.
         ВАЖНО: используем ИНДЕКС буфера, а не глобальный счётчик.
         Иначе после reboot "чётность"/phase смещается, и DC начинает применяться не к той фазе. */
     {
         /* Сохраняем 0..7 (для GUI), но LSB (even/odd) берём от PA3. */
         uint8_t parity = adc_parity_from_pa3();
         uint8_t buffer_index = (uint8_t)((done_idx & 0x06u) | (parity & 1u));
         s_buffer_parity[done_idx & (FIFO_FRAMES - 1u)] = buffer_index;
     }

    /* Cache maintenance для только что заполненного буфера */
    adc_invalidate_cache_for_buffer(adc1_buffers[done_idx], total_samples);
    #if !DIAG_SINGLE_ADC1
    adc_invalidate_cache_for_buffer(adc2_buffers[done_idx], total_samples);
    #endif

    uint32_t backlogA = adc_ch_wr_seq[0] - adc_ch_rd_seq[0];
    uint32_t backlogB = 0;
    #if !DIAG_SINGLE_ADC1
    backlogB = adc_ch_wr_seq[1] - adc_ch_rd_seq[1];
    #endif

    /* USB/backpressure never gates acquisition. Keep only the newest pending
       frames and immediately reuse the freed DMA ring slot. */
    (void)backlogA;
    (void)backlogB;
    adc_trim_reader_backlog(&adc_ch_rd_seq[0], adc_ch_wr_seq[0],
                            &adc_ch_overflow_drops[0]);
    #if !DIAG_SINGLE_ADC1
    adc_trim_reader_backlog(&adc_ch_rd_seq[1], adc_ch_wr_seq[1],
                            &adc_ch_overflow_drops[1]);
    #endif
    adc_stream_paused = 0u;

    /* Есть место — запускаем DMA на следующий буфер */
    /* NDTR страховка: программируем фактическое N только перед новым стартом */
    dma1->NDTR = total_samples;
    HAL_ADC_Start_DMA(s_adc1, (uint32_t*)adc1_buffers[next_idx], total_samples);
    #if !DIAG_SINGLE_ADC1
    dma2->NDTR = total_samples;
    HAL_ADC_Start_DMA(s_adc2, (uint32_t*)adc2_buffers[next_idx], total_samples);
    #endif

    s_last_started_idx = next_idx;
    s_next_ring_index = next_idx;
    s_tc_mask = 0;
    adc_last_full0_ms = HAL_GetTick();
    adc_last_full1_ms = adc_last_full0_ms;

    // ОТКЛЮЧЕНО: guard проверка не критична для работы
    #if 0
    if (guard_bad_done && ADC_GUARD_DROP_ON_MISMATCH) {
        frame_overflow_drops++;
        // ОТКЛЮЧЕНО: printf тормозит @ 200Hz
        // printf("[ADC_DROP] guard mismatch idx=%lu -> drop frame\r\n", (unsigned long)done_idx);
    }
    if (guard_bad_done && !ADC_GUARD_DROP_ON_MISMATCH) {
        adc_guard_bypass++;
        // ОТКЛЮЧЕНО: printf тормозит @ 200Hz
        // printf("[ADC_WARN] guard mismatch idx=%lu -> publish anyway\r\n", (unsigned long)done_idx);
    }
    #endif
    (void)guard_bad_done; // suppress unused warning

    /* (lossless/backpressure) overflow drops removed */

    // ========== ДИАГНОСТИКА: Сравнение данных EVEN vs ODD (БЕЗОПАСНО - после DMA check) ==========
    static uint32_t dbg_sample_count = 0;
    static uint32_t even_sum[5] = {0};  // Суммы для EVEN: [0],[1],[2],[100],[299]
    static uint32_t odd_sum[5] = {0};   // Суммы для ODD
    static uint32_t even_count = 0;
    static uint32_t odd_count = 0;
    
    if (dbg_sample_count < 50) {  // Собираем данные с первых 50 буферов (25 EVEN + 25 ODD)
        uint8_t current_buffer_index = s_buffer_parity[done_idx] & 0x07;  // 0-7, ограничиваем
        uint8_t current_parity = current_buffer_index & 1;  // 0=even, 1=odd
        
        if (total_samples > 299) {
            uint16_t s0   = adc1_buffers[done_idx][0];
            uint16_t s1   = adc1_buffers[done_idx][1];
            uint16_t s2   = adc1_buffers[done_idx][2];
            uint16_t s100 = adc1_buffers[done_idx][100];
            uint16_t s299 = adc1_buffers[done_idx][299];
            
            if (current_parity == 0) {  // EVEN
                even_sum[0] += s0;
                even_sum[1] += s1;
                even_sum[2] += s2;
                even_sum[3] += s100;
                even_sum[4] += s299;
                even_count++;
            } else {  // ODD
                odd_sum[0] += s0;
                odd_sum[1] += s1;
                odd_sum[2] += s2;
                odd_sum[3] += s100;
                odd_sum[4] += s299;
                odd_count++;
            }
        }
        
        dbg_sample_count++;
        
        // После сбора 50 буферов выводим сравнение
        if (dbg_sample_count == 50 && even_count > 0 && odd_count > 0) {
            printf("\r\n[ADC_PHASE_COMPARE] Collected %lu EVEN + %lu ODD buffers\r\n",
                   (unsigned long)even_count, (unsigned long)odd_count);
            printf("  EVEN averages: [0]=%lu [1]=%lu [2]=%lu [100]=%lu [299]=%lu\r\n",
                   even_sum[0]/even_count, even_sum[1]/even_count, even_sum[2]/even_count,
                   even_sum[3]/even_count, even_sum[4]/even_count);
            printf("  ODD  averages: [0]=%lu [1]=%lu [2]=%lu [100]=%lu [299]=%lu\r\n",
                   odd_sum[0]/odd_count, odd_sum[1]/odd_count, odd_sum[2]/odd_count,
                   odd_sum[3]/odd_count, odd_sum[4]/odd_count);
            
            // Вычисляем разницу
            int32_t diff0 = (int32_t)(even_sum[0]/even_count) - (int32_t)(odd_sum[0]/odd_count);
            int32_t diff1 = (int32_t)(even_sum[1]/even_count) - (int32_t)(odd_sum[1]/odd_count);
            int32_t diff100 = (int32_t)(even_sum[3]/even_count) - (int32_t)(odd_sum[3]/odd_count);
            
            printf("  Differences: [0]=%ld [1]=%ld [100]=%ld\r\n", diff0, diff1, diff100);
            
            if (diff0 == 0 && diff1 == 0 && diff100 == 0) {
                printf("  *** WARNING: EVEN and ODD data are IDENTICAL! ***\r\n");
                printf("  *** PA2 meander exists but doesn't affect ADC signal ***\r\n");
            } else {
                printf("  OK: EVEN and ODD data differ (PA2 modulates signal)\r\n");
            }
            printf("\r\n");
        }
    }

    // PERFORMANCE CRITICAL: minmax scan отключён (480k ops/sec @ 200Hz × 1200 samples × 2 channels)
    // Эта проверка тормозила систему, снижая FPS со 160 до 125
    #if 0
    /* Диагностика: вычисляем min/max и индекс max для кадра (помогает локализовать всплески) */
    uint16_t a_min=0, a_max=0, a_imax=0, b_min=0, b_max=0, b_imax=0;
    adc_scan_minmax(adc1_buffers[done_idx], (uint16_t)total_samples, &a_min, &a_max, &a_imax);
    #if !DIAG_SINGLE_ADC1
    adc_scan_minmax(adc2_buffers[done_idx], (uint16_t)total_samples, &b_min, &b_max, &b_imax);
    #else
    b_min = b_max = b_imax = 0;
    #endif

    /* Жёстко отбрасываем кадр, если в нём есть выброс > 12 бит (признак повреждения памяти) */
    if ((a_max > 4095u) || (b_max > 4095u)) {
        frame_overflow_drops++;
        // ОТКЛЮЧЕНО: printf тормозит @ 200Hz
        // printf("[ADC_DROP] spike>4095 idx=%lu Amax=%u Bmax=%u\r\n",
        //        (unsigned long)done_idx, (unsigned)a_max, (unsigned)b_max);
    }
    uint32_t spike_log_now = HAL_GetTick();
    adc_last_min[0] = a_min; adc_last_max[0] = a_max; adc_last_max_idx[0] = a_imax; adc_last_max_tick[0] = spike_log_now;
    adc_last_min[1] = b_min; adc_last_max[1] = b_max; adc_last_max_idx[1] = b_imax; adc_last_max_tick[1] = spike_log_now;
    
    // ОТКЛЮЧЕНО: spike logging тормозит @ 200Hz (каждый кадр с max>4000 вызывает ~200ms printf)
    #if 0
    /* Лимитированный лог крупных всплесков для локализации артефактов */
    if((a_max > 4000u) || (b_max > 4000u)){
        static uint32_t last_spike_log_ms = 0;
        if(spike_log_now - last_spike_log_ms > 500u){
            last_spike_log_ms = spike_log_now;
            uint16_t a_win[9] = {0}; uint16_t b_win[9] = {0};
            uint16_t ia0 = (a_imax>4)? (uint16_t)(a_imax-4) : 0;
            uint16_t ib0 = (b_imax>4)? (uint16_t)(b_imax-4) : 0;
            for(uint16_t k=0;k<9;k++){
                uint16_t ia = (uint16_t)(ia0 + k); if(ia < total_samples) a_win[k] = adc1_buffers[done_idx][ia];
                uint16_t ib = (uint16_t)(ib0 + k); if(ib < total_samples) b_win[k] = adc2_buffers[done_idx][ib];
            }
            printf("[ADC_SPIKE] idx=%lu A_max=%u@%u B_max=%u@%u samples=%lu Awin=%u,%u,%u,%u,%u,%u,%u,%u,%u Bwin=%u,%u,%u,%u,%u,%u,%u,%u,%u\r\n",
                   (unsigned long)done_idx, (unsigned)a_max, (unsigned)a_imax,
                   (unsigned)b_max, (unsigned)b_imax, (unsigned long)total_samples,
                   (unsigned)a_win[0],(unsigned)a_win[1],(unsigned)a_win[2],(unsigned)a_win[3],(unsigned)a_win[4],(unsigned)a_win[5],(unsigned)a_win[6],(unsigned)a_win[7],(unsigned)a_win[8],
                   (unsigned)b_win[0],(unsigned)b_win[1],(unsigned)b_win[2],(unsigned)b_win[3],(unsigned)b_win[4],(unsigned)b_win[5],(unsigned)b_win[6],(unsigned)b_win[7],(unsigned)b_win[8]);
            /* Проверим guard слова текущего буфера на случай утечки защитного шаблона в полезную область */
            printf("[ADC_SPIKE_GUARD] idx=%lu preA=%04x postA=%04x preB=%04x postB=%04x\r\n",
                   (unsigned long)done_idx,
                   (unsigned)adc_guard_pre(adc1_raw, done_idx)[0], (unsigned)adc_guard_post(adc1_raw, done_idx)[0],
                   (unsigned)adc_guard_pre(adc2_raw, done_idx)[0], (unsigned)adc_guard_post(adc2_raw, done_idx)[0]);
        }
    }
    #endif
    #endif  // minmax scan disabled

#if ADC_USB_STAGE_ENABLE
    /* КРИТИЧНО: DMA пишет в adc1/adc2_buffers минуя D-cache. 
       Перед memcpy (CPU read) ОБЯЗАТЕЛЬНО инвалидируем cache → чтение из RAM */
    SCB_InvalidateDCache_by_Addr((uint32_t*)adc1_buffers[done_idx], total_samples * sizeof(uint16_t));
    SCB_InvalidateDCache_by_Addr((uint32_t*)adc2_buffers[done_idx], total_samples * sizeof(uint16_t));
    memcpy(usb_stage_bufA, adc1_buffers[done_idx], total_samples * sizeof(uint16_t));
    memcpy(usb_stage_bufB, adc2_buffers[done_idx], total_samples * sizeof(uint16_t));
    adc_stage_crc_a = adc_crc16_le(usb_stage_bufA, (uint16_t)total_samples);
    adc_stage_crc_seq = frame_wr_seq + 1u;
    adc_flush_cache_for_buffer(usb_stage_bufA, total_samples);
    adc_flush_cache_for_buffer(usb_stage_bufB, total_samples);
#else
    adc_flush_cache_for_buffer(adc1_buffers[done_idx], total_samples);
#endif
    #if !DIAG_SINGLE_ADC1
    adc_flush_cache_for_buffer(adc2_buffers[done_idx], total_samples);
    #endif

    // ВАЖНО: Сохраняем buffer_index ЗДЕСЬ (в момент готовности пары),
    // чтобы он точно соответствовал данным. Берём индекс DMA-буфера (done_idx%8).
    /* Для согласования с внешней модуляцией: parity берём по PA3 (PA3=1 -> even). */
    uint8_t buffer_index = (uint8_t)((done_idx & 0x06u) | (adc_parity_from_pa3() & 1u));
    uint32_t safe_done_idx = done_idx & (FIFO_FRAMES - 1u);
    s_buffer_parity[safe_done_idx] = buffer_index;
    
    // DEBUG: Выводим каждые 200 сохранений
    static uint32_t dbg_save_counter = 0;
    if (++dbg_save_counter % 200 == 0) {
         printf("[SAVE] global_counter=%lu, buf_idx=%u, done_idx=%lu\r\n", 
             s_global_buffer_counter, buffer_index, done_idx);
    }
    
    s_pair_ready_mask[done_idx] = READY_MASK_FULL;
    adc_mark_ready_and_publish(READY_MASK_FULL);
    #endif  /* #if 0 - конец старой TIM2-driven логики */
}

/* ========================================================================
   СТАРАЯ СХЕМА: DMA TC callback (теперь не используется для переключения)
   ======================================================================== */
__attribute__((optimize("O2"))) void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
    if (!hadc) return;

    uint8_t bit = 0;
    if (hadc->Instance == (s_adc1 ? s_adc1->Instance : NULL)) {
        bit = 0x01u;
        dma_full0++;
        adc_last_full0_ms = HAL_GetTick();
    }
    #if !DIAG_SINGLE_ADC1
    else if (hadc->Instance == (s_adc2 ? s_adc2->Instance : NULL)) {
        bit = 0x02u;
        dma_full1++;
        adc_last_full1_ms = HAL_GetTick();
    }
    #endif
    else {
        return;
    }

    if (s_adc_dbm_fault_pending != 0u) return;

    /* CT already points at the NEXT active bank when TC fires. Recycle only
       the just-completed, inactive bank, before any publication/LED work.
       No ADC stop, DMA disable, timer gating, copy, scan or wait occurs here. */
    DMA_Stream_TypeDef *stream = (DMA_Stream_TypeDef*)hadc->DMA_Handle->Instance;
    uint32_t dma_cr = stream->CR;
    uint32_t done_addr = (dma_cr & DMA_SxCR_CT) ? stream->M0AR : stream->M1AR;
    uint16_t (*buffers)[MAX_FRAME_SAMPLES] = (bit == 0x01u) ? adc1_buffers : adc2_buffers;
    uint32_t base = (uint32_t)&buffers[0][0];
    uint32_t stride = (uint32_t)sizeof(buffers[0]);
    if (((dma_cr & DMA_SxCR_DBM) == 0u) || (done_addr < base) ||
        ((done_addr - base) >= FIFO_FRAMES * stride) ||
        (((done_addr - base) % stride) != 0u)) {
        s_adc_tc_rearm_failures++;
        s_adc_dbm_fault_pending = 1u;
        return;
    }
    uint32_t done_idx = adc_addr_to_index(done_addr, buffers);
    uint32_t channel = (bit == 0x01u) ? 0u : 1u;
    if ((done_idx != (adc_ch_wr_seq[channel] & (FIFO_FRAMES - 1u))) ||
        ((s_pair_ready_mask[done_idx] & bit) != 0u)) {
        /* A lost TC must not silently pair data from different frame periods. */
        s_adc_tc_rearm_failures++;
        s_adc_dbm_fault_pending = 1u;
        return;
    }
    uint32_t future_idx = (done_idx + 2u) & (FIFO_FRAMES - 1u);
    if ((dma_cr & DMA_SxCR_CT) != 0u) {
        stream->M0AR = (uint32_t)buffers[future_idx];
    } else {
        stream->M1AR = (uint32_t)buffers[future_idx];
    }
    s_pair_ready_mask[done_idx] |= bit;
    s_tc_mask |= bit;

    /* Обновляем поканальные счётчики (для adc_get_frame_ch) */
    if (bit & 0x01u) {
        adc_ch_wr_seq[0]++;
        adc_trim_reader_backlog(&adc_ch_rd_seq[0], adc_ch_wr_seq[0],
                                &adc_ch_overflow_drops[0]);
    }
    #if !DIAG_SINGLE_ADC1
    if (bit & 0x02u) {
        adc_ch_wr_seq[1]++;
        adc_trim_reader_backlog(&adc_ch_rd_seq[1], adc_ch_wr_seq[1],
                                &adc_ch_overflow_drops[1]);
    }
    #endif

    /* ДИАГНОСТИКА: Отслеживаем случаи когда только один ADC завершился */
    
    /* Pair only matching ring slots. Both DMA streams already capture the
       next buffer in hardware; publication does not rearm either ADC. */
    if (s_pair_ready_mask[done_idx] == READY_MASK_FULL) {
        s_tc_mask = 0;
        s_both_ready++;
        
        /* Маркер фазы теперь обновляется только в adc_marker_pa3_toggle()/adc_marker_set_level(),
           чтобы sync-bit всегда соответствовал реальному GPIO без двойного источника истины. */
        extern TIM_HandleTypeDef htim15;
        

        
        /* Runtime-подстройка TIM15->ARR отключена: базовая частота только из профиля. */

        /* ОТКЛЮЧЕНО: Старая подстройка по фазе - убрана для чистого режима частотной синхронизации */
        /* adc_sync_phase_on_buffer(); */

        /* В ручном поиске частоты не делаем жёсткого выравнивания по sync-фронту,
           иначе фаза движется рывками из-за принудительных подхватов. */
        extern volatile uint8_t sync_edge_seen;
        if (sync_edge_seen) {
            sync_edge_seen = 0u;
        }

/* PA2 update moved to early execution (near PB8 toggle) to minimize skew */
          (void)0;

          /* ВАЖНО: Определяем parity по счетчику буферов после restart */
          /* Первый буфер после restart (s_buffers_since_restart=0) -> 0&1=0 -> инверсия -> 1=ODD */
          /* Второй буфер (s_buffers_since_restart=1) -> 1&1=1 -> инверсия -> 0=EVEN */
          uint8_t parity_bit = (s_buffers_since_restart++ & 1u) ? 0u : 1u;  // 0=EVEN, 1=ODD
          uint8_t buffer_index = (uint8_t)((done_idx & 0x06u) | (parity_bit & 1u));
          s_global_buffer_counter++;
          s_buffer_parity[done_idx] = buffer_index;

          /* PB8 уже переключен выше (для всех буферов) */

        s_next_ring_index = (done_idx + 1u) & (FIFO_FRAMES - 1u);
        /* Попробуем опубликовать готовые подряд пары */
        adc_mark_ready_and_publish(READY_MASK_FULL);
        /* Legacy display diagnostics must not delay the timing marker. */
        /* Частотная синхронизация: корректируем TIM15 по TIM5 */
            extern TIM_HandleTypeDef htim5;
            extern TIM_HandleTypeDef htim15;
            //extern volatile uint8_t vnd_sync_mode_public;
            
            /* Интегральный регулятор фазы (фильтр джиттера) */
            // NON-BLOCKING IMPLEMENTATION
            
            // --- AUTO-SWITCH: Master/Slave Detection ---
            extern volatile uint32_t sync_last_edge_ms;
            uint32_t now_ms = HAL_GetTick();
            uint32_t time_since_edge = 0;
            if (now_ms >= sync_last_edge_ms) time_since_edge = now_ms - sync_last_edge_ms;
            else time_since_edge = 0; // overflow safety
            
            bool signal_present = (time_since_edge < 120u) && (sync_last_edge_ms != 0u);
            
            extern volatile uint8_t vnd_sync_mode_public;
            extern volatile uint8_t vnd_sync_ok_public;
            static uint8_t sync_locked = 0;
            static uint32_t lock_stable_cnt = 0;
            static uint32_t unlock_stable_cnt = 0;
            static uint8_t sync_lock_eval_div = 0u;
            extern volatile uint8_t g_arr_manual_mode;
            static uint8_t sync_loop_reset_req = 0;

            if (g_arr_manual_mode) {
                if (vnd_sync_mode_public == VND_SYNC_MODE_MASTER) {
                    g_auto_freq_sync_enable = 0;
                    vnd_sync_ok_public = 1u;
                } else if (vnd_sync_mode_public == VND_SYNC_MODE_SLAVE) {
                    g_auto_freq_sync_enable = 1;
                    vnd_sync_ok_public = 0u;
                } else {
                    g_auto_freq_sync_enable = 0;
                    vnd_sync_ok_public = 0u;
                }
                sync_locked = 0;
                lock_stable_cnt = 0u;
                unlock_stable_cnt = 0u;
                sync_lock_eval_div = 0u;
            } else {
                g_auto_freq_sync_enable = (vnd_sync_mode_public == VND_SYNC_MODE_SLAVE) ? 1u : 0u;
            }

            if (signal_present && vnd_sync_mode_public == VND_SYNC_MODE_SLAVE) {
                // Signal IS present -> SLAVE MODE CANDIDATE
                uint8_t evaluate_lock = 0u;

                if (++sync_lock_eval_div >= 8u) {
                    sync_lock_eval_div = 0u;
                    evaluate_lock = 1u;
                }

                {
                    int32_t target_phase_ticks = tim15_get_default_target_phase_ticks();
                    int32_t phase_error = g_tim5_avg_phase - target_phase_ticks;

                    if (sync_locked && evaluate_lock) {
                    // Already locked: check if we lost it (very wide window)
                    bool bad_phase = (phase_error <= -20000 || phase_error >= 20000);
                    if (bad_phase) {
                        unlock_stable_cnt++;
                        // Require continuous failure for ~1 second on the averaged phase updates.
                        if(unlock_stable_cnt > 25) {
                            sync_locked = 0;
                            unlock_stable_cnt = 0;
                        }
                    } else {
                        unlock_stable_cnt = 0;
                    }
                } else if (!sync_locked && evaluate_lock) {
                    // Not locked: green only after the averaged phase enters a narrow window
                    // and keeps holding there on repeated averaged updates.
                    bool good_phase = (phase_error > -40 && phase_error < 40);
                    if (good_phase) {
                        lock_stable_cnt++;
                        // Require about 1 second of stable averaged phase before Green.
                        if(lock_stable_cnt > 25) {
                            sync_locked = 1;
                            lock_stable_cnt = 0;
                        }
                    } else {
                        lock_stable_cnt = 0;
                    }
                }
                }
                vnd_sync_ok_public = sync_locked;
            } else {
                sync_locked = 0;
                vnd_sync_ok_public = (vnd_sync_mode_public == VND_SYNC_MODE_MASTER) ? 1u : 0u;
                lock_stable_cnt = 0u;
                unlock_stable_cnt = 0u;
                sync_lock_eval_div = 0u;
            }
            
            /* Role arbitration is owned by vnd_sync_apply_mode()/RS485 auto-role.
               This ADC path must not rewrite vnd_sync_mode_public: doing so bypasses
               host-forced sync mode and can make M/S bounce without a host. */
            g_auto_freq_sync_enable = (vnd_sync_mode_public == VND_SYNC_MODE_SLAVE) ? 1u : 0u;
            
            {
                static int32_t phase_integrator = 0;
                static uint32_t samples_collected = 0;
                enum { SYNC_CHECK_PERIOD_BUFFERS = 8 };

                if (sync_loop_reset_req || !g_auto_freq_sync_enable) {
                    phase_integrator = 0;
                    samples_collected = 0;
                    g_tim5_avg_phase = 0;
                    sync_loop_reset_req = 0;
                }

                if (g_auto_freq_sync_enable) {
                    extern volatile uint32_t sync_tim5_period_ticks;
                    uint32_t period = sync_tim5_period_ticks;
                    uint32_t cnt = htim5.Instance->CNT;
                    int32_t current_phase = 0;

                    if (period < 1000000u) period = 1375000u;

                    if (cnt <= (period / 2u)) {
                        current_phase = (int32_t)cnt;
                    } else {
                        current_phase = (int32_t)cnt - (int32_t)period;
                    }

                    if (((uint8_t)(s_global_buffer_counter & 1u)) != 0u) {
                        phase_integrator += current_phase;
                        samples_collected++;
                    }

                    if (samples_collected >= SYNC_CHECK_PERIOD_BUFFERS) {
                        g_tim5_avg_phase = phase_integrator / (int32_t)samples_collected;
                        phase_integrator = 0;
                        samples_collected = 0;
                    }
                }
            }
            
            // СТАРЫЙ МЕХАНИЗМ ОТКЛЮЧЕН (заменен на интегратор выше)
            #if 0
            if (g_auto_freq_sync_enable) {
                // ... old code ...
            }
            #endif
            
            // ТЕСТОВЫЙ РЕЖИМ: ОТКЛЮЧЕН - слишком сильные скачки
            // С безопасной проверкой положения счётчика
            #if 0
            if (vnd_sync_mode_public == 1 && is_odd_buffer) {
                static uint32_t test_cnt = 0;
                static int8_t test_direction = -1;  // Начинаем с -1
                static int8_t pending_correction = 0;  // Ожидающая коррекция
                
                extern TIM_HandleTypeDef htim15;
                uint32_t current_arr = htim15.Instance->ARR;
                uint32_t current_cnt = htim15.Instance->CNT;
                
                test_cnt++;
                
                // Каждые 400 нечётных буферов (~2.0 сек) запрашиваем изменение
                if ((test_cnt % 400) == 0) {
                    pending_correction = test_direction;
                    test_direction = -test_direction;  // Меняем направление для следующего раза
                }
                
                // Применяем коррекцию только когда CNT в безопасной зоне (первая четверть периода)
                if (pending_correction != 0) {
                    if (current_cnt < (current_arr / 4)) {
                        // Безопасно изменять ARR
                        int32_t new_arr = (int32_t)current_arr + pending_correction;
                        
                        // Ограничиваем диапазон ARR: 1100..1190
                        if (new_arr < 1100) new_arr = 1100;
                        if (new_arr > 1190) new_arr = 1190;
                        
                        htim15.Instance->ARR = (uint32_t)new_arr;
                        pending_correction = 0;  // Коррекция применена
                    }
                }
            }
            #endif


    } else {
        /* Один из ADC завершился, но второй еще нет - считаем для диагностики */
        if (bit == 0x01u) s_adc1_alone++;
        if (bit == 0x02u) s_adc2_alone++;
    }

    return;

#if 0  /* СТАРАЯ ЛОГИКА (оставлено как справка, не используется) */
    
    /* В CIRCULAR mode HAL может снова включить HTIE при перезапуске - отключаем его.
       В CIRCULAR DMA автоматически перезапускается, но мы хотим только TC IRQ, не HT. */
    DMA_Stream_TypeDef *st_adc1 = (DMA_Stream_TypeDef*)hdma_adc1.Instance;
    st_adc1->CR &= ~((uint32_t)(1u<<3));  /* Отключаем HTIE каждый раз */
    
    if (hadc->Instance == (s_adc1 ? s_adc1->Instance : NULL)) {
    dma_full0++; dbg_dma1_full_count++;
#if DIAG_DMA_CALLBACK_LIMIT
    if(dbg_dma1_full_count > DIAG_DMA_CALLBACK_LIMIT){
        HAL_ADC_Stop_DMA(s_adc1);
        printf("[ADC][WARN] FULL limit reached -> stop DMA (half=%lu full=%lu)\r\n",
           (unsigned long)dbg_dma1_half_count,
           (unsigned long)dbg_dma1_full_count);
        return;
    }
#endif
    adc_last_full0_ms = HAL_GetTick();
    
    /* Один общий callback обслуживает ОБА канала: считаем, что по завершению DMA ADC1
       готов кадр и по ADC1, и по ADC2 с одним и тем же индексом. 
       КРИТИЧНО: СНАЧАЛА перезапускаем ADC+DMA, ПОТОМ обрабатываем done_idx! */
    uint32_t done_idx = s_next_ring_index;
    uint32_t next_idx = (s_next_ring_index + 1u) & (FIFO_FRAMES - 1u);
    uint32_t total_samples = (uint32_t)g_active_samples;
    
    /* ====== ПРИОРИТЕТ 1: RESTART ADC+DMA БЕЗ ЗАДЕРЖЕК ====== */
    /* В NORMAL mode после TC нужен Stop → Start цикл, но БЕЗ polling.
       Stop сбрасывает состояние HAL, Start конфигурирует новый буфер.
       HAL внутри проверяет флаги и не требует ожидания - это атомарные операции. */
    
    /* ADC1: Stop (мгновенный сброс HAL state) → Start (новый буфер) */
    HAL_ADC_Stop_DMA(s_adc1);
    HAL_StatusTypeDef st1 = HAL_ADC_Start_DMA(s_adc1, (uint32_t*)adc1_buffers[next_idx], total_samples);
    if (st1 != HAL_OK) {
        ADC_LOGF("[ADC][ERR] ADC1 Start_DMA failed: %d\r\n", st1);
    }
    
    #if !DIAG_SINGLE_ADC1
    /* ADC2: Stop → Start */
    HAL_ADC_Stop_DMA(s_adc2);
    HAL_StatusTypeDef st2 = HAL_ADC_Start_DMA(s_adc2, (uint32_t*)adc2_buffers[next_idx], total_samples);
    if (st2 != HAL_OK) {
        ADC_LOGF("[ADC][ERR] ADC2 Start_DMA failed: %d\r\n", st2);
    }
    #endif
    
    s_next_ring_index = next_idx;
    
    /* КРИТИЧНО: Используем ПРЕПОСЛЕДНИЙ буфер для маркеров!
       done_idx - это буфер, который только что завершился DMA TC.
       Но пока мы в прерывании, TIM15 @ 275kHz продолжает слать триггеры в ADC,
       который уже перезапущен на next_idx. Если обработка callback затянется,
       done_idx может быть частично перезаписан новыми данными АЦП.
       
       Поэтому пишем маркеры в (done_idx - 1), который точно не используется! */
    uint32_t marker_idx = (done_idx + FIFO_FRAMES - 1u) & (FIFO_FRAMES - 1u);  // done_idx - 1 с wrap
        
    /* Обрабатываем done_idx — публикуем в очередь USB */
    if (done_idx < FIFO_FRAMES) {
        /* Обновляем счётчики по каналу A */
        adc_ch_wr_seq[0]++;
        uint32_t backlogA = adc_ch_wr_seq[0] - adc_ch_rd_seq[0];
        if (backlogA > FIFO_FRAMES) {
            uint32_t excess = backlogA - FIFO_FRAMES;
            adc_ch_overflow_drops[0] += excess;
            adc_ch_rd_seq[0] += excess;
        }
        
        /* Invalidate cache перед чтением done_idx (DMA писал туда данные) */
        adc_invalidate_cache_for_buffer(adc1_buffers[done_idx], g_active_samples);
        
#if 0  // MARKERS DISABLED
        // DEBUG: Создаём "лестницу" маркеров в ПРЕПОСЛЕДНЕМ буфере (marker_idx)
        // Это безопасно — marker_idx гарантированно не используется ни DMA, ни USB
        adc_invalidate_cache_for_buffer(adc1_buffers[marker_idx], g_active_samples);
        for (uint16_t i = 0; i < g_active_samples; i += 100) {
            uint16_t value = (i / 100) * 500;  // 0, 500, 1000, 1500, 2000, ...
            if (value > 4095) value = 4095;
            adc1_buffers[marker_idx][i] = value;
        }
        adc_flush_cache_for_buffer(adc1_buffers[marker_idx], g_active_samples);
        
        // DEBUG: Проверка лестницы сразу после записи (каждую секунду)
        // ВНИМАНИЕ: Проверяем marker_idx, где реально записали маркеры!
        static uint32_t last_check_ms = 0;
        static uint32_t check_counter = 0;
        uint32_t now_ms = HAL_GetTick();
        if (now_ms - last_check_ms >= 1000) {
            last_check_ms = now_ms;
            check_counter++;
            // Проверяем marker_idx (препоследний буфер с маркерами)
            uint16_t s0 = adc1_buffers[marker_idx][0];
            uint16_t s100 = adc1_buffers[marker_idx][100];
            uint16_t s200 = adc1_buffers[marker_idx][200];
            uint16_t s300 = adc1_buffers[marker_idx][300];
            uint16_t s400 = adc1_buffers[marker_idx][400];
            printf("[MCU_TX#%lu] A marker_idx=%lu: [0]=%u [100]=%u [200]=%u [300]=%u [400]=%u\r\n", 
                   (unsigned long)check_counter, (unsigned long)marker_idx, s0, s100, s200, s300, s400);
            
            // DEBUG: Проверка лестницы B в том же marker_idx
            uint16_t s0_b = adc2_buffers[marker_idx][0];
            uint16_t s100_b = adc2_buffers[marker_idx][100];
            uint16_t s200_b = adc2_buffers[marker_idx][200];
            uint16_t s300_b = adc2_buffers[marker_idx][300];
            uint16_t s400_b = adc2_buffers[marker_idx][400];
            printf("[MCU_TX#%lu] B marker_idx=%lu: [0]=%u [100]=%u [200]=%u [300]=%u [400]=%u\r\n", 
                   (unsigned long)check_counter, (unsigned long)marker_idx, s0_b, s100_b, s200_b, s300_b, s400_b);
        }
#endif  // MARKERS DISABLED

        /* Обновляем счётчики по каналу B */
        adc_ch_wr_seq[1]++;
        uint32_t backlogB = adc_ch_wr_seq[1] - adc_ch_rd_seq[1];
        if (backlogB > FIFO_FRAMES) {
            uint32_t excess = backlogB - FIFO_FRAMES;
            adc_ch_overflow_drops[1] += excess;
            adc_ch_rd_seq[1] += excess;
        }
        
        adc_invalidate_cache_for_buffer(adc2_buffers[done_idx], g_active_samples);
        
#if 0  // MARKERS DISABLED
        // DEBUG: Аналогичная лестница для канала B в ПРЕПОСЛЕДНЕМ буфере (marker_idx)
        adc_invalidate_cache_for_buffer(adc2_buffers[marker_idx], g_active_samples);
        for (uint16_t i = 0; i < g_active_samples; i += 100) {
            uint16_t value = (i / 100) * 500;
            if (value > 4095) value = 4095;
            adc2_buffers[marker_idx][i] = value;
        }
        adc_flush_cache_for_buffer(adc2_buffers[marker_idx], g_active_samples);
        
        // Flush cache после записи маркеров для текущего done_idx (если нужно)
        adc_flush_cache_for_buffer(adc1_buffers[done_idx], g_active_samples);
        adc_flush_cache_for_buffer(adc2_buffers[done_idx], g_active_samples);
#endif  // MARKERS DISABLED

        /* Отмечаем пару как готовую и сразу публикуем */
        s_pair_ready_mask[done_idx] = 0x03u;
        adc_mark_ready_and_publish(0x03);
    }
} else if (hadc->Instance == (s_adc2 ? s_adc2->Instance : NULL)) {
        /* ADC2 callback НЕ ДОЛЖЕН вызываться при ADC2_DISABLE_DMA_IRQS=1
           Если всё же вызвался - это ошибка конфигурации */
        ADC_LOGF("[ADC][ERR] ADC2 callback unexpected! IRQ should be disabled\r\n");
    }
#endif  /* ОСНОВНОЙ DMA CALLBACK - ВКЛЮЧЁН */
}

// Legacy external-sync hook. A sync edge is not allowed to stop/rearm DMA or
// reset the ADC sampling cycle.
void adc_stream_sync_edge(void)
{
    adc_stream_paused = 0u;
}

/* Периодический вотчдог: если давно не было DMA Full от ADC1, считаем поток зависшим и мягко перезапускаем.
   Это устраняет зависания, когда цепочка ADC/DMA перестаёт генерировать события (см. STALL_WARN: ADC_IDLE). */
/* Age for intervals shorter than 2^31 ms, including HAL_GetTick wrap.
   An ISR can update `before` one tick after main captured `now`; that is a
   small future timestamp, not an age of 0xFFFFFFFF ms. Treat it as age zero.
   The old unsigned helper caused periodic false ADC restarts on this race. */
static inline uint32_t tick_diff32(uint32_t now, uint32_t before)
{
    uint32_t delta = now - before;
    return (delta <= 0x7FFFFFFFu) ? delta : 0u;
}

#define ADC_WD_TIMEOUT_MS 500u

/* Селективный перезапуск канала B полностью отключён в рабочей конфигурации.
   Исторически пытались мягко перезапускать только B, но это давало нестабильность
   и лишний шум в логах. Сейчас при проблемах с потоком полагаемся только на общий
   adc_stream_restart(NULL, NULL) по тайм-ауту A. Оставляем заглушку под #if 0
   на случай возврата к экспериментам. */
#if 0
static int adc_restart_channel_b(void){
    (void)g_active_samples;
    (void)s_next_ring_index;
    if(!s_adc2) return 0;
    ADC_LOGF("[ADC][WD] adc_restart_channel_b() called (EXPERIMENTAL)\r\n");
    return 0;
}
#endif

static HAL_StatusTypeDef adc_stream_watchdog_recover(uint32_t now_ms,
                                                     uint32_t reason_code,
                                                     const char *reason)
{
    uint32_t primask = __get_PRIMASK();
    uint8_t source_is_live = 0u;

    /* Revalidate under one IRQ lock immediately before the destructive HAL
       stop/start. A DMA callback may have published a healthy pair after the
       watchdog made its first decision. Runtime recovery must never cut that
       live acquisition (and therefore TX200) in half. */
    __disable_irq();
    now_ms = HAL_GetTick();
    if (reason_code == 1u) {
        source_is_live =
            (uint8_t)((adc_publish_count != s_dma_arm_publish_snapshot) ? 1u : 0u);
    } else if (reason_code == 2u) {
        source_is_live =
            (uint8_t)(((adc_last_publish_ms != 0u) &&
                       (tick_diff32(now_ms, adc_last_publish_ms) <=
                        ADC_WD_TIMEOUT_MS)) ? 1u : 0u);
    } else if (reason_code == 3u) {
        /* A periodic NDTR read can alias a healthy circular stream. Fresh
           completed buffers prove progress even when NDTR repeats exactly. */
        source_is_live =
            (uint8_t)(((__HAL_DMA_GET_COUNTER(&hdma_adc2) !=
                        (uint32_t)g_active_samples) ||
                       ((adc_last_full1_ms != 0u) &&
                        (tick_diff32(now_ms, adc_last_full1_ms) <=
                         ADC_WD_TIMEOUT_MS))) ? 1u : 0u);
    } else if (reason_code == 4u) {
        source_is_live =
            (uint8_t)(((adc_last_full0_ms != 0u) &&
                       (tick_diff32(now_ms, adc_last_full0_ms) <=
                        ADC_WD_TIMEOUT_MS)) ? 1u : 0u);
    } else if (reason_code == 5u) {
        source_is_live = (uint8_t)(s_adc_dbm_fault_pending == 0u);
    }

    if (source_is_live != 0u) {
        s_adc_restart_suppressed_live++;
        __set_PRIMASK(primask);
        return HAL_BUSY;
    }

    adc_restart_attempts++;
    s_adc_restart_reason = reason_code;
    s_adc_restart_ndtr_a = __HAL_DMA_GET_COUNTER(&hdma_adc1);
    s_adc_restart_ndtr_b = __HAL_DMA_GET_COUNTER(&hdma_adc2);
    s_adc_restart_publish_age_ms = (adc_last_publish_ms == 0u)
        ? 0xFFFFFFFFu
        : tick_diff32(now_ms, adc_last_publish_ms);
    ADC_LOGF("[ADC][WD] %s -> atomic pair rearm\r\n", reason ? reason : "stall");

    HAL_StatusTypeDef rc = adc_stream_recover_dma_pair();
    if (rc == HAL_OK) {
        s_watchdog_recovery_pending = 1u;
        s_watchdog_recovery_publish_snapshot = adc_publish_count;
        s_watchdog_recovery_started_ms = now_ms;
    }
    __set_PRIMASK(primask);
    return rc;
}

void adc_stream_watchdog(void)
{
    /* Локальный захват текущего тика (исключаем рассинхронизацию перед вызовом) */
    uint32_t now_ms = HAL_GetTick();
    uint8_t arr_manual_mode = 0u;
    if(s_adc1 == NULL || (!DIAG_SINGLE_ADC1 && s_adc2 == NULL)) return; /* ещё не инициализированы */
    if(adc_stream_static_mode_enabled()) return; /* статический режим: DMA не запускается */
    {
        extern volatile uint8_t g_arr_manual_mode;
        arr_manual_mode = g_arr_manual_mode;
    }

    /* A recovery is successful only after the ISR publishes a new A+B pair.
       Give the freshly armed DMA enough time before allowing another attempt. */
    if (s_watchdog_recovery_pending) {
        if (adc_publish_count != s_watchdog_recovery_publish_snapshot) {
            adc_restart_success++;
            s_watchdog_recovery_pending = 0u;
        } else if (tick_diff32(now_ms, s_watchdog_recovery_started_ms) < 500u) {
            return;
        } else {
            s_watchdog_recovery_pending = 0u;
        }
    }

    /* A full USB FIFO is not an ADC state. Old firmware could leave this
       legacy flag set and permanently disable watchdog recovery. */
    adc_stream_paused = 0u;
    if (arr_manual_mode) return; /* В ручном ARR-режиме запрещаем только watchdog-рестарты */

    if (s_adc_dbm_fault_pending != 0u) {
        (void)adc_stream_watchdog_recover(now_ms, 5u, "DBM bank/sequence mismatch");
        return;
    }

    /* The first arm (including START) can fail before either DMA callback is
       seen. Do not wait for last_full0_ms in that case. */
    if (s_dma_arm_ms != 0u &&
        adc_publish_count == s_dma_arm_publish_snapshot &&
        tick_diff32(now_ms, s_dma_arm_ms) > 500u) {
        (void)adc_stream_watchdog_recover(now_ms, 1u, "no pair after arm");
        return;
    }

    uint32_t lastA = adc_last_full0_ms;
    uint32_t lastB = adc_last_full1_ms;
    if(lastA == 0) return; /* поток ещё не стартовал (нет ни одного полного завершения) */

    /* A and B callbacks may still change while their pairing state is broken.
       Publication age is therefore the authoritative liveness condition. */
    uint32_t publish_ref_ms = adc_last_publish_ms;
    if (publish_ref_ms < s_dma_arm_ms) publish_ref_ms = s_dma_arm_ms;
    if (publish_ref_ms != 0u && tick_diff32(now_ms, publish_ref_ms) > 500u) {
        (void)adc_stream_watchdog_recover(now_ms, 2u, "pair publication stalled");
        return;
    }

    /* Защита от ложных "будущих" меток lastA/lastB (гонка или порча памяти):
       если метка немного впереди now ( <100000 мс ), считаем dt=0, игнорируем. */
    if(lastA > now_ms){ uint32_t ahead = lastA - now_ms; if(ahead < 100000u){ lastA = now_ms; } }
    if(lastB > now_ms){ uint32_t ahead = lastB - now_ms; if(ahead < 100000u){ lastB = now_ms; } }

    uint32_t dtA = tick_diff32(now_ms, lastA);
    // uint32_t dtB_now = (lastB==0) ? 0 : tick_diff32(now_ms, lastB);  // Неиспользуется

    /* Диагностика NDTR и эскалация при застывшем NDTRB (DMA не стартовал) */
    static uint32_t last_dbg_ms = 0;
    static uint32_t last_summary_ms = 0;   /* для агрегированной статистики раз в 10 сек */
    static uint32_t last_ndtrB = 0xFFFFFFFFu;
    static uint32_t last_ndtrB_change_ms = 0;
    static uint8_t  b_stuck_strikes = 0; /* фиксируем повторные застои Б, чтобы не спамить рестартами */
    
    /* Агрегированная статистика за 10 секунд */
    if(now_ms - last_summary_ms >= 10000u){
        last_summary_ms = now_ms;
        extern volatile uint32_t frame_wr_seq;  /* Общий счётчик завершённых пар A+B */
        static uint32_t prev_wr_seq = 0;
        uint32_t bufs_done = (frame_wr_seq > prev_wr_seq) ? (frame_wr_seq - prev_wr_seq) : 0;
        prev_wr_seq = frame_wr_seq;
        float bufHz = (float)bufs_done / 10.0f;
        (void)bufHz;  // Используется в ADC_LOGF, может быть закомпилировано без логов

        /* Раздельная статистика по каналам A/B */
        static uint32_t prev_ch_wr[2] = {0,0};
        uint32_t chA_done = (adc_ch_wr_seq[0] > prev_ch_wr[0]) ? (adc_ch_wr_seq[0] - prev_ch_wr[0]) : 0;
        uint32_t chB_done = (adc_ch_wr_seq[1] > prev_ch_wr[1]) ? (adc_ch_wr_seq[1] - prev_ch_wr[1]) : 0;
        prev_ch_wr[0] = adc_ch_wr_seq[0];
        prev_ch_wr[1] = adc_ch_wr_seq[1];
        float hzA = (float)chA_done / 10.0f;
        float hzB = (float)chB_done / 10.0f;
        (void)hzA; (void)hzB;  // Используются в ADC_LOGF

        ADC_LOGF("[ADC][STAT_10s] buffers=%lu (%.1f Hz) restarts=%lu/%lu dtA=%lums dtB=%lums samples=%u\r\n",
                 (unsigned long)bufs_done, bufHz,
                 (unsigned long)adc_restart_attempts, (unsigned long)adc_restart_success,
                 (unsigned long)dtA, (unsigned long)((lastB==0)?0:tick_diff32(now_ms,lastB)),
                 (unsigned)g_active_samples);
        ADC_LOGF("[ADC][STAT_CH] A=%lu (%.1f Hz) B=%lu (%.1f Hz) pairs=%lu (%.1f Hz)\r\n",
                 (unsigned long)chA_done, hzA,
                 (unsigned long)chB_done, hzB,
                 (unsigned long)bufs_done, bufHz);
    }
    
    if(now_ms - last_dbg_ms >= 250u){
        last_dbg_ms = now_ms;
        DMA_Stream_TypeDef *dma1_stream = (DMA_Stream_TypeDef*)hdma_adc1.Instance;
        DMA_Stream_TypeDef *dma2_stream = (DMA_Stream_TypeDef*)hdma_adc2.Instance;
        uint32_t ndtrA = dma1_stream->NDTR;
        uint32_t ndtrB = dma2_stream->NDTR;
        /* Убрали частый лог WDDBG — данные теперь агрегируются раз в 10 сек */
        /* Отслеживаем изменения NDTRB */
        if(ndtrB != last_ndtrB){ last_ndtrB = ndtrB; last_ndtrB_change_ms = now_ms; b_stuck_strikes = 0; }
        else {
            uint32_t stuck_ms = now_ms - last_ndtrB_change_ms;
            if(stuck_ms > 200u && ndtrB == (uint32_t)g_active_samples && dtA < 400u &&
               ((lastB == 0u) || (tick_diff32(now_ms, lastB) > ADC_WD_TIMEOUT_MS))){
                b_stuck_strikes++;
                ADC_LOGF("[ADC][WD] CH_B DMA not advancing: ndtrB=%u unchanged %lums (strike=%u). dtA=%lu dtB=%lu -> restart BOTH\r\n",
                         (unsigned)ndtrB, (unsigned long)stuck_ms, (unsigned)b_stuck_strikes, (unsigned long)dtA,
                         (unsigned long)((lastB == 0u) ? 0u : tick_diff32(now_ms, lastB)));
                dump_b_path_regs(ndtrA, ndtrB);
                if(adc_stream_watchdog_recover(now_ms, 3u, "channel B DMA stalled") == HAL_OK){
                    b_stuck_strikes = 0;
                } else {
                    ADC_LOGF("[ADC][WD] full restart after B-DMA-stuck FAILED\r\n");
                }
                return;
            }
        }
    }

    if(dtA > ADC_WD_TIMEOUT_MS){
        ADC_LOGF("[ADC][WD] No DMA Full A for %lu ms -> restart BOTH\r\n", (unsigned long)dtA);
        if(adc_stream_watchdog_recover(now_ms, 4u, "no DMA Full A") != HAL_OK){
            ADC_LOGF("[ADC][WD] full restart FAILED\r\n");
        }
        return; /* после общего рестарта не выполняем частный контроль B */
    }
     /* Дополнительный селективный контроль канала B отключён как
         нестабильный и шумный. Если когда-нибудь понадобится вернуть эксперименты,
         здесь можно восстановить логику dtB/dtA и выборочные рестарты. */
}

/* === Fine Frequency Tuning === */
/* Установка частоты TX200/фазового маркера PA1/PA2/PC7 в диапазоне 180-250 Hz
 * Допускаем два формата payload:
 *  - marker_hz (<=350): желаемая частота комплементарного меандра
 *  - buf_rate_hz (>350): частота DMA буферов (маркер = buf_rate/2)
 */
void adc_stream_set_buf_rate_fine(uint16_t raw_hz) {
    uint16_t marker_hz = 0;
    uint16_t buf_rate_hz = 0;

    if (raw_hz > 350u) {
        /* трактуем как buf_rate_hz */
        buf_rate_hz = raw_hz;
        marker_hz = (uint16_t)(buf_rate_hz / 2u);
    } else {
        /* трактуем как marker_hz */
        marker_hz = raw_hz;
        buf_rate_hz = (uint16_t)(marker_hz * 2u);
    }

    if (marker_hz < 180u || marker_hz > 250u) {
        ADC_LOGF("[ADC][RATE] Fine-tune marker=%u Hz out of range (180-250), ignoring\r\n", (unsigned)marker_hz);
        return;
    }

    /* Repeating the current RPI setting must be a no-op. Reapplying TIM15/TIM5
       resets phase timing and, during a reconnect loop, can prevent USB progress. */
    if (g_fine_buf_rate_override == buf_rate_hz) {
        return;
    }
    
    /* Устанавливаем override для buf_rate */
    g_fine_buf_rate_override = buf_rate_hz;

    /* Применяем тайминги независимо от активного профиля */
    adc_stream_apply_timing();

    ADC_LOGF("[ADC][RATE] Fine-tune: raw=%u -> marker=%u Hz, buf_rate=%u Hz\r\n",
             (unsigned)raw_hz, (unsigned)marker_hz, (unsigned)buf_rate_hz);
}

void adc_stream_set_arr_fine_offset(int32_t offset) {
    if (offset < -128) {
        offset = -128;
    } else if (offset > 128) {
        offset = 128;
    }

    if (g_arr_fine_offset == offset) {
        return;
    }
    g_arr_fine_offset = offset;
    adc_stream_apply_timing();
}

int32_t adc_stream_get_arr_fine_offset(void) {
    return g_arr_fine_offset;
}

// Внешняя синхронизация: установка buf_rate без ограничений marker_hz
void adc_stream_set_buf_rate_external(uint16_t buf_rate_hz) {
    if(buf_rate_hz < 20u || buf_rate_hz > 1000u) {
        ADC_LOGF("[ADC][RATE] External sync out of range: %u Hz\r\n", (unsigned)buf_rate_hz);
        return;
    }
    if (g_fine_buf_rate_override == buf_rate_hz) {
        return;
    }
    g_fine_buf_rate_override = buf_rate_hz;
    adc_stream_apply_timing();
    ADC_LOGF("[ADC][RATE] External sync: buf_rate=%u Hz\r\n", (unsigned)buf_rate_hz);
}

void adc_stream_clear_buf_rate_override(void) {
    uint16_t prev = g_fine_buf_rate_override;

    if (prev == 0u) {
        return;
    }

    g_fine_buf_rate_override = 0u;

    {
        extern TIM_HandleTypeDef htim15;
        if (htim15.Instance != NULL) {
            adc_stream_apply_timing();
        }
    }

    ADC_LOGF("[ADC][RATE] Cleared external override: %u Hz -> profile %u Hz\r\n",
             (unsigned)prev,
             (unsigned)g_profiles[g_active_profile].buf_rate_hz);
}

// Тестовые функции удалены - используем только реальный ADC+DMA
