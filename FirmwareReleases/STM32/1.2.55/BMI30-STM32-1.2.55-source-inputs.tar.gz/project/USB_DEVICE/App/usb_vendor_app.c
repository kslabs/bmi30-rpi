/* Vendor streaming application (cleaned: duplicates removed) */
#include <stdint.h>
#include "usbd_cdc_custom.h"
#include "usb_device.h"
#include "usbd_core.h"
#include "usb_vendor_app.h"
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <math.h>
#include "adc_stream.h"
#include "main.h"
#include "usb_cdc_proto.h"
#include "build_info.h"
#include "ws2812_spi.h"
#include <stddef.h> /* offsetof для отладочного вывода */
#include "stm32h7xx_hal.h" /* SCB_* cache maintenance (may HardFault if MPU/cache config incomplete) */

/* External timer handle for TIM5 (32-bit phase counter) */
extern TIM_HandleTypeDef htim5;

/* Для дублирования фрагментов кадров в CDC (Virtual COM) */
#include "usbd_cdc_if.h"
#include "usbd_cdc_custom.h" /* для USBD_VND_RequestSoftReset/DeepReset (объявления находятся в .c) */
#include "vnd_testgen.h"

/* === DC калибровка ROI 200 samples (LOSSLESS_ROI / AVG_ROI) ===
   Требование:
   - DC буферы 200 семплов для каждого (канал A/B) × (even/odd)
   - LOSSLESS_ROI: применяем DC к копии ROI перед USB payload
   - AVG_ROI: единственная DC-таблица применяется и обучается до усреднения
   - RPI задаёт только постоянную скорость settle_ms; 0 выключает обучение
   - DMA/FIFO raw буферы не изменяем
   - Сохранение в Flash только по команде хоста, если не включён периодический save.
*/
#include "stm32h7xx_hal_flash.h"
#include "stm32h7xx_hal_flash_ex.h"

/* В этом проекте операции invalidate/clean DCache могут вызывать HardFault
    (см. комментарий в adc_stream.c). Поэтому по умолчанию отключаем их.
    Если позже будет настроена некэшируемая память/MPU корректно — можно включить. */
#ifndef VND_ENABLE_CACHE_INVALIDATE
#define VND_ENABLE_CACHE_INVALIDATE 0
#endif

/* Управление шумными логами (по умолчанию выключено) */
#ifndef VND_DC_LOG_ENABLE
#define VND_DC_LOG_ENABLE 0
#endif
#if VND_DC_LOG_ENABLE
#define VND_DC_LOGF(...) printf(__VA_ARGS__)
#else
#define VND_DC_LOGF(...) do { if (0) { (void)(printf)(__VA_ARGS__); } } while (0)
#endif

#ifndef VND_PROF_LOG_ENABLE
#define VND_PROF_LOG_ENABLE 0
#endif
#if VND_PROF_LOG_ENABLE
#define VND_PROF_LOGF(...) printf(__VA_ARGS__)
#else
#define VND_PROF_LOGF(...) do { if (0) { (void)(printf)(__VA_ARGS__); } } while (0)
#endif

/* Verification build default: keep the COM port quiet except explicit DC speed
   confirmation in SET_DC_SPEED. Define VND_UART_LOG_ENABLE=1 to restore logs. */
#ifndef VND_UART_LOG_ENABLE
#define VND_UART_LOG_ENABLE 0
#endif
#if !VND_UART_LOG_ENABLE
/* Validate disabled diagnostics while keeping UART and argument reads absent. */
#define printf(...) do { if (0) { (void)(printf)(__VA_ARGS__); } } while (0)
#endif

#ifndef VND_CDC_LOG_ENABLE
#define VND_CDC_LOG_ENABLE 0
#endif

#ifndef VND_LED_EVENTS_ENABLE
#define VND_LED_EVENTS_ENABLE 1
#endif

#ifndef VND_SYNC_DIAG_ENABLE
#define VND_SYNC_DIAG_ENABLE 1
#endif

#ifndef VND_SYNC_DIAG_PRINTF
#define VND_SYNC_DIAG_PRINTF 0
#endif

#ifndef VND_AVG_DIAG_PRINTF
#define VND_AVG_DIAG_PRINTF 0
#endif

/* Forward declaration (реализация ниже) для предотвращения implicit-function-warning при раннем вызове */
void vnd_diag_log_possible_stall(void);
static void cdc_logf(const char *fmt, ...);
static void vnd_apply_tx_enable_outputs(void);
static uint8_t vnd_tx_set_enabled_internal(uint8_t enable, const char *reason);
static uint8_t vnd_tx_refresh_effective(uint32_t now_ms, const char *reason);
static void vnd_tx_failsafe_service(uint32_t now_ms);
static void vnd_log_dc_cmd_rx(const uint8_t *data, uint32_t len);

/* Управление дублированием данных кадров в CDC (COM-порт):
 *  0 — отключено (оставляем только события START/STOP и 1 Гц статистику)
 *  1 — включено (превью первых 64 сэмплов раз в ≤10 Гц)
 */
#ifndef VND_CDC_PREVIEW_ENABLE
#define VND_CDC_PREVIEW_ENABLE 0
#endif

#ifndef VND_DIAG_BUFFER_ID_MODE
#define VND_DIAG_BUFFER_ID_MODE 1  /* Режим отладки: использовать ID буфера вместо seq */
#endif

#ifndef VND_ENABLE_LOG
#define VND_ENABLE_LOG 0 /* ОТКЛЮЧЕНО: логи засоряют терминал */
#endif
#if VND_ENABLE_LOG
#define VND_LOG(...) do { printf("[VND] " __VA_ARGS__); printf("\r\n"); } while(0)
#else
#define VND_LOG(...) do{}while(0)
#endif

extern USBD_HandleTypeDef hUsbDeviceHS;
extern volatile uint8_t need_usb_status_refresh;

/* В диагностическом режиме упростим логику: отправлять только A-кадр (без обязательного B).
    Это помогает подтвердить транспорт USB IN и исключает потенциальные блокировки на pending_B. */
#ifndef VND_DIAG_SEND_A_ONLY
#define VND_DIAG_SEND_A_ONLY 0
#endif

/* Полностью отключить тестовые кадры (TEST) и связанную с ними
    стартовую/keepalive логику, чтобы исключить гонки и зависания EP
    на некоторых хостах. При включении — начинаем сразу с A/B. */
#ifndef VND_DISABLE_TEST
#define VND_DISABLE_TEST 1
#endif

/* Команды */
#define VND_CMD_START_STREAM   0x20u
#define VND_CMD_STOP_STREAM    0x21u
#define VND_CMD_DEVICE_RESET   0x22u  /* ПОЛНЫЙ RESET MCU (для отладки) */
#define VND_CMD_GET_STATUS     0x30u
/* Диагностический статус: отправить STAT немедленно даже при pending_B (для отладки зависаний) */
#define VND_CMD_GET_STATUS_IMM 0x31u
/* Отладка фаз/буферов: инверсия тестового выхода PA2 (TIM2_CH3) */
#define VND_CMD_TOGGLE_TIM2CH3_INV 0x32u
#ifndef VND_CMD_SET_TX_ENABLE
#define VND_CMD_SET_TX_ENABLE   0x33u /* payload: u8 0/1; persistent active-low external TX enable on PA1 */
#endif
#ifndef VND_CMD_SET_OPTIC_POWER
#define VND_CMD_SET_OPTIC_POWER 0x34u /* payload: u8 0..255 (мощность оптического TX) */
#endif
#ifndef VND_CMD_LED_EVENT
#define VND_CMD_LED_EVENT       0x35u /* payload: u8 event, u16 duration_ms */
#endif
#ifndef VND_CMD_SET_OPTIC_HOLD
#define VND_CMD_SET_OPTIC_HOLD  0x39u /* payload: u16 deciseconds; legacy u8 seconds accepted */
#endif
#ifndef VND_CMD_SET_LED_PATTERN
#define VND_CMD_SET_LED_PATTERN 0x3Bu /* payload: u8 ws2812_pattern_t */
#endif
#ifndef VND_CMD_SET_OPTIC_REACTION_SOURCE
#define VND_CMD_SET_OPTIC_REACTION_SOURCE 0x44u /* payload: u8 source_id 0..31, 0xFF=disabled */
#endif
#ifndef VND_CMD_SET_WIRE_MODE
#define VND_CMD_SET_WIRE_MODE 0x45u /* payload: v1, mode, lease_ms LE, transport_epoch LE */
#endif
#ifndef VND_CMD_GET_SYNC_DIAG
#define VND_CMD_GET_SYNC_DIAG 0x46u /* EP0 IN: SYN1 */
#endif
#ifndef VND_CMD_SET_DET_ADC
#define VND_CMD_SET_DET_ADC     0x3Cu /* payload: u8 bit0=DetADC1, bit1=DetADC2 */
#endif
#ifndef VND_CMD_HOST_RX_ACK
#define VND_CMD_HOST_RX_ACK     0x36u /* payload: u32 total host-received A/B frames */
#endif
#ifndef VND_CMD_HOST_RX_CLEAR
#define VND_CMD_HOST_RX_CLEAR   0x37u /* payload: none, clear host receive heartbeat */
#endif
/* ДОБАВЛЕНО: управление окнами/частотой */
#define VND_CMD_SET_WINDOWS    0x10u /* payload: start0,len0,start1,len1 (LE, u16) */
#define VND_CMD_SET_BUF_RATE_FINE 0x1Cu /* payload: marker_hz (<=350) или buf_rate_hz (>350), fine 180-250 Hz */
#ifndef VND_CMD_SET_SYNC_MODE
#define VND_CMD_SET_SYNC_MODE     0x1Du /* persistent local MASTER/SLAVE: mode + u64 Unix ms LE */
#endif
#define VND_CMD_SET_RS485_ID      0x3Du /* local USB only: u8 device_id 0..31 */
#ifndef VND_CMD_SET_RS485_IP
#define VND_CMD_SET_RS485_IP      0x3Eu /* payload: u8 ip[4] network order */
#endif
#ifndef VND_CMD_REQUEST_RS485_IDENT
#define VND_CMD_REQUEST_RS485_IDENT 0x3Fu /* payload none: start one identity scan */
#endif
#ifndef VND_CMD_GET_RS485_IDENT
#define VND_CMD_GET_RS485_IDENT   0x40u /* payload: optional u8 node_id, returns RID1 */
#endif
#ifndef VND_CMD_SET_LCD_ROLE_OVERLAY
#define VND_CMD_SET_LCD_ROLE_OVERLAY 0x41u /* payload: u8 enable, optional u8 period_s, u8 duration_s */
#endif
#ifndef VND_CMD_SET_RPI_INFO
#define VND_CMD_SET_RPI_INFO      0x42u /* payload: u16 RPI number LE + IPv4[4] */
#endif
#ifndef VND_CMD_GET_RS485_SENSOR
#define VND_CMD_GET_RS485_SENSOR  0x43u /* EP0 IN: SNS1 */
#endif
#define VND_CMD_SET_BLOCK_HZ   0x11u /* payload: u16 hz (20..100) или 0xFFFF=макс (100) */
/* Новая команда: установка ограничения числа выборок на канал в рабочем кадре */
#define VND_CMD_SET_TRUNC_SAMPLES 0x16u /* payload: u16 samples (0=отключить усечение) */
/* Новая команда: явная установка samples_per_frame для управления FPS (пара A+B ≈ Fs/samples) */
#define VND_CMD_SET_FRAME_SAMPLES 0x17u /* payload: u16 samples_per_frame (на канал) */
/* Новый режим: асинхронная передача A/B — без строгого чередования A→B; какой готов, тот и уходит */
#define VND_CMD_SET_ASYNC_MODE   0x18u /* payload: u8 mode (0=pairing/strict A->B, 1=async A/B independent) */
/* Новый режим выбора каналов: 0=A-only, 1=B-only, 2=both */
#define VND_CMD_SET_CHMODE       0x19u /* payload: u8 mode (0=A-only, 1=B-only, 2=both) */

/* Режимы стриминга (поведение выбора кадров/окна)
     SET_STREAM_MODE payload:
         - [1] u8 mode: 0=LATEST (lossy), 1=LOSSLESS_ROI, 2=AVG_ROI
         - [2] u8 avg_n (опционально, только для mode=2): 1..64, default=24
*/
#define VND_CMD_SET_STREAM_MODE  0x1Au
/* One scalar DC speed: u32 settle_ms, 0=learning off. */
#define VND_CMD_SET_DC_SPEED     0x1Fu
#define VND_CMD_SAVE_DC_TO_FLASH 0x2Bu
#define VND_CMD_GET_DC_CONFIG    0x3Au

#define VND_SYNC_MODE_MASTER 0u
#define VND_SYNC_MODE_SLAVE  1u
#define VND_SYNC_MODE_OFF    2u
#ifndef VND_SYNC_MODE_AUTO
#define VND_SYNC_MODE_AUTO   0xFFu
#endif
#ifndef VND_SYNC_MODE_AUTO_LEGACY
#define VND_SYNC_MODE_AUTO_LEGACY 3u
#endif
#define VND_STREAM_MODE_LATEST        0u
#define VND_STREAM_MODE_LOSSLESS_ROI  1u
#define VND_STREAM_MODE_AVG_ROI       2u
#define VND_AVG_MAX_N                 64u  /* Максимум 64 буфера для усреднения (шаг 8: 8/16/24/32/40/48/56/64) */
#ifndef VND_AVG_MIN_N
#define VND_AVG_MIN_N                 8u
#endif
#ifndef VND_AVG_LATEST_WINS
/* AVG_ROI is a live stream, not a backlog. If USB falls behind, keep only the
   newest averaged ROI pair and drop stale queued pairs. */
#define VND_AVG_LATEST_WINS           1u
#endif
#ifndef VND_TXCPLT_START_RAW_NEXT
/* Keep USB DataIn/TxCplt lightweight. Raw next-frame preparation can copy up to
   600 samples and must run from Vendor_Stream_Task(), not from the USB callback. */
#define VND_TXCPLT_START_RAW_NEXT     0u
#endif
#define VND_AVG_OUT_Q                 4u
#define VND_HOST_RX_ACK_TIMEOUT_MS    1500u
#ifndef VND_USB_IN_BUSY_STALL_MS
#define VND_USB_IN_BUSY_STALL_MS       220u
#endif
#ifndef VND_USB_IN_NO_PROGRESS_MS
#define VND_USB_IN_NO_PROGRESS_MS      300u
#endif
#ifndef VND_USB_IN_RECOVERY_COOLDOWN_MS
#define VND_USB_IN_RECOVERY_COOLDOWN_MS 250u
#endif
#ifndef VND_USB_IN_ACTIVE_HARD_STALL_MS
/* Active USB IN нельзя часто отменять: HAL_PCD_EP_Abort() рвёт pending bulk read на хосте. */
#define VND_USB_IN_ACTIVE_HARD_STALL_MS 1200u
#endif
#ifndef VND_USB_IN_ABORT_ACTIVE_STREAM
/* An enabled Bulk IN endpoint is owned by the USB core and may legitimately
   wait for host IN tokens for an arbitrary time. Aborting it tears down the
   host's pending bulk read and creates the stream gap that the watchdog is
   meant to avoid. Stale software-busy state is still recovered below once the
   hardware endpoint is no longer enabled. */
#define VND_USB_IN_ABORT_ACTIVE_STREAM 0u
#endif
#ifndef VND_USB_IN_ACTIVE_HOLD_LOG_MS
#define VND_USB_IN_ACTIVE_HOLD_LOG_MS 1000u
#endif
#ifndef VND_USB_FRAME_PACE_MS
/* Старый host пишет HOST_RX_ACK почти на каждый кадр. Короткий зазор между IN
   кадрами убирает гонку A->B на FS bulk без повторной отправки старых данных. */
#define VND_USB_FRAME_PACE_MS 4u
#endif
#ifndef VND_USB_AFTER_HOST_ACK_PACE_MS
/* HOST_RX_ACK приходит OUT-пакетом из старого синхронного host-loop. Не ставим
   следующий IN сразу в тот же слот: даём хосту снова выставить bulk read. */
#define VND_USB_AFTER_HOST_ACK_PACE_MS 12u
#endif
#ifndef VND_USB_ROI_PAD_TO_MPS
/* ROI frames must finish with a short FS bulk packet. Padding 432-byte frames to
   512 can leave old host readers waiting for more data until their timeout. */
#define VND_USB_ROI_PAD_TO_MPS 0u
#endif
#ifndef VND_USB_ROI_PAD_BYTES
#define VND_USB_ROI_PAD_BYTES 512u
#endif

/* Параметры */
#define VND_DEFAULT_TEST_SAMPLES   80u
#define VND_DEBUG_FORCE_STAT_INTERVAL_MS 200u // было 100
#define VND_DEBUG_RAW_STAT_INTERVAL_MS   100u

/* ---------------- Глобальные переменные состояния (централизовано) ---------------- */
/* Видимая снаружи (CDC) метка стриминга */
volatile uint8_t streaming = 0;
static volatile uint8_t vnd_tx_requested_enable = 0; /* Persistent host/manual request; changed only by SET_TX_ENABLE/TX200. */
static volatile uint8_t vnd_tx_enable = 0; /* 1=enable complementary TX200 waveform on PA2/PC7 and PA1; 0=clamp it off. */
static volatile uint32_t vnd_tx_host_cmd_count = 0;
static volatile uint32_t vnd_tx_host_cmd_last_ms = 0;
static volatile uint8_t vnd_tx_host_cmd_last_value = 0;
static volatile uint32_t vnd_tx_effective_change_count = 0;
static volatile uint32_t vnd_tx_effective_off_count = 0;
static volatile uint32_t vnd_tx_effective_last_change_ms = 0;
static volatile uint8_t vnd_tx_effective_last_value = 0;
/* Последовательность пар (инкремент только после успешного завершения B) */
volatile uint32_t stream_seq = 0;
/* Фактически зафиксированный размер кадров и ожидаемый размер байт */
volatile uint16_t cur_samples_per_frame = 0;
volatile uint16_t cur_expected_frame_size = 0;
/* Служебные отметки старта/ошибок */
volatile uint32_t start_cmd_ms = 0;
volatile uint32_t vnd_last_error = 0;
/* Отложенный (main-loop) перезапуск ADC/DMA по команде START.
    Важно: USBD_VND_DataReceived может вызываться из USB IRQ, поэтому тяжёлые действия
    (останов/запуск DMA, cache maintenance) выполняем в Vendor_Stream_Task(). */
/* Флаги канала передачи */
static volatile uint8_t  vnd_ep_busy = 0;     /* EP IN занят */
static volatile uint8_t  vnd_inflight = 0;    /* есть незавершённая передача */
/* Тестовый кадр (разрешён один раз на START, для keepalive) */
static volatile uint8_t  test_sent = 0;
static volatile uint8_t  test_in_flight = 0;
/* Отладочные счётчики/статусы */
volatile uint32_t dbg_produced_seq = 0;
volatile uint32_t dbg_sent_seq_adc0 = 0;
volatile uint32_t dbg_sent_seq_adc1 = 0;
volatile uint32_t dbg_partial_frame_abort = 0;
volatile uint32_t dbg_size_mismatch = 0;
volatile uint32_t dbg_resend_blocked = 0;
/* (Определения vnd_diag_prepare_pair и vnd_diag_try_tx перенесены ниже, после объявлений типов/буферов) */
static volatile uint32_t dbg_tx_attempt = 0;
static volatile uint32_t dbg_tx_reject = 0;
static volatile uint32_t dbg_tx_sent = 0;
static volatile uint32_t dbg_status_sent = 0;
volatile uint32_t dbg_sent_ch0_total = 0; // новые счётчики по каналам
volatile uint32_t dbg_sent_ch1_total = 0;
/* Глобальный счётчик завершений передачи (используется в статусе и диагностике) */
volatile uint32_t dbg_tx_cplt = 0;
/* Следующая метка последовательности для назначения готовящимся парам (может опережать stream_seq,
   который инкрементируется только по завершении B). */
static volatile uint32_t next_seq_to_assign = 0;

/* Actual protocol/USB failures only. A transient BUSY is normal flow control. */
static volatile uint32_t vnd_error_counter = 0;
static volatile uint32_t vnd_last_txcplt_ms = 0;      /* время последнего успешного завершения передачи */
static volatile uint32_t vnd_last_frame_txcplt_ms = 0; /* время последнего успешного завершения рабочего кадра A/B */
static volatile uint32_t vnd_last_host_rx_ack_ms = 0;  /* время последнего подтверждения чтения потока от хоста */
static volatile uint32_t vnd_host_rx_last_counter = 0; /* последний принятый счётчик host-received frames */
static volatile uint8_t  vnd_host_rx_counter_valid = 0;
static inline uint8_t vnd_tick_age_ms(uint32_t now_ms, uint32_t before_ms, uint32_t *age_ms)
{
    if(before_ms == 0u){
        if(age_ms) *age_ms = 0xFFFFFFFFu;
        return 0u;
    }
    /* If an ISR wrote before_ms after the local now_ms snapshot, do not treat it as a 49-day timeout. */
    int32_t age = (int32_t)(now_ms - before_ms);
    if(age < 0){
        if(age_ms) *age_ms = 0u;
        return 0u;
    }
    if(age_ms) *age_ms = (uint32_t)age;
    return 1u;
}
/* Счётчик переданных семплов (оба канала суммарно) */
static volatile uint64_t vnd_total_tx_samples = 0ULL;
/* Новые маркеры состояния запуска потока */

/* Режим смягчения команды DEVICE_RESET: вместо NVIC_SystemReset выполнить мягкое USB восстановление
    через флаг need_recovery, если включено. Это предотвращает полное исчезновение устройства с шины
    при частых запросах 0x22 и снижает влияние на отладку. */
#ifndef VND_DEVICE_RESET_SOFT_ONLY
/* Жёсткий reset по 0x22 отключён: только мягкое восстановление USB без NVIC_SystemReset. */
#define VND_DEVICE_RESET_SOFT_ONLY 1
#endif

/* Флаг восстановления (определён в main.c) */
extern volatile uint8_t need_recovery;
static volatile uint8_t  vnd_pending_init = 0;  /* 1 после START пока нет ни одного кадра A/B */
static volatile uint8_t  vnd_stream_active = 0; /* 1 после первой успешной передачи A или B */
/* Init-pump диагностика */
static volatile uint32_t init_pump_attempts = 0;    /* сколько циклов быстрой попытки отправки первой A */
static volatile uint32_t init_pump_a_sent  = 0;     /* 1+ если хотя бы одна A ушла через init-pump */

/* Временные метки/диагностика */
static volatile uint32_t first_test_sent_ms = 0;
static uint32_t dma_snapshot_full0 = 0;
static uint32_t dma_snapshot_full1 = 0;
static uint8_t no_dma_status_sent = 0;
static uint32_t dbg_last_forced_stat_ms = 0;
static uint8_t dbg_printed_sizes = 0;
static uint8_t dbg_any_valid_frame = 0;

/* Хостовые параметры для вывода на LCD */
static uint8_t host_profile = 0; /* последний профиль, присланный хостом (как есть) */

/* ДИАГНОСТИКА: отслеживание последней принятой команды START/STOP */
static volatile uint8_t  last_cmd_received = 0;     /* 0x20=START, 0x21=STOP, 0=none */
static volatile uint32_t last_cmd_timestamp_ms = 0; /* HAL_GetTick() когда команда получена */
static volatile uint32_t cmd_start_count = 0;       /* счётчик принятых START */
static volatile uint32_t cmd_stop_count = 0;        /* счётчик принятых STOP */

/* Sync master/slave via TIM16 CH1 */
static volatile uint8_t  vnd_sync_mode = VND_SYNC_MODE_SLAVE; /* 0=master, 1=slave, 2=off */
static volatile uint16_t vnd_sync_pending_hz = 0;
static volatile uint16_t vnd_sync_last_hz = 0;
static volatile uint32_t vnd_sync_last_apply_ms = 0;
static volatile uint32_t vnd_sync_last_capture = 0;
static volatile uint8_t  vnd_sync_capture_valid = 0;
static volatile uint32_t vnd_sync_tick_hz = 1000000u; /* TIM16 IC tick (Hz) */
static volatile uint32_t vnd_sync_last_capture_ms = 0;

/* Public status for LCD */
volatile uint8_t  vnd_sync_mode_public = VND_SYNC_MODE_SLAVE;
volatile uint8_t  vnd_sync_ok_public = 1u;
static volatile uint8_t  vnd_sync_mode_host_forced = 0u;
volatile uint8_t  vnd_lcd_role_overlay_enabled = 0u;
volatile uint8_t  vnd_lcd_role_overlay_active = 0u;
volatile uint8_t  vnd_lcd_role_overlay_period_s = 4u;
volatile uint8_t  vnd_lcd_role_overlay_duration_s = 4u;
volatile uint8_t  vnd_lcd_role_overlay_color_id = VND_LCD_SYNC_COLOR_WHITE;
volatile uint16_t vnd_lcd_role_overlay_rgb565 = 0xFFFFu;
volatile uint32_t vnd_lcd_role_overlay_config_seq = 0u;
volatile vnd_optic_source_diag_t vnd_optic_source_diag = {
    .cmd_value = 0xFFFFFFFFu, .applied = 0xFFFFFFFFu
};

static uint8_t vnd_lcd_role_overlay_clamp_s(uint8_t value_s)
{
    if (value_s < 3u) {
        return 3u;
    }
    if (value_s > 5u) {
        return 5u;
    }
    return value_s;
}

void vnd_lcd_role_overlay_configure(uint8_t enabled, uint8_t period_s, uint8_t duration_s)
{
    vnd_lcd_role_overlay_period_s = vnd_lcd_role_overlay_clamp_s(period_s);
    vnd_lcd_role_overlay_duration_s = vnd_lcd_role_overlay_clamp_s(duration_s);
    vnd_lcd_role_overlay_enabled = (enabled != 0u) ? 1u : 0u;
    vnd_lcd_role_overlay_active = 0u;
    vnd_lcd_role_overlay_config_seq++;
    need_usb_status_refresh = 1u;
}

void vnd_sync_on_edge(void)
{
    vnd_sync_last_capture_ms = HAL_GetTick();
    vnd_sync_ok_public = 1u;
}

/* TX диагностика */
static volatile uint8_t  vnd_tx_ready = 1;      /* готовность к новой передаче */
static volatile uint16_t vnd_last_tx_len = 0;   /* длина последней передачи */
static volatile uint32_t vnd_last_tx_start_ms = 0; /* время начала последней передачи */
/* Резерв: последний отправленный буфер (для fallback классификации при проблемах с meta-FIFO) */
static volatile uint8_t  last_tx_is_frame = 0;
static volatile uint8_t  last_tx_flags = 0;     /* 0x01=A, 0x02=B, 0x80=TEST */
static volatile uint32_t last_tx_seq = 0;
/* Простой «истинный» маркер текущей передачи (в полёте) — не зависит от очереди метаданных */
static volatile uint8_t  inflight_is_frame = 0;
static volatile uint8_t  inflight_flags = 0; /* 0x01/0x02/0x80 */
static volatile uint32_t inflight_seq = 0;
/* Режим полноценный/диагностический */
static volatile uint8_t full_mode = 1;          /* 1 = слать рабочие ADC кадры, 0 = только тест/статус */
static volatile uint64_t vnd_total_tx_bytes = 0ULL;
/* Ограничение выборок (0 = без ограничения -> берём полный буфер профиля) */
static volatile uint16_t vnd_trunc_samples = 0;
/* Параметры кадровой частоты */
static volatile uint16_t vnd_frame_samples_req = 0; /* если 0 — вычислять по умолчанию под ~20 FPS */
static volatile uint16_t vnd_pair_period_ms = 50;   /* целевой период пары A+B в миллисекундах */
static volatile uint32_t vnd_next_pair_ms = 0;      /* следующий момент разрешения отправки A новой пары */
static volatile uint32_t vnd_next_frame_tx_ms = 0;  /* минимальный момент старта следующего A/B IN */
static volatile uint8_t  vnd_last_tx_pace_busy = 0;
/* Флаг: первая полноценная пара (A->B) завершена. До этого STAT между парами стараемся не слать. */
static volatile uint8_t first_pair_done = 0;
/* Базовая отметка суммарных байт на момент START для вычисления дельты к STOP */
static volatile uint64_t vnd_tx_bytes_at_start = 0ULL;
/* Флаг для продолжения передачи из main/таска после TXCPLT */
volatile uint8_t vnd_tx_kick = 0;

/* Асинхронный режим передачи: 0 = строгие пары A->B (по умолчанию), 1 = A/B независимы */
static volatile uint8_t async_mode = 0;
/* Флаг: хост явно задавал async_mode через SET_ASYNC_MODE.
    Нужен, чтобы START не перетирал настройку и можно было включать парный/ROI режим. */
static volatile uint8_t async_mode_host_set = 0;
/* Режим каналов: 0=A-only, 1=B-only, 2=both (default) */
static volatile uint8_t vnd_ch_mode = 2;

/* Дефолтный размер кадра в полном режиме (семплов на канал) */
#ifndef VND_FULL_DEFAULT_SAMPLES
#define VND_FULL_DEFAULT_SAMPLES 300
#endif

/* Тестовый режим: генерация пилообразного сигнала вместо реальных данных ADC */
#define USE_TEST_SAWTOOTH 0 /* Отключаем полную замену пайплайна тестовым источником */
/* Новый мягкий режим: подменяем полезную нагрузку на пилу, но сохраняем ADC/DMA и async. */
#ifndef TEST_OVERLAY_SAWTOOTH
#define TEST_OVERLAY_SAWTOOTH 0  /* DISABLED: Testing real ADC data with forced EXTSEL/EXTEN */
#endif
/* реализация генератора тестового сигнала вынесена в vnd_testgen.* */
/* Разрешение на отправку STAT в стриме: 0=запрещено, 1=разрешён один STAT */
volatile uint8_t vnd_status_permit_once = 0;
/* Отложенная отправка тестового кадра после ACK-STAT */
static volatile uint8_t test_pending = 0;
/* Управление стартовым STAT (ACK на START) и единоразовым тестом */
static volatile uint8_t start_stat_planned = 0;   /* устаревший флаг, не используем для новой логики */
static volatile uint8_t start_stat_inflight = 0;  /* Стартовый STAT начат, ждём его завершения */
/* Флаг «ACK на START завершён» — разрешает единовременную отправку тестового кадра из таска */
static volatile uint8_t start_ack_done = 0;
/* Новые флаги пошаговой последовательности */
static volatile uint8_t status_ack_pending = 0;   /* Нужно отправить ACK-STAT на START (только из таска) */
static volatile uint8_t stop_request = 0;         /* Запрошен STOP (нужно отправить STAT, затем остановить) */
static volatile uint8_t stop_stat_inflight = 0;   /* Сейчас в полёте STAT как ACK на STOP */
/* Диагностика подготовки пар */
static volatile uint32_t dbg_prepare_calls = 0;
static volatile uint32_t dbg_prepare_ok = 0;
static volatile uint32_t dbg_task_calls = 0; /* сколько раз заходили в Vendor_Stream_Task */
static volatile uint32_t dbg_task_gap_count = 0;
static volatile uint32_t dbg_task_gap_last_ms = 0;
static volatile uint32_t dbg_task_gap_max_ms = 0;
static volatile uint32_t dbg_tx_force_idle_count = 0;
static volatile uint32_t dbg_tx_force_idle_last_ms = 0;
static volatile uint32_t dbg_tx_drop_recovery_count = 0;
static volatile uint32_t dbg_tx_drop_recovery_last_ms = 0;
static volatile uint32_t dbg_tx_drop_recovery_request_count = 0;
static vnd_usb_recovery_diag_t dbg_tx_drop_recovery_diag = {0};
static volatile uint32_t dbg_tx_active_hold_count = 0;
static volatile uint32_t dbg_tx_active_hold_last_ms = 0;
static volatile uint8_t  vnd_tx_drop_recovery_request = 0;
/* Счётчик пропущенных кадров (last-buffer-wins): сколько кадров FIFO было перескочено */
static volatile uint32_t dbg_skipped_frames = 0;

/* Состояния передачи пары */
static uint8_t channel0_sent_curseq = 0;
static uint8_t channel1_sent_curseq = 0;
static uint32_t __attribute__((unused)) last_sent_seq_adc0 = 0xFFFFFFFFu;
static uint32_t __attribute__((unused)) last_sent_seq_adc1 = 0xFFFFFFFFu;

/* Буфер статуса */
#ifndef VND_STATUS_MAX
#define VND_STATUS_MAX 137u
#endif
#ifndef VND_BULK_STATUS_MAX
#define VND_BULK_STATUS_MAX 136u
#endif
static uint8_t status_buf[VND_BULK_STATUS_MAX];
static vnd_status_v1_t g_status;
static volatile uint8_t pending_status = 0; /* требуется отправить STAT при освобождении EP */
/* Асинхронные event-пакеты для host-side change stream. */
#ifndef VND_EVENT_MAX
#define VND_EVENT_MAX 64u
#endif
#ifndef VND_EVENT_HDR_SIZE
#define VND_EVENT_HDR_SIZE 16u
#endif
#ifndef VND_EVENT_QUEUE_LEN
#define VND_EVENT_QUEUE_LEN 8u
#endif
#ifndef VND_TEMP_EVENT_PERIOD_MS
#define VND_TEMP_EVENT_PERIOD_MS 2000u
#endif
#ifndef VND_STATE_EVENT_PERIOD_MS
#define VND_STATE_EVENT_PERIOD_MS 250u
#endif
#ifndef VND_EVENT_HEARTBEAT_MS
#define VND_EVENT_HEARTBEAT_MS 30000u
#endif
#ifndef VND_SENSOR_VDDA_DELTA_MV
#define VND_SENSOR_VDDA_DELTA_MV 20u
#endif
#ifndef VND_SENSOR_VBAT_DELTA_MV
#define VND_SENSOR_VBAT_DELTA_MV 50u
#endif
static uint8_t vnd_event_q[VND_EVENT_QUEUE_LEN][VND_EVENT_MAX];
static uint8_t vnd_event_tx_buf[VND_EVENT_MAX];
static uint8_t vnd_event_len[VND_EVENT_QUEUE_LEN];
static volatile uint8_t vnd_event_head = 0u;
static volatile uint8_t vnd_event_tail = 0u;
static volatile uint8_t vnd_event_count = 0u;
static volatile uint32_t vnd_event_seq = 0u;
static volatile uint32_t vnd_event_last_enqueue_ms = 0u;
static volatile uint32_t dbg_event_enqueued = 0u;
static volatile uint32_t dbg_event_tx_attempt = 0u;
static volatile uint32_t dbg_event_tx_ok = 0u;
static volatile uint32_t dbg_event_tx_fail = 0u;
static volatile uint32_t dbg_event_tx_defer = 0u;
static volatile uint32_t dbg_event_tx_cplt = 0u;
static volatile uint32_t dbg_event_dropped = 0u;
static volatile uint8_t dbg_event_last_enqueue_type = 0xFFu;
static volatile uint8_t dbg_event_last_tx_type = 0xFFu;
static volatile uint8_t dbg_event_last_cplt_type = 0xFFu;
static volatile uint8_t vnd_event_inflight_type = 0xFFu;
static volatile uint8_t vnd_event_inflight_len = 0u;
static volatile uint32_t vnd_event_next_tx_ms = 0u;
static volatile uint8_t vnd_change_force_event = 1u;
static uint32_t vnd_sensor_last_poll_ms = 0u;
static uint32_t vnd_state_last_poll_ms = 0u;
static int16_t vnd_temp_last_sent_c = (int16_t)-32768;
static int16_t vnd_temp_last_read_c = 0;
static mcu_internal_adc_v1_t vnd_mcu_adc_last_sent;
static uint8_t vnd_mcu_adc_have_last = 0u;
static uint8_t vnd_optic_last_payload[8];
static uint8_t vnd_optic_last_len = 0u;
static uint8_t vnd_optic_have_last = 0u;
static uint8_t vnd_sync_last_payload[16];
static uint8_t vnd_sync_last_len = 0u;
static uint8_t vnd_sync_have_last = 0u;
static uint8_t vnd_sensor_map_last_payload[40];
static uint8_t vnd_sensor_map_last_len = 0u;
static uint8_t vnd_sensor_map_have_last = 0u;
static uint8_t vnd_mode_last_payload[16];
static uint8_t vnd_mode_last_len = 0u;
static uint8_t vnd_mode_have_last = 0u;
static uint8_t vnd_error_last_payload[16];
static uint8_t vnd_error_last_len = 0u;
static uint8_t vnd_error_have_last = 0u;
static volatile uint32_t dbg_frame_crc_finalized = 0u;
static volatile uint16_t dbg_frame_crc_last = 0u;
/* ADC frame reserved2 diagnostics for async source snapshot integrity. */
static volatile uint32_t dbg_async_snapshot_copies[2] = {0u, 0u};
static volatile uint32_t dbg_async_snapshot_gen_move[2] = {0u, 0u};
static volatile uint32_t dbg_async_snapshot_fifo_guard[2] = {0u, 0u};
static volatile uint32_t dbg_async_consume_ok[2] = {0u, 0u};
static volatile uint32_t dbg_async_consume_fail[2] = {0u, 0u};
static volatile uint32_t dbg_async_last_dma_seq[2] = {0u, 0u};
static volatile uint32_t dbg_async_last_wr_before[2] = {0u, 0u};
static volatile uint32_t dbg_async_last_wr_after[2] = {0u, 0u};
static volatile uint32_t dbg_async_last_rd_before[2] = {0u, 0u};
static volatile uint32_t dbg_async_last_rd_after[2] = {0u, 0u};
static volatile uint32_t dbg_async_last_ms[2] = {0u, 0u};
static volatile uint16_t dbg_async_last_samples[2] = {0u, 0u};
static volatile uint16_t dbg_async_last_reserved2[2] = {0u, 0u};
static volatile uint16_t dbg_async_last_crc16[2] = {0u, 0u};

#define VND_R2_BUFFER_INDEX_MASK      0x0007u
#define VND_R2_SOURCE_SLOT_SHIFT      3u
#define VND_R2_SOURCE_SLOT_MASK       0x00F8u
#define VND_R2_SNAPSHOT_USED          0x0100u
#define VND_R2_GENERATION_MOVED       0x0200u
#define VND_R2_FIFO_GUARD             0x0400u
#define VND_R2_CONSUME_OK             0x0800u
#define VND_R2_TXCPLT_SHIFT           12u
#define VND_R2_TXCPLT_MASK            0xF000u
/* Новые этапы (stage) времени старта потока/интерфейса */
volatile uint32_t vnd_stage_alt1_ms = 0;      /* фиксируется при SET_INTERFACE alt=1 */
volatile uint32_t vnd_stage_first_frame_ms = 0; /* фиксируется при первом успешном TXCPLT A/B */

/* Состояние фейковых кадров */
static __attribute__((unused)) uint8_t fake_inflight = 0;   /* reserved for diag */
static uint8_t diag_mode_active = 0; /* 1 = слать диагностические пары постоянно */
static uint16_t diag_hz = 60;        /* частота кадров-пар, Гц (20..100) (информативно) */
static uint32_t diag_period_ms = 0;  /* не используется для темпирования (макс. скорость) */
static uint32_t diag_next_ms = 0;    /* не используется для темпирования (сохранено для совместимости) */
static uint16_t diag_samples = VND_DEFAULT_TEST_SAMPLES; /* сэмплов на канал в диагностическом режиме */
static uint16_t diag_frame_len = 0;  /* общий размер кадра (hdr+payload) в диагностике */
/* Буферы диагностических кадров A/B (живут до завершения передачи) */
static uint8_t diag_a_buf[VND_FRAME_MAX_SIZE];
static uint8_t diag_b_buf[VND_FRAME_MAX_SIZE];
/* Последовательно подготовленная пара для текущего stream_seq в DIAG: */
static uint32_t diag_prepared_seq = 0xFFFFFFFFu;
static uint32_t diag_current_pair_seq = 0xFFFFFFFFu;
static uint16_t win_start0 = 0, win_len0 = 0, win_start1 = 0, win_len1 = 0;
static uint8_t win_auto = 1; /* авто-окно для ROI (зависит от частоты) */

#ifndef VND_ROI_LEN_DEFAULT
#define VND_ROI_LEN_DEFAULT 200u
#endif
#ifndef VND_ROI_BASE_START_200HZ
#define VND_ROI_BASE_START_200HZ 300u
#endif
#ifndef VND_ROI_BASE_MARKER_HZ
#define VND_ROI_BASE_MARKER_HZ 200u
#endif

static uint16_t vnd_compute_auto_roi_start(uint16_t samples, uint16_t marker_hz)
{
    int32_t delta = (int32_t)marker_hz - (int32_t)VND_ROI_BASE_MARKER_HZ;
    int32_t start = (int32_t)VND_ROI_BASE_START_200HZ + delta;
    int32_t max_start = (int32_t)samples - (int32_t)VND_ROI_LEN_DEFAULT;
    if (max_start < 0) max_start = 0;
    if (start < 0) start = 0;
    if (start > max_start) start = max_start;
    return (uint16_t)start;
}

static void vnd_apply_auto_roi_window(void)
{
    uint16_t samples = adc_stream_get_active_samples();
    if (samples == 0u) samples = 600u;
    uint16_t buf_rate = adc_stream_get_buf_rate();
    uint16_t marker_hz = (buf_rate != 0u) ? (uint16_t)(buf_rate / 2u) : (uint16_t)VND_ROI_BASE_MARKER_HZ;
    uint16_t new_start = vnd_compute_auto_roi_start(samples, marker_hz);
    win_len0 = VND_ROI_LEN_DEFAULT;
    win_start0 = new_start;
    win_start1 = 0u;
    win_len1 = 0u;
}

/* Текущий режим стриминга (по умолчанию оставляем текущий "последний буфер") */
static volatile uint8_t vnd_stream_mode = VND_STREAM_MODE_LATEST;

static inline uint8_t vnd_frame_pace_applies(void)
{
#if VND_USB_FRAME_PACE_MS > 0
    if(!streaming || diag_mode_active) return 0u;
    /* AVG_ROI is already rate-limited by buf_rate / avg_n. Extra USB pacing
       throttles avg_n=8/16 below their expected 50/25 fps and delays B after A. */
    return (vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI) ? 1u : 0u;
#else
    return 0u;
#endif
}

static inline uint8_t vnd_frame_pace_ready(uint32_t now_ms)
{
    if(!vnd_frame_pace_applies()) return 1u;
#if VND_USB_AFTER_HOST_ACK_PACE_MS > 0
    if(vnd_last_host_rx_ack_ms != 0u){
        uint32_t ack_age_ms = 0u;
        if(vnd_tick_age_ms(now_ms, vnd_last_host_rx_ack_ms, &ack_age_ms) &&
           ack_age_ms < (uint32_t)VND_USB_AFTER_HOST_ACK_PACE_MS){
            return 0u;
        }
    }
#endif
    if(vnd_next_frame_tx_ms == 0u) return 1u;
    return ((int32_t)(now_ms - vnd_next_frame_tx_ms) >= 0) ? 1u : 0u;
}

static inline void vnd_frame_pace_arm(uint32_t now_ms)
{
    if(vnd_frame_pace_applies()){
        vnd_next_frame_tx_ms = now_ms + (uint32_t)VND_USB_FRAME_PACE_MS;
    }
}

/* stream_mode=2: усреднение ROI по N буферам, раздельно для even/odd. */
static volatile uint8_t vnd_avg_n = 24; /* 8..64 (рабочие значения: 8/16/24/32/40/48/56/64) */
static uint8_t vnd_avg_cnt[2] = {0,0};
static uint8_t vnd_avg_next_parity = 0; /* 0=even, 1=odd (legacy; не используется для выпуска кадров) */
static uint32_t vnd_avg_last_dma_seq[2] = {0,0};
static uint32_t vnd_avg_last_ts_ms[2] = {0,0};
static uint32_t vnd_avg_sum[2][2][MAX_FRAME_SAMPLES]; /* [parity][ch][i] */
static __attribute__((unused)) uint16_t vnd_avg_out[2][MAX_FRAME_SAMPLES];    /* [ch][i] */

/* Диагностика stream_mode=2: сколько входных кадров съели / сколько усреднённых выпустили */
static volatile uint32_t dbg_avg_in_frames = 0;
static volatile uint32_t dbg_avg_out_frames = 0;
static volatile uint32_t dbg_avg_tx_pairs = 0;
static uint32_t dbg_avg_last_print_ms = 0;
static uint32_t dbg_avg_in_last = 0, dbg_avg_out_last = 0, dbg_avg_tx_last = 0;

/* DC: параметры */
#ifndef VND_DC_ROI_LEN
#define VND_DC_ROI_LEN 200u
#endif
#ifndef VND_DC_SAVE_PERIOD_MS
#define VND_DC_SAVE_PERIOD_MS (0u) /* отключено: сохранение только по команде хоста (0x2B) */
#endif
#ifndef VND_DC_SAVE_PERIOD_FIRST_MS
#define VND_DC_SAVE_PERIOD_FIRST_MS (0u) /* отключено: сохранение только по команде хоста (0x2B) */
#endif

/* Time-based adaptive DC. RPI sends the only runtime parameter: settle_ms.
   Zero disables learning; 1 is fastest; 1000 means one second. */
#ifndef VND_DC_SETTLE_MAX_MS
#define VND_DC_SETTLE_MAX_MS    (24u*60u*60u*1000u)
#endif
/* Proportional gain 8 gives exp(-8*t/settle). From 32768 LSB to the 16-LSB
   deadband this takes ln(32768/16)/8 = 0.953 * settle_ms. */
#ifndef VND_DC_ADAPTIVE_GAIN
#define VND_DC_ADAPTIVE_GAIN (8u)
#endif
#ifndef VND_DC_TARGET_ZERO
#define VND_DC_TARGET_ZERO (32768u)
#endif

/* Deadband для адаптации DC вокруг midscale.
    Без deadband даже при правильном DC из-за шума знак (v-32768) будет часто меняться,
    что приводит к "random walk" (постоянно dirty и ощущение, что после reboot всё заново).
    Значение в LSB. */
#ifndef VND_DC_DEADBAND
#define VND_DC_DEADBAND 16u
#endif

/* ВНИМАНИЕ: адрес Flash должен быть вне области прошивки.
   Мы резервируем последний сектор через линкер (см. STM32H723VGTX_FLASH.ld).
   Для 1MB FLASH: база последнего сектора = 0x080E0000 (128KB сектор №7). */
#ifndef VND_DC_FLASH_ADDR
#define VND_DC_FLASH_ADDR 0x080E0000u
#endif

#define VND_DC_MAGIC 0x31434456u /* 'V''D''C''1' little-endian */
/* ver=5: one shared DC table; pre/post select only the processing location. */
#define VND_DC_VER   5u

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint16_t ver;
    uint16_t roi_len; /* ожидаем 200 */
    uint32_t write_counter;
    uint16_t crc16; /* CRC16-CCITT по полю data[] */
    uint16_t _rsv0;

    int16_t  dc[2][2][VND_DC_ROI_LEN]; /* shared [ch][parity][i] DC correction */
    /* The previous blob was 1648 bytes but already occupied a 1664-byte
       flashword-aligned journal slot. The extra 16 bytes therefore add the
       selected-SLAVE metadata without changing slot addresses. */
    uint8_t  _pad[48];
} vnd_dc_blob_t;

/* Stored in the first 28 bytes of vnd_dc_blob_t::_pad. The last four bytes of
   _pad remain the existing DC commit marker, so DC journal v5 stays readable. */
#define VND_RS485_ROLE_META_MAGIC 0x5253u /* 'SR' */
#define VND_RS485_ROLE_META_VER_LEGACY 1u
#define VND_RS485_ROLE_META_VER        2u
typedef struct __attribute__((packed)) {
    uint16_t magic;
    uint8_t version;
    uint8_t flags;
    uint8_t node_id;
    uint8_t slave_id_high_water;
    uint32_t master_assigned_unix_s;
    uint16_t master_assigned_millis;
    uint8_t master_uid[12];
    uint16_t crc16;
    uint8_t reserved[2];
} vnd_rs485_role_meta_t;

/* Stored after the unchanged commit marker at _pad+32. Presence/validity is
   protected by flags in vnd_rs485_role_meta_t; this compact record stores a
   UID64 prefix, sufficient to recognize the selected board after reboot. A
   later RS485 claim/enum ACK upgrades it to the full UID96 in RAM. */
typedef struct __attribute__((packed)) {
    uint32_t slave_assigned_unix_s;
    uint16_t slave_assigned_millis;
    uint8_t slave_uid_prefix[8];
    uint16_t crc16;
} vnd_rs485_slave_meta_t;

/* Flash layout: append-only journal inside the reserved 128KB sector.
   This avoids long sector erase on every save (which can stall USB/main loop).
   We erase the sector only when it becomes full or journal tail is corrupted.
   Slot size must be multiple of 32 bytes for FLASHWORD programming. */
#define VND_DC_FLASH_SECTOR_SIZE (0x20000u)
#define VND_DC_SLOT_SIZE         (((uint32_t)sizeof(vnd_dc_blob_t) + 31u) & ~31u)
#define VND_DC_COMMIT_MAGIC      0x21434456u /* 'VDC!' little-endian */
#define VND_DC_COMMIT_OFFSET     ((uint32_t)offsetof(vnd_dc_blob_t, _pad) + 28u)
#define VND_RS485_SLAVE_META_OFFSET ((uint32_t)offsetof(vnd_dc_blob_t, _pad) + 32u)
#define VND_DC_RECOVERY_MAGIC    0x44524356u /* 'VCRD' little-endian */

_Static_assert((VND_DC_SLOT_SIZE % 32u) == 0u, "DC journal slot must be flashword aligned");
_Static_assert((VND_DC_COMMIT_OFFSET + sizeof(uint32_t)) <= sizeof(vnd_dc_blob_t),
               "DC commit marker must stay inside the blob");
_Static_assert(sizeof(vnd_rs485_role_meta_t) == 28u,
               "RS485 role metadata must leave the DC commit marker intact");
_Static_assert(sizeof(vnd_rs485_slave_meta_t) == 16u,
               "selected-SLAVE metadata must fit the old aligned journal slot");
_Static_assert(sizeof(vnd_dc_blob_t) == VND_DC_SLOT_SIZE,
               "extended DC blob must exactly fill one journal slot");

#ifndef VND_DC_SAVE_DRY_RUN
#define VND_DC_SAVE_DRY_RUN      0u
#endif

#ifndef VND_DC_SAVE_UNLOCK_TEST
#define VND_DC_SAVE_UNLOCK_TEST  0u
#endif

#ifndef VND_DC_SAVE_ERASE_ENABLE
#define VND_DC_SAVE_ERASE_ENABLE 1u
#endif

#ifndef VND_DC_SAVE_ERASE_ONLY_TEST
#define VND_DC_SAVE_ERASE_ONLY_TEST 0u
#endif

static int16_t  vnd_dc_buf[2][2][VND_DC_ROI_LEN];
static uint8_t  vnd_dc_loaded = 0;
static uint8_t  vnd_dc_dirty = 0;
static uint32_t vnd_dc_write_counter = 0;
static uint32_t vnd_dc_flash_next_off = 0;
static uint32_t vnd_dc_last_save_ms = 0;
static uint32_t vnd_dc_last_dirty_log_ms = 0;
static volatile uint8_t vnd_dc_load_request = 0;
static volatile uint8_t vnd_dc_save_request = 0;
/* K1 recovery uses previously reserved metadata bytes; DC slot addresses and
   the v2 RS485 role record remain readable by the previous firmware. */
#define VND_COMM_RECOVERY_META_FLAG 0x40u
#define VND_COMM_RECOVERY_CHECK 0xA55Au
#define VND_COMM_RECOVERY_HOLD_MS 2000u
/* CPU-only state lives in DTCM; keep the acquisition RAM_D1 budget unchanged.
   NOLOAD memory is initialized explicitly before reading the Flash journal. */
static volatile uint16_t vnd_comm_recovery_generation __attribute__((section(".ram_dtcm")));
static volatile uint8_t vnd_comm_recovery_pending __attribute__((section(".ram_dtcm")));
static volatile uint8_t vnd_comm_recovery_durable __attribute__((section(".ram_dtcm")));
static volatile uint16_t vnd_comm_recovery_ack_request __attribute__((section(".ram_dtcm")));
static uint8_t vnd_comm_recovery_boot_armed __attribute__((section(".ram_dtcm")));
static uint32_t vnd_comm_recovery_boot_ms __attribute__((section(".ram_dtcm")));
/* One coefficient bank and one time base per channel/parity. Fractional Q16
   progress is kept per sample so slow RPI settings remain accurate without a
   forced one-LSB step. */
static uint32_t vnd_dc_last_adapt_ms[2][2];
static uint32_t vnd_dc_adapt_frac_q16[2][2][VND_DC_ROI_LEN];

volatile uint32_t vnd_dc_speed_settle_ms = 0u;
volatile uint32_t vnd_dc_speed_set_at_ms = 0u;
volatile uint32_t vnd_dc_speed_cmd_count = 0u;
volatile uint32_t vnd_dc_speed_reject_count = 0u;
volatile uint32_t vnd_dc_adapt_call_count = 0u;
volatile uint32_t vnd_dc_adapt_updates = 0u;
volatile uint32_t vnd_dc_adapt_last_ms = 0u;
volatile uint32_t vnd_dc_adapt_last_dt_ms = 0u;
volatile uint32_t vnd_dc_adapt_max_abs_err = 0u;
volatile uint32_t vnd_dc_adapt_max_corr = 0u;
volatile int32_t  vnd_dc_adapt_mean_err = 0;

/* После reboot "чет/нечет" (parity) может оказаться инвертирован относительно того, что было
    во время обучения/сохранения (из-за фазировки старта DMA/TIM).
    Мы НЕ смешиваем 4 DC массива, а один раз на старте определяем swap (0/1) и дальше
    используем parity^swap при применении/адаптации. */
static uint8_t vnd_dc_parity_swap = 0;
static uint8_t vnd_dc_parity_swap_valid = 0;

static void vnd_dc_load_once(void);
static void vnd_dc_apply_only(uint8_t ch, uint8_t parity, uint16_t *out, uint16_t roi_len);
static void vnd_dc_apply_and_adapt(uint8_t ch, uint8_t parity, uint16_t *out, uint16_t roi_len);
static void vnd_avg_reset(void);

/* Exported counters for LCD/diagnostics (see usb_vendor_app.h) */
volatile uint32_t vnd_dc_save_ok_count = 0;
volatile uint32_t vnd_dc_save_fail_count = 0;
volatile uint32_t vnd_dc_save_last_ms = 0;
volatile uint8_t  vnd_dc_save_last_result = 0; /* 0=none, 1=ok, 2=fail */

/* Public mirror of blob write_counter for LCD/debug (see usb_vendor_app.h) */
volatile uint32_t vnd_dc_write_counter_public = 0;

/* Exported live state for LCD progress indicator */
volatile uint8_t  vnd_dc_dirty_public = 0;
volatile uint32_t vnd_dc_dirty_since_ms = 0;
volatile uint32_t vnd_dc_save_period_ms = (uint32_t)VND_DC_SAVE_PERIOD_MS;

/* DC save diagnostics */
volatile uint32_t vnd_dc_save_last_err = 0;
volatile uint32_t vnd_dc_save_last_sector_error = 0;
volatile uint32_t vnd_dc_save_last_bank = 0;
volatile uint32_t vnd_dc_save_last_sector = 0;

/* DC load diagnostics (published for LCD) */
volatile uint8_t  vnd_dc_load_flags_public = 0; /* bit0=loaded OK, bit1=erase_pending */
volatile uint16_t vnd_dc_loaded_crc16_public = 0;
volatile uint32_t vnd_dc_flash_next_off_public = 0;

void vnd_dc_request_save_to_flash(void)
{
    vnd_dc_save_request = 1u;
}

static void vnd_dc_reset_adapt_timestamps(void)
{
    memset(vnd_dc_last_adapt_ms, 0, sizeof(vnd_dc_last_adapt_ms));
    memset(vnd_dc_adapt_frac_q16, 0, sizeof(vnd_dc_adapt_frac_q16));
}

static void vnd_dc_reset_adapt_state(void)
{
    vnd_dc_reset_adapt_timestamps();
}

/* ADC restart can start the physical even/odd marker from the opposite phase.
   The coefficients themselves remain valid, but their parity mapping must be
   selected again before the first new frame is processed. */
static __attribute__((unused)) void vnd_dc_on_adc_restart(void)
{
    vnd_dc_parity_swap_valid = 0u;
    /* The RPI speed is wall-clock based and remains active across ADC restarts.
       Preserve per-bank timestamps/budgets so the next frame catches up instead
       of restarting the requested settle interval from an artificial 20 ms. */
}

static uint32_t vnd_dc_rd_le32(const uint8_t *p)
{
    return (uint32_t)p[0] |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

static uint8_t vnd_dc_apply_speed_payload(const uint8_t *payload, uint32_t payload_len)
{
    if(payload == NULL || payload_len != sizeof(uint32_t)) return 0u;

    uint32_t settle_ms = vnd_dc_rd_le32(payload);
    if(settle_ms > (uint32_t)VND_DC_SETTLE_MAX_MS) return 0u;
    if(settle_ms != vnd_dc_speed_settle_ms){
        /* A speed change only changes the gain from the next update onward.
           Keep the per-bank wall-clock timestamps and sub-LSB Q16 residue so
           repeated RPI speed commands cannot restart or stall convergence. */
        vnd_dc_speed_settle_ms = settle_ms;
    }
    vnd_dc_speed_set_at_ms = HAL_GetTick();
    vnd_dc_speed_cmd_count++;
    return 1u;
}

typedef struct {
    uint32_t magic;
    uint32_t magic_inv;
    uint32_t fault_addr;
    uint32_t cfsr;
    uint32_t count;
} vnd_dc_recovery_t;

static volatile vnd_dc_recovery_t __attribute__((section(".noinit"))) vnd_dc_recovery;

static uint8_t vnd_dc_flash_addr_in_range(uint32_t addr)
{
    return (uint8_t)((addr >= (uint32_t)VND_DC_FLASH_ADDR) &&
                     (addr < ((uint32_t)VND_DC_FLASH_ADDR + (uint32_t)VND_DC_FLASH_SECTOR_SIZE)));
}

uint8_t vnd_dc_note_flash_fault(uint32_t fault_addr, uint32_t cfsr)
{
    if(!vnd_dc_flash_addr_in_range(fault_addr)) return 0u;

    if(vnd_dc_recovery.magic != VND_DC_RECOVERY_MAGIC ||
       vnd_dc_recovery.magic_inv != ~VND_DC_RECOVERY_MAGIC){
        vnd_dc_recovery.count = 0;
    }
    vnd_dc_recovery.magic = VND_DC_RECOVERY_MAGIC;
    vnd_dc_recovery.magic_inv = ~VND_DC_RECOVERY_MAGIC;
    vnd_dc_recovery.fault_addr = fault_addr;
    vnd_dc_recovery.cfsr = cfsr;
    vnd_dc_recovery.count++;
    return 1u;
}

static void vnd_dc_flash_clear_error_flags(void)
{
#if defined(FLASH_FLAG_ALL_ERRORS)
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);
#elif defined(FLASH_FLAG_ALL_ERRORS_BANK1)
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS_BANK1);
    #if defined(FLASH_FLAG_ALL_ERRORS_BANK2)
        __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS_BANK2);
    #endif
#else
    /* Nothing to clear on this HAL variant. */
#endif
}

static void vnd_dc_flash_erase_target(uint32_t *bank, uint32_t *sector)
{
    uint32_t erase_bank = FLASH_BANK_1;
    uint32_t erase_sector;
    uint32_t rel = (uint32_t)VND_DC_FLASH_ADDR - 0x08000000u;
    uint32_t sec_global = rel / 0x20000u;

    if(sec_global >= (uint32_t)FLASH_SECTOR_TOTAL){
        sec_global = (uint32_t)FLASH_SECTOR_TOTAL - 1u;
    }

#if defined(FLASH_BANK_2)
    if(sec_global >= 4u) erase_bank = FLASH_BANK_2;
#endif

#if defined(FLASH_SECTOR_0)
    erase_sector = (uint32_t)FLASH_SECTOR_0 + sec_global;
#else
    erase_sector = sec_global;
#endif

    *bank = erase_bank;
    *sector = erase_sector;
}

static HAL_StatusTypeDef vnd_dc_erase_reserved_sector(uint32_t *sector_error,
                                                       uint32_t *erase_bank,
                                                       uint32_t *erase_sector)
{
    FLASH_EraseInitTypeDef e;
    vnd_dc_flash_erase_target(erase_bank, erase_sector);
    memset(&e, 0, sizeof(e));
    e.TypeErase = FLASH_TYPEERASE_SECTORS;
    e.Banks = *erase_bank;
    e.Sector = *erase_sector;
    e.NbSectors = 1;
    return HAL_FLASHEx_Erase(&e, sector_error);
}

static uint32_t vnd_dc_blob_commit_value(const vnd_dc_blob_t *b)
{
    uint32_t commit = 0u;
    memcpy(&commit, ((const uint8_t*)b) + VND_DC_COMMIT_OFFSET, sizeof(commit));
    return commit;
}

static void vnd_dc_blob_set_commit(vnd_dc_blob_t *b)
{
    const uint32_t commit = VND_DC_COMMIT_MAGIC;
    memcpy(((uint8_t*)b) + VND_DC_COMMIT_OFFSET, &commit, sizeof(commit));
}

static void vnd_dc_boot_recovery_erase_if_requested(void)
{
    static uint8_t checked = 0;
    if(checked) return;
    checked = 1;

    if(vnd_dc_recovery.magic != VND_DC_RECOVERY_MAGIC ||
       vnd_dc_recovery.magic_inv != ~VND_DC_RECOVERY_MAGIC){
        return;
    }

    uint32_t erase_bank = 0;
    uint32_t erase_sector = 0;
    uint32_t sector_error = 0;
    uint32_t err = 0;

    printf("[DC] RECOVERY: erase reserved flash after fault addr=0x%08lX cfsr=0x%08lX count=%lu\r\n",
           (unsigned long)vnd_dc_recovery.fault_addr,
           (unsigned long)vnd_dc_recovery.cfsr,
           (unsigned long)vnd_dc_recovery.count);

    HAL_FLASH_Unlock();
    vnd_dc_flash_clear_error_flags();
    HAL_StatusTypeDef st = vnd_dc_erase_reserved_sector(&sector_error, &erase_bank, &erase_sector);
    HAL_FLASH_Lock();

#if defined(HAL_FLASH_GetError)
    err = HAL_FLASH_GetError();
#endif
    vnd_dc_save_last_bank = erase_bank;
    vnd_dc_save_last_sector = erase_sector;
    vnd_dc_save_last_sector_error = sector_error;
    vnd_dc_save_last_err = err;
    vnd_dc_save_last_ms = HAL_GetTick();

    if(st == HAL_OK){
        vnd_dc_recovery.magic = 0;
        vnd_dc_recovery.magic_inv = 0;
        vnd_dc_flash_next_off = 0;
        vnd_dc_flash_next_off_public = 0;
        vnd_dc_load_flags_public = 0;
        printf("[DC] RECOVERY OK: erased bank=%lu sector=%lu\r\n",
               (unsigned long)erase_bank, (unsigned long)erase_sector);
    } else {
        vnd_dc_save_fail_count++;
        vnd_dc_save_last_result = 2;
        vnd_dc_loaded = 1;
        memset(vnd_dc_buf, 0, sizeof(vnd_dc_buf));
        vnd_dc_dirty = 0;
        vnd_dc_dirty_public = 0;
        vnd_dc_dirty_since_ms = 0;
        vnd_dc_flash_next_off = VND_DC_FLASH_SECTOR_SIZE;
        vnd_dc_flash_next_off_public = vnd_dc_flash_next_off;
        printf("[DC] RECOVERY FAIL: bank=%lu sector=%lu err=0x%08lX sec_err=%lu; DC disabled for this boot\r\n",
               (unsigned long)erase_bank, (unsigned long)erase_sector,
               (unsigned long)err, (unsigned long)sector_error);
    }
}

/* DC compensation is independent of stream_mode and runs on every new raw frame. */

static uint16_t vnd_crc16_ccitt(const uint8_t *data, uint32_t len); /* объявлена ниже в файле */

static uint16_t vnd_rs485_role_meta_crc(const vnd_rs485_role_meta_t *meta)
{
    uint32_t start = (uint32_t)offsetof(vnd_rs485_role_meta_t, version);
    uint32_t end = (uint32_t)offsetof(vnd_rs485_role_meta_t, crc16);
    return vnd_crc16_ccitt(((const uint8_t *)meta) + start, end - start);
}

static uint16_t vnd_rs485_slave_meta_crc(const vnd_rs485_slave_meta_t *meta)
{
    return vnd_crc16_ccitt((const uint8_t *)meta,
                           (uint32_t)offsetof(vnd_rs485_slave_meta_t, crc16));
}

static void vnd_rs485_role_meta_store(vnd_dc_blob_t *blob)
{
    rs485_role_persist_state_t state;
    vnd_rs485_role_meta_t meta;
    vnd_rs485_slave_meta_t slave_meta;

    if(blob == NULL) return;
    memset(&state, 0, sizeof(state));
    memset(&meta, 0, sizeof(meta));
    memset(&slave_meta, 0, sizeof(slave_meta));
    rs485_role_persist_export(&state);

    meta.magic = VND_RS485_ROLE_META_MAGIC;
    meta.version = VND_RS485_ROLE_META_VER;
    meta.flags = state.flags | (vnd_comm_recovery_pending ? VND_COMM_RECOVERY_META_FLAG : 0u);
    meta.reserved[0] = (uint8_t)vnd_comm_recovery_generation;
    meta.reserved[1] = (uint8_t)(vnd_comm_recovery_generation >> 8);
    blob->_rsv0 = vnd_comm_recovery_generation ^ VND_COMM_RECOVERY_CHECK;
    meta.node_id = state.node_id;
    meta.slave_id_high_water = state.slave_id_high_water;
    meta.master_assigned_unix_s = state.master_assigned_unix_s;
    meta.master_assigned_millis = state.master_assigned_millis;
    memcpy(meta.master_uid, state.master_uid, sizeof(meta.master_uid));
    meta.crc16 = vnd_rs485_role_meta_crc(&meta);
    memcpy(blob->_pad, &meta, sizeof(meta));

    if ((state.flags & RS485_ROLE_PERSIST_SLAVE_EPOCH) != 0u) {
        slave_meta.slave_assigned_unix_s = state.slave_assigned_unix_s;
        slave_meta.slave_assigned_millis = state.slave_assigned_millis;
        if ((state.flags & RS485_ROLE_PERSIST_SLAVE_VALID) != 0u) {
            memcpy(slave_meta.slave_uid_prefix,
                   state.slave_uid,
                   sizeof(slave_meta.slave_uid_prefix));
        }
        slave_meta.crc16 = vnd_rs485_slave_meta_crc(&slave_meta);
        memcpy(((uint8_t *)blob) + VND_RS485_SLAVE_META_OFFSET,
               &slave_meta,
               sizeof(slave_meta));
    }
}

static void vnd_rs485_role_meta_restore(const vnd_dc_blob_t *blob)
{
    rs485_role_persist_state_t state;
    vnd_rs485_role_meta_t meta;
    vnd_rs485_slave_meta_t slave_meta;

    if(blob == NULL) return;
    memcpy(&meta, blob->_pad, sizeof(meta));
    if(meta.magic != VND_RS485_ROLE_META_MAGIC ||
       ((meta.version != VND_RS485_ROLE_META_VER_LEGACY) &&
        (meta.version != VND_RS485_ROLE_META_VER)) ||
       meta.crc16 != vnd_rs485_role_meta_crc(&meta)){
        return;
    }

    memset(&state, 0, sizeof(state));
    state.flags = meta.flags & (uint8_t)~VND_COMM_RECOVERY_META_FLAG;
    {
        uint16_t generation = (uint16_t)meta.reserved[0] | ((uint16_t)meta.reserved[1] << 8);
        if (blob->_rsv0 == (uint16_t)(generation ^ VND_COMM_RECOVERY_CHECK)) {
            vnd_comm_recovery_generation = generation;
            vnd_comm_recovery_pending = ((meta.flags & VND_COMM_RECOVERY_META_FLAG) != 0u && generation != 0u);
            vnd_comm_recovery_durable = 1u;
        }
    }
    state.node_id = meta.node_id;
    state.slave_id_high_water = meta.slave_id_high_water;
    state.master_assigned_unix_s = meta.master_assigned_unix_s;
    state.master_assigned_millis = meta.master_assigned_millis;
    memcpy(state.master_uid, meta.master_uid, sizeof(state.master_uid));
    if (meta.version == VND_RS485_ROLE_META_VER_LEGACY) {
        /* v1 could preserve sparse/provisional ids such as S23 and could also
           leave several boards unassigned. Keep the network-wide MASTER and
           selected sensor-SLAVE, but commission slave ids again exactly once.
           The first successful assignment saves this record as v2. */
        state.flags &= (uint8_t)~RS485_ROLE_PERSIST_NODE_VALID;
        state.node_id = 0u;
        state.slave_id_high_water = 0u;
    }
    if ((state.flags & RS485_ROLE_PERSIST_SLAVE_EPOCH) != 0u) {
        memcpy(&slave_meta,
               ((const uint8_t *)blob) + VND_RS485_SLAVE_META_OFFSET,
               sizeof(slave_meta));
        if ((slave_meta.slave_assigned_unix_s == 0u) ||
            (slave_meta.slave_assigned_millis >= 1000u) ||
            (slave_meta.crc16 != vnd_rs485_slave_meta_crc(&slave_meta))) {
            state.flags &= (uint8_t)~(RS485_ROLE_PERSIST_SLAVE_EPOCH |
                                      RS485_ROLE_PERSIST_SLAVE_VALID |
                                      RS485_ROLE_PERSIST_SLAVE_UID64);
        } else {
            state.slave_assigned_unix_s = slave_meta.slave_assigned_unix_s;
            state.slave_assigned_millis = slave_meta.slave_assigned_millis;
            if ((state.flags & RS485_ROLE_PERSIST_SLAVE_VALID) != 0u) {
                memcpy(state.slave_uid,
                       slave_meta.slave_uid_prefix,
                       sizeof(slave_meta.slave_uid_prefix));
                state.flags |= RS485_ROLE_PERSIST_SLAVE_UID64;
            }
        }
    }
    rs485_role_persist_import(&state);
}

/* === TIM5 sync helpers (32-bit phase counter) === */
__attribute__((unused))
static uint32_t vnd_tim5_get_tim_clk(void)
{
    uint32_t pclk1 = HAL_RCC_GetPCLK1Freq();
    uint32_t ppre1 = (RCC->D2CFGR & RCC_D2CFGR_D2PPRE1) >> RCC_D2CFGR_D2PPRE1_Pos;
    return ((ppre1 & 0x4u) != 0u) ? (pclk1 * 2u) : pclk1;
}

__attribute__((unused))
static void vnd_sync_stop_tim5(void)
{
    (void)HAL_TIM_Base_Stop(&htim5);
}

__attribute__((unused))
static void vnd_sync_start_tim5_base(void)
{
    (void)HAL_TIM_Base_Start(&htim5);
}

static void vnd_sync_set_master(uint16_t buf_rate_hz)
{
    /* TIM5 теперь используется как 32-битный счётчик фазы, не как генератор синхроимпульсов */
    (void)buf_rate_hz;
    vnd_sync_last_hz = buf_rate_hz;
}

static void vnd_sync_set_slave(void)
{
    /* TIM5 как 32-битный счётчик фазы: запускается базовым таймером в main.c */
    vnd_sync_capture_valid = 0;
}

static void vnd_sync_apply_mode(uint8_t mode)
{
    if(mode > VND_SYNC_MODE_OFF) mode = VND_SYNC_MODE_OFF;

    /* A repeated role announcement is state refresh, not a reason to touch
       timers, ADC/DMA or the host-controlled TX200 output. */
    if(mode == vnd_sync_mode_public) {
        vnd_sync_mode = mode;
        return;
    }

    vnd_sync_mode = mode;
    {
        extern volatile uint8_t sync_edge_seen;
        extern volatile uint32_t sync_last_edge_ms;
        extern TIM_HandleTypeDef htim5;
        extern volatile uint8_t sync_align_pending;
        extern volatile uint8_t sync_phase_lock_armed;
        extern volatile uint8_t sync_phase_lock_active;
        extern volatile uint8_t sync_restart_on_edge;
        sync_edge_seen = 0u;
        sync_last_edge_ms = 0u;
        htim5.Instance->CNT = 0u;
        sync_align_pending = 0u;
        sync_phase_lock_armed = 0u;
        sync_phase_lock_active = 0u;
        sync_restart_on_edge = 0u;
    }
    if(mode == VND_SYNC_MODE_MASTER){
        vnd_sync_mode_public = VND_SYNC_MODE_MASTER;
        vnd_sync_set_master(0u);
        vnd_sync_ok_public = 1u;
    } else if(mode == VND_SYNC_MODE_SLAVE){
        vnd_sync_mode_public = VND_SYNC_MODE_SLAVE;
        vnd_sync_set_slave();
        vnd_sync_ok_public = 0u;
        vnd_sync_start_tim5_base();
    } else {
        vnd_sync_mode_public = VND_SYNC_MODE_OFF;
        vnd_sync_ok_public = 0u;
    }
    vnd_sync_pending_hz = 0u;
    vnd_sync_last_capture_ms = 0u;
    vnd_sync_last_apply_ms = 0u;
    HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
    /* Role changes must not clear the RPI rate override, restart ADC/DMA,
       reset frame parity, or alter the persistent SET_TX_ENABLE request. */
    cdc_logf("EVT SYNC_MODE APPLY mode=%u continuous_adc=1 tx_unchanged=1",
             (unsigned)mode);
}

static void vnd_sync_apply_host_forced_mode(uint8_t mode)
{
    if(mode > VND_SYNC_MODE_OFF) mode = VND_SYNC_MODE_OFF;

    vnd_sync_mode_host_forced = 1u;
    vnd_sync_apply_mode(mode);
}

/* Принудительная установка режима (не блокируется флагом host_forced) */
void vnd_sync_apply_mode_forced(uint8_t mode)
{
    if(mode == VND_SYNC_MODE_MASTER) {
        /* Network MASTER may only be appointed by the timestamped host
           command handled by rs485_role_assign_master_from_host(). */
        return;
    }
    vnd_sync_apply_host_forced_mode(mode);
}

/* A newer network-wide host assignment must be able to demote an older local
   host-forced MASTER. */
void vnd_sync_apply_network_mode(uint8_t mode)
{
    vnd_sync_mode_host_forced = 0u;
    vnd_sync_apply_mode(mode);
}

/* Снятие принудительного режима, возврат к автоматическому */
void vnd_sync_release_host_forced(void)
{
    uint8_t persisted_mode = VND_SYNC_MODE_SLAVE;

    vnd_sync_mode_host_forced = 0u;
    if(rs485_role_get_local_persisted_mode(&persisted_mode) == 0u) {
        persisted_mode = VND_SYNC_MODE_SLAVE;
    }
    vnd_sync_apply_mode(persisted_mode);
}

uint8_t vnd_sync_is_mode_host_forced(void)
{
    return vnd_sync_mode_host_forced;
}

static int16_t *vnd_dc_bank(uint8_t ch, uint8_t parity)
{
    if(ch > 1u || parity > 1u) return NULL;
    return vnd_dc_buf[ch][parity];
}

__attribute__((unused))
static uint16_t vnd_dc_bank_crc16(uint8_t ch, uint8_t parity)
{
    if(ch > 1u || parity > 1u) return 0;
    return vnd_crc16_ccitt((const uint8_t*)vnd_dc_buf[ch][parity], (uint32_t)sizeof(vnd_dc_buf[ch][parity]));
}

static uint32_t vnd_dc_score_bank(const uint16_t *raw, uint16_t raw_ns, uint16_t roi_start, uint16_t roi_len, uint8_t ch, uint8_t parity)
{
    if(!raw) return 0xFFFFFFFFu;
    if(ch > 1u || parity > 1u) return 0xFFFFFFFFu;
    if(roi_len != (uint16_t)VND_DC_ROI_LEN) return 0xFFFFFFFFu;
    if(raw_ns < (uint16_t)(roi_start + roi_len)) return 0xFFFFFFFFu;
    int16_t *bank = vnd_dc_bank(ch, parity);
    if(bank == NULL) return 0xFFFFFFFFu;

    /* Скоринг: весь ROI (200 точек). Это выполняется редко (один раз после reboot),
       поэтому лучше быть надёжным, чем быстрым. */
    uint32_t acc = 0;
    for(uint16_t i = 0; i < roi_len; i++){
        uint16_t v = raw[roi_start + i];
        int16_t dc = bank[i];
        int32_t y = (int32_t)v + (int32_t)dc;
        int32_t e = y - (int32_t)VND_DC_TARGET_ZERO;
        if(e < 0) e = -e;
        acc += (uint32_t)e;
    }
    return acc;
}

/* Resolve the physical even/odd phase against the two persistent banks from
   the first complete pair after boot or ADC restart. This helper must be used
   by every 200-sample path: AVG streaming intentionally skips the background
   maintenance pass, so relying on that pass would leave a stale/default map. */
static void vnd_dc_ensure_parity_mapping(const uint16_t *raw_a,
                                         const uint16_t *raw_b,
                                         uint16_t raw_ns,
                                         uint16_t roi_start,
                                         uint16_t roi_len,
                                         uint8_t raw_parity)
{
    if(vnd_dc_parity_swap_valid) return;
    if(raw_a == NULL || raw_b == NULL) return;
    if(roi_len != (uint16_t)VND_DC_ROI_LEN) return;
    if(raw_ns < (uint16_t)(roi_start + roi_len)) return;

    raw_parity &= 1u;
    uint32_t score_direct = 0u;
    uint32_t score_swapped = 0u;
    score_direct += vnd_dc_score_bank(raw_a, raw_ns, roi_start, roi_len, 0u, raw_parity);
    score_direct += vnd_dc_score_bank(raw_b, raw_ns, roi_start, roi_len, 1u, raw_parity);
    score_swapped += vnd_dc_score_bank(raw_a, raw_ns, roi_start, roi_len, 0u, (uint8_t)(raw_parity ^ 1u));
    score_swapped += vnd_dc_score_bank(raw_b, raw_ns, roi_start, roi_len, 1u, (uint8_t)(raw_parity ^ 1u));

    vnd_dc_parity_swap = (score_swapped < score_direct) ? 1u : 0u;
    vnd_dc_parity_swap_valid = 1u;
    VND_DC_LOGF("[DC] PARITY_REMAP=%u raw_p=%u direct=%lu swapped=%lu\r\n",
                (unsigned)vnd_dc_parity_swap,
                (unsigned)raw_parity,
                (unsigned long)score_direct,
                (unsigned long)score_swapped);
}

static inline void vnd_invalidate_dcache_range(uint32_t addr, uint32_t len)
{
#if (VND_ENABLE_CACHE_INVALIDATE && (__DCACHE_PRESENT == 1U))
    if(len == 0u) return;
    uint32_t a0 = addr & ~31u;
    uint32_t a1 = (addr + len + 31u) & ~31u;
    uint32_t alen = a1 - a0;
    SCB_InvalidateDCache_by_Addr((uint32_t*)a0, (int32_t)alen);
#else
    (void)addr; (void)len;
#endif
}

/* Background DC maintenance (always-on, independent of stream_mode).
   Uses every new raw ADC latest FIFO frame (peek) and the one RPI-set speed.
   IMPORTANT: uses peek API so it does NOT consume FIFO frames used for USB streaming. */
static void vnd_dc_background_step(uint16_t roi_start, uint16_t roi_len)
{
    /* Обязательно загрузить DC из Flash как можно раньше после reboot,
       даже если окно пока не выставлено в 200. */
    vnd_dc_load_once();
    /* DC owns one fixed 200-sample region. The current USB window length is not
       a permission flag and must never stop adaptation. */
    (void)roi_len;
    roi_len = (uint16_t)VND_DC_ROI_LEN;

     /* Обновляемся на каждом новом FIFO-кадре; скорость обучения задаёт host через settle_ms. */
    static uint32_t last_seq = 0xFFFFFFFFu;

    uint16_t *a_ptr = NULL, *b_ptr = NULL; uint16_t ns = 0; uint32_t dma_seq = 0;
    if(!adc_peek_latest_frame_pair_fifo(&a_ptr, &b_ptr, &ns, &dma_seq)){
        return;
    }
    if(dma_seq == last_seq) return;
    last_seq = dma_seq;
    if(!a_ptr || !b_ptr) return;
    if(ns < roi_len) return;
    if(((uint32_t)roi_start + (uint32_t)roi_len) > (uint32_t)ns){
        uint16_t default_start = (uint16_t)VND_ROI_BASE_START_200HZ;
        roi_start = (((uint32_t)default_start + (uint32_t)roi_len) <= (uint32_t)ns)
                  ? default_start
                  : (uint16_t)(ns - roi_len);
    }

    uint32_t now_ms = HAL_GetTick();

    uint8_t parity = (uint8_t)(adc_get_buffer_parity(dma_seq) & 1u);

    /* Use local copy of ROI so we don't mutate ADC buffers. */
    static uint16_t tmp_a[VND_DC_ROI_LEN];
    static uint16_t tmp_b[VND_DC_ROI_LEN];
    memcpy(tmp_a, a_ptr + roi_start, (size_t)roi_len * sizeof(uint16_t));
    memcpy(tmp_b, b_ptr + roi_start, (size_t)roi_len * sizeof(uint16_t));

    /* Диагностика согласования с GUI: раз в секунду печатаем min/max/mean по ROI
       до и после применения DC (для тех же данных). */
    static uint32_t last_stats_ms = 0;
    uint8_t do_stats = 0u;
    if(last_stats_ms == 0u || (now_ms - last_stats_ms) >= 1000u){
        last_stats_ms = now_ms;
        do_stats = 1u;
    }
    uint16_t raw_mn_a = 0xFFFFu, raw_mx_a = 0u;
    uint16_t raw_mn_b = 0xFFFFu, raw_mx_b = 0u;
    __attribute__((unused)) int32_t raw_mean_a = 0;
    __attribute__((unused)) int32_t raw_mean_b = 0;
    if(do_stats){
        int64_t sum_a = 0;
        int64_t sum_b = 0;
        for(uint16_t i = 0; i < roi_len; i++){
            uint16_t va = tmp_a[i];
            uint16_t vb = tmp_b[i];
            if(va < raw_mn_a) raw_mn_a = va;
            if(va > raw_mx_a) raw_mx_a = va;
            if(vb < raw_mn_b) raw_mn_b = vb;
            if(vb > raw_mx_b) raw_mx_b = vb;
            sum_a += (int32_t)va;
            sum_b += (int32_t)vb;
        }
        raw_mean_a = (int32_t)(sum_a / (int32_t)roi_len);
        raw_mean_b = (int32_t)(sum_b / (int32_t)roi_len);
    }

    /* Ensure persisted DC is loaded before first adapt. */
    vnd_dc_load_once();

    vnd_dc_ensure_parity_mapping(a_ptr, b_ptr, ns, roi_start, roi_len, parity);

    /* Один раз после загрузки определяем, не инвертирован ли parity. */
    if(!vnd_dc_parity_swap_valid){
        uint32_t s0 = 0, s1 = 0;
        /* swap=0: используем parity как есть */
        s0 += vnd_dc_score_bank(a_ptr, ns, roi_start, roi_len, 0u, parity);
        s0 += vnd_dc_score_bank(b_ptr, ns, roi_start, roi_len, 1u, parity);
        /* swap=1: используем инвертированный parity */
        s1 += vnd_dc_score_bank(a_ptr, ns, roi_start, roi_len, 0u, (uint8_t)(parity ^ 1u));
        s1 += vnd_dc_score_bank(b_ptr, ns, roi_start, roi_len, 1u, (uint8_t)(parity ^ 1u));

        if(s1 < s0){
            vnd_dc_parity_swap = 1u;
        } else {
            vnd_dc_parity_swap = 0u;
        }
        vnd_dc_parity_swap_valid = 1u;
        VND_DC_LOGF("[DC] PARITY_SWAP=%u (raw_parity=%u s0=%lu s1=%lu)\r\n",
               (unsigned)vnd_dc_parity_swap, (unsigned)parity,
               (unsigned long)s0, (unsigned long)s1);

        /* Одноразовая проверка, что применяемый банк действительно центрирует ROI. */
        {
            uint8_t p_use = (uint8_t)(parity ^ vnd_dc_parity_swap);
            uint8_t p_alt = (uint8_t)(p_use ^ 1u);
            int16_t *bank_a = vnd_dc_bank(0u, p_use);
            int16_t *bank_b = vnd_dc_bank(1u, p_use);
            int16_t *bank2_a = vnd_dc_bank(0u, p_alt);
            int16_t *bank2_b = vnd_dc_bank(1u, p_alt);

            int64_t raw_sum_a = 0, raw_sum_b = 0;
            for(uint16_t i = 0; i < roi_len; i++){
                raw_sum_a += (int32_t)a_ptr[roi_start + i];
                raw_sum_b += (int32_t)b_ptr[roi_start + i];
            }
            __attribute__((unused)) int32_t raw_mean_a = (int32_t)(raw_sum_a / (int32_t)roi_len);
            __attribute__((unused)) int32_t raw_mean_b = (int32_t)(raw_sum_b / (int32_t)roi_len);

            /* check for chosen bank */
            int64_t sum_a = 0, sum_b = 0;
            uint32_t err_a = 0, err_b = 0;
            for(uint16_t i = 0; i < roi_len; i++){
                int32_t ya = (int32_t)a_ptr[roi_start + i] + (int32_t)(bank_a ? bank_a[i] : 0);
                int32_t yb = (int32_t)b_ptr[roi_start + i] + (int32_t)(bank_b ? bank_b[i] : 0);
                sum_a += ya;
                sum_b += yb;
                int32_t ea = ya - (int32_t)VND_DC_TARGET_ZERO; if(ea < 0) ea = -ea;
                int32_t eb = yb - (int32_t)VND_DC_TARGET_ZERO; if(eb < 0) eb = -eb;
                err_a += (uint32_t)ea;
                err_b += (uint32_t)eb;
            }
            __attribute__((unused)) int32_t mean_a = (int32_t)(sum_a / (int32_t)roi_len);
            __attribute__((unused)) int32_t mean_b = (int32_t)(sum_b / (int32_t)roi_len);

            /* check for alternative bank (flip parity bank) */
            int64_t sum2_a = 0, sum2_b = 0;
            uint32_t err2_a = 0, err2_b = 0;
            for(uint16_t i = 0; i < roi_len; i++){
                int32_t ya = (int32_t)a_ptr[roi_start + i] + (int32_t)(bank2_a ? bank2_a[i] : 0);
                int32_t yb = (int32_t)b_ptr[roi_start + i] + (int32_t)(bank2_b ? bank2_b[i] : 0);
                sum2_a += ya;
                sum2_b += yb;
                int32_t ea = ya - (int32_t)VND_DC_TARGET_ZERO; if(ea < 0) ea = -ea;
                int32_t eb = yb - (int32_t)VND_DC_TARGET_ZERO; if(eb < 0) eb = -eb;
                err2_a += (uint32_t)ea;
                err2_b += (uint32_t)eb;
            }
            __attribute__((unused)) int32_t mean2_a = (int32_t)(sum2_a / (int32_t)roi_len);
            __attribute__((unused)) int32_t mean2_b = (int32_t)(sum2_b / (int32_t)roi_len);

                 VND_DC_LOGF("[DC] APPLY_CHECK: roi=%u+%u raw_meanA=%ld raw_meanB=%ld p=%u meanA=%ld meanB=%ld errA=%lu errB=%lu alt_p=%u alt_meanA=%ld alt_meanB=%ld alt_errA=%lu alt_errB=%lu\r\n",
                   (unsigned)roi_start, (unsigned)roi_len,
                   (long)raw_mean_a, (long)raw_mean_b,
                   (unsigned)p_use,
                   (long)mean_a, (long)mean_b,
                   (unsigned long)err_a, (unsigned long)err_b,
                   (unsigned)p_alt,
                   (long)mean2_a, (long)mean2_b,
                   (unsigned long)err2_a, (unsigned long)err2_b);
        }
    }

    vnd_dc_apply_and_adapt(0, parity, tmp_a, roi_len);
    vnd_dc_apply_and_adapt(1, parity, tmp_b, roi_len);

    if(do_stats && vnd_dc_parity_swap_valid){
        __attribute__((unused)) uint8_t p_use = (uint8_t)(parity ^ vnd_dc_parity_swap);

        uint16_t mn_a = 0xFFFFu, mx_a = 0u;
        uint16_t mn_b = 0xFFFFu, mx_b = 0u;
        int64_t sum_a = 0;
        int64_t sum_b = 0;
        for(uint16_t i = 0; i < roi_len; i++){
            uint16_t va = tmp_a[i];
            uint16_t vb = tmp_b[i];
            if(va < mn_a) mn_a = va;
            if(va > mx_a) mx_a = va;
            if(vb < mn_b) mn_b = vb;
            if(vb > mx_b) mx_b = vb;
            sum_a += (int32_t)va;
            sum_b += (int32_t)vb;
        }
        __attribute__((unused)) int32_t mean_a = (int32_t)(sum_a / (int32_t)roi_len);
        __attribute__((unused)) int32_t mean_b = (int32_t)(sum_b / (int32_t)roi_len);

        VND_DC_LOGF("[DC] ROI_STATS: roi=%u+%u raw_p=%u swap=%u p=%u "
               "A_raw(mn=%u mx=%u mean=%ld) A_dc(mn=%u mx=%u mean=%ld) "
               "B_raw(mn=%u mx=%u mean=%ld) B_dc(mn=%u mx=%u mean=%ld)\r\n",
               (unsigned)roi_start, (unsigned)roi_len,
               (unsigned)parity, (unsigned)vnd_dc_parity_swap, (unsigned)p_use,
               (unsigned)raw_mn_a, (unsigned)raw_mx_a, (long)raw_mean_a,
               (unsigned)mn_a, (unsigned)mx_a, (long)mean_a,
               (unsigned)raw_mn_b, (unsigned)raw_mx_b, (long)raw_mean_b,
               (unsigned)mn_b, (unsigned)mx_b, (long)mean_b);
    }
}

static void vnd_dc_apply_only(uint8_t ch, uint8_t parity, uint16_t *out, uint16_t roi_len)
{
    if(!out) return;
    if(roi_len != (uint16_t)VND_DC_ROI_LEN) return;
    if(ch > 1u || parity > 1u) return;

    uint8_t p = (uint8_t)(parity ^ (vnd_dc_parity_swap_valid ? vnd_dc_parity_swap : 0u));
    int16_t *bank = vnd_dc_bank(ch, p);
    if(bank == NULL) return;
    for(uint16_t i=0;i<roi_len;i++){
        int16_t dc = bank[i];
        int32_t y = (int32_t)out[i] + (int32_t)dc;
        if(y < 0){
            y = 0;
        } else if(y > 65535){
            y = 65535;
        }
        out[i] = (uint16_t)y;
    }
}

static void vnd_dc_apply_and_adapt(uint8_t ch, uint8_t parity, uint16_t *out, uint16_t roi_len)
{
    if(!out) return;
    if(roi_len != (uint16_t)VND_DC_ROI_LEN) return;
    if(ch > 1u || parity > 1u) return;

     uint8_t p = (uint8_t)(parity ^ (vnd_dc_parity_swap_valid ? vnd_dc_parity_swap : 0u));
    int16_t *bank = vnd_dc_bank(ch, p);
    if(bank == NULL) return;

    /* Apply the one persistent table even when RPI has set speed to zero. */
    for(uint16_t i=0;i<roi_len;i++){
        int16_t dc = bank[i];
        uint16_t v = out[i];
        int32_t y = (int32_t)v + (int32_t)dc;
        if(y < 0) y = 0;
        else if(y > 65535) y = 65535;
        out[i] = (uint16_t)y;
    }

    uint32_t now_ms = HAL_GetTick();
    uint32_t settle_ms = vnd_dc_speed_settle_ms;
    vnd_dc_adapt_call_count++;
    vnd_dc_adapt_last_ms = now_ms;
    vnd_dc_adapt_last_dt_ms = 0u;
    vnd_dc_adapt_max_corr = 0u;

     /* 2) Adaptive proportional DC for every sample of the 200-sample ROI.
         corr[i] is proportional to that sample's current distance from the
         deadband and to elapsed wall time. Large errors move quickly; the step
         decreases smoothly near zero. Q16 residue is independent per sample.
         Модель: out = raw + dc[i]; если out[i] выше 32768 -> dc[i] делаем более отрицательным. */
    int64_t sum = 0;
    uint32_t max_abs_err = 0u;
    for(uint16_t i=0;i<roi_len;i++){
        int32_t e_i = (int32_t)out[i] - (int32_t)VND_DC_TARGET_ZERO;
        uint32_t abs_i = (e_i < 0) ? (uint32_t)(-e_i) : (uint32_t)e_i;
        if(abs_i > max_abs_err){
            max_abs_err = abs_i;
        }
        sum += (int32_t)out[i];
    }
    int32_t mean = (int32_t)(sum / (int32_t)roi_len);
    __attribute__((unused)) int32_t err = mean - (int32_t)VND_DC_TARGET_ZERO;
    vnd_dc_adapt_max_abs_err = max_abs_err;
    vnd_dc_adapt_mean_err = err;

    if(settle_ms == 0u){
        vnd_dc_last_adapt_ms[ch][p] = now_ms;
        memset(vnd_dc_adapt_frac_q16[ch][p], 0,
               sizeof(vnd_dc_adapt_frac_q16[ch][p]));
        return;
    }

    int32_t dead = (int32_t)VND_DC_DEADBAND;
    if(dead < 0) dead = 0;
    if(max_abs_err <= (uint32_t)dead){
        vnd_dc_last_adapt_ms[ch][p] = now_ms;
        memset(vnd_dc_adapt_frac_q16[ch][p], 0,
               sizeof(vnd_dc_adapt_frac_q16[ch][p]));
        return;
    }

    uint8_t changed = 0;
    uint32_t last_ms = vnd_dc_last_adapt_ms[ch][p];
    uint32_t dt_ms;
    if(last_ms != 0u){
        dt_ms = (uint32_t)(now_ms - last_ms);
    } else if(vnd_dc_speed_set_at_ms != 0u){
        dt_ms = (uint32_t)(now_ms - vnd_dc_speed_set_at_ms);
    } else {
        dt_ms = 20u;
    }
    vnd_dc_last_adapt_ms[ch][p] = now_ms;
    if(dt_ms == 0u){
        return;
    }
    /* Preserve wall-clock progress across short ADC/USB interruptions, while
       never applying more than one complete settling interval at once. */
    if(dt_ms > settle_ms){
        dt_ms = settle_ms;
    }
    vnd_dc_adapt_last_dt_ms = dt_ms;
    uint32_t max_corr_applied = 0u;

    /* Every point gets its own magnitude as well as its own sign. */
    {
        for(uint16_t i=0;i<roi_len;i++){
            int32_t e = (int32_t)out[i] - (int32_t)VND_DC_TARGET_ZERO;
            uint32_t abs_e = (e < 0) ? (uint32_t)(-e) : (uint32_t)e;
            if(abs_e <= (uint32_t)dead){
                vnd_dc_adapt_frac_q16[ch][p][i] = 0u;
                continue;
            }

            int32_t dc_i32 = (int32_t)bank[i];
            uint32_t remaining = abs_e - (uint32_t)dead;
            uint64_t add_q16 =
                ((uint64_t)abs_e * (uint64_t)dt_ms *
                 (uint64_t)VND_DC_ADAPTIVE_GAIN * 65536ULL) /
                (uint64_t)settle_ms;
            uint64_t budget_q16 =
                (uint64_t)vnd_dc_adapt_frac_q16[ch][p][i] + add_q16;
            uint64_t limit_q16 = (uint64_t)remaining << 16;
            if(budget_q16 > limit_q16){
                budget_q16 = limit_q16;
            }
            uint32_t corr = (uint32_t)(budget_q16 >> 16);
            vnd_dc_adapt_frac_q16[ch][p][i] =
                (uint32_t)(budget_q16 - ((uint64_t)corr << 16));
            if(corr == 0u) continue;
            if(corr > max_corr_applied) max_corr_applied = corr;

            if(e > 0){
                dc_i32 -= (int32_t)corr;
            } else {
                dc_i32 += (int32_t)corr;
            }
            if(dc_i32 < -32768){
                dc_i32 = -32768;
            }
            if(dc_i32 > 32767){
                dc_i32 = 32767;
            }

            int16_t nv = (int16_t)dc_i32;
            if(nv != bank[i]){
                bank[i] = nv;
                changed = 1;
            }
        }
    }
    vnd_dc_adapt_max_corr = max_corr_applied;

    if(changed){
        if(!vnd_dc_dirty){
            uint32_t now_ms = HAL_GetTick();
            vnd_dc_dirty_since_ms = now_ms;
        }
        /* ограничим частоту DIRTY лога */
        {
            uint32_t now_ms = HAL_GetTick();
            if(vnd_dc_last_dirty_log_ms == 0u || (now_ms - vnd_dc_last_dirty_log_ms) > 1000u){
                vnd_dc_last_dirty_log_ms = now_ms;
                   VND_DC_LOGF("[DC] DIRTY: ch=%u p=%u settle=%lums dt=%lums maxcorr=%lu maxerr=%lu mean=%ld err=%ld\r\n",
                       (unsigned)ch, (unsigned)p,
                       (unsigned long)settle_ms,
                       (unsigned long)dt_ms,
                       (unsigned long)max_corr_applied,
                       (unsigned long)max_abs_err,
                       (long)mean, (long)err);
            }
        }
        vnd_dc_adapt_updates++;
        vnd_dc_dirty = 1;
        vnd_dc_dirty_public = 1;
    }
}

static void vnd_dc_load_once(void)
{
    vnd_dc_boot_recovery_erase_if_requested();
    if(vnd_dc_loaded) return;
    vnd_dc_loaded = 1;

    /* Scan journal once after reset: find last valid record + compute next write offset.
       If tail is corrupted (non-empty but invalid), mark sector as "needs erase" for next save. */
    const uint8_t *base = (const uint8_t *)(uintptr_t)VND_DC_FLASH_ADDR;
    const vnd_dc_blob_t *best = NULL;
    uint32_t best_cnt = 0;
    uint32_t next_off = 0;
    uint8_t need_erase = 0;

    for(uint32_t off = 0; (off + (uint32_t)sizeof(vnd_dc_blob_t)) <= VND_DC_FLASH_SECTOR_SIZE; off += VND_DC_SLOT_SIZE){
        const vnd_dc_blob_t *b = (const vnd_dc_blob_t *)(const void *)(base + off);
        if(b->magic == 0xFFFFFFFFu){
            next_off = off;
            break;
        }
        if(b->magic != VND_DC_MAGIC || b->ver != (uint16_t)VND_DC_VER || b->roi_len != (uint16_t)VND_DC_ROI_LEN){
            next_off = off;
            need_erase = 1;
            break;
        }
        if(vnd_dc_blob_commit_value(b) != VND_DC_COMMIT_MAGIC){
            next_off = off;
            need_erase = 1;
            break;
        }
        uint32_t data_off = (uint32_t)offsetof(vnd_dc_blob_t, dc);
        uint32_t data_len = (uint32_t)offsetof(vnd_dc_blob_t, _pad) - data_off;
        uint16_t crc = vnd_crc16_ccitt(((const uint8_t*)b) + data_off, data_len);
        if(crc != b->crc16){
            next_off = off;
            need_erase = 1;
            break;
        }
        if(best == NULL || b->write_counter >= best_cnt){
            best = b;
            best_cnt = b->write_counter;
        }
        next_off = off + VND_DC_SLOT_SIZE;
    }

    if(next_off > (VND_DC_FLASH_SECTOR_SIZE - VND_DC_SLOT_SIZE)){
        /* Full sector */
        need_erase = 1;
    }
    vnd_dc_flash_next_off = need_erase ? VND_DC_FLASH_SECTOR_SIZE : next_off;
    vnd_dc_flash_next_off_public = vnd_dc_flash_next_off;

    if(best == NULL){
        VND_DC_LOGF("[DC] LOAD EMPTY (journal)\r\n");
        memset(vnd_dc_buf, 0, sizeof(vnd_dc_buf));
        vnd_dc_dirty = 0;
        vnd_dc_dirty_public = 0;
        vnd_dc_dirty_since_ms = 0;
        vnd_dc_write_counter = 0;
        vnd_dc_write_counter_public = 0;
        vnd_dc_load_flags_public = 0;
        vnd_dc_loaded_crc16_public = 0;
        vnd_dc_last_save_ms = HAL_GetTick();
        vnd_dc_reset_adapt_state();
        return;
    }

    memcpy(vnd_dc_buf, best->dc, sizeof(vnd_dc_buf));
    vnd_rs485_role_meta_restore(best);
    vnd_dc_reset_adapt_state();
    vnd_dc_parity_swap_valid = 0u; /* пересчитаем после загрузки на первом кадре */
    vnd_dc_write_counter = best->write_counter;
    vnd_dc_write_counter_public = vnd_dc_write_counter;
    vnd_dc_load_flags_public = (uint8_t)(1u | (need_erase ? 2u : 0u));
    vnd_dc_loaded_crc16_public = best->crc16;
    vnd_dc_dirty = 0;
    vnd_dc_dirty_public = 0;
    vnd_dc_dirty_since_ms = 0;
    vnd_dc_last_save_ms = HAL_GetTick();
        VND_DC_LOGF("[DC] LOAD OK (journal): cnt=%lu next_off=%lu%s\r\n",
           (unsigned long)vnd_dc_write_counter,
           (unsigned long)vnd_dc_flash_next_off,
           need_erase ? " ERASE_PENDING" : "");

        /* Печатаем контрольные суммы 4 массивов DC (канал×parity), чтобы руками сравнить до/после reboot. */
        VND_DC_LOGF("[DC] BANK CRC16: A0=%04X A1=%04X B0=%04X B1=%04X\r\n",
            (unsigned)vnd_dc_bank_crc16(0u,0u), (unsigned)vnd_dc_bank_crc16(0u,1u),
            (unsigned)vnd_dc_bank_crc16(1u,0u), (unsigned)vnd_dc_bank_crc16(1u,1u));
}

void vnd_persistent_config_load_once(void)
{
    vnd_comm_recovery_generation = 0u;
    vnd_comm_recovery_pending = 0u;
    vnd_comm_recovery_durable = 0u;
    vnd_comm_recovery_ack_request = 0u;
    vnd_comm_recovery_boot_armed = 0u;
    vnd_comm_recovery_boot_ms = 0u;
    vnd_dc_load_once();
}

void vnd_comm_recovery_boot_begin(void)
{
    vnd_comm_recovery_boot_ms = HAL_GetTick();
    vnd_comm_recovery_boot_armed = (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_SET);
}

void vnd_comm_recovery_boot_service(uint32_t now_ms)
{
    /* Consume EP0 ACK outside the USB interrupt, before any Flash snapshot.
       An IRQ must not clear dirty while an older journal append is in flight. */
    uint16_t acknowledgement = vnd_comm_recovery_ack_request;
    if (acknowledgement != 0u) {
        vnd_comm_recovery_ack_request = 0u;
        if (vnd_comm_recovery_pending && vnd_comm_recovery_durable &&
            acknowledgement == vnd_comm_recovery_generation) {
            vnd_comm_recovery_pending = 0u;
            vnd_comm_recovery_durable = 0u;
            vnd_dc_dirty = vnd_dc_dirty_public = 1u;
            vnd_dc_save_request = 1u;
            printf("[COMM] Recovery acknowledged generation=%u\r\n", (unsigned)acknowledgement);
        }
    }
    if (!vnd_comm_recovery_boot_armed) return;
    if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) != GPIO_PIN_SET) {
        vnd_comm_recovery_boot_armed = 0u;
        return;
    }
    if ((uint32_t)(now_ms - vnd_comm_recovery_boot_ms) < VND_COMM_RECOVERY_HOLD_MS) return;
    vnd_comm_recovery_boot_armed = 0u;
    /* Each deliberate held-K1 boot is a new request, including when an older
       host ACK was interrupted by power loss. Do not deduplicate this gesture. */
    {
        uint16_t generation = (uint16_t)(vnd_comm_recovery_generation + 1u);
        vnd_comm_recovery_generation = generation ? generation : 1u;
        vnd_comm_recovery_pending = 1u;
        vnd_comm_recovery_durable = 0u;
        vnd_dc_dirty = vnd_dc_dirty_public = 1u;
        vnd_dc_save_request = 1u;
        printf("[COMM] K1 recovery requested generation=%u\r\n", (unsigned)vnd_comm_recovery_generation);
    }
}

uint16_t vnd_build_comm_recovery(uint8_t *dst, uint16_t max_len)
{
    if (dst == NULL || max_len < VND_COMM_RECOVERY_SIZE) return 0u;
    memset(dst, 0, VND_COMM_RECOVERY_SIZE);
    memcpy(dst, "COM1", 4u);
    dst[4] = 1u;
    dst[5] = vnd_comm_recovery_pending;
    dst[6] = vnd_comm_recovery_durable;
    dst[8] = (uint8_t)vnd_comm_recovery_generation;
    dst[9] = (uint8_t)(vnd_comm_recovery_generation >> 8);
    dst[10] = (uint8_t)VND_COMM_RECOVERY_HOLD_MS;
    dst[11] = (uint8_t)(VND_COMM_RECOVERY_HOLD_MS >> 8);
    memcpy(dst + 12u, (const void *)UID_BASE, 12u);
    return VND_COMM_RECOVERY_SIZE;
}

static void vnd_ack_comm_recovery(uint16_t generation)
{
    if (!vnd_comm_recovery_pending || !vnd_comm_recovery_durable ||
        generation == 0u || generation != vnd_comm_recovery_generation) return;
    vnd_comm_recovery_ack_request = generation;
}

static void vnd_dc_try_save_periodic(void)
{
    uint8_t manual_save = 0u;
    if(vnd_dc_save_request){
        vnd_dc_save_request = 0u;
        manual_save = 1u;
    }
    /* Привязываем период к моменту, когда DC стал dirty (и к LCD-прогрессу).
       Это устраняет ситуацию, когда прогресс дошёл до конца, а попытка save не делается.
       Условие: если dirty и прошло >= period с dirty_since_ms — пытаемся писать.
       При FAIL: НЕ очищаем dirty, но перезапускаем отсчёт (следующая попытка через period).
       При OK: очищаем dirty и сбрасываем dirty_since_ms.
     */
    if(!manual_save && !vnd_dc_dirty_public) return;
    if(!manual_save && !vnd_dc_dirty) return;
    uint32_t now = HAL_GetTick();
    uint32_t period = (vnd_dc_write_counter == 0u)
                      ? (uint32_t)VND_DC_SAVE_PERIOD_FIRST_MS
                      : (uint32_t)VND_DC_SAVE_PERIOD_MS;
    vnd_dc_save_period_ms = period;
    if(!manual_save && period == 0u) return;
    if(!manual_save && vnd_dc_dirty_since_ms == 0u){
        vnd_dc_dirty_since_ms = now;
        return;
    }
    if(!manual_save && (now - vnd_dc_dirty_since_ms) < period) return;

    vnd_dc_blob_t blob;
    memset(&blob, 0, sizeof(blob));
    blob.magic = VND_DC_MAGIC;
    blob.ver = (uint16_t)VND_DC_VER;
    blob.roi_len = (uint16_t)VND_DC_ROI_LEN;
    blob.write_counter = ++vnd_dc_write_counter;
    vnd_dc_write_counter_public = vnd_dc_write_counter;
    memcpy(blob.dc, vnd_dc_buf, sizeof(vnd_dc_buf));
    vnd_rs485_role_meta_store(&blob);
    vnd_dc_blob_set_commit(&blob);
    uint32_t data_off = (uint32_t)offsetof(vnd_dc_blob_t, dc);
    uint32_t data_len = (uint32_t)offsetof(vnd_dc_blob_t, _pad) - data_off;
    blob.crc16 = vnd_crc16_ccitt(((const uint8_t*)&blob) + data_off, data_len);

     /* Диагностика: контрольные суммы 4 DC массивов в RAM на момент сохранения.
         Это позволяет сравнить с тем, что загрузится после reboot. */
    VND_DC_LOGF("[DC] SAVE BANK CRC16: A0=%04X A1=%04X B0=%04X B1=%04X\r\n",
              (unsigned)vnd_dc_bank_crc16(0u,0u), (unsigned)vnd_dc_bank_crc16(0u,1u),
              (unsigned)vnd_dc_bank_crc16(1u,0u), (unsigned)vnd_dc_bank_crc16(1u,1u));

#if VND_DC_SAVE_DRY_RUN
    vnd_dc_dirty = 0;
    vnd_dc_dirty_public = 0;
    vnd_dc_dirty_since_ms = 0;
    vnd_dc_last_save_ms = now;
    vnd_dc_save_ok_count++;
    vnd_dc_save_last_result = 1;
    vnd_dc_save_last_ms = now;
    vnd_dc_loaded_crc16_public = blob.crc16;
    VND_DC_LOGF("[DC] SAVE DRYRUN OK: cnt=%lu crc=0x%04X\r\n",
           (unsigned long)vnd_dc_write_counter, (unsigned)blob.crc16);
    return;
#endif

    /* Запись во Flash: journal append. Стираем сектор ТОЛЬКО когда он заполнится/повреждён. */
    HAL_StatusTypeDef unlock_st = HAL_FLASH_Unlock();
    if(unlock_st != HAL_OK){
        uint32_t err = 0;
#if defined(HAL_FLASH_GetError)
        err = HAL_FLASH_GetError();
#endif
        vnd_dc_save_last_err = err;
        vnd_dc_save_fail_count++;
        vnd_dc_save_last_result = 2;
        vnd_dc_save_last_ms = now;
        vnd_dc_dirty_since_ms = now;
        VND_DC_LOGF("[DC] SAVE FAIL: unlock st=%lu err=0x%08lX\r\n",
               (unsigned long)unlock_st, (unsigned long)err);
        return;
    }
    /* HAL версии отличаются по именам флагов ошибок. */
#if defined(FLASH_FLAG_ALL_ERRORS)
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);
#elif defined(FLASH_FLAG_ALL_ERRORS_BANK1)
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS_BANK1);
    #if defined(FLASH_FLAG_ALL_ERRORS_BANK2)
        __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS_BANK2);
    #endif
#else
    /* Fallback: ничего не чистим явно */
#endif

#if VND_DC_SAVE_UNLOCK_TEST
    {
        uint32_t err = 0;
#if defined(HAL_FLASH_GetError)
        err = HAL_FLASH_GetError();
#endif
        vnd_dc_save_last_err = err;
        HAL_FLASH_Lock();
        vnd_dc_dirty = 0;
        vnd_dc_dirty_public = 0;
        vnd_dc_dirty_since_ms = 0;
        vnd_dc_last_save_ms = now;
        vnd_dc_save_ok_count++;
        vnd_dc_save_last_result = 1;
        vnd_dc_save_last_ms = now;
        vnd_dc_loaded_crc16_public = blob.crc16;
        VND_DC_LOGF("[DC] SAVE UNLOCK_TEST OK: cnt=%lu err=0x%08lX crc=0x%04X\r\n",
               (unsigned long)vnd_dc_write_counter, (unsigned long)err, (unsigned)blob.crc16);
        return;
    }
#endif

            /* Определяем bank/sector по адресу (STM32H723, 1MB FLASH, 128KB sectors).
               В этом проекте DC хранится в 0x080E0000..0x080FFFFF, это ГЛОБАЛЬНЫЙ сектор #7.
               Устройство dual-bank: Bank1 содержит сектора 0..3, Bank2 содержит сектора 4..7. */
            uint32_t erase_bank = FLASH_BANK_1;
            uint32_t erase_sector = 0;
            {
                uint32_t addr = (uint32_t)VND_DC_FLASH_ADDR;
                uint32_t rel = addr - 0x08000000u;
                uint32_t sec_global = rel / 0x20000u; /* 128KB */
                if(sec_global > 7u) sec_global = 7u;

            #if defined(FLASH_BANK_2)
                if(sec_global >= 4u) erase_bank = FLASH_BANK_2;
            #endif

            #if defined(FLASH_SECTOR_0)
                erase_sector = (uint32_t)FLASH_SECTOR_0 + sec_global;
            #else
                erase_sector = sec_global;
            #endif
            }

    /* Сохраним, что именно использовали (для LCD/диагностики) */
    vnd_dc_save_last_bank = erase_bank;
    vnd_dc_save_last_sector = erase_sector;
    vnd_dc_save_last_sector_error = 0;
    vnd_dc_save_last_err = 0;

    /* Determine write offset. If sector is full/corrupted, erase once and restart from 0. */
    uint32_t write_off = vnd_dc_flash_next_off;
    if(write_off > (VND_DC_FLASH_SECTOR_SIZE - VND_DC_SLOT_SIZE)){
#if !VND_DC_SAVE_ERASE_ENABLE
        vnd_dc_save_last_err = 0;
        vnd_dc_save_fail_count++;
        vnd_dc_save_last_result = 2;
        vnd_dc_save_last_ms = now;
        vnd_dc_dirty_since_ms = now;
        VND_DC_LOGF("[DC] SAVE SKIP: erase disabled next_off=%lu\r\n",
               (unsigned long)write_off);
        HAL_FLASH_Lock();
        return;
#else
        FLASH_EraseInitTypeDef e;
        uint32_t sector_error = 0;
        memset(&e, 0, sizeof(e));
        e.TypeErase = FLASH_TYPEERASE_SECTORS;
        e.Banks = erase_bank;
        e.Sector = erase_sector;
        e.NbSectors = 1;
        if(HAL_FLASHEx_Erase(&e, &sector_error) != HAL_OK){
            uint32_t err = 0;
#if defined(HAL_FLASH_GetError)
            err = HAL_FLASH_GetError();
#endif
            vnd_dc_save_last_err = err;
            vnd_dc_save_last_sector_error = sector_error;
            vnd_dc_save_fail_count++;
            vnd_dc_save_last_result = 2;
            vnd_dc_save_last_ms = now;
                 VND_DC_LOGF("[DC] SAVE FAIL: erase(full) bank=%lu sector=%lu err=0x%08lX sec_err=%lu\r\n",
                   (unsigned long)erase_bank, (unsigned long)erase_sector, (unsigned long)err, (unsigned long)sector_error);
            HAL_FLASH_Lock();
            /* Не сбрасываем dirty. Перезапускаем отсчёт до следующей попытки. */
            vnd_dc_dirty_since_ms = now;
            return;
        }
        write_off = 0;
        vnd_dc_flash_next_off = 0;
    #if VND_DC_SAVE_ERASE_ONLY_TEST
        vnd_dc_flash_next_off_public = 0;
        vnd_dc_dirty = 0;
        vnd_dc_dirty_public = 0;
        vnd_dc_dirty_since_ms = 0;
        vnd_dc_last_save_ms = now;
        vnd_dc_save_ok_count++;
        vnd_dc_save_last_result = 1;
        vnd_dc_save_last_ms = now;
        vnd_dc_load_flags_public = 0u;
        HAL_FLASH_Lock();
        VND_DC_LOGF("[DC] SAVE ERASE_TEST OK: bank=%lu sector=%lu\r\n",
               (unsigned long)erase_bank, (unsigned long)erase_sector);
        return;
    #endif
#endif
    }

    /* Программирование flashword: 32 bytes */
    const uint8_t *src = (const uint8_t*)&blob;
    uint32_t addr = (uint32_t)VND_DC_FLASH_ADDR + write_off;
    uint32_t remaining = (uint32_t)sizeof(blob);
    uint8_t ok = 1;
    while(remaining){
        uint32_t chunk = remaining;
        if(chunk > 32u) chunk = 32u;
        uint32_t fw32[8] __attribute__((aligned(32)));
        for(uint8_t i=0;i<8;i++) fw32[i] = 0xFFFFFFFFu;
        memcpy((uint8_t*)fw32, src, chunk);
        if(HAL_FLASH_Program(FLASH_TYPEPROGRAM_FLASHWORD, addr, (uint32_t)(uintptr_t)fw32) != HAL_OK){
            ok = 0;
            break;
        }
        addr += 32u;
        src  += chunk;
        remaining -= chunk;
    }
    HAL_FLASH_Lock();

    /* NOTE: no read-back verify here to avoid extra Flash reads and any DCache coherency pitfalls.
       We treat HAL_OK for all program operations as success. */

    if(ok){
        /* Only a committed journal append makes a request eligible for host ACK. */
        if (blob._rsv0 == (uint16_t)(vnd_comm_recovery_generation ^ VND_COMM_RECOVERY_CHECK) &&
            (((const vnd_rs485_role_meta_t *)(const void *)blob._pad)->flags & VND_COMM_RECOVERY_META_FLAG) ==
            (vnd_comm_recovery_pending ? VND_COMM_RECOVERY_META_FLAG : 0u)) {
            vnd_comm_recovery_durable = 1u;
        }
        vnd_dc_dirty = 0;
        vnd_dc_dirty_public = 0;
        vnd_dc_dirty_since_ms = 0;
        vnd_dc_last_save_ms = now;
        vnd_dc_save_ok_count++;
        vnd_dc_save_last_result = 1;
        vnd_dc_save_last_ms = now;
        vnd_dc_flash_next_off = write_off + VND_DC_SLOT_SIZE;
        vnd_dc_flash_next_off_public = vnd_dc_flash_next_off;
        vnd_dc_load_flags_public = 1u; /* after a successful write, journal state is sane */
        vnd_dc_loaded_crc16_public = blob.crc16;
        VND_DC_LOGF("[DC] SAVE OK: bank=%lu sector=%lu addr=0x%08lX cnt=%lu\r\n",
               (unsigned long)erase_bank, (unsigned long)erase_sector,
               (unsigned long)(uint32_t)(VND_DC_FLASH_ADDR + write_off), (unsigned long)vnd_dc_write_counter);
    } else {
        uint32_t err = 0;
#if defined(HAL_FLASH_GetError)
        err = HAL_FLASH_GetError();
#endif
        vnd_dc_save_last_err = err;
        vnd_dc_save_fail_count++;
        vnd_dc_save_last_result = 2;
        vnd_dc_save_last_ms = now;
        VND_DC_LOGF("[DC] SAVE FAIL: prog bank=%lu sector=%lu err=0x%08lX\r\n",
               (unsigned long)erase_bank, (unsigned long)erase_sector, (unsigned long)err);
        /* Не сбрасываем dirty. Перезапускаем отсчёт до следующей попытки. */
        vnd_dc_dirty_since_ms = now;
    }
}

/* === DSP (AVG_ROI): свёртка/корреляции на 200 усреднённых сэмплах ===
   Важно: не модифицируем данные потока, только считаем метрики и профилируем время.
   - Свёртка (как "матч-фильтр") здесь представлена как dot(x, x) / энергии и dot(even, odd).
   - Корреляция между even/odd (внутри канала) и между каналами (A/B) на одинаковой parity.
*/
typedef struct {
    uint8_t have[2][2]; /* [ch][parity] */
    uint16_t last[2][2][MAX_FRAME_SAMPLES];
    uint16_t roi_len;

    float corr_eo[2]; /* corr(even, odd) per channel */
    float corr_ab[2]; /* corr(A,B) for parity: [0]=even, [1]=odd */

    uint32_t dsp_us_total;
    uint32_t dsp_us_cnt;
    uint32_t dsp_us_max;
} vnd_dsp_stats_t;

static vnd_dsp_stats_t vnd_dsp = {0};

static inline void vnd_dwt_init_once(void)
{
    static uint8_t inited = 0;
    if(inited) return;
    inited = 1;
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    /* Shared monotonic timebase for RS485/ADC markers and DSP profiling.
       Starting the first averaged output must not reset phase timestamps. */
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

static inline uint32_t vnd_dwt_cycles(void)
{
    return DWT->CYCCNT;
}

static inline uint32_t vnd_cycles_to_us(uint32_t cycles)
{
    uint32_t hz = SystemCoreClock;
    if(hz == 0u) hz = 1u;
    return (uint32_t)(((uint64_t)cycles * 1000000ull) / (uint64_t)hz);
}

static float vnd_corr_norm_u16(const uint16_t *x, const uint16_t *y, uint16_t n)
{
    if(n == 0u) return 0.0f;
    uint64_t sx = 0, sy = 0;
    for(uint16_t i=0;i<n;i++){ sx += x[i]; sy += y[i]; }
    float mx = (float)sx / (float)n;
    float my = (float)sy / (float)n;

    double num = 0.0;
    double ex = 0.0;
    double ey = 0.0;
    for(uint16_t i=0;i<n;i++){
        double dx = (double)x[i] - (double)mx;
        double dy = (double)y[i] - (double)my;
        num += dx * dy;
        ex  += dx * dx;
        ey  += dy * dy;
    }
    double den = sqrt(ex * ey);
    if(den <= 1e-12) return 0.0f;
    return (float)(num / den);
}

static void vnd_dsp_update(uint8_t parity, const uint16_t out_ch0[MAX_FRAME_SAMPLES], const uint16_t out_ch1[MAX_FRAME_SAMPLES], uint16_t roi_len)
{
    if(roi_len == 0u) return;
    if(roi_len > MAX_FRAME_SAMPLES) roi_len = MAX_FRAME_SAMPLES;

    vnd_dsp.roi_len = roi_len;
    for(uint16_t i=0;i<roi_len;i++){
        vnd_dsp.last[0][parity][i] = out_ch0[i];
        vnd_dsp.last[1][parity][i] = out_ch1[i];
    }
    vnd_dsp.have[0][parity] = 1;
    vnd_dsp.have[1][parity] = 1;

    /* Корреляция even/odd внутри каждого канала, когда есть обе parity */
    for(uint8_t ch=0; ch<2; ch++){
        if(vnd_dsp.have[ch][0] && vnd_dsp.have[ch][1]){
            vnd_dsp.corr_eo[ch] = vnd_corr_norm_u16(vnd_dsp.last[ch][0], vnd_dsp.last[ch][1], roi_len);
        }
    }
    /* Корреляция между каналами на текущей parity */
    if(vnd_dsp.have[0][parity] && vnd_dsp.have[1][parity]){
        vnd_dsp.corr_ab[parity] = vnd_corr_norm_u16(vnd_dsp.last[0][parity], vnd_dsp.last[1][parity], roi_len);
    }
}

/* Очередь готовых усреднённых ROI кадров (mode=2) */
static uint8_t vnd_avg_q_head = 0, vnd_avg_q_tail = 0, vnd_avg_q_count = 0;
static uint16_t vnd_avg_q_out[VND_AVG_OUT_Q][2][MAX_FRAME_SAMPLES];
static uint32_t vnd_avg_q_dma_seq[VND_AVG_OUT_Q];
static uint32_t vnd_avg_q_ts_ms[VND_AVG_OUT_Q];
static uint8_t vnd_avg_q_bufidx[VND_AVG_OUT_Q]; /* 0..7, где bit0 = parity (even/odd) */
static uint8_t vnd_avg_gui_ctr = 0; /* 0,2,4,6 — для формирования 0..7 с parity битом */
static volatile uint32_t dbg_avg_drop_frames = 0;

static void vnd_avg_drain_fifo(uint16_t roi_start, uint16_t roi_len);

static void vnd_avg_reset(void)
{
    vnd_avg_cnt[0] = 0; vnd_avg_cnt[1] = 0;
    vnd_avg_next_parity = 0;
    vnd_avg_last_dma_seq[0] = 0; vnd_avg_last_dma_seq[1] = 0;
    vnd_avg_last_ts_ms[0] = 0; vnd_avg_last_ts_ms[1] = 0;
    vnd_avg_q_head = 0; vnd_avg_q_tail = 0; vnd_avg_q_count = 0;
    vnd_avg_gui_ctr = 0;
    dbg_avg_in_frames = 0;
    dbg_avg_out_frames = 0;
    dbg_avg_tx_pairs = 0;
    dbg_avg_drop_frames = 0;
    dbg_avg_last_print_ms = 0;
    dbg_avg_in_last = 0; dbg_avg_out_last = 0; dbg_avg_tx_last = 0;
    memset(&vnd_dsp, 0, sizeof(vnd_dsp));
    /* суммы обнулять не требуется: мы заново инициализируем по vnd_avg_cnt==0 */
}

static void vnd_avg_drain_fifo(uint16_t roi_start, uint16_t roi_len)
{
    if(vnd_stream_mode != VND_STREAM_MODE_AVG_ROI) return;
    if(!streaming) return;
    if(roi_len == 0u) return;
    if(roi_len > VND_MAX_SAMPLES) roi_len = VND_MAX_SAMPLES;
    if(roi_len > MAX_FRAME_SAMPLES) roi_len = MAX_FRAME_SAMPLES;

    uint8_t avg_n = vnd_avg_n;
    if(avg_n < (uint8_t)VND_AVG_MIN_N) avg_n = (uint8_t)VND_AVG_MIN_N;
    if(avg_n > VND_AVG_MAX_N) avg_n = VND_AVG_MAX_N;

    /* Для основных режимов 24+ быстро догоняем FIFO; 16 держим безопасным режимом.
       Когда USB уже держит IN/pending_B, не делаем длинный CPU burst перед обслуживанием B. */
    uint8_t drain_limit = 64u;
    if(avg_n <= 16u) drain_limit = 16u;
    {
        extern uint8_t USBD_VND_TxIsBusy(void);
        uint8_t usb_active = (vnd_ep_busy || vnd_inflight || USBD_VND_TxIsBusy()) ? 1u : 0u;
        if(usb_active){
            drain_limit = (avg_n <= 16u) ? 4u : 8u;
        }
        if(vnd_avg_q_count >= (uint8_t)(VND_AVG_OUT_Q - 1u) && drain_limit > 4u){
            drain_limit = 4u;
        }
    }

    for(uint8_t iter = 0; iter < drain_limit; ++iter)
    {
        uint16_t *a_ptr = NULL, *b_ptr = NULL; uint16_t ns = 0; uint32_t dma_seq = 0;
        if(!adc_peek_frame_pair_fifo(&a_ptr, &b_ptr, &ns, &dma_seq)){
            break; /* нет новых кадров */
        }
        if(ns < (uint16_t)(roi_start + roi_len)){
            (void)adc_consume_frame_pair_fifo(dma_seq);
            continue; /* кадр не подходит под окно */
        }
        dbg_avg_in_frames++;

        uint8_t parity = (uint8_t)(adc_get_buffer_parity(dma_seq) & 1u);
        if(vnd_avg_cnt[parity] == 0){
            for(uint16_t i=0;i<roi_len;i++){
                vnd_avg_sum[parity][0][i] = 0;
                vnd_avg_sum[parity][1][i] = 0;
            }
        }
        uint16_t *a_roi = a_ptr + roi_start;
        uint16_t *b_roi = b_ptr + roi_start;
        const uint16_t *a_sum_src = a_roi;
        const uint16_t *b_sum_src = b_roi;

        /* В AVG_ROI DC применяется до усреднения: берём raw ROI в локальную копию,
           применяем единственный процесс DC/адаптации и уже скорректированные точки добавляем в сумму.
           Raw DMA/FIFO буферы остаются неизменными. */
        if(roi_len == (uint16_t)VND_DC_ROI_LEN){
            static uint16_t avg_dc_tmp_a[VND_DC_ROI_LEN];
            static uint16_t avg_dc_tmp_b[VND_DC_ROI_LEN];

            vnd_dc_load_once();
            vnd_dc_ensure_parity_mapping(a_roi, b_roi, roi_len, 0u, roi_len, parity);
            memcpy(avg_dc_tmp_a, a_roi, (size_t)roi_len * sizeof(uint16_t));
            memcpy(avg_dc_tmp_b, b_roi, (size_t)roi_len * sizeof(uint16_t));
            vnd_dc_apply_and_adapt(0, parity, avg_dc_tmp_a, roi_len);
            vnd_dc_apply_and_adapt(1, parity, avg_dc_tmp_b, roi_len);
            a_sum_src = avg_dc_tmp_a;
            b_sum_src = avg_dc_tmp_b;
        }

        for(uint16_t i=0;i<roi_len;i++){
            vnd_avg_sum[parity][0][i] += (uint32_t)a_sum_src[i];
            vnd_avg_sum[parity][1][i] += (uint32_t)b_sum_src[i];
        }
        vnd_avg_cnt[parity]++;
        vnd_avg_last_dma_seq[parity] = dma_seq;
        vnd_avg_last_ts_ms[parity] = HAL_GetTick();
        (void)adc_consume_frame_pair_fifo(dma_seq);

        /* Группа готова: выпускаем усреднённый кадр РОВНО после получения avg_n кадров этой parity.
           Важно: не используем vnd_avg_next_parity для условия выпуска, иначе при «прогреве»
           оба счётчика могут стать >= avg_n и кадры начнут выпускаться почти с входной частотой.
           Каждый входной кадр должен попасть ровно в одну группу (по своей parity). */
        if(vnd_avg_cnt[parity] >= avg_n)
        {
#if VND_AVG_LATEST_WINS
            if(vnd_avg_q_count != 0u){
                dbg_avg_drop_frames += (uint32_t)vnd_avg_q_count;
                vnd_avg_q_head = vnd_avg_q_tail;
                vnd_avg_q_count = 0u;
            }
#else
            if(vnd_avg_q_count >= VND_AVG_OUT_Q){
                vnd_avg_q_head = (uint8_t)((vnd_avg_q_head + 1u) % VND_AVG_OUT_Q);
                vnd_avg_q_count--;
                dbg_avg_drop_frames++;
            }
#endif

            uint8_t out_parity = parity;
            uint8_t q = vnd_avg_q_tail;
            for(uint16_t i=0;i<roi_len;i++){
                vnd_avg_q_out[q][0][i] = (uint16_t)((vnd_avg_sum[out_parity][0][i] + (uint32_t)(avg_n/2u)) / (uint32_t)avg_n);
                vnd_avg_q_out[q][1][i] = (uint16_t)((vnd_avg_sum[out_parity][1][i] + (uint32_t)(avg_n/2u)) / (uint32_t)avg_n);
            }

            /* DSP (корреляции/профилирование) — на готовом усреднённом DC-corrected ROI */
            vnd_dwt_init_once();
            uint32_t c0 = vnd_dwt_cycles();
            vnd_dsp_update(out_parity, vnd_avg_q_out[q][0], vnd_avg_q_out[q][1], roi_len);
            uint32_t c1 = vnd_dwt_cycles();
            uint32_t dus = vnd_cycles_to_us(c1 - c0);
            vnd_dsp.dsp_us_total += dus;
            vnd_dsp.dsp_us_cnt++;
            if(dus > vnd_dsp.dsp_us_max) vnd_dsp.dsp_us_max = dus;

            vnd_avg_q_dma_seq[q] = vnd_avg_last_dma_seq[out_parity];
            vnd_avg_q_ts_ms[q] = vnd_avg_last_ts_ms[out_parity];
                /* ВАЖНО: parity/индекс для GUI должны быть стабильны.
                    Нельзя вычислять parity позже по dma_seq, потому что s_buffer_parity[] — кольцевой буфер.
                    Поэтому сохраняем метку 0..7 прямо в очереди. */
                vnd_avg_q_bufidx[q] = (uint8_t)((vnd_avg_gui_ctr & 0x06u) | (out_parity & 1u));
                if((out_parity & 1u) != 0u){
                    vnd_avg_gui_ctr = (uint8_t)((vnd_avg_gui_ctr + 2u) & 0x06u);
                }

            vnd_avg_q_tail = (uint8_t)((vnd_avg_q_tail + 1u) % VND_AVG_OUT_Q);
            vnd_avg_q_count++;

            dbg_avg_out_frames++;

            vnd_avg_cnt[out_parity] = 0;
        }
    }
}



/* === FPS измерение === */
static uint32_t fps_pair_count = 0;       /* Кол-во завершённых пар с момента старта измерения */
static uint32_t fps_frame_a_count = 0;    /* Кол-во отправленных A-кадров */
static uint32_t fps_frame_b_count = 0;    /* Кол-во отправленных B-кадров */
static uint32_t fps_prepare_count = 0;    /* Кол-во вызовов vnd_prepare_pair */
static uint32_t fps_measurement_start_ms = 0; /* Время начала измерения */
static uint32_t fps_last_report_ms = 0;   /* Время последнего отчёта */

/* === Профилирование производительности === */
typedef struct {
    uint32_t prepare_total_us;    /* Суммарное время подготовки пар (мкс) */
    uint32_t prepare_count;       /* Кол-во вызовов prepare */
    uint32_t transmit_total_us;   /* Суммарное время transmit (мкс) */
    uint32_t transmit_count;      /* Кол-во вызовов transmit */
    uint32_t txcplt_total_us;     /* Суммарное время TxCplt (мкс) */
    uint32_t txcplt_count;        /* Кол-во вызовов TxCplt */
    uint32_t last_pair_complete_ms; /* Время последнего завершения пары */
    uint32_t min_pair_interval_ms;  /* Минимальный интервал между парами */
    uint32_t max_pair_interval_ms;  /* Максимальный интервал между парами */
} perf_stats_t;

static perf_stats_t perf_stats = {0};

/* Вспомогательная функция для получения времени в микросекундах (используем HAL_GetTick с умножением) */
static inline uint32_t get_us_approx(void) {
    /* Приблизительно: 1 мс = 1000 мкс. Для более точного измерения нужен DWT, 
       но HAL_GetTick безопаснее и достаточно точен для наших целей */
    static uint32_t last_tick = 0;
    static uint32_t us_offset = 0;
    uint32_t tick = HAL_GetTick();
    if(tick != last_tick){
        us_offset = 0;
        last_tick = tick;
    }
    return tick * 1000 + us_offset++;
}

/* Инвалидация D-Cache для DMA-буфера (копия функции из adc_stream.c) */
static inline void vnd_invalidate_cache_for_buffer(void *buf, uint32_t samples)
{
#if (VND_ENABLE_CACHE_INVALIDATE && defined (SCB_InvalidateDCache_by_Addr))
    uintptr_t addr = (uintptr_t)buf;
    uintptr_t start = addr & ~(uintptr_t)31u; /* выравнивание вниз до 32 байт */
    uint32_t bytes = samples * (uint32_t)sizeof(uint16_t);
    uint32_t extra = (uint32_t)(addr - start);
    uint32_t total = bytes + extra;
    uint32_t total_aligned = (total + 31u) & ~31u; /* кратность 32 */
    SCB_InvalidateDCache_by_Addr((uint32_t*)start, (int32_t)total_aligned);
#else
    (void)buf; (void)samples;
#endif
}

/* Быстрый санитайзер: заменяет явно повреждённые (>12 бит) значения последним валидным */
static __attribute__((unused)) uint32_t vnd_sanitize_samples(uint16_t *buf, uint16_t samples, const char *tag)
{
    uint32_t fixed = 0;
    uint16_t prev = 0;
    uint8_t have_prev = 0;
    uint16_t first_bad = 0, first_idx = 0;
    for(uint16_t i = 0; i < samples; ++i){
        uint16_t v = buf[i];
        if(v > 4095u){
            if(fixed == 0){ first_bad = v; first_idx = i; }
            buf[i] = have_prev ? prev : 0;
            fixed++;
        } else {
            prev = v; have_prev = 1;
        }
    }
    if(fixed){
        static uint32_t last_log_ms = 0;
        uint32_t now = HAL_GetTick();
        if(now - last_log_ms >= 1000u){
            last_log_ms = now;
            printf("[VND_SAN] %s fixed=%lu first_idx=%u first_bad=%u prev=%u\r\n",
                   tag, (unsigned long)fixed, (unsigned)first_idx, (unsigned)first_bad, (unsigned)(have_prev ? prev : 0));
        }
    }
    return fixed;
}
/* Подсчёт выбросов >4095 (опционально, если включить санитайзер) */
static volatile uint32_t dbg_gt4095_ch[2] = {0,0};
#ifndef VND_ENABLE_ADC_SANITIZE
#define VND_ENABLE_ADC_SANITIZE 0 /* по умолчанию не трогаем данные ADC */
#endif

#ifndef VND_SPIKE_CLIP_ENABLE
#define VND_SPIKE_CLIP_ENABLE 0 /* теперь не клипуем, только детектируем */
#endif
#ifndef VND_SPIKE_THRESHOLD
#define VND_SPIKE_THRESHOLD 3000u
#endif
#ifndef VND_SPIKE_MIN_LEN
#define VND_SPIKE_MIN_LEN 6u
#endif

/* Детектор/клиппер блоков высокой амплитуды (короткие пачки ≈10 семплов) */
static __attribute__((unused)) uint32_t vnd_detect_and_clip_spikes(uint16_t *buf, uint16_t samples, const char *tag)
{
    if(!buf || samples == 0) return 0;
    uint32_t events = 0;
    uint16_t thr = VND_SPIKE_THRESHOLD;
    uint16_t last_good = 0;
    uint8_t have_last = 0;
    static uint32_t last_log_ms = 0;
    for(uint16_t i=0; i<samples; ){
        uint16_t v = buf[i];
        if(v <= thr){
            last_good = v; have_last = 1; i++; continue;
        }
        /* найден старт блока выше порога */
        uint16_t start = i;
        uint16_t maxv = v;
        while(i < samples && buf[i] > thr){
            if(buf[i] > maxv) maxv = buf[i];
            i++;
        }
        uint16_t len = (uint16_t)(i - start);
        if(len >= VND_SPIKE_MIN_LEN){
            events++;
            /* опционально клипуем весь блок на последнее валидное значение */
            if(VND_SPIKE_CLIP_ENABLE){
                uint16_t fill = have_last ? last_good : 0;
                for(uint16_t k=start; k<start+len && k<samples; ++k){ buf[k] = fill; }
            }
            uint32_t now = HAL_GetTick();
            if(now - last_log_ms >= 500u){
                last_log_ms = now;
                printf("[VND_SPIKE] %s idx=%u len=%u max=%u thr=%u clip=%u\r\n",
                       tag, (unsigned)start, (unsigned)len, (unsigned)maxv,
                       (unsigned)thr, (unsigned)VND_SPIKE_CLIP_ENABLE);
            }
        }
    }
    return events;
}

typedef struct {
    uint16_t idx;
    uint16_t len;
    uint16_t maxv;
    uint8_t  ch;
} spike_info_t;

static __attribute__((unused)) void vnd_log_spike_window(const spike_info_t *si, const uint16_t *buf, uint16_t samples, uint32_t seq)
{
    if(!si || !buf) return;
    uint16_t start = si->idx;
    uint16_t end = (uint16_t)(start + si->len);
    uint16_t w0 = (start > 8) ? (uint16_t)(start - 8) : 0;
    uint16_t w1 = end + 8; if(w1 > samples) w1 = samples;
    /* Логируем только до 16 значений, чтобы не шуметь CDC */
    char line[256];
    int pos = snprintf(line, sizeof(line), "[SPIKE_DUMP] CH=%c seq=%lu idx=%u len=%u max=%u win=%u..%u vals=",
                       si->ch ? 'B' : 'A', (unsigned long)seq, (unsigned)si->idx, (unsigned)si->len, (unsigned)si->maxv,
                       (unsigned)w0, (unsigned)w1);
    uint16_t printed = 0;
    for(uint16_t i = w0; i < w1 && pos < (int)sizeof(line)-8; ++i){
        pos += snprintf(line+pos, sizeof(line)-pos, "%u,", (unsigned)buf[i]);
        if(++printed >= 16) break;
    }
    if(pos > 0 && pos < (int)sizeof(line)) line[pos-1] = 0; /* убрать последнюю запятую */
    cdc_logf("%s", line);
}

static __attribute__((unused)) uint8_t vnd_detect_spike_info(uint16_t *buf, uint16_t samples, uint16_t thr, uint16_t min_len, uint8_t ch, spike_info_t *out)
{
    if(!buf || samples < min_len || !out) return 0;
    for(uint16_t i=0; i<samples; ){
        uint16_t v = buf[i];
        if(v <= thr){ i++; continue; }
        uint16_t start = i;
        uint16_t maxv = v;
        while(i < samples && buf[i] > thr){ if(buf[i] > maxv) maxv = buf[i]; i++; }
        uint16_t len = i - start;
        if(len >= min_len){
            out->idx = start; out->len = len; out->maxv = maxv; out->ch = ch;
            return 1;
        }
    }
    return 0;
}

/* Локальная утилита: обновить LCD параметрами, присланными хостом */
/* ДИАГНОСТИКА: обновление индикации последней принятой команды на LCD и UART */
static void vnd_update_cmd_indicator(void)
{
    if (vnd_lcd_role_overlay_active != 0u) {
        return;
    }

    char cmd_str[16];
    uint32_t now = HAL_GetTick();
    uint32_t elapsed_sec = (now >= last_cmd_timestamp_ms) ? ((now - last_cmd_timestamp_ms) / 1000) : 0;
    
    /* Компактный формат для размещения после "USB:CFG" на верхней строке LCD:
       Показываем последнюю команду и сколько секунд назад она была получена */
    if (last_cmd_received == 0x20) {
        snprintf(cmd_str, sizeof(cmd_str), "ST:%lu", (unsigned long)cmd_start_count);
    } else if (last_cmd_received == 0x21) {
        snprintf(cmd_str, sizeof(cmd_str), "SP:%lu", (unsigned long)cmd_stop_count);
    } else {
        snprintf(cmd_str, sizeof(cmd_str), "--:0");
    }
    
    /* Вывод на LCD строка 0 (y=0), позиция x=80 пикселей (между USB:CFG и T2:) */
    LCD_ShowString_Size(80, 0, cmd_str, 16, YELLOW, BLACK);
    
    /* Дополнительно вывод в UART для отладки */
    if (last_cmd_received == 0x20) {
        printf("[CMD_IND] START received #%lu (at t=%lu ms, %lu sec ago)\r\n",
               (unsigned long)cmd_start_count, (unsigned long)last_cmd_timestamp_ms, (unsigned long)elapsed_sec);
        printf("[CMD_IND] START cfg: stream_mode=%u avg_n=%u async=%u chmode=%u\r\n",
               (unsigned)vnd_stream_mode, (unsigned)vnd_avg_n, (unsigned)async_mode, (unsigned)vnd_ch_mode);
    } else if (last_cmd_received == 0x21) {
        printf("[CMD_IND] STOP received #%lu (at t=%lu ms, %lu sec ago)\r\n",
               (unsigned long)cmd_stop_count, (unsigned long)last_cmd_timestamp_ms, (unsigned long)elapsed_sec);
    }
}

static void vnd_update_lcd_params(void)
{
    /* Частота блоков (пар кадров A+B): в FULL берём из периода пары, в DIAG — diag_hz */
    uint16_t block_hz = 0;
    if(full_mode) {
        uint16_t pp = vnd_pair_period_ms;
        block_hz = (pp > 0) ? (uint16_t)(1000u / pp) : 0u;
    } else {
        block_hz = diag_hz;
    }

    /* Кол-во сэмплов на канал в кадре: если явно задано командой — используем его, иначе активное */
    uint16_t frame_samples = (vnd_frame_samples_req != 0) ? vnd_frame_samples_req
                                : ((cur_samples_per_frame != 0) ? cur_samples_per_frame
                                                                : adc_stream_get_active_samples());

    /* Обновить LCD (только при изменениях внутри функции отображения) */
    // stream_display_update_host_params(
    //     host_profile,
    //     frame_samples,
    //     block_hz,
    //     win_start0, win_len0,
    //     win_start1, win_len1,
    //     (uint8_t)full_mode
    // );

    /* stream_display_update_host_params() сейчас выключен; подавляем -Werror по локальным метрикам */
    (void)block_hz;
    (void)frame_samples;
}

static void vnd_log_dc_cmd_rx(const uint8_t *data, uint32_t len)
{
    (void)data;
    (void)len;
}

/* --- CDC дублирование: отправляем компактную ASCII строку с первыми 64 сэмплами --- */
static __attribute__((unused)) uint32_t cdc_last_send_ms = 0;       /* для троттлинга */
static __attribute__((unused)) char     cdc_line_buf[1024];         /* статический буфер для передачи */
static __attribute__((unused)) uint16_t rd_le16(const uint8_t *p){ return (uint16_t)(p[0] | (p[1] << 8)); }
static __attribute__((unused)) uint32_t rd_le32(const uint8_t *p){ return (uint32_t)(p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24)); }
static void vnd_cdc_duplicate_preview(const uint8_t *buf, uint16_t len, const char *tag)
{
    /* При отключённом превью не выводим копию потока в CDC */
#if !VND_CDC_PREVIEW_ENABLE
    (void)buf; (void)len; (void)tag;
    return;
#else
    /* Троттлинг, чтобы не забивать CDC: не чаще 10 Гц */
    uint32_t now = HAL_GetTick();
    /* Периодический INIT_DBG до первой реальной кадра: каждые ~20мс выводим состояние счётчиков каналов и режимов. */
    if(streaming && vnd_stage_first_frame_ms == 0){
        static uint32_t last_init_dbg_ms = 0;
        if(now - last_init_dbg_ms >= 20){
            last_init_dbg_ms = now;
            extern volatile uint32_t adc_ch_wr_seq[2];
            extern volatile uint32_t adc_ch_rd_seq[2];
            cdc_logf("INIT_DBG t=%lu pend_init=%u wrA=%lu wrB=%lu rdA=%lu rdB=%lu ch_mode=%u async=%u ep_busy=%u",
                     (unsigned long)now,
                     (unsigned)vnd_pending_init,
                     (unsigned long)adc_ch_wr_seq[0], (unsigned long)adc_ch_wr_seq[1],
                     (unsigned long)adc_ch_rd_seq[0], (unsigned long)adc_ch_rd_seq[1],
                     (unsigned)vnd_ch_mode, (unsigned)async_mode, (unsigned)vnd_ep_busy);
        }
        /* Fallback отключён: всегда держим два канала, даже если B задерживается. */
    }
    if ((now - cdc_last_send_ms) < 100) return;
    if (!buf || len < VND_FRAME_HDR_SIZE) return;
    /* Парсим вручную поля заголовка (LE) */
    uint16_t magic = rd_le16(buf + 0);
    if (magic != 0xA55A) return;
    uint32_t seq = rd_le32(buf + 4);
    uint16_t ns  = rd_le16(buf + 12);
    if (ns == 0) return;
    if ((uint32_t)VND_FRAME_HDR_SIZE + (uint32_t)ns*2u > (uint32_t)len) return;
    unsigned off = 0;
    const char *chan = tag ? tag : "?";
    off += (unsigned)snprintf(cdc_line_buf + off, sizeof(cdc_line_buf) - off,
                              "[%s] seq=%lu n=%u first64:", chan, (unsigned long)seq, (unsigned)ns);
    uint16_t show = (ns > 64u) ? 64u : ns;
    for (uint16_t i = 0; i < show && off + 8 < sizeof(cdc_line_buf); i++)
    {
        uint16_t v = rd_le16(buf + VND_FRAME_HDR_SIZE + 2u*i);
        off += (unsigned)snprintf(cdc_line_buf + off, sizeof(cdc_line_buf) - off, " %u", (unsigned)v);
    }
    if (off + 2 < sizeof(cdc_line_buf)) {
        cdc_line_buf[off++] = '\r';
        cdc_line_buf[off++] = '\n';
    }
    uint8_t rc = CDC_Transmit_HS((uint8_t*)cdc_line_buf, (uint16_t)off);
    if (rc == USBD_OK) {
        cdc_last_send_ms = now;
    }
#endif
}

/* --- CDC события/статистика (COM-порт): START/STOP и периодическая скорость --- */
static uint32_t cdc_stats_last_ms = 0;         /* последняя отметка отправки статистики */
static uint64_t cdc_stats_prev_bytes = 0ULL;   /* предыдущее значение счётчика байт */
static char     cdc_evt_buf[160];              /* буфер форматирования событий */

static void cdc_logf(const char *fmt, ...)
{
    if((uint32_t)VND_CDC_LOG_ENABLE == 0u){
        (void)fmt;
        return;
    }

    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(cdc_evt_buf, sizeof(cdc_evt_buf) - 2, fmt, ap);
    va_end(ap);
    if(n < 0) return;
    if(n > (int)sizeof(cdc_evt_buf) - 2) n = (int)sizeof(cdc_evt_buf) - 2;
    cdc_evt_buf[n++] = '\r';
    cdc_evt_buf[n++] = '\n';
    /* неблокирующая попытка: если CDC занят — событие может быть пропущено */
    (void)CDC_Transmit_HS((uint8_t*)cdc_evt_buf, (uint16_t)n);
}

/* Периодическая диагностика синхронизации (slave): индекс сэмпла TIM16 на конце буфера */
static void vnd_cdc_sync_diag(uint32_t now_ms)
{
    static uint32_t last_ms = 0;
    static uint16_t prev_idx = 0;
    static uint8_t prev_valid = 0;
    if(diag_mode_active){ return; }
    if(now_ms - last_ms < 1000u){ return; } /* не чаще 1 Гц */
    last_ms = now_ms;

    if(vnd_sync_mode_public != VND_SYNC_MODE_SLAVE){
        return;
    }

    if(!adc_sync_dbg_updated){
        return;
    }
    adc_sync_dbg_updated = 0u;

    uint16_t idx = adc_sync_dbg_last_idx;
    uint16_t n = adc_sync_dbg_last_samples;
    uint32_t buf = adc_sync_dbg_last_buf;
    uint32_t age = now_ms - adc_sync_dbg_last_ms;

    uint16_t delta = 0;
    if(prev_valid && n > 0u){
        uint16_t d = (idx >= prev_idx) ? (uint16_t)(idx - prev_idx) : (uint16_t)(prev_idx - idx);
        if(d > (n / 2u)) d = (uint16_t)(n - d);
        delta = d;
    }
    prev_idx = idx;
    prev_valid = 1u;

    cdc_logf("SYNC_DBG t=%lums buf=%lu idx=%u/%u d=%u age=%lums",
             (unsigned long)now_ms,
             (unsigned long)buf,
             (unsigned)idx,
             (unsigned)n,
             (unsigned)delta,
             (unsigned long)age);
  if (VND_SYNC_DIAG_PRINTF) {
    printf("[SYNC_DBG] t=%lums buf=%lu idx=%u/%u d=%u age=%lums\r\n",
           (unsigned long)now_ms,
           (unsigned long)buf,
           (unsigned)idx,
           (unsigned)n,
           (unsigned)delta,
           (unsigned long)age);
  }
}

static void vnd_cdc_periodic_stats(uint32_t now_ms)
{
    /* В диагностическом режиме не трогаем CDC вовсе — уменьшаем накладные расходы */
    if(diag_mode_active){ return; }
    vnd_cdc_sync_diag(now_ms);
    if(now_ms - cdc_stats_last_ms < 1000) return; /* не чаще 1 Гц */
    cdc_stats_last_ms = now_ms;
    uint64_t cur = vnd_total_tx_bytes;
    uint64_t d   = (cur >= cdc_stats_prev_bytes) ? (cur - cdc_stats_prev_bytes) : 0ULL;
    cdc_stats_prev_bytes = cur;
    uint32_t bps = (uint32_t)d; /* за ~1 секунду */
    /* Добавляем количество переданных кадров A/B для сравнения с host RX */
    /* Новая расширенная строка: выводим попытки/отказы TX и частичные abort'ы для анализа стабильности */
    extern volatile uint32_t dbg_tx_attempt; /* объявлены выше */
    extern volatile uint32_t dbg_tx_reject;
    extern volatile uint32_t dbg_partial_frame_abort;
    extern volatile uint32_t dbg_size_mismatch;
    uint32_t tx_attempt = dbg_tx_attempt;
    uint32_t tx_reject  = dbg_tx_reject;
    uint32_t tx_ok      = dbg_tx_cplt; /* число завершённых передач (может включать STAT/TEST) */
    uint32_t frame_abort = dbg_partial_frame_abort;
    uint32_t size_mism   = dbg_size_mismatch;
    uint16_t diag_samples_cur = cur_samples_per_frame;
    uint16_t buf_rate = adc_stream_get_buf_rate();
    uint8_t channel_count = (vnd_ch_mode == 2u) ? 2u : 1u;
    uint16_t frame_bytes = 0u;
    uint32_t demand_bps = 0u;
    /* Оценка потока в Мбит/с (грубая: только пользовательские байты за 1с *8/1e6) */
    float mbps = (float)(bps * 8ULL) / 1000000.0f;

    if (diag_samples_cur == 0u) {
        if ((vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI) || (vnd_stream_mode == VND_STREAM_MODE_AVG_ROI)) {
            diag_samples_cur = (win_len0 != 0u) ? win_len0 : (uint16_t)VND_ROI_LEN_DEFAULT;
        } else if (vnd_frame_samples_req != 0u) {
            diag_samples_cur = vnd_frame_samples_req;
        } else {
            diag_samples_cur = adc_stream_get_active_samples();
            if (diag_samples_cur == 0u) {
                diag_samples_cur = (uint16_t)VND_FULL_DEFAULT_SAMPLES;
            }
        }
    }
    if (diag_samples_cur > VND_MAX_SAMPLES) {
        diag_samples_cur = VND_MAX_SAMPLES;
    }
    frame_bytes = (uint16_t)(VND_FRAME_HDR_SIZE + ((uint32_t)diag_samples_cur * 2u));
    demand_bps = (uint32_t)channel_count * (uint32_t)frame_bytes * (uint32_t)buf_rate;

    cdc_logf("STAT bytes_total=%llu bps=%lu (%.2f Mbps) streaming=%u diag=%u sentA=%lu sentB=%lu seq=%lu tx_attempt=%lu tx_reject=%lu tx_cplt=%lu abort=%lu sz_mm=%lu",
             (unsigned long long)cur, (unsigned long)bps, (double)mbps,
             (unsigned)streaming, (unsigned)diag_mode_active,
             (unsigned long)dbg_sent_ch0_total, (unsigned long)dbg_sent_ch1_total, (unsigned long)stream_seq,
             (unsigned long)tx_attempt, (unsigned long)tx_reject, (unsigned long)tx_ok,
             (unsigned long)frame_abort, (unsigned long)size_mism);
  if (VND_SYNC_DIAG_PRINTF) {
    printf("[USB_RATE] tx=%luB/s raw=%luB/s tx=%.2fMbps raw=%.2fMbps ns=%u frame=%u ch=%u buf=%u A=%lu B=%lu txcplt=%lu\r\n",
           (unsigned long)bps,
           (unsigned long)demand_bps,
           (double)mbps,
           (double)((float)(demand_bps * 8ULL) / 1000000.0f),
           (unsigned)diag_samples_cur,
           (unsigned)frame_bytes,
           (unsigned)channel_count,
           (unsigned)buf_rate,
           (unsigned long)dbg_sent_ch0_total,
           (unsigned long)dbg_sent_ch1_total,
           (unsigned long)tx_ok);
  }
}

/* CRC16-CCITT-FALSE: poly 0x1021, init 0xFFFF. */
static uint16_t vnd_crc16_ccitt_update(uint16_t crc, const uint8_t *data, uint32_t len)
{
    static const uint16_t crc4_table[16] = {
        0x0000u, 0x1021u, 0x2042u, 0x3063u,
        0x4084u, 0x50A5u, 0x60C6u, 0x70E7u,
        0x8108u, 0x9129u, 0xA14Au, 0xB16Bu,
        0xC18Cu, 0xD1ADu, 0xE1CEu, 0xF1EFu
    };

    for(uint32_t i = 0; i < len; ++i){
        uint8_t v = data[i];
        uint8_t idx = (uint8_t)(((crc >> 12) ^ (v >> 4)) & 0x0Fu);
        crc = (uint16_t)((crc << 4) ^ crc4_table[idx]);
        idx = (uint8_t)(((crc >> 12) ^ (v & 0x0Fu)) & 0x0Fu);
        crc = (uint16_t)((crc << 4) ^ crc4_table[idx]);
    }
    return crc;
}

static uint16_t vnd_crc16_ccitt(const uint8_t *data, uint32_t len)
{
    return vnd_crc16_ccitt_update(0xFFFFu, data, len);
}

/* Заголовок кадра */
/*
 * Формат под спецификацию хоста (ровно 32 байта, LE):
 *   [0..1] magic = 0xA55A -> 5A A5
 *   [2]    ver   = 0x01
 *   [3]    flags: 0x01=ADC0, 0x02=ADC1, 0x80=TEST, +0x04 если есть CRC16
 *   [4..7] seq (u32 LE) — общий для пары
 *   [8..11] timestamp (u32 LE) — одинаковый в паре
 *   [12..13] total_samples (u16 LE)
 *   [14..15] zone_count=0
 *   [16..19] zone1_offset=0
 *   [20..23] zone1_length=0
 *   [24..27] reserved=dma_seq/source generation
 *   [28..29] reserved2=buffer_index + source snapshot diagnostics
 *   [30..31] crc16: CRC16-CCITT-FALSE по header[0..29] + payload, если flags bit2=1
 */
typedef struct __attribute__((packed)) {
    uint16_t magic;           /* 0xA55A */
    uint8_t  ver;             /* 0x01 */
    uint8_t  flags;           /* см. описание выше */
    uint32_t seq;             /* номер логической последовательности (пары) */
    uint32_t timestamp;       /* HAL_GetTick */
    uint16_t total_samples;   /* кол-во сэмплов */
    uint16_t zone_count;      /* 0 */
    uint32_t zone1_offset;    /* 0 */
    uint32_t zone1_length;    /* 0 */
    uint32_t reserved;        /* 0 */
    uint16_t reserved2;       /* 0 */
    uint16_t crc16;           /* CRC16-CCITT-FALSE без самого поля crc16 */
} vnd_frame_hdr_t;
_Static_assert(sizeof(vnd_frame_hdr_t)==32, "vnd_frame_hdr_t must be 32 bytes (PACKING ERROR)");

static uint16_t vnd_pack_frame_reserved2(uint32_t dma_seq, uint16_t diag_flags)
{
    uint16_t buffer_index = (uint16_t)(adc_get_buffer_parity(dma_seq) & 0x07u);
    uint16_t source_slot = (uint16_t)((dma_seq % (uint32_t)FIFO_FRAMES) & 0x1Fu);
    uint16_t txcplt_lsb = (uint16_t)((dbg_tx_cplt & 0x0Fu) << VND_R2_TXCPLT_SHIFT);

    return (uint16_t)((buffer_index & VND_R2_BUFFER_INDEX_MASK) |
                      ((source_slot << VND_R2_SOURCE_SLOT_SHIFT) & VND_R2_SOURCE_SLOT_MASK) |
                      (diag_flags & (uint16_t)(VND_R2_SNAPSHOT_USED |
                                               VND_R2_GENERATION_MOVED |
                                               VND_R2_FIFO_GUARD |
                                               VND_R2_CONSUME_OK)) |
                      (txcplt_lsb & VND_R2_TXCPLT_MASK));
}

static uint16_t vnd_refresh_frame_reserved2_buffer_index(uint16_t reserved2, uint32_t dma_seq)
{
    uint16_t buffer_index = (uint16_t)(adc_get_buffer_parity(dma_seq) & 0x07u);
    return (uint16_t)((reserved2 & (uint16_t)~VND_R2_BUFFER_INDEX_MASK) | buffer_index);
}

static uint16_t vnd_frame_crc16(const uint8_t *frame, uint32_t payload_len)
{
    uint16_t crc = 0xFFFFu;
    crc = vnd_crc16_ccitt_update(crc, frame, VND_FRAME_HDR_SIZE - 2u);
    crc = vnd_crc16_ccitt_update(crc, frame + VND_FRAME_HDR_SIZE, payload_len);
    return crc;
}

static void vnd_frame_finalize_crc(uint8_t *frame)
{
    vnd_frame_hdr_t *h = (vnd_frame_hdr_t*)frame;
    uint32_t payload_len = (uint32_t)h->total_samples * 2u;

    h->flags |= VND_FRAME_FLAG_CRC16;
    h->crc16 = 0u;
    h->crc16 = vnd_frame_crc16(frame, payload_len);
    dbg_frame_crc_finalized++;
    dbg_frame_crc_last = h->crc16;
}

/* Состояние кадра */
typedef enum { FB_FILL=0, FB_READY=1, FB_SENDING=2 } frame_state_t;

typedef struct {
    volatile frame_state_t st;
    uint16_t samples;
    uint8_t  flags;
    uint16_t frame_size;
    uint32_t seq;
    uint32_t dma_seq;
    uint16_t crc16;
    uint32_t crc_seq;
    uint8_t  buf[VND_FRAME_MAX_SIZE];
} ChanFrame;

#define VND_PAIR_BUFFERS 8  /* Возврат к 8 для стабильности */
static ChanFrame g_frames[VND_PAIR_BUFFERS][2];
static uint8_t pair_fill_idx = 0;
static uint8_t pair_send_idx = 0;
static uint8_t sending_channel = 0xFF; /* 0 /1 когда активна передача */
/* Простой режим управления отправкой: только из таска */
static uint8_t simple_tx_mode = 1;
/* Флаги машины состояний по требованию хоста */
static volatile uint8_t pending_B = 0;  /* 1 = нужно отправить B после A */
/* Диагностика зависаний между A и B */
static uint32_t pending_B_since_ms = 0; /* время, когда завершилась передача A и мы начали ждать B */

/* Прототипы */
static void vnd_reset_buffers(void);
// static void vnd_send_test_frame(void); // удален, не используется
static void vnd_prepare_pair(void);
static void vnd_build_frame(ChanFrame *cf);
static uint8_t vnd_get_active_stream_slot(uint8_t want_b);
void USBD_VND_TxCplt(void);
static void vnd_consume_strict_fifo_pair(uint8_t slot);
static void vnd_clear_pair_slot(uint8_t slot);
static int vnd_find_pair_by_seq(uint32_t seq);
static void vnd_try_start_tx(void);
static int  vnd_validate_frame(const uint8_t *buf, uint16_t len, uint8_t expect_test, uint8_t allow_zero_samples);
static USBD_StatusTypeDef vnd_transmit_frame(uint8_t *buf, uint16_t len, uint8_t is_test, uint8_t allow_zero_samples, const char *tag);
/* Диагностика: подготовка и отправка A/B тестовой пары (упрощённой) */
static void vnd_diag_prepare_pair(uint32_t seq, uint16_t samples);
static int  vnd_diag_try_tx(void);
/* Классификация последнего отправленного буфера для корректного разбора в TxCplt */
typedef struct {
    uint8_t  is_frame;      /* 1 = кадр с заголовком */
    uint8_t  flags;         /* исходные flags из hdr (0x01/0x02/0x80) */
    uint32_t seq_field;     /* seq из hdr на момент отправки */
    uint32_t push_tick;     /* HAL_GetTick() при постановке в FIFO */
} vnd_tx_meta_t;
#define VND_TX_META_FIFO 8
static vnd_tx_meta_t vnd_tx_meta_fifo[VND_TX_META_FIFO];
static uint8_t vnd_tx_meta_head = 0; /* push */
static uint8_t vnd_tx_meta_tail = 0; /* pop */
/* Диагностические счётчики метаданных */
static uint32_t meta_push_total = 0;
static uint32_t meta_pop_total = 0;
static uint32_t meta_empty_events = 0;
static uint32_t meta_overflow_events = 0;
static inline uint8_t vnd_tx_meta_depth(void){
    uint8_t h = vnd_tx_meta_head, t = vnd_tx_meta_tail;
    if(h>=t) return (uint8_t)(h - t);
    return (uint8_t)(VND_TX_META_FIFO - (t - h));
}

static inline uint32_t vnd_delta_u32(uint32_t cur, uint32_t prev)
{
    return (cur >= prev) ? (cur - prev) : cur;
}

static void vnd_note_task_entry(uint32_t now_ms)
{
    static uint32_t prev_ms = 0u;
    static uint8_t prev_streaming = 0u;

    if(prev_ms != 0u){
        uint32_t gap_ms = (uint32_t)(now_ms - prev_ms);
        if(gap_ms > dbg_task_gap_max_ms){
            dbg_task_gap_max_ms = gap_ms;
        }
        if(gap_ms > 100u){
            dbg_task_gap_count++;
            dbg_task_gap_last_ms = gap_ms;
            if(prev_streaming && gap_ms > 500u){
                printf("[TASKGAP] t=%lu gap=%lu prev_stream=1 stream=%u task=%lu\r\n",
                       (unsigned long)now_ms,
                       (unsigned long)gap_ms,
                       (unsigned)streaming,
                       (unsigned long)dbg_task_calls);
            }
        }
    }

    prev_ms = now_ms;
    prev_streaming = streaming ? 1u : 0u;
}

static void vnd_uart_stream_stats(uint32_t now_ms)
{
    static uint32_t last_ms = 0u;
    static uint32_t prev_task = 0u;
    static uint32_t prev_hb = 0u;
    static uint32_t prev_txcplt = 0u;
    static uint32_t prev_sent_a = 0u;
    static uint32_t prev_sent_b = 0u;
    static uint32_t prev_wr = 0u;
    static uint32_t prev_rd = 0u;
    static uint32_t prev_avg_in = 0u;
    static uint32_t prev_avg_out = 0u;
    static uint32_t prev_avg_tx = 0u;
    static uint32_t prev_data_in = 0u;

    if(!streaming){
        last_ms = 0u;
        prev_task = dbg_task_calls;
        extern volatile uint32_t main_loop_heartbeat;
        prev_hb = main_loop_heartbeat;
        prev_txcplt = dbg_tx_cplt;
        prev_sent_a = dbg_sent_ch0_total;
        prev_sent_b = dbg_sent_ch1_total;
        prev_wr = frame_wr_seq;
        prev_rd = frame_rd_seq;
        prev_avg_in = dbg_avg_in_frames;
        prev_avg_out = dbg_avg_out_frames;
        prev_avg_tx = dbg_avg_tx_pairs;
        prev_data_in = USBD_VND_DataInCount();
        return;
    }

    if(last_ms != 0u && (uint32_t)(now_ms - last_ms) < 1000u){
        return;
    }

    uint32_t dt_ms = (last_ms == 0u) ? 1000u : (uint32_t)(now_ms - last_ms);
    last_ms = now_ms;
    if(dt_ms == 0u){ dt_ms = 1u; }

    uint32_t txcplt = dbg_tx_cplt;
    uint32_t sent_a = dbg_sent_ch0_total;
    uint32_t sent_b = dbg_sent_ch1_total;
    uint32_t wr = frame_wr_seq;
    uint32_t rd = frame_rd_seq;
    uint32_t avg_in = dbg_avg_in_frames;
    uint32_t avg_out = dbg_avg_out_frames;
    uint32_t avg_tx = dbg_avg_tx_pairs;
    uint32_t data_in = USBD_VND_DataInCount();
    uint32_t task = dbg_task_calls;
    extern volatile uint32_t main_loop_heartbeat;
    extern volatile uint32_t last_heartbeat_ms;
    extern volatile uint32_t loop_cycle_last_avg;
    extern volatile uint32_t g_usb_last_sof_ms;
    uint32_t hb = main_loop_heartbeat;

    uint32_t d_txcplt = vnd_delta_u32(txcplt, prev_txcplt);
    uint32_t d_a = vnd_delta_u32(sent_a, prev_sent_a);
    uint32_t d_b = vnd_delta_u32(sent_b, prev_sent_b);
    uint32_t d_wr = vnd_delta_u32(wr, prev_wr);
    uint32_t d_rd = vnd_delta_u32(rd, prev_rd);
    uint32_t d_avg_in = vnd_delta_u32(avg_in, prev_avg_in);
    uint32_t d_avg_out = vnd_delta_u32(avg_out, prev_avg_out);
    uint32_t d_avg_tx = vnd_delta_u32(avg_tx, prev_avg_tx);
    uint32_t d_data_in = vnd_delta_u32(data_in, prev_data_in);
    uint32_t d_task = vnd_delta_u32(task, prev_task);
    uint32_t d_hb = vnd_delta_u32(hb, prev_hb);

    prev_task = task;
    prev_hb = hb;
    prev_txcplt = txcplt;
    prev_sent_a = sent_a;
    prev_sent_b = sent_b;
    prev_wr = wr;
    prev_rd = rd;
    prev_avg_in = avg_in;
    prev_avg_out = avg_out;
    prev_avg_tx = avg_tx;
    prev_data_in = data_in;

    extern uint8_t USBD_VND_TxIsBusy(void);
    uint8_t ll_busy = USBD_VND_TxIsBusy();
    uint32_t last_age = 0xFFFFFFFFu;
    (void)vnd_tick_age_ms(now_ms, vnd_last_txcplt_ms, &last_age);
    uint32_t frame_age = 0xFFFFFFFFu;
    (void)vnd_tick_age_ms(now_ms, vnd_last_frame_txcplt_ms, &frame_age);
    uint32_t tx_age = 0u;
    if(!vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &tx_age)){
        tx_age = 0u;
    }
    uint32_t hb_age = 0xFFFFFFFFu;
    (void)vnd_tick_age_ms(now_ms, last_heartbeat_ms, &hb_age);
    uint32_t sof_age = 0xFFFFFFFFu;
    (void)vnd_tick_age_ms(now_ms, g_usb_last_sof_ms, &sof_age);
    uint32_t host_rx_age = 0xFFFFFFFFu;
    (void)vnd_tick_age_ms(now_ms, vnd_last_host_rx_ack_ms, &host_rx_age);
    uint32_t force_idle_age = 0xFFFFFFFFu;
    (void)vnd_tick_age_ms(now_ms, dbg_tx_force_idle_last_ms, &force_idle_age);
    uint16_t in_total_len = USBD_VND_InTotalLength();
    char role = (vnd_sync_mode_public == VND_SYNC_MODE_MASTER) ? 'M' :
                (vnd_sync_mode_public == VND_SYNC_MODE_SLAVE) ? 'S' : 'O';

    printf("[USBSTAT] t=%lu role=%c stream=%u mode=%u async=%u ch=%u dt=%lu task=%lu(+%lu) gap=%lu/%lu/%lu hb=%lu(+%lu) hbage=%lu sof=%lu loop=%lu ep=%u ll=%u infl=%u pendB=%u err=%lu kick=%u meta=%u q=%u last=%lu frame=%lu txage=%lu len=%u tl=%u din=%lu(+%lu) unst=%lu/%lu rxage=%lu rx=%lu txcplt=%lu(+%lu) A=%lu(+%lu) B=%lu(+%lu) wr=%lu(+%lu) rd=%lu(+%lu) avg=%lu/%lu/%lu(+%lu/%lu/%lu)\r\n",
           (unsigned long)now_ms,
           role,
           (unsigned)streaming,
           (unsigned)vnd_stream_mode,
           (unsigned)async_mode,
           (unsigned)vnd_ch_mode,
           (unsigned long)dt_ms,
           (unsigned long)task,
           (unsigned long)d_task,
           (unsigned long)dbg_task_gap_last_ms,
           (unsigned long)dbg_task_gap_max_ms,
           (unsigned long)dbg_task_gap_count,
           (unsigned long)hb,
           (unsigned long)d_hb,
           (unsigned long)hb_age,
           (unsigned long)sof_age,
           (unsigned long)loop_cycle_last_avg,
           (unsigned)vnd_ep_busy,
           (unsigned)ll_busy,
           (unsigned)vnd_inflight,
           (unsigned)pending_B,
           (unsigned long)vnd_last_error,
           (unsigned)vnd_tx_kick,
           (unsigned)vnd_tx_meta_depth(),
           (unsigned)vnd_avg_q_count,
           (unsigned long)last_age,
           (unsigned long)frame_age,
           (unsigned long)tx_age,
           (unsigned)vnd_last_tx_len,
           (unsigned)in_total_len,
           (unsigned long)data_in,
           (unsigned long)d_data_in,
           (unsigned long)dbg_tx_force_idle_count,
           (unsigned long)force_idle_age,
           (unsigned long)host_rx_age,
           (unsigned long)vnd_host_rx_last_counter,
           (unsigned long)txcplt,
           (unsigned long)d_txcplt,
           (unsigned long)sent_a,
           (unsigned long)d_a,
           (unsigned long)sent_b,
           (unsigned long)d_b,
           (unsigned long)wr,
           (unsigned long)d_wr,
           (unsigned long)rd,
           (unsigned long)d_rd,
           (unsigned long)avg_in,
           (unsigned long)avg_out,
           (unsigned long)avg_tx,
           (unsigned long)d_avg_in,
           (unsigned long)d_avg_out,
           (unsigned long)d_avg_tx);
}

static void vnd_recover_avg_pending_b_stall(uint32_t now_ms)
{
    if(!streaming || !full_mode || diag_mode_active) return;
    if(vnd_stream_mode != VND_STREAM_MODE_AVG_ROI) return;
    if(!pending_B) return;

    extern uint8_t USBD_VND_TxIsBusy(void);
    uint8_t ll_busy = USBD_VND_TxIsBusy();
    if(vnd_ep_busy || ll_busy || vnd_inflight) return;

    uint32_t frame_age = 0u;
    if(!vnd_tick_age_ms(now_ms, vnd_last_frame_txcplt_ms, &frame_age)){
        frame_age = 0u;
    }
    uint32_t pend_age = 0u;
    if(!vnd_tick_age_ms(now_ms, pending_B_since_ms, &pend_age)){
        pend_age = 0u;
    }

    uint8_t b_slot = vnd_get_active_stream_slot(1u);
    ChanFrame *fA = &g_frames[b_slot][0];
    ChanFrame *fB = &g_frames[b_slot][1];

    if(fB->st == FB_READY) return;
    if(fB->st == FB_SENDING && vnd_last_tx_start_ms != 0u){
        uint32_t b_tx_age = 0u;
        if(!vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &b_tx_age) || b_tx_age <= 250u){
            return;
        }
    }

    uint8_t queue_ready = (vnd_avg_q_count != 0u) ? 1u : 0u;
    if(!((queue_ready && (frame_age > 350u || pend_age > 350u)) ||
         frame_age > 1200u || pend_age > 1200u)){
        return;
    }

    printf("[USBRECOVER] avg_pendB age=%lu pend=%lu slot=%u A=%u B=%u q=%u meta=%u seq=%lu\r\n",
           (unsigned long)frame_age,
           (unsigned long)pend_age,
           (unsigned)b_slot,
           (unsigned)fA->st,
           (unsigned)fB->st,
           (unsigned)vnd_avg_q_count,
           (unsigned)vnd_tx_meta_depth(),
           (unsigned long)stream_seq);
    VND_LOG("AVG_PENDB_RECOVER age=%lums pend=%lums slot=%u A=%u B=%u q=%u",
            (unsigned long)frame_age,
            (unsigned long)pend_age,
            (unsigned)b_slot,
            (unsigned)fA->st,
            (unsigned)fB->st,
            (unsigned)vnd_avg_q_count);

    vnd_tx_meta_head = vnd_tx_meta_tail = 0;
    vnd_ep_busy = 0;
    vnd_tx_ready = 1;
    vnd_inflight = 0;
    vnd_last_tx_start_ms = 0;
    inflight_is_frame = 0;
    inflight_flags = 0;
    inflight_seq = 0;
    vnd_reset_buffers();

    stream_seq++;
    dbg_produced_seq++;
    vnd_tx_kick = 1;
}

static inline void vnd_tx_meta_push(uint8_t is_frame, uint8_t flags, uint32_t seq_field){
    uint8_t next = (uint8_t)((vnd_tx_meta_head + 1u) % VND_TX_META_FIFO);
    if(next == vnd_tx_meta_tail){
        /* overflow - drop oldest */
        vnd_tx_meta_tail = (uint8_t)((vnd_tx_meta_tail + 1u) % VND_TX_META_FIFO);
        meta_overflow_events++;
        VND_LOG("WARN META_FIFO_OVF depth_before=%u", (unsigned)vnd_tx_meta_depth());
    }
    vnd_tx_meta_fifo[vnd_tx_meta_head].is_frame = is_frame;
    vnd_tx_meta_fifo[vnd_tx_meta_head].flags = flags;
    vnd_tx_meta_fifo[vnd_tx_meta_head].seq_field = seq_field;
    vnd_tx_meta_fifo[vnd_tx_meta_head].push_tick = HAL_GetTick();
    vnd_tx_meta_head = next;
    meta_push_total++;
    /* Умеренный лог только для рабочих кадров (A/B/TEST); STAT слишком часты не будут */
    if(is_frame){
        VND_LOG("META_PUSH fl=0x%02X seq=%lu depth=%u", (unsigned)flags, (unsigned long)seq_field, (unsigned)vnd_tx_meta_depth());
    }
}
static inline int vnd_tx_meta_pop(vnd_tx_meta_t *out){
    if(vnd_tx_meta_tail == vnd_tx_meta_head){ meta_empty_events++; return 0; } /* empty */
    *out = vnd_tx_meta_fifo[vnd_tx_meta_tail];
    vnd_tx_meta_tail = (uint8_t)((vnd_tx_meta_tail + 1u) % VND_TX_META_FIFO);
    meta_pop_total++;
    return 1;
}

static inline void vnd_clear_inflight_meta(void)
{
    inflight_is_frame = 0;
    inflight_flags = 0;
    inflight_seq = 0;
}

static inline void vnd_mark_service_inflight(void)
{
    vnd_inflight = 1;
    vnd_clear_inflight_meta();
}

static inline void vnd_rollback_tx_start(void)
{
    vnd_tx_ready = 1;
    vnd_ep_busy = 0;
    vnd_inflight = 0;
    vnd_clear_inflight_meta();
}

/* Metadata must be visible before USBD_LL_Transmit can complete. Short service
   packets may raise DataIn before the transmit call returns; pushing metadata
   afterwards leaves an orphan entry and makes the watchdog report a false
   recovery. On a synchronous submit failure the caller rolls this entry back. */
static inline void vnd_tx_meta_before(uint8_t *buf, uint16_t len){
    uint8_t is_frame = 0, flags = 0; uint32_t seq_field = 0;
    if(len >= VND_FRAME_HDR_SIZE){
        const vnd_frame_hdr_t *h = (const vnd_frame_hdr_t*)buf;
        if(h->magic == 0xA55A){ is_frame = 1; flags = h->flags; seq_field = h->seq; }
    }
    /* Сохраняем последнюю отправку для fallback-классификации */
    last_tx_is_frame = is_frame; last_tx_flags = flags; last_tx_seq = seq_field;
    vnd_tx_meta_push(is_frame, flags, seq_field);
}

static inline void vnd_tx_meta_rollback_last(void)
{
    if(vnd_tx_meta_head == vnd_tx_meta_tail) return;
    vnd_tx_meta_head = (uint8_t)((vnd_tx_meta_head + VND_TX_META_FIFO - 1u) % VND_TX_META_FIFO);
    if(meta_push_total != 0u) meta_push_total--;
}
/* Нейтрализовать «застрявшую» запись в meta-FIFO (например, после ForceTxIdle),
   чтобы последующий TxCplt не принял её за реальный кадр и не исказил порядок. */
static __attribute__((unused)) void vnd_meta_neutralize(uint8_t flags_mask, uint32_t seq_field)
{
    uint8_t t = vnd_tx_meta_tail;
    while(t != vnd_tx_meta_head){
        vnd_tx_meta_t *m = &vnd_tx_meta_fifo[t];
        if(m->is_frame &&
           (((uint8_t)(m->flags ^ flags_mask) & 0x83u) == 0u) &&
           (m->seq_field == seq_field)){
            m->is_frame = 0; m->flags = 0; /* превратить в служебный */
            VND_LOG("META_NEUTRALIZE fl=0x%02X seq=%lu", (unsigned)flags_mask, (unsigned long)seq_field);
            break;
        }
        t = (uint8_t)((t + 1u) % VND_TX_META_FIFO);
    }
}

static uint8_t vnd_slot_has_active_frames(uint8_t slot)
{
    if(slot >= VND_PAIR_BUFFERS) return 0u;
    return (g_frames[slot][0].st != FB_FILL || g_frames[slot][1].st != FB_FILL) ? 1u : 0u;
}

static uint8_t vnd_usb_in_active_slot_for_recovery(uint32_t seq_field, uint8_t flags)
{
    uint8_t ch_bits = (uint8_t)(flags & 0x03u);
    if(ch_bits != 0u){
        int seq_slot = vnd_find_pair_by_seq(seq_field);
        if(seq_slot >= 0){
            return (uint8_t)seq_slot;
        }
    }

    return vnd_get_active_stream_slot((pending_B || sending_channel == 1u || ch_bits == 0x02u) ? 1u : 0u);
}

static uint8_t vnd_usb_in_has_recoverable_state(void)
{
    if(vnd_ep_busy || vnd_inflight || pending_B || sending_channel != 0xFFu || vnd_tx_meta_depth() != 0u){
        return 1u;
    }

    return vnd_slot_has_active_frames(vnd_get_active_stream_slot(0u));
}

static uint8_t vnd_usb_in_active_abort_allowed(uint8_t ll_busy, uint32_t age_ms)
{
    if(!ll_busy){
        return 1u;
    }

#if VND_USB_IN_ABORT_ACTIVE_STREAM
    return (age_ms >= (uint32_t)VND_USB_IN_ACTIVE_HARD_STALL_MS) ? 1u : 0u;
#else
    /* Never repair application state while the USB class still owns a Bulk IN
       transfer. Sampling DIEPCTL.EPENA here is not a safe completion test: the
       bit clears before the pending DataIn interrupt has necessarily run, so a
       main-loop sample can race a perfectly healthy completion and drop that
       frame. A real disconnect/SetInterface path resets the class explicitly;
       watchdog recovery below remains available once low-level busy is clear. */
    (void)age_ms;
    return 0u;
#endif
}

static void vnd_usb_in_note_active_hold(const char *reason, uint32_t now_ms, uint32_t age_ms)
{
    uint32_t log_age_ms = 0u;

    dbg_tx_active_hold_count++;
    if(dbg_tx_active_hold_last_ms != 0u &&
       vnd_tick_age_ms(now_ms, dbg_tx_active_hold_last_ms, &log_age_ms) &&
       log_age_ms < (uint32_t)VND_USB_IN_ACTIVE_HOLD_LOG_MS){
        return;
    }
    dbg_tx_active_hold_last_ms = now_ms;

    extern uint8_t USBD_VND_TxIsBusy(void);
    extern uint16_t USBD_VND_InTotalLength(void);
    USBD_VND_InHwState hw;
    USBD_VND_GetInHwState(&hw);
    printf("[WARN EP_HOLD] kind=%s age=%lu len=%u tl=%u ll=%u ep=%u infl=%u ch=%u pendB=%u meta=%u q=%u hwctl=0x%08lX hwsz=0x%08lX hwint=0x%08lX hsts=0x%08lX hemp=0x%08lX xfer=%lu/%lu cnt=%lu\r\n",
           reason ? reason : "?",
           (unsigned long)age_ms,
           (unsigned)vnd_last_tx_len,
           (unsigned)USBD_VND_InTotalLength(),
           (unsigned)USBD_VND_TxIsBusy(),
           (unsigned)vnd_ep_busy,
           (unsigned)vnd_inflight,
           (unsigned)sending_channel,
           (unsigned)pending_B,
           (unsigned)vnd_tx_meta_depth(),
           (unsigned)vnd_avg_q_count,
           (unsigned long)hw.diepctl,
           (unsigned long)hw.dieptsiz,
           (unsigned long)hw.diepint,
           (unsigned long)hw.dtxfsts,
           (unsigned long)hw.diepempmsk,
           (unsigned long)hw.xfer_count,
           (unsigned long)hw.xfer_len,
           (unsigned long)dbg_tx_active_hold_count);
}

static uint8_t vnd_drop_current_stream_unit(uint8_t slot, uint8_t flags)
{
    uint8_t ch_bits = (uint8_t)(flags & 0x03u);

    if(slot >= VND_PAIR_BUFFERS){
        slot = pair_send_idx;
    }

    if(vnd_stream_mode == VND_STREAM_MODE_LATEST){
        uint8_t had_sending = 0u;
        for(uint8_t i = 0u; i < VND_PAIR_BUFFERS; i++){
            if(vnd_slot_has_active_frames(i)){
                if(g_frames[i][0].st == FB_SENDING || g_frames[i][1].st == FB_SENDING){
                    had_sending = 1u;
                    break;
                }
            }
        }
        uint8_t data_context = (ch_bits != 0u || sending_channel != 0xFFu || had_sending) ? 1u : 0u;
        if(data_context){
            vnd_reset_buffers();
            stream_seq++;
            dbg_produced_seq++;
            return 1u;
        }
        return 0u;
    }

    uint8_t had_slot = vnd_slot_has_active_frames(slot);
    uint8_t had_sending = (had_slot &&
                           (g_frames[slot][0].st == FB_SENDING || g_frames[slot][1].st == FB_SENDING)) ? 1u : 0u;
    uint8_t should_drop = (ch_bits != 0u || sending_channel != 0xFFu || had_sending) ? 1u : 0u;

    if(should_drop && had_slot){
        if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI){
            vnd_consume_strict_fifo_pair(slot);
        }
        vnd_clear_pair_slot(slot);
    }

    if(should_drop){
        pair_send_idx = (uint8_t)((slot + 1u) % VND_PAIR_BUFFERS);
        pair_fill_idx = pair_send_idx;
        pending_B = 0;
        pending_B_since_ms = 0;
        sending_channel = 0xFFu;
        stream_seq++;
        dbg_produced_seq++;
        return 1u;
    }

    pending_B = 0;
    pending_B_since_ms = 0;
    sending_channel = 0xFFu;
    return 0u;
}

static uint8_t vnd_usb_in_recovery_reason_code(const char *reason)
{
    if(reason == NULL) return 0u;
    if(strcmp(reason, "status") == 0) return 1u;
    if(strcmp(reason, "busy") == 0) return 2u;
    if(strcmp(reason, "no_progress") == 0) return 3u;
    if(strcmp(reason, "latest_inflight") == 0) return 4u;
    if(strcmp(reason, "lossless_a_wd") == 0) return 5u;
    if(strcmp(reason, "lossless_b_wd") == 0) return 6u;
    return 15u;
}

static void vnd_usb_in_drop_recover(const char *reason, uint32_t now_ms, uint32_t age_ms)
{
    extern uint8_t USBD_VND_TxIsBusy(void);
    extern void USBD_VND_ForceTxIdle(void);

    uint8_t ll_busy_before = USBD_VND_TxIsBusy();
    uint8_t ep_before = vnd_ep_busy;
    uint8_t inflight_before = vnd_inflight;
    uint8_t meta_before = vnd_tx_meta_depth();
    uint8_t ch_before = sending_channel;
    uint8_t pend_before = pending_B;
    uint16_t stuck_len = vnd_last_tx_len;
    uint8_t flags_before = inflight_flags;
    uint32_t seq_before = inflight_seq;

    if(!vnd_usb_in_active_abort_allowed(ll_busy_before, age_ms)){
        vnd_tx_drop_recovery_request = 0u;
        vnd_usb_in_note_active_hold(reason, now_ms, age_ms);
        return;
    }

    if((flags_before & 0x03u) == 0u && last_tx_is_frame){
        flags_before = last_tx_flags;
        seq_before = last_tx_seq;
    }

    uint8_t recoverable_before = vnd_usb_in_has_recoverable_state();
    uint8_t stale_app_before = (ep_before || inflight_before || meta_before != 0u ||
                                ch_before != 0xFFu || pend_before) ? 1u : 0u;
    /* ForceTxIdle aborts and flushes the hardware endpoint. Application-only
       bookkeeping must never be used as a reason to touch an already idle LL
       endpoint; doing so can race the next healthy transfer. */
    uint8_t need_force_idle = ll_busy_before ? 1u : 0u;

    if(!need_force_idle && !stale_app_before && !recoverable_before){
        vnd_tx_drop_recovery_request = 0u;
        return;
    }

    uint8_t slot = vnd_usb_in_active_slot_for_recovery(seq_before, flags_before);

    if(!need_force_idle && ((flags_before & 0x03u) == 0u) && vnd_slot_has_active_frames(slot)){
        if(g_frames[slot][0].st != FB_FILL){
            flags_before = 0x01u;
            seq_before = g_frames[slot][0].seq;
        } else if(g_frames[slot][1].st != FB_FILL){
            flags_before = 0x02u;
            seq_before = g_frames[slot][1].seq;
        }
    }

    if(need_force_idle){
        USBD_VND_ForceTxIdle();
        dbg_tx_force_idle_count++;
        dbg_tx_force_idle_last_ms = now_ms;
    }
    dbg_tx_drop_recovery_count++;
    dbg_tx_drop_recovery_last_ms = now_ms;

    USBD_VND_InHwState hw_before;
    USBD_VND_GetInHwState(&hw_before);
    uint8_t dropped = vnd_drop_current_stream_unit(slot, flags_before);

    dbg_tx_drop_recovery_diag.age_ms = age_ms;
    dbg_tx_drop_recovery_diag.hw_diepctl = hw_before.diepctl;
    dbg_tx_drop_recovery_diag.tx_len = stuck_len;
    dbg_tx_drop_recovery_diag.reason = vnd_usb_in_recovery_reason_code(reason);
    dbg_tx_drop_recovery_diag.ll_busy = ll_busy_before;
    dbg_tx_drop_recovery_diag.ep_busy = ep_before;
    dbg_tx_drop_recovery_diag.inflight = inflight_before;
    dbg_tx_drop_recovery_diag.sending_channel = ch_before;
    dbg_tx_drop_recovery_diag.pending_b = pend_before;
    dbg_tx_drop_recovery_diag.meta_depth = meta_before;
    dbg_tx_drop_recovery_diag.stream_mode = vnd_stream_mode;
    dbg_tx_drop_recovery_diag.dropped = dropped;

    vnd_tx_meta_head = vnd_tx_meta_tail = 0u;
    vnd_clear_inflight_meta();
    vnd_ep_busy = 0u;
    vnd_tx_ready = 1u;
    vnd_inflight = 0u;
    vnd_last_tx_start_ms = 0u;
    test_in_flight = 0u;
    status_ack_pending = 0u;
    start_stat_inflight = 0u;
    start_ack_done = 1u;
    vnd_tx_drop_recovery_request = 0u;
    vnd_tx_kick = 1u;

    printf("[WARN EP_DROP] kind=%s age=%lu len=%u force=%u ll=%u ep=%u infl=%u ch=%u pendB=%u slot=%u fl=0x%02X meta=%u mode=%u dropped=%u cnt=%lu req=%lu\r\n",
           reason ? reason : "?",
           (unsigned long)age_ms,
           (unsigned)stuck_len,
           (unsigned)need_force_idle,
           (unsigned)ll_busy_before,
           (unsigned)ep_before,
           (unsigned)inflight_before,
           (unsigned)ch_before,
           (unsigned)pend_before,
           (unsigned)slot,
           (unsigned)flags_before,
           (unsigned)meta_before,
           (unsigned)vnd_stream_mode,
           (unsigned)dropped,
           (unsigned long)dbg_tx_drop_recovery_count,
           (unsigned long)dbg_tx_drop_recovery_request_count);
}

static void vnd_usb_in_request_drop_recovery_from_status(uint32_t now_ms)
{
    if(!streaming || stop_request) return;

    extern uint8_t USBD_VND_TxIsBusy(void);
    uint8_t ll_busy = USBD_VND_TxIsBusy();
    uint8_t busyish = (ll_busy || vnd_ep_busy || vnd_inflight || vnd_tx_meta_depth() != 0u) ? 1u : 0u;
    uint32_t age_ms = 0u;

    if(busyish &&
       vnd_last_tx_start_ms != 0u &&
       vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &age_ms) &&
       age_ms > VND_USB_IN_BUSY_STALL_MS){
        if(!vnd_usb_in_active_abort_allowed(ll_busy, age_ms)){
            vnd_usb_in_note_active_hold("status_busy", now_ms, age_ms);
            return;
        }
        if(!vnd_tx_drop_recovery_request){
            dbg_tx_drop_recovery_request_count++;
        }
        vnd_tx_drop_recovery_request = 1u;
        vnd_tx_kick = 1u;
        return;
    }

    if(vnd_stream_active &&
       vnd_last_frame_txcplt_ms != 0u &&
       vnd_usb_in_has_recoverable_state() &&
       vnd_tick_age_ms(now_ms, vnd_last_frame_txcplt_ms, &age_ms) &&
       age_ms > VND_USB_IN_NO_PROGRESS_MS){
        if(!busyish){
            /* READY/pending data is not a failed USB transfer. Let the stream
               task submit it; never convert scheduler latency into a drop. */
            vnd_tx_kick = 1u;
            return;
        }
        if(!vnd_usb_in_active_abort_allowed(ll_busy, age_ms)){
            vnd_usb_in_note_active_hold("status_no_progress", now_ms, age_ms);
            return;
        }
        if(!vnd_tx_drop_recovery_request){
            dbg_tx_drop_recovery_request_count++;
        }
        vnd_tx_drop_recovery_request = 1u;
        vnd_tx_kick = 1u;
    }
}

static void vnd_usb_in_drop_recovery_poll(uint32_t now_ms)
{
    if(!streaming || stop_request){
        vnd_tx_drop_recovery_request = 0u;
        return;
    }

    uint32_t cooldown_age = 0u;
    uint32_t last_recovery_ms = dbg_tx_drop_recovery_last_ms;
    if(last_recovery_ms == 0u){
        last_recovery_ms = dbg_tx_force_idle_last_ms;
    }
    if(last_recovery_ms != 0u &&
       vnd_tick_age_ms(now_ms, last_recovery_ms, &cooldown_age) &&
       cooldown_age < VND_USB_IN_RECOVERY_COOLDOWN_MS){
        return;
    }

    extern uint8_t USBD_VND_TxIsBusy(void);
    uint8_t ll_busy = USBD_VND_TxIsBusy();
    uint8_t busyish = (ll_busy || vnd_ep_busy || vnd_inflight || vnd_tx_meta_depth() != 0u) ? 1u : 0u;
    uint32_t age_ms = 0u;

    if(vnd_tx_drop_recovery_request){
        /* A queued READY frame or pending B is work to schedule, not a stuck
           transfer. Only stale in-flight bookkeeping may enter recovery. */
        if(!busyish){
            vnd_tx_drop_recovery_request = 0u;
            vnd_tx_kick = 1u;
            return;
        }
        if(vnd_last_tx_start_ms != 0u){
            (void)vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &age_ms);
        } else if(vnd_last_frame_txcplt_ms != 0u){
            (void)vnd_tick_age_ms(now_ms, vnd_last_frame_txcplt_ms, &age_ms);
        }
        if(!vnd_usb_in_active_abort_allowed(ll_busy, age_ms)){
            vnd_tx_drop_recovery_request = 0u;
            vnd_usb_in_note_active_hold("status", now_ms, age_ms);
            return;
        }
        vnd_usb_in_drop_recover("status", now_ms, age_ms);
        return;
    }

    if(busyish &&
       vnd_last_tx_start_ms != 0u &&
       vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &age_ms) &&
       age_ms > VND_USB_IN_BUSY_STALL_MS){
        if(!vnd_usb_in_active_abort_allowed(ll_busy, age_ms)){
            vnd_usb_in_note_active_hold("busy", now_ms, age_ms);
            return;
        }
        vnd_usb_in_drop_recover("busy", now_ms, age_ms);
        return;
    }

    if(vnd_stream_active &&
       vnd_last_frame_txcplt_ms != 0u &&
       vnd_usb_in_has_recoverable_state() &&
       vnd_tick_age_ms(now_ms, vnd_last_frame_txcplt_ms, &age_ms) &&
       age_ms > VND_USB_IN_NO_PROGRESS_MS){
        if(!busyish){
            /* Nothing is in flight. Keep the prepared pair and ask the normal
               scheduler to submit it instead of manufacturing a sequence gap. */
            vnd_tx_kick = 1u;
            return;
        }
        if(!vnd_usb_in_active_abort_allowed(ll_busy, age_ms)){
            vnd_usb_in_note_active_hold("no_progress", now_ms, age_ms);
            return;
        }
        vnd_usb_in_drop_recover("no_progress", now_ms, age_ms);
    }
}
static __attribute__((unused)) void vnd_debug_force_status_tick(void);
static void vnd_debug_raw_stat_tick(void);
static void __attribute__((unused)) vnd_send_fake_pair(void); // удалим позже; сейчас заглушка ниже
static void vnd_log_hdr_layout(void);
static void vnd_try_send_pending_status_from_task(void);
static void vnd_try_send_test_from_task(void);
/* Быстрый пайплайн: немедленная отправка следующего кадра из TxCplt */
static int vnd_try_send_B_immediate(void);
static int vnd_try_send_A_nextpair_immediate(void);
/* Заглушки для отключённых диагностик в static-mode */
static __attribute__((unused)) void vnd_debug_raw_stat_tick(void){ }
static void vnd_send_fake_pair(void){ }
static __attribute__((unused)) void vnd_debug_force_status_tick(void){ }
static __attribute__((unused)) void vnd_try_start_tx(void){ }
/* Аварийный keepalive: если совсем нет успешных завершений передач первые секунды */
static void vnd_emergency_keepalive(uint32_t now_ms);
/* Сервис: асинхронная обработка команд управления (EP0 SOFT/DEEP RESET) */
extern void USBD_VND_ProcessControlRequests(void);
/* Асинхронный планировщик A/B */
static int vnd_async_try_tx(void);
static int vnd_find_pair_by_seq(uint32_t seq);

void Vendor_Control_Task(void)
{
    USBD_VND_ProcessControlRequests();
}

/* Вычисление периода пары по требуемым samples_per_frame и текущему профилю ADC (buf_rate_hz) */
static void vnd_recompute_pair_timing(uint16_t samples_per_frame)
{
    /* Используем частоту буферов (Fs блоков/с), а не абсолютную частоту сэмплов */
    extern uint16_t adc_stream_get_buf_rate(void);
    uint16_t buf_rate = adc_stream_get_buf_rate();
    if(buf_rate == 0) buf_rate = 20; /* защита от деления на ноль */
    if(samples_per_frame == 0) samples_per_frame = 1;
    /* period_ms ≈ 1000 * samples_per_frame / buf_rate (округление) */
    uint32_t num = (uint32_t)samples_per_frame * 1000u + (uint32_t)(buf_rate/2u);
    uint32_t ms  = num / (uint32_t)buf_rate;
    if(ms == 0) ms = 1;
    vnd_pair_period_ms = (uint16_t)((ms > 1000u) ? 1000u : ms);
    /* Примечание: период больше не используется как задержка — передаём сразу при готовности данных.
       Оставляем расчёт только для информационных целей. */
    VND_LOG("PAIR_TIMING(info): samples=%u buf_rate=%u -> period≈%u ms",
        (unsigned)samples_per_frame, (unsigned)buf_rate, (unsigned)vnd_pair_period_ms);
}

/* Публичная функция: полный сброс/останов пайплайна */
void vnd_pipeline_stop_reset(int deep)
{
    /* Остановить передачу и внутренние состояния */
    streaming = 0; diag_mode_active = 0; full_mode = 1;
    stop_request = 0; pending_status = 0; start_stat_inflight = 0; status_ack_pending = 0; start_ack_done = 1;
    vnd_ep_busy = 0; vnd_tx_ready = 1; vnd_inflight = 0; sending_channel = 0xFF; pending_B = 0; pending_B_since_ms = 0;
    test_sent = 0; test_in_flight = 0; vnd_tx_kick = 1;
    /* Очистить мета-FIFO и счётчики */
    vnd_tx_meta_head = vnd_tx_meta_tail = 0; meta_push_total = meta_pop_total = meta_empty_events = meta_overflow_events = 0;
    stream_seq = 0; next_seq_to_assign = 0; dbg_produced_seq = 0; first_pair_done = 0;
    vnd_last_frame_txcplt_ms = 0; vnd_last_host_rx_ack_ms = 0; vnd_host_rx_last_counter = 0; vnd_host_rx_counter_valid = 0;
    cur_samples_per_frame = 0; cur_expected_frame_size = 0; dbg_any_valid_frame = 0;
    vnd_event_inflight_type = 0xFFu;
    vnd_event_inflight_len = 0u;
    vnd_event_next_tx_ms = 0u;
    vnd_reset_buffers();
    /* Even a deep USB-class reset is USB-only. ADC/DMA, marker and RS485 SYNC
       remain continuous while RPI closes/reopens endpoints. */
    (void)deep;
    /* Индикация */
    HAL_GPIO_WritePin(Data_ready_GPIO22_GPIO_Port, Data_ready_GPIO22_Pin, GPIO_PIN_RESET);
    /* A USB pipeline stop preserves the requested switch position, while the
       effective TX output is clamped off until streaming starts again. */
    (void)vnd_tx_refresh_effective(HAL_GetTick(), "pipeline_stop");
}

/* Реализация ранее отсутствовавшей функции */
/* Форсированное завершение зависшего тестового кадра без прихода TxCplt.
   Условия: test_in_flight == 0 (мы уже вручную сняли busy по таймауту), test_sent == 0 (ещё не засчитан),
   в FIFO присутствует meta с flags=0x80 и возраст > 60 мс.
   Вместо удаления элемента (что может рассинхронизировать последующие TxCplt), мы помечаем его как служебный:
     is_frame=0; flags=0; — таким образом последующий TxCplt безопасно извлекёт и проигнорирует.
   Гейтинг отправки A перестанет видеть TEST meta (по flags) и разрешит прогресс. */
static void vnd_force_complete_test_meta_if_stale(void)
{
#if VND_DISABLE_TEST
    /* В режиме без TEST: убедимся, что meta-FIFO не содержит блокирующих TEST записей */
    uint8_t t = vnd_tx_meta_tail;
    while(t != vnd_tx_meta_head){
        vnd_tx_meta_t *m = &vnd_tx_meta_fifo[t];
        if(m->is_frame && ((m->flags & 0x80u) != 0u)){ m->is_frame = 0; m->flags = 0; }
        t = (uint8_t)((t + 1u) % VND_TX_META_FIFO);
    }
    return;
#else
    if(test_in_flight) return;
    uint8_t t = vnd_tx_meta_tail;
    uint32_t now = HAL_GetTick();
    while(t != vnd_tx_meta_head){
        vnd_tx_meta_t *m = &vnd_tx_meta_fifo[t];
        if(m->is_frame && ((m->flags & 0x80u) != 0u)){
            uint32_t age = now - m->push_tick;
            if(age > 60){
                /* Форсируем */
                m->is_frame = 0; m->flags = 0; /* превращаем в служебный */
                if(!test_sent){ test_sent = 1; first_test_sent_ms = HAL_GetTick(); }
                VND_LOG("FORCE_TEST_META age=%lums depth=%u", (unsigned long)age, (unsigned)vnd_tx_meta_depth());
            }
            break; /* обрабатываем только первый TEST */
        }
        t = (uint8_t)((t + 1u) % VND_TX_META_FIFO);
    }
#endif
}

/* === Функция вывода FPS статистики и профилирования по CDC === */
void vnd_report_fps_stats(void)
{
    uint32_t now_ms = HAL_GetTick();
    uint32_t elapsed_ms = now_ms - fps_measurement_start_ms;
    
    if(elapsed_ms < 100) return; /* Слишком рано для измерения */
    
    /* Вычисляем FPS */
    float elapsed_sec = (float)elapsed_ms / 1000.0f;
    float pair_fps = (float)fps_pair_count / elapsed_sec;
    float frame_a_fps = (float)fps_frame_a_count / elapsed_sec;
    float frame_b_fps = (float)fps_frame_b_count / elapsed_sec;
    float prepare_fps = (float)fps_prepare_count / elapsed_sec;
    
    /* Вычисляем средние времена */
    uint32_t avg_prepare_us = (perf_stats.prepare_count > 0) ? 
        (perf_stats.prepare_total_us / perf_stats.prepare_count) : 0;
    uint32_t avg_transmit_us = (perf_stats.transmit_count > 0) ?
        (perf_stats.transmit_total_us / perf_stats.transmit_count) : 0;
    uint32_t avg_txcplt_us = (perf_stats.txcplt_count > 0) ?
        (perf_stats.txcplt_total_us / perf_stats.txcplt_count) : 0;
    
    cdc_logf("FPS pairs=%.1f A=%.1f B=%.1f prep=%.1f (%.1fs)",
        pair_fps, frame_a_fps, frame_b_fps, prepare_fps, elapsed_sec);
    cdc_logf("PERF prepare=%luus tx=%luus txcplt=%luus pair_int=%lu..%lums",
        (unsigned long)avg_prepare_us, (unsigned long)avg_transmit_us, 
        (unsigned long)avg_txcplt_us,
        (unsigned long)perf_stats.min_pair_interval_ms,
        (unsigned long)perf_stats.max_pair_interval_ms);
    
    fps_last_report_ms = now_ms;
}

/* === Функция вывода детального профилирования по запросу === */
void vnd_print_perf_stats(void)
{
    uint32_t now_ms = HAL_GetTick();
    uint32_t elapsed_ms = now_ms - fps_measurement_start_ms;
    float elapsed_sec = (elapsed_ms > 0) ? ((float)elapsed_ms / 1000.0f) : 0.001f;
    
    /* FPS */
    float pair_fps = (float)fps_pair_count / elapsed_sec;
    float frame_a_fps = (float)fps_frame_a_count / elapsed_sec;
    float frame_b_fps = (float)fps_frame_b_count / elapsed_sec;
    
    /* Средние времена */
    uint32_t avg_prepare_us = (perf_stats.prepare_count > 0) ? 
        (perf_stats.prepare_total_us / perf_stats.prepare_count) : 0;
    uint32_t avg_transmit_us = (perf_stats.transmit_count > 0) ?
        (perf_stats.transmit_total_us / perf_stats.transmit_count) : 0;
    uint32_t avg_txcplt_us = (perf_stats.txcplt_count > 0) ?
        (perf_stats.txcplt_total_us / perf_stats.txcplt_count) : 0;
    
    cdc_logf("=== PERFORMANCE STATS (%.1fs) ===", elapsed_sec);
    cdc_logf("FPS: pairs=%.1f A=%.1f B=%.1f", pair_fps, frame_a_fps, frame_b_fps);
    cdc_logf("COUNTS: pairs=%lu A=%lu B=%lu prep=%lu",
        (unsigned long)fps_pair_count, (unsigned long)fps_frame_a_count,
        (unsigned long)fps_frame_b_count, (unsigned long)fps_prepare_count);
    cdc_logf("TIMING: prepare=%luus tx=%luus txcplt=%luus",
        (unsigned long)avg_prepare_us, (unsigned long)avg_transmit_us,
        (unsigned long)avg_txcplt_us);
    cdc_logf("INTERVAL: min=%lums max=%lums",
        (unsigned long)perf_stats.min_pair_interval_ms,
        (unsigned long)perf_stats.max_pair_interval_ms);
    
    /* Диагностика ADC */
    extern volatile uint32_t frame_wr_seq, frame_rd_seq;
    cdc_logf("ADC: wr=%lu rd=%lu skipped=%lu",
        (unsigned long)frame_wr_seq, (unsigned long)frame_rd_seq,
        (unsigned long)dbg_skipped_frames);
}

static void vnd_put_le16(uint8_t *dst, uint16_t v)
{
    dst[0] = (uint8_t)(v & 0xFFu);
    dst[1] = (uint8_t)((v >> 8) & 0xFFu);
}

static void vnd_put_le32(uint8_t *dst, uint32_t v)
{
    dst[0] = (uint8_t)(v & 0xFFu);
    dst[1] = (uint8_t)((v >> 8) & 0xFFu);
    dst[2] = (uint8_t)((v >> 16) & 0xFFu);
    dst[3] = (uint8_t)((v >> 24) & 0xFFu);
}

static uint8_t vnd_event_enqueue(uint8_t event_type, const uint8_t *payload, uint16_t payload_len)
{
    if(payload_len > (uint16_t)(VND_EVENT_MAX - VND_EVENT_HDR_SIZE)){
        return 0u;
    }

    if(vnd_event_count >= VND_EVENT_QUEUE_LEN){
        vnd_event_tail = (uint8_t)((vnd_event_tail + 1u) % VND_EVENT_QUEUE_LEN);
        vnd_event_count--;
        dbg_event_dropped++;
    }

    uint8_t idx = vnd_event_head;
    uint8_t *pkt = vnd_event_q[idx];
    uint32_t seq = vnd_event_seq++;
    uint32_t now_ms = HAL_GetTick();

    pkt[0] = (uint8_t)'E';
    pkt[1] = (uint8_t)'V';
    pkt[2] = (uint8_t)'T';
    pkt[3] = (uint8_t)'1';
    pkt[4] = 1u;
    pkt[5] = event_type;
    vnd_put_le16(&pkt[6], payload_len);
    vnd_put_le32(&pkt[8], seq);
    vnd_put_le32(&pkt[12], now_ms);
    if(payload_len != 0u && payload != NULL){
        memcpy(&pkt[VND_EVENT_HDR_SIZE], payload, payload_len);
    }

    vnd_event_len[idx] = (uint8_t)(VND_EVENT_HDR_SIZE + payload_len);
    vnd_event_head = (uint8_t)((vnd_event_head + 1u) % VND_EVENT_QUEUE_LEN);
    vnd_event_count++;
    vnd_event_last_enqueue_ms = now_ms;
    dbg_event_enqueued++;
    dbg_event_last_enqueue_type = event_type;
    vnd_tx_kick = 1u;
    return 1u;
}

static uint16_t vnd_absdiff_u16(uint16_t a, uint16_t b)
{
    return (a >= b) ? (uint16_t)(a - b) : (uint16_t)(b - a);
}

static uint8_t vnd_payload_changed(const uint8_t *payload,
                                   uint8_t payload_len,
                                   uint8_t *last_payload,
                                   uint8_t *last_len,
                                   uint8_t *have_last)
{
    if((payload == NULL) || (last_payload == NULL) || (last_len == NULL) || (have_last == NULL)){
        return 0u;
    }
    if((*have_last == 0u) || (*last_len != payload_len)){
        return 1u;
    }
    return (memcmp(last_payload, payload, payload_len) != 0) ? 1u : 0u;
}

static void vnd_payload_remember(const uint8_t *payload,
                                 uint8_t payload_len,
                                 uint8_t *last_payload,
                                 uint8_t *last_len,
                                 uint8_t *have_last)
{
    if((payload == NULL) || (last_payload == NULL) || (last_len == NULL) || (have_last == NULL)){
        return;
    }
    memcpy(last_payload, payload, payload_len);
    *last_len = payload_len;
    *have_last = 1u;
}

static void vnd_copy_ascii_fixed(uint8_t *dst, uint8_t len, const char *src)
{
    uint8_t i;

    if((dst == NULL) || (len == 0u)){
        return;
    }
    memset(dst, 0, len);
    if(src == NULL){
        return;
    }
    for(i = 0u; (i < len) && (src[i] != '\0'); i++){
        dst[i] = (uint8_t)src[i];
    }
}

static void vnd_change_event_force_report(void)
{
    vnd_change_force_event = 1u;
    vnd_tx_kick = 1u;
}

static void vnd_emit_fw_info_event(uint8_t force)
{
    uint8_t payload[47];

    if(force == 0u){
        return;
    }

    payload[0] = 1u;
    payload[1] = (uint8_t)FW_VERSION_MAJOR;
    payload[2] = (uint8_t)FW_VERSION_MINOR;
    payload[3] = (uint8_t)FW_VERSION_PATCH;
    payload[4] = 0u;
    vnd_put_le32(&payload[5], HAL_GetUIDw0());
    vnd_put_le32(&payload[9], HAL_GetUIDw1());
    vnd_put_le32(&payload[13], HAL_GetUIDw2());
    vnd_copy_ascii_fixed(&payload[17], 10u, fw_build_date);
    vnd_copy_ascii_fixed(&payload[27], 8u, fw_build_time);
    vnd_copy_ascii_fixed(&payload[35], 12u, fw_git_hash);

    (void)vnd_event_enqueue(VND_EVT_TYPE_FW_INFO, payload, (uint16_t)sizeof(payload));
}

static uint8_t vnd_mcu_adc_changed(const mcu_internal_adc_v1_t *now)
{
    if(now == NULL){
        return 0u;
    }
    if(vnd_mcu_adc_have_last == 0u){
        return 1u;
    }
    if(now->flags != vnd_mcu_adc_last_sent.flags){
        return 1u;
    }
    if(now->temp_c != vnd_mcu_adc_last_sent.temp_c){
        return 1u;
    }
    if(vnd_absdiff_u16(now->vdda_mv, vnd_mcu_adc_last_sent.vdda_mv) >= (uint16_t)VND_SENSOR_VDDA_DELTA_MV){
        return 1u;
    }
    if(vnd_absdiff_u16(now->vbat_mv, vnd_mcu_adc_last_sent.vbat_mv) >= (uint16_t)VND_SENSOR_VBAT_DELTA_MV){
        return 1u;
    }
    return 0u;
}

static void vnd_emit_mcu_adc_events(const mcu_internal_adc_v1_t *snap, uint8_t force)
{
    if(snap == NULL){
        return;
    }

    vnd_temp_last_read_c = snap->temp_c;
    if((force != 0u) || (snap->temp_c != vnd_temp_last_sent_c)){
        uint8_t temp_payload[2];
        vnd_put_le16(temp_payload, (uint16_t)snap->temp_c);
        if(vnd_event_enqueue(VND_EVT_TYPE_TEMP_C, temp_payload, (uint16_t)sizeof(temp_payload))){
            vnd_temp_last_sent_c = snap->temp_c;
        }
    }

    if((force != 0u) || vnd_mcu_adc_changed(snap)){
        uint8_t payload[16];
        payload[0] = snap->version;
        payload[1] = snap->flags;
        vnd_put_le16(&payload[2], (uint16_t)snap->temp_c);
        vnd_put_le16(&payload[4], snap->vdda_mv);
        vnd_put_le16(&payload[6], snap->vbat_mv);
        vnd_put_le16(&payload[8], snap->raw_temp);
        vnd_put_le16(&payload[10], snap->raw_vrefint);
        vnd_put_le16(&payload[12], snap->raw_vbat);
        vnd_put_le16(&payload[14], snap->reserved);
        if(vnd_event_enqueue(VND_EVT_TYPE_MCU_ADC, payload, (uint16_t)sizeof(payload))){
            vnd_mcu_adc_last_sent = *snap;
            vnd_mcu_adc_have_last = 1u;
        }
    }
}

static void vnd_sensor_event_poll(uint32_t now_ms, uint8_t force)
{
    uint8_t due = force;
    mcu_internal_adc_v1_t snap;

    if((uint32_t)(now_ms - vnd_sensor_last_poll_ms) >= (uint32_t)VND_TEMP_EVENT_PERIOD_MS){
        due = 1u;
    }
    if(due == 0u){
        return;
    }

    vnd_sensor_last_poll_ms = now_ms;
    if(mcu_internal_adc_read(&snap)){
        vnd_emit_mcu_adc_events(&snap, force);
    }
}

#define VND_RPI_OPTIC_STATUS_BIT 0x20u

static uint8_t vnd_optic_rpi_report_allowed(void)
{
    /* Optical input is a physical sensor state, not a synchronization-quality
       estimate. Never turn a stable PD0 HIGH into a synthetic LOW when visual
       SYNC lock, role diagnostics, or topology flags fluctuate. Conflicted or
       stale remote IDs are already suppressed by rs485_status_get_snapshot(). */
    return 1u;
}

static void vnd_optic_rpi_sanitize_queued_event(uint8_t *packet,
                                                uint16_t packet_len)
{
    uint8_t changed = 0u;
    uint8_t event_type;

    if((packet == NULL) ||
       (packet_len < VND_EVENT_HDR_SIZE) ||
       (vnd_optic_rpi_report_allowed() != 0u)){
        return;
    }

    event_type = packet[5];
    if((event_type == VND_EVT_TYPE_OPTIC_STATE) &&
       (packet_len >= (uint16_t)(VND_EVENT_HDR_SIZE + 8u))){
        if((packet[VND_EVENT_HDR_SIZE + 1u] & 0x01u) != 0u){
            packet[VND_EVENT_HDR_SIZE + 1u] &= (uint8_t)~0x01u;
            changed = 1u;
        }
        if(changed != 0u){
            vnd_optic_have_last = 0u;
        }
    } else if((event_type == VND_EVT_TYPE_SYNC_STATE) &&
              (packet_len >= (uint16_t)(VND_EVENT_HDR_SIZE + 16u))){
        if((packet[VND_EVENT_HDR_SIZE + 13u] &
            VND_RPI_OPTIC_STATUS_BIT) != 0u){
            packet[VND_EVENT_HDR_SIZE + 13u] &=
                (uint8_t)~VND_RPI_OPTIC_STATUS_BIT;
            changed = 1u;
        }
        if(changed != 0u){
            vnd_sync_have_last = 0u;
        }
    } else if((event_type == VND_EVT_TYPE_SENSOR_MAP) &&
              (packet_len >= (uint16_t)(VND_EVENT_HDR_SIZE + 40u))){
        for(uint8_t device_id = 0u; device_id < 32u; device_id++){
            uint8_t *status =
                &packet[VND_EVENT_HDR_SIZE + 8u + device_id];
            if((*status & VND_RPI_OPTIC_STATUS_BIT) != 0u){
                *status &= (uint8_t)~VND_RPI_OPTIC_STATUS_BIT;
                changed = 1u;
            }
        }
        if(changed != 0u){
            vnd_sensor_map_have_last = 0u;
        }
    }
}

static void vnd_emit_optic_state_event(uint8_t force)
{
    uint8_t payload[8];
    uint8_t flags = 0u;

    if((vnd_optic_rpi_report_allowed() != 0u) &&
       (optic_sensor_get_state() != 0u)){
        flags |= 0x01u;
    }
    if(vnd_tx_enable != 0u){
        flags |= 0x02u;
    }

    payload[0] = 1u;
    payload[1] = flags;
    payload[2] = optic_tx_get_power();
    payload[3] = dynamic_led_get_pattern();
    vnd_put_le16(&payload[4], optic_sensor_get_hold_deciseconds());
    payload[6] = 0u;
    payload[7] = 0u;

    if((force != 0u) ||
       vnd_payload_changed(payload, (uint8_t)sizeof(payload),
                           vnd_optic_last_payload, &vnd_optic_last_len, &vnd_optic_have_last)){
        if(vnd_event_enqueue(VND_EVT_TYPE_OPTIC_STATE, payload, (uint16_t)sizeof(payload))){
            vnd_payload_remember(payload, (uint8_t)sizeof(payload),
                                 vnd_optic_last_payload, &vnd_optic_last_len, &vnd_optic_have_last);
        }
    }
}

static void vnd_emit_sync_state_event(uint8_t force)
{
    vnd_lcd_sync_snapshot_t lcd;
    uint8_t local_status = 0u;
    uint8_t active_status_count = 0u;
    uint32_t seen_mask = 0u;
    uint8_t payload[16];
    uint8_t flags = 0u;
    uint8_t total_devices = 1u;
    uint8_t persisted_mode = VND_SYNC_MODE_SLAVE;
    uint32_t age_ds = 0xFFFFu;

    memset(&lcd, 0, sizeof(lcd));
    vnd_get_lcd_sync_snapshot(&lcd);
    (void)rs485_status_get_snapshot(&local_status, &active_status_count, &seen_mask, NULL, 32u);

    if((lcd.raw_mode == VND_SYNC_MODE_MASTER) ||
       (lcd.raw_mode == VND_SYNC_MODE_SLAVE)){
        total_devices = (active_status_count != 0u) ? active_status_count : 1u;
    }
    if(total_devices == 0u){
        total_devices = 1u;
    }

    if(lcd.sync_signal_alive != 0u) flags |= 0x01u;
    if(lcd.sync_ok_visual != 0u) flags |= 0x02u;
    if(lcd.sync_color_locked != 0u) flags |= 0x04u;
    if(vnd_sync_is_mode_host_forced() != 0u) flags |= 0x08u;
    if(vnd_sync_ok_public != 0u) flags |= 0x10u;
    if(rs485_role_get_local_persisted_mode(&persisted_mode) != 0u) flags |= 0x20u;
    if(rs485_node_local_id_conflict() != 0u) flags |= 0x40u;
    if(rs485_multiple_master_detected() != 0u) flags |= 0x80u;
    if(lcd.sync_age_ms != 0xFFFFFFFFu){
        age_ds = lcd.sync_age_ms / 100u;
        if(age_ds > 0xFFFFu) age_ds = 0xFFFFu;
    }

    payload[0] = 1u;
    payload[1] = lcd.raw_mode;
    payload[2] = lcd.display_mode;
    payload[3] = lcd.display_char;
    payload[4] = lcd.node_id;
    payload[5] = active_status_count;
    payload[6] = total_devices;
    payload[7] = flags;
    vnd_put_le32(&payload[8], seen_mask);
    payload[12] = lcd.display_value;
    payload[13] = (uint8_t)(local_status & 0xE0u);
    if(vnd_optic_rpi_report_allowed() == 0u) {
        payload[13] &= (uint8_t)~VND_RPI_OPTIC_STATUS_BIT;
    }
    if(rs485_role_get_local_persisted_mode(&persisted_mode) != 0u) {
        payload[13] |= (persisted_mode == VND_SYNC_MODE_MASTER) ? 0x01u : 0x02u;
    }
    if(lcd.node_id_assigned != 0u) {
        payload[13] |= 0x04u;
    }
    vnd_put_le16(&payload[14], (uint16_t)age_ds);

    if((force != 0u) ||
       vnd_payload_changed(payload, 14u,
                           vnd_sync_last_payload, &vnd_sync_last_len, &vnd_sync_have_last)){
        if(vnd_event_enqueue(VND_EVT_TYPE_SYNC_STATE, payload, (uint16_t)sizeof(payload))){
            vnd_payload_remember(payload, 14u,
                                 vnd_sync_last_payload, &vnd_sync_last_len, &vnd_sync_have_last);
        }
    }
}

static void vnd_emit_sensor_map_event(uint8_t force)
{
    vnd_lcd_sync_snapshot_t lcd;
    uint8_t payload[40];
    uint8_t node_count = 0u;
    uint32_t seen_mask = 0u;

    memset(&lcd, 0, sizeof(lcd));
    memset(payload, 0, sizeof(payload));
    vnd_get_lcd_sync_snapshot(&lcd);
    (void)rs485_status_get_snapshot(NULL,
                                    &node_count,
                                    &seen_mask,
                                    &payload[8],
                                    32u);
    if(vnd_optic_rpi_report_allowed() == 0u){
        for(uint8_t device_id = 0u; device_id < 32u; device_id++){
            payload[8u + device_id] &=
                (uint8_t)~VND_RPI_OPTIC_STATUS_BIT;
        }
    }

    payload[0] = 1u;
    payload[1] = lcd.node_id;
    if(lcd.node_id_assigned != 0u) {
        payload[2] |= 0x01u;
    }
    if(lcd.raw_mode == VND_SYNC_MODE_MASTER) {
        payload[2] |= 0x02u;
    }
    payload[3] = node_count;
    vnd_put_le32(&payload[4], seen_mask);

    if((force != 0u) ||
       vnd_payload_changed(payload, (uint8_t)sizeof(payload),
                           vnd_sensor_map_last_payload,
                           &vnd_sensor_map_last_len,
                           &vnd_sensor_map_have_last)){
        if(vnd_event_enqueue(VND_EVT_TYPE_SENSOR_MAP,
                             payload,
                             (uint16_t)sizeof(payload))){
            vnd_payload_remember(payload, (uint8_t)sizeof(payload),
                                 vnd_sensor_map_last_payload,
                                 &vnd_sensor_map_last_len,
                                 &vnd_sensor_map_have_last);
        }
    }
}

static uint8_t vnd_host_rx_alive_now(uint32_t now_ms)
{
    uint32_t age_ms = 0u;
    return (uint8_t)(streaming &&
                     vnd_tick_age_ms(now_ms, vnd_last_host_rx_ack_ms, &age_ms) &&
                     age_ms <= VND_HOST_RX_ACK_TIMEOUT_MS);
}

static void vnd_tx_failsafe_service(uint32_t now_ms)
{
    (void)vnd_tx_refresh_effective(now_ms, "failsafe");
}

static void vnd_emit_mode_state_event(uint32_t now_ms, uint8_t force)
{
    uint8_t payload[16];
    uint8_t flags = 0u;

    if(streaming) flags |= 0x01u;
    if(diag_mode_active) flags |= 0x02u;
    if(vnd_pending_init) flags |= 0x04u;
    if(vnd_stream_active) flags |= 0x08u;
    if(full_mode) flags |= 0x10u;
    if(async_mode) flags |= 0x20u;
    if(vnd_tx_enable) flags |= 0x40u;
    if(vnd_host_rx_alive_now(now_ms)) flags |= 0x80u;

    payload[0] = 1u;
    payload[1] = flags;
    payload[2] = vnd_stream_mode;
    payload[3] = vnd_ch_mode;
    payload[4] = host_profile;
    payload[5] = vnd_avg_n;
    vnd_put_le16(&payload[6], cur_samples_per_frame);
    vnd_put_le16(&payload[8], vnd_frame_samples_req);
    vnd_put_le16(&payload[10], vnd_trunc_samples);
    payload[12] = vnd_sync_mode_public;
    payload[13] = vnd_sync_is_mode_host_forced();
    payload[14] = 0u;
    payload[15] = 0u;

    if((force != 0u) ||
       vnd_payload_changed(payload, (uint8_t)sizeof(payload),
                           vnd_mode_last_payload, &vnd_mode_last_len, &vnd_mode_have_last)){
        if(vnd_event_enqueue(VND_EVT_TYPE_MODE_STATE, payload, (uint16_t)sizeof(payload))){
            vnd_payload_remember(payload, (uint8_t)sizeof(payload),
                                 vnd_mode_last_payload, &vnd_mode_last_len, &vnd_mode_have_last);
        }
    }
}

static void vnd_emit_error_state_event(uint8_t force)
{
    uint8_t payload[16];
    uint8_t flags = 0u;
    uint32_t last_error = vnd_last_error;

    if(last_error != 0u){
        flags |= 0x01u;
    }

    payload[0] = 1u;
    payload[1] = flags;
    vnd_put_le16(&payload[2], (last_error > 0xFFFFu) ? 0xFFFFu : (uint16_t)last_error);
    vnd_put_le32(&payload[4], vnd_error_counter);
    vnd_put_le32(&payload[8], dbg_tx_force_idle_count);
    vnd_put_le32(&payload[12], dbg_tx_drop_recovery_count);

    if((force != 0u) ||
       vnd_payload_changed(payload, (uint8_t)sizeof(payload),
                           vnd_error_last_payload, &vnd_error_last_len, &vnd_error_have_last)){
        if(vnd_event_enqueue(VND_EVT_TYPE_ERROR_STATE, payload, (uint16_t)sizeof(payload))){
            vnd_payload_remember(payload, (uint8_t)sizeof(payload),
                                 vnd_error_last_payload, &vnd_error_last_len, &vnd_error_have_last);
        }
    }
}

static void vnd_state_event_poll(uint32_t now_ms, uint8_t force)
{
    uint8_t due = force;
    uint8_t heartbeat = 0u;

    if((uint32_t)(now_ms - vnd_state_last_poll_ms) >= (uint32_t)VND_STATE_EVENT_PERIOD_MS){
        due = 1u;
    }
    if((vnd_event_count == 0u) &&
       ((uint32_t)(now_ms - vnd_event_last_enqueue_ms) >= (uint32_t)VND_EVENT_HEARTBEAT_MS)){
        due = 1u;
        heartbeat = 1u;
    }
    if(due == 0u){
        return;
    }
    vnd_state_last_poll_ms = now_ms;

    vnd_emit_fw_info_event(force);
    vnd_emit_optic_state_event(force);
    vnd_emit_sync_state_event(force);
    vnd_emit_sensor_map_event(force);
    vnd_emit_mode_state_event(now_ms, (uint8_t)(force || heartbeat));
    vnd_emit_error_state_event(force);
}

void Vendor_ChangeEvent_Task(void)
{
    uint32_t now_ms = HAL_GetTick();
    uint8_t force;
    uint8_t refresh;
    uint32_t primask;

    /* RS485 and sensor paths can raise these flags from interrupts. Snapshot
       and clear atomically; a request arriving later remains pending. */
    primask = __get_PRIMASK();
    __disable_irq();
    force = vnd_change_force_event;
    refresh = need_usb_status_refresh;
    vnd_change_force_event = 0u;
    need_usb_status_refresh = 0u;
    if(primask == 0u){
        __enable_irq();
    }

    if((refresh != 0u) && (force == 0u)){
        uint32_t enqueued_before = dbg_event_enqueued;

        /* Only controlled-sensor state is latency-critical. Role/topology,
           mode and error state remain on the 250 ms state poll below. Calling
           SYNC_STATE for every transient RS485 word can otherwise create a
           continuous service stream while the bus window is changing. */
        vnd_emit_optic_state_event(0u);
        vnd_emit_sensor_map_event(0u);
        if(dbg_event_enqueued != enqueued_before){
            pending_status = 1u;
            vnd_tx_kick = 1u;
        }
    } else if((refresh != 0u) && (force != 0u)){
        /* Preserve the legacy STAT companion for a genuine forced report. */
        pending_status = 1u;
        vnd_tx_kick = 1u;
    }

    vnd_state_event_poll(now_ms, force);
    vnd_sensor_event_poll(now_ms, force);
}

static uint8_t vnd_has_pending_event(void)
{
    return (uint8_t)(vnd_event_count != 0u);
}

static uint8_t vnd_can_preempt_stream_with_event(void)
{
    if(!vnd_has_pending_event()) return 0u;
    if(!streaming) return 1u;
    if(!first_pair_done && !vnd_stream_active) return 0u;
    if(pending_B || sending_channel != 0xFFu) return 0u;
    return 1u;
}

static void vnd_try_send_pending_event_from_task(void)
{
    if(!vnd_has_pending_event()) return;
    if(vnd_ep_busy || vnd_inflight){
        dbg_event_tx_defer++;
        return;
    }
    uint32_t now_ms = HAL_GetTick();
    if((vnd_event_next_tx_ms != 0u) && ((int32_t)(now_ms - vnd_event_next_tx_ms) < 0)){
        dbg_event_tx_defer++;
        return;
    }

    uint8_t idx = vnd_event_tail;
    uint16_t l = vnd_event_len[idx];
    if(l < VND_EVENT_HDR_SIZE || l > VND_EVENT_MAX){
        vnd_event_tail = (uint8_t)((vnd_event_tail + 1u) % VND_EVENT_QUEUE_LEN);
        if(vnd_event_count != 0u) vnd_event_count--;
        return;
    }
    uint8_t event_type = vnd_event_q[idx][5];
    memcpy(vnd_event_tx_buf, vnd_event_q[idx], l);
    vnd_optic_rpi_sanitize_queued_event(vnd_event_tx_buf, l);

    vnd_status_permit_once = 1;
    vnd_tx_ready = 0;
    vnd_ep_busy = 1;
    vnd_last_tx_len = l;
    vnd_last_tx_start_ms = now_ms;
    vnd_mark_service_inflight();
    dbg_event_tx_attempt++;
    vnd_event_inflight_type = event_type;
    vnd_event_inflight_len = (uint8_t)l;
    vnd_tx_meta_before(vnd_event_tx_buf, l);
    if(USBD_VND_Transmit(&hUsbDeviceHS, vnd_event_tx_buf, l) == USBD_OK){
        vnd_event_tail = (uint8_t)((vnd_event_tail + 1u) % VND_EVENT_QUEUE_LEN);
        if(vnd_event_count != 0u) vnd_event_count--;
        dbg_event_tx_ok++;
        dbg_event_last_tx_type = event_type;
        vnd_event_next_tx_ms = 0u;
    } else {
        vnd_tx_meta_rollback_last();
        dbg_event_tx_fail++;
        vnd_event_next_tx_ms = now_ms + 20u;
        vnd_event_inflight_type = 0xFFu;
        vnd_event_inflight_len = 0u;
        vnd_status_permit_once = 0;
        vnd_rollback_tx_start();
    }
}

/* Отправка отложенного STAT только из таска */
static void vnd_try_send_pending_status_from_task(void)
{
    /* В диагностическом режиме полностью запрещаем любые STAT по bulk-IN,
       чтобы исключить окна между A и B. Для статуса используйте EP0 (ctrl).
       Также ACK-STOP в DIAG не отправляем через bulk (см. обработчик STOP). */
    if(diag_mode_active){ return; }
    if(!pending_status) return;
    /* Нельзя отправлять STAT, если есть незавершённая передача (даже если busy временно сброшен) */
    if(vnd_ep_busy || vnd_inflight) return;
    uint16_t l = vnd_build_status((uint8_t*)status_buf, sizeof(status_buf));
    if(!l) { pending_status = 0; return; } /* (очистка дублирующего кода STAT уже выполнена выше) */
    vnd_status_permit_once = 1;
    vnd_tx_ready = 0; vnd_ep_busy = 1; vnd_last_tx_len = l; vnd_last_tx_start_ms = HAL_GetTick();
    vnd_mark_service_inflight();
    vnd_tx_meta_before((uint8_t*)status_buf, l);
    if(USBD_VND_Transmit(&hUsbDeviceHS, (uint8_t*)status_buf, l) == USBD_OK){
        VND_LOG("STAT_TX pending(task) len=%u depth=%u", l, (unsigned)vnd_tx_meta_depth());
        if(stop_request){ stop_stat_inflight = 1; }
        pending_status = 0;
    } else {
        vnd_tx_meta_rollback_last();
        VND_LOG("STAT_TX pending(task) busy/fail");
        vnd_status_permit_once = 0;
        vnd_rollback_tx_start();
    }
}

void Vendor_Status_Task(void)
{
    if(!streaming && !vnd_ep_busy && !vnd_inflight){
        vnd_try_send_pending_status_from_task();
    }
}

void Vendor_Maintenance_Task(void)
{
#ifndef VND_MAINT_ENABLE_DC_LOAD
#define VND_MAINT_ENABLE_DC_LOAD 1u
#endif
#ifndef VND_MAINT_ENABLE_DC_BACKGROUND
#define VND_MAINT_ENABLE_DC_BACKGROUND 1u
#endif
#ifndef VND_MAINT_ENABLE_DC_SAVE
#define VND_MAINT_ENABLE_DC_SAVE 1u
#endif
#if VND_MAINT_ENABLE_DC_LOAD
    vnd_dc_load_once();

    if(vnd_dc_load_request){
        vnd_dc_load_request = 0;
        vnd_dc_load_once();
    }
#endif
#if VND_MAINT_ENABLE_DC_BACKGROUND
    {
        uint16_t roi_start = win_start0;
        uint16_t roi_len   = win_len0;
        if(roi_len == 0u){
            if(win_auto){
                vnd_apply_auto_roi_window();
                roi_start = win_start0;
                roi_len = win_len0;
            } else {
                roi_start = (uint16_t)VND_ROI_BASE_START_200HZ;
                roi_len = (uint16_t)VND_ROI_LEN_DEFAULT;
            }
        }
        /* AVG_ROI owns DC only for the exact 200-sample table. For any other USB
           window, the fixed background DC process must continue independently. */
        if(!(streaming && full_mode && !diag_mode_active &&
             vnd_stream_mode == VND_STREAM_MODE_AVG_ROI &&
             roi_len == (uint16_t)VND_DC_ROI_LEN)){
            vnd_dc_background_step(roi_start, roi_len);
        }
#if VND_MAINT_ENABLE_DC_SAVE
        vnd_dc_try_save_periodic();
#endif
    }
#endif

    {
        uint32_t now_ms = HAL_GetTick();
        vnd_tx_failsafe_service(now_ms);

        if(vnd_sync_mode == VND_SYNC_MODE_MASTER){
            uint16_t hz = adc_stream_get_buf_rate();
            if(hz != 0u && hz != vnd_sync_last_hz){
                vnd_sync_set_master(hz);
            }
            vnd_sync_ok_public = 1u;
        } else if(vnd_sync_mode == VND_SYNC_MODE_SLAVE){
            uint16_t hz = vnd_sync_pending_hz;
            if(hz != 0u && (now_ms - vnd_sync_last_apply_ms) > 200u){
                vnd_sync_pending_hz = 0;
                vnd_sync_last_apply_ms = now_ms;
                if(win_auto && (vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI)){
                    uint16_t prev_start = win_start0;
                    vnd_apply_auto_roi_window();
                    if(win_start0 != prev_start){
                        vnd_avg_reset();
                        vnd_update_lcd_params();
                    }
                }
            }
            {
                extern volatile uint32_t sync_last_edge_ms;
                vnd_sync_ok_public = (uint8_t)((sync_last_edge_ms != 0u && (now_ms - sync_last_edge_ms) <= 1000u) ? 1u : 0u);
            }
        }
    }

}

/* Тик от таймера */
static volatile uint8_t vnd_tick_flag = 0;
void usb_vendor_periodic_tick(void){ vnd_tick_flag = 1; }

void vnd_request_adc_restart_from_isr(void)
{
    /* USB/sync control is not allowed to restart acquisition. A real ADC/DMA
       stall is recovered only by adc_stream_watchdog(). */
}

/*
 * ВАЖНО:
 * - В on-wire протоколе поле hdr.seq должно отражать логическую последовательность кадра,
 *   привязанную к данным DMA (а не к счётчику отправок).
 * - Хостовый GUI использует (seq & 1) как even/odd, поэтому seq НЕ должен быть пер-канальным

 *   счётчиком передачи.
 */

/* ---------------- Вспомогательные ---------------- */
static void vnd_reset_buffers(void){
    for(uint8_t p=0;p<VND_PAIR_BUFFERS;p++) for(uint8_t c=0;c<2;c++){ g_frames[p][c].st=FB_FILL; g_frames[p][c].samples=0; g_frames[p][c].flags = c?VND_FLAGS_ADC1:VND_FLAGS_ADC0; g_frames[p][c].frame_size=0; g_frames[p][c].seq=0; g_frames[p][c].dma_seq=0; g_frames[p][c].crc16=0; g_frames[p][c].crc_seq=0; memset(g_frames[p][c].buf,0xCC,sizeof(g_frames[p][c].buf)); }
    pair_fill_idx=pair_send_idx=0; sending_channel=0xFF; channel0_sent_curseq=channel1_sent_curseq=0; pending_B = 0; pending_B_since_ms = 0;
    vnd_next_frame_tx_ms = 0;
    vnd_last_tx_pace_busy = 0;
}

uint16_t vnd_build_status(uint8_t *dst, uint16_t max_len){
    uint8_t sync_master_flags = 0u;
    uint8_t optic_report_allowed = 0u;
    rs485_selected_slave_snapshot_t selected_slave;

    if(max_len < 64) return 0; /* требуется минимум v1 */
    memset(&g_status,0,sizeof(g_status));
    memset(&selected_slave, 0, sizeof(selected_slave));
    /* Сигнатура 'STAT' в первых 4 байтах */
    g_status.sig[0] = 'S';
    g_status.sig[1] = 'T';
    g_status.sig[2] = 'A';
    g_status.sig[3] = 'T';
    g_status.version = 6; /* v6: direct device IDs 0..31, 137 bytes */
    g_status.cur_samples = cur_samples_per_frame;
    g_status.frame_bytes = (uint16_t)(VND_FRAME_HDR_SIZE + cur_samples_per_frame*2u);
    g_status.test_frames = test_sent ? 1u : 0u;
    g_status.produced_seq = dbg_produced_seq;
    g_status.sent0 = dbg_sent_ch0_total;
    g_status.sent1 = dbg_sent_ch1_total;
    g_status.dbg_tx_cplt = dbg_tx_cplt;
    g_status.dbg_partial_frame_abort = dbg_partial_frame_abort;
    g_status.dbg_size_mismatch = dbg_size_mismatch;
    /* Получим DMA счётчики */
    adc_stream_debug_t d; adc_stream_get_debug(&d);
    g_status.dma_done0 = d.dma_full0;
    g_status.dma_done1 = d.dma_full1;
    g_status.frame_wr_seq = d.frame_wr_seq;
    /* Дополнение: сохранить независимые seq по каналам в резервных полях для отладки (LSW) */
    /* Используем zone_count/zone1_offset временно, НЕ нарушая сигнатуру first 4 bytes (для старого парсера останутся нулями, если не читает эти поля) */
    /* Предполагается, что хост обновит парсер позже; сейчас это поле диагностическое. */
    /* ВНИМАНИЕ: если host строго ожидает zone_count==0, можно отключить. */
    /* Формат STAT не расширяем: master optic отдаем битом flags_runtime. */
    (void)rs485_status_get_master_snapshot(NULL, NULL, &sync_master_flags);
    optic_report_allowed = vnd_optic_rpi_report_allowed();

    if(streaming) g_status.flags_runtime |= VND_STFLAG_STREAMING;
    if(diag_mode_active) g_status.flags_runtime |= VND_STFLAG_DIAG_ACTIVE;
    if(vnd_pending_init) g_status.flags_runtime |= VND_STFLAG_PENDING_INIT;
    if(vnd_stream_active) g_status.flags_runtime |= VND_STFLAG_STREAM_ACTIVE;
    if(vnd_tx_enable) g_status.flags_runtime |= VND_STFLAG_TX_ENABLED;
    if((optic_report_allowed != 0u) && optic_sensor_get_state()) {
        g_status.flags_runtime |= VND_STFLAG_OPTIC_ACTIVE;
    }
    if((optic_report_allowed != 0u) &&
       ((sync_master_flags & 0x04u) != 0u)) { /* rs485 master snapshot flag: optic active */
        g_status.flags_runtime |= VND_STFLAG_MASTER_OPTIC_ACTIVE;
    }
    if((optic_report_allowed != 0u) && optic_any_sensor_active()) {
        g_status.flags_runtime |= VND_STFLAG_GROUP_OPTIC_ACTIVE;
    }
    {
        uint8_t persisted_mode = VND_SYNC_MODE_SLAVE;
        if(rs485_role_get_local_persisted_mode(&persisted_mode) != 0u) {
            g_status.flags_runtime |= VND_STFLAG_RS485_ROLE_PERSISTED;
            if(persisted_mode == VND_SYNC_MODE_MASTER) {
                g_status.flags_runtime |= VND_STFLAG_RS485_PERSISTED_MASTER;
            }
        }
        if(rs485_node_get_conflict_mask() != 0u) {
            g_status.flags_runtime |= VND_STFLAG_RS485_ID_CONFLICT;
        }
        if(rs485_multiple_master_detected() != 0u) {
            g_status.flags_runtime |= VND_STFLAG_MULTIPLE_MASTER;
        }
    }
    rs485_role_get_selected_slave_snapshot(&selected_slave);
    if((selected_slave.flags & RS485_SELECTED_SLAVE_FLAG_VALID) != 0u) {
        g_status.flags_runtime |= VND_STFLAG_SELECTED_SLAVE_VALID;
    }
    if((selected_slave.flags & RS485_SELECTED_SLAVE_FLAG_LOCAL) != 0u) {
        g_status.flags_runtime |= VND_STFLAG_SELECTED_SLAVE_LOCAL;
    }
    {
        uint8_t selected_sensor_bits =
            (uint8_t)(selected_slave.sensor_status & 0xE0u);
        if(optic_report_allowed == 0u) {
            selected_sensor_bits &=
                (uint8_t)~VND_RPI_OPTIC_STATUS_BIT;
        }
        if(((selected_slave.flags & RS485_SELECTED_SLAVE_FLAG_FRESH) != 0u) &&
           (selected_sensor_bits != 0u)) {
            g_status.flags_runtime |= VND_STFLAG_SELECTED_SLAVE_SENSOR;
        }
    }
    /* Новые поля диагностики */
    uint16_t f2 = 0;
    /* Бит0 = занятость IN EP: локальная (vnd_ep_busy) ИЛИ низкоуровневая (LL vnd_tx_busy) */
    {
        extern uint8_t USBD_VND_TxIsBusy(void);
        uint8_t ll_busy = USBD_VND_TxIsBusy();
        if(vnd_ep_busy || ll_busy) f2 |= 1u<<0;
    }
    if(vnd_tx_ready)         f2 |= 1u<<1;
    if(pending_B)            f2 |= 1u<<2;
    if(test_in_flight)       f2 |= 1u<<3;
    if(start_ack_done)       f2 |= 1u<<4;
    if(start_stat_inflight)  f2 |= 1u<<5;
    if(start_stat_planned)   f2 |= 1u<<6;
    if(pending_status)       f2 |= 1u<<7;
    if(simple_tx_mode)       f2 |= 1u<<8;
    if(diag_mode_active)     f2 |= 1u<<9;
    if(first_pair_done)      f2 |= 1u<<10; /* переместим ниже биты READY/SENDING */
    /* Доп. диагностика: наличие готовых кадров в g_frames[0] */
    {
        uint8_t st_slot = vnd_get_active_stream_slot(pending_B ? 1u : 0u);
        ChanFrame *fa = &g_frames[st_slot][0];
        ChanFrame *fb = &g_frames[st_slot][1];
        if (fa->st == FB_READY) f2 |= 1u<<11;
        if (fb->st == FB_READY) f2 |= 1u<<12;
        /* Новые биты: состояние SENDING для A/B чтобы различать READY и активную передачу */
        if (fa->st == FB_SENDING) f2 |= 1u<<13;
        if (fb->st == FB_SENDING) f2 |= 1u<<14;
    }
    g_status.flags2 = f2;
    g_status.sending_ch = sending_channel;
    g_status.pair_idx = (uint16_t)(((uint16_t)pair_fill_idx << 8) | pair_send_idx);
    g_status.last_tx_len = vnd_last_tx_len;
    g_status.cur_stream_seq = stream_seq;
     /* Переиспользуем резервные поля для отладки на хосте (совместимо с parser'ом):
        reserved0 = LSB dbg_prepare_calls, reserved2(low) = LSB dbg_prepare_ok,
        reserved3 = LSW frame_rd_seq (для сравнения с frame_wr_seq). */
     /* Упаковываем в reserved0: нижние 4 бита = LSB dbg_prepare_calls, старшие 4 = lastTxRC (LL) */
     do {
         extern uint8_t USBD_VND_LastTxRC(void);
         uint8_t rc = USBD_VND_LastTxRC();
         uint8_t lsb = (uint8_t)(dbg_prepare_calls & 0x0Fu);
         g_status.reserved0 = (uint8_t)((rc << 4) | lsb);
     } while(0);
      /* reserved2 переупаковка:
          низшие 4 бита = LSB dbg_prepare_ok,
          старшие 4 бита = (init_pump_attempts & 0x0F) (диагностика старта).
          Факт отправки A через pump отражаем также в flags2 бит15. */
      uint8_t prep_lsb = (uint8_t)(dbg_prepare_ok & 0x0Fu);
      uint8_t pump_att = (uint8_t)(init_pump_attempts & 0x0Fu);
      g_status.reserved2 = (uint8_t)((pump_att << 4) | prep_lsb);
    /* Оптическая телеметрия для RPI (legacy 64B view):
       reserved3[15:8] = optic_power (0..255),
       reserved3[7:2]  = optic_hold_seconds rounded up (1..63),
       reserved3[1]    = tx_enable,
       reserved3[0]    = optic_active. */
    do {
        uint8_t optic_power = optic_tx_get_power();
        uint8_t optic_hold_seconds = optic_sensor_get_hold_seconds();
        uint8_t optic_bits = (uint8_t)((optic_hold_seconds & 0x3Fu) << 2);
        if ((optic_report_allowed != 0u) && optic_sensor_get_state()) {
            optic_bits |= 0x01u;
        }
        if (vnd_tx_enable) {
            optic_bits |= 0x02u;
        }
        g_status.reserved3 = (uint16_t)(((uint16_t)optic_power << 8) | optic_bits);
    } while (0);
    /* Отразим факт успешной отправки A через init-pump в flags2 бит15 ("A_fill READY" ранее не использовался) */
    if(init_pump_a_sent){ g_status.flags2 |= (uint16_t)(1u<<15); }
    /* v2 расширение: заполняем метки стадий (если доступны) */
    g_status.stage_alt1_ms = vnd_stage_alt1_ms;
    g_status.stage_start_ms = start_cmd_ms;
    g_status.stage_first_frame_ms = vnd_stage_first_frame_ms;
    
    /* v3 расширение: ДИАГНОСТИКА счётчиков нулевых буферов ADC */
    g_status.ch_zero_buffers_A = d.ch_zero_buffers[0];
    g_status.ch_zero_buffers_B = d.ch_zero_buffers[1];
    /* v4 расширение: текущий tick и метки последнего полного DMA кадра по каналам */
    do {
        uint32_t now_ms = HAL_GetTick();
        extern volatile uint32_t adc_last_full0_ms;
        extern volatile uint32_t adc_last_full1_ms;
        g_status.now_ms = now_ms;
        g_status.last_full0_ms = adc_last_full0_ms;
        g_status.last_full1_ms = adc_last_full1_ms;
        uint32_t host_rx_ack_age_ms = 0u;
        if (streaming &&
            vnd_tick_age_ms(now_ms, vnd_last_host_rx_ack_ms, &host_rx_ack_age_ms) &&
            host_rx_ack_age_ms <= VND_HOST_RX_ACK_TIMEOUT_MS) {
            g_status.flags_runtime |= VND_STFLAG_HOST_RX_ALIVE;
        }
        vnd_usb_in_request_drop_recovery_from_status(now_ms);
    } while(0);
    /* v5 extension: RPI-facing sync and dynamic LED state */
    do {
        g_status.optic_hold_ds = optic_sensor_get_hold_deciseconds();
        g_status.led_pattern = dynamic_led_get_pattern();
        (void)rs485_status_get_snapshot(&g_status.sync_local_status,
                                        &g_status.sync_node_count,
                                        &g_status.sync_seen_mask,
                                        g_status.sync_status_bytes,
                                        (uint8_t)sizeof(g_status.sync_status_bytes));
        if(optic_report_allowed == 0u) {
            g_status.sync_local_status &=
                (uint8_t)~VND_RPI_OPTIC_STATUS_BIT;
            for(uint8_t device_id = 0u;
                device_id < (uint8_t)sizeof(g_status.sync_status_bytes);
                device_id++) {
                g_status.sync_status_bytes[device_id] &=
                    (uint8_t)~VND_RPI_OPTIC_STATUS_BIT;
            }
        }
    } while(0);
     /* Хак: инкремент dbg_skipped_frames отображаем в sent0/sent1 дельтах, но здесь добавим только
        косвенную диагностику: если skips растут, host увидит разницу produced_seq - sent*. Дополнительно
        можно временно печатать в CDC при отладке (сейчас лог выключен для скорости). */
    /* Output length is schema-aligned for old hosts: 64B(v1), 96B(v4),
       136B(v5 prefix), or 137B(v6). */
    if(max_len < 96u){
        g_status.version = 1;
        memcpy(dst, &g_status, 64);
        return 64;
    }
    if(max_len < 136u){
        g_status.version = 4;
        memcpy(dst, &g_status, 96);
        return 96;
    }
    if(max_len < (uint16_t)sizeof(g_status)){
        vnd_status_v1_t legacy_status = g_status;

        /* Preserve the real v5 wire layout for existing RPI software:
           bit/index 0 means device 1, ... bit/index 30 means device 31.
           Device 0 is representable only by the 137-byte v6 layout. */
        legacy_status.version = 5;
        legacy_status.sync_seen_mask = 0u;
        legacy_status.sync_node_count = 0u;
        memset(legacy_status.sync_status_bytes, 0,
               sizeof(legacy_status.sync_status_bytes));
        for(uint8_t device_id = 1u; device_id < 32u; device_id++){
            uint32_t direct_bit = (1u << device_id);
            if((g_status.sync_seen_mask & direct_bit) != 0u){
                uint8_t legacy_index = (uint8_t)(device_id - 1u);
                legacy_status.sync_seen_mask |= (1u << legacy_index);
                legacy_status.sync_status_bytes[legacy_index] =
                    g_status.sync_status_bytes[device_id];
                legacy_status.sync_node_count++;
            }
        }
        memcpy(dst, &legacy_status, 136u);
        return 136u;
    }
    memcpy(dst,&g_status,sizeof(g_status));
    return (uint16_t)sizeof(g_status);
}

uint16_t vnd_build_lcd_status(uint8_t *dst, uint16_t max_len)
{
    vnd_lcd_status_v1_t st;
    vnd_lcd_sync_snapshot_t snap;

    if ((dst == NULL) || (max_len < (uint16_t)sizeof(st))) {
        return 0u;
    }

    memset(&st, 0, sizeof(st));
    memset(&snap, 0, sizeof(snap));
    vnd_get_lcd_sync_snapshot(&snap);

    st.sig[0] = 'L';
    st.sig[1] = 'C';
    st.sig[2] = 'D';
    st.sig[3] = 'S';
    st.version = 1u;
    st.raw_mode = snap.raw_mode;
    st.display_mode = snap.display_mode;
    st.display_value = snap.display_value;
    st.slave_count = snap.slave_count;
    st.node_id = snap.node_id;
    st.display_color_id = snap.display_color_id;
    st.display_char = snap.display_char;
    st.display_rgb565 = snap.display_rgb565;
    st.sync_age_ms = snap.sync_age_ms;

    if (vnd_lcd_role_overlay_active != 0u) {
        st.display_mode = snap.raw_mode;
        if (snap.raw_mode == VND_SYNC_MODE_SLAVE) {
            st.display_char = (uint8_t)'S';
            st.display_value = (uint8_t)(snap.node_id & 0x1Fu);
        } else if (snap.raw_mode == VND_SYNC_MODE_MASTER) {
            st.display_char = (uint8_t)'M';
            st.display_value = (uint8_t)(snap.node_id & 0x1Fu);
        } else {
            st.display_char = (uint8_t)'O';
            st.display_value = 0u;
        }
    }

    if (snap.sync_signal_alive != 0u) {
        st.flags |= VND_LCD_SYNC_FLAG_SIGNAL_ALIVE;
    }
    if (snap.sync_ok_visual != 0u) {
        st.flags |= VND_LCD_SYNC_FLAG_SYNC_OK_VISUAL;
    }
    if (snap.sync_color_locked != 0u) {
        st.flags |= VND_LCD_SYNC_FLAG_COLOR_LOCKED;
    }
    if (snap.sync_signal_alive == 0u) {
        st.flags |= VND_LCD_SYNC_FLAG_DISPLAY_FALLBACK;
    }
    if (vnd_sync_is_mode_host_forced() != 0u) {
        st.flags |= VND_LCD_SYNC_FLAG_HOST_FORCED;
    }
    if (vnd_lcd_role_overlay_enabled != 0u) {
        st.flags |= VND_LCD_SYNC_FLAG_ROLE_OVERLAY_EN;
    }
    if (vnd_lcd_role_overlay_active != 0u) {
        st.flags |= VND_LCD_SYNC_FLAG_ROLE_OVERLAY_ACT;
        st.display_rgb565 = vnd_lcd_role_overlay_rgb565;
        st.display_color_id = vnd_lcd_role_overlay_color_id;
    }
    {
        uint8_t persisted_mode = VND_SYNC_MODE_SLAVE;
        if (rs485_role_get_local_persisted_mode(&persisted_mode) != 0u) {
            st.flags |= VND_LCD_SYNC_FLAG_ROLE_PERSISTED;
            if (persisted_mode == VND_SYNC_MODE_MASTER) {
                st.flags |= VND_LCD_SYNC_FLAG_PERSISTED_MASTER;
            }
        }
        if (rs485_node_local_id_conflict() != 0u) {
            st.flags |= VND_LCD_SYNC_FLAG_NODE_ID_CONFLICT;
        }
        if (rs485_multiple_master_detected() != 0u) {
            st.flags |= VND_LCD_SYNC_FLAG_MULTIPLE_MASTER;
        }
        if (snap.node_id_assigned != 0u) {
            st.flags |= VND_LCD_SYNC_FLAG_DEVICE_ID_ASSIGNED;
        }
    }

    st.text[0] = (char)st.display_char;
    if (((st.display_mode == VND_SYNC_MODE_SLAVE) ||
         (st.display_mode == VND_SYNC_MODE_MASTER)) &&
        (snap.node_id_assigned == 0u)) {
        st.text[1] = '-';
        st.text[2] = '-';
    } else if (st.display_mode == VND_SYNC_MODE_OFF) {
        st.text[1] = ' ';
        st.text[2] = ' ';
    } else {
        st.text[1] = (char)('0' + ((st.display_value / 10u) % 10u));
        st.text[2] = (char)('0' + (st.display_value % 10u));
    }
    st.text[3] = '\0';

    memcpy(dst, &st, sizeof(st));
    return (uint16_t)sizeof(st);
}

uint16_t vnd_build_dc_config(uint8_t *dst, uint16_t max_len)
{
    vnd_dc_config_v2_t st;
    if ((dst == NULL) || (max_len < (uint16_t)sizeof(st))) {
        return 0u;
    }

    memset(&st, 0, sizeof(st));
    st.sig[0] = 'D';
    st.sig[1] = 'C';
    st.sig[2] = 'C';
    st.sig[3] = 'F';
    st.version = 2u;
    st.enabled = (vnd_dc_speed_settle_ms != 0u) ? 1u : 0u;
    if(vnd_dc_dirty_public) st.flags |= VND_DC_STATUS_FLAG_DIRTY;
    st.settle_ms = vnd_dc_speed_settle_ms;
    st.set_at_ms = vnd_dc_speed_set_at_ms;
    st.adapt_updates = vnd_dc_adapt_updates;

    memcpy(dst, &st, sizeof(st));
    return (uint16_t)sizeof(st);
}

uint16_t vnd_build_rs485_ident(uint8_t node_id, uint8_t *dst, uint16_t max_len)
{
    vnd_rs485_ident_v1_t st;
    rs485_identity_snapshot_t snap;

    if ((dst == NULL) || (max_len < (uint16_t)sizeof(st))) {
        return 0u;
    }

    memset(&st, 0, sizeof(st));
    memset(&snap, 0, sizeof(snap));
    st.sig[0] = 'R';
    st.sig[1] = 'I';
    st.sig[2] = 'D';
    st.sig[3] = '1';
    st.version = 1u;

    if (rs485_identity_get_snapshot(node_id, &snap) != 0u) {
        st.node_id = snap.node_id;
        st.flags = snap.flags;
        memcpy(st.short_id, snap.short_id, sizeof(st.short_id));
        memcpy(st.ip4, snap.ip4, sizeof(st.ip4));
        st.seen_page_mask = snap.seen_page_mask;
        st.last_ms = snap.last_ms;
        st.rpi_number = snap.rpi_number;
    } else {
        memset(st.short_id, '?', 9u);
        st.short_id[9] = '\0';
    }

    memcpy(dst, &st, sizeof(st));
    return (uint16_t)sizeof(st);
}

uint16_t vnd_build_rs485_sensor(uint8_t device_id,
                                uint8_t *dst,
                                uint16_t max_len)
{
    vnd_rs485_sensor_v1_t st;
    rs485_sensor_snapshot_t snap;

    if ((dst == NULL) || (max_len < (uint16_t)sizeof(st))) {
        return 0u;
    }

    memset(&st, 0, sizeof(st));
    memset(&snap, 0, sizeof(snap));
    st.sig[0] = 'S';
    st.sig[1] = 'N';
    st.sig[2] = 'S';
    st.sig[3] = '1';
    st.version = 1u;
    if (rs485_sensor_get_snapshot(device_id, &snap) != 0u) {
        st.device_id = snap.device_id;
        st.flags = snap.flags;
        st.sensor_bits = snap.sensor_bits;
        st.last_changed_index = snap.last_changed_index;
        st.last_change_ms = snap.last_change_ms;
    }

    memcpy(dst, &st, sizeof(st));
    return (uint16_t)sizeof(st);
}

uint16_t vnd_build_sync_diag(uint8_t *dst, uint16_t max_len)
{
    rs485_sync_diag_snapshot_t source;
    vnd_sync_diag_v1_t diag;

    if((dst == NULL) || (max_len < (uint16_t)sizeof(diag))) {
        return 0u;
    }

    memset(&source, 0, sizeof(source));
    memset(&diag, 0, sizeof(diag));
    rs485_sync_get_diag_snapshot(&source);

    memcpy(diag.sig, "SYN1", 4u);
    diag.version = 1u;
    diag.wire_mode = source.wire_mode;
    diag.sync_role = source.sync_role;
    diag.phase_relation = source.phase_relation;
    diag.node_id = source.node_id;
    diag.node_count = source.node_count;
    diag.boot_id = source.boot_id;
    diag.transport_epoch = source.transport_epoch;
    diag.lease_remaining_ms = source.lease_remaining_ms;
    diag.sync_age_ms = source.sync_age_ms;
    diag.sync_edge_count = source.sync_edge_count;
    diag.buffer_count = source.buffer_count;
    diag.active_samples = source.active_samples;
    diag.buffer_rate_hz = source.buffer_rate_hz;
    diag.phase_error_ticks = source.phase_error_ticks;
    diag.control_error_ticks = source.control_error_ticks;
    diag.sync_period_ticks = source.sync_period_ticks;
    diag.tim5_tick_hz = source.tim5_tick_hz;
    diag.uart_error_count = source.uart_error_count;
    diag.sync_rejected_early_count = source.sync_rejected_early_count;
    diag.sync_tx_deferred_count = source.sync_tx_deferred_count;
    diag.sync_tx_coalesced_count = source.sync_tx_coalesced_count;
    diag.sync_tx_delay_max_ticks = source.sync_tx_delay_max_ticks;
    diag.wire_fallback_count = source.wire_fallback_count;
    diag.last_fallback_reason = source.last_fallback_reason;
    diag.regular_reply_divisor = source.regular_reply_divisor;

    if(source.lease_remaining_ms != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_LEASE_ACTIVE;
    }
    if(source.signal_alive != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_SIGNAL_ALIVE;
    }
    if(source.phase_locked != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_PHASE_LOCKED;
    }
    if(source.phase_relation == 1u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_IN_PHASE;
    }
    if(source.node_id_assigned != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_NODE_ASSIGNED;
    }
    if(rs485_node_local_id_conflict() != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_ID_CONFLICT;
    }
    if(rs485_multiple_master_detected() != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_MULTIPLE_MASTER;
    }
    if(streaming != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_STREAMING;
    }
    if(source.sync_tx_pending != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_SYNC_TX_PENDING;
    }
    if(source.wire_mode != RS485_WIRE_MODE_FULL) {
        diag.flags |= VND_SYNC_DIAG_FLAG_REDUCED_WIRE;
    }
    if(source.wire_transition_pending != 0u) {
        diag.flags |= VND_SYNC_DIAG_FLAG_WIRE_TRANSITION;
    }

    memcpy(dst, &diag, sizeof(diag));
    return (uint16_t)sizeof(diag);
}

uint16_t vnd_build_tx_phase(uint8_t *dst, uint16_t max_len)
{
    if(dst == NULL || max_len < VND_TX_PHASE_STATUS_SIZE) return 0u;
    memset(dst, 0, VND_TX_PHASE_STATUS_SIZE);
    memcpy(dst, "TXP1", 4u);
    dst[4] = 1u;

    /* Snapshot requested/applied phases and pins at the same boundary. */
    uint8_t requested, applied;
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    adc_stream_get_tx_phase_masks(&requested, &applied);
    dst[5] = requested & 1u;
    dst[6] = (requested >> 1) & 1u;
    dst[7] = applied & 1u;
    dst[8] = (applied >> 1) & 1u;
    dst[9] = (uint8_t)((vnd_tx_requested_enable ? 1u : 0u) |
                       (vnd_tx_enable ? 2u : 0u) |
                       (streaming ? 4u : 0u) |
                       (requested != applied ? 8u : 0u));
    dst[10] = adc_stream_get_marker_level();
    uint32_t pa_levels = GPIOA->IDR;
    dst[11] = (pa_levels & GPIO_PIN_1) ? 1u : 0u;
    dst[12] = (pa_levels & GPIO_PIN_2) ? 1u : 0u;
    dst[13] = (GPIOC->IDR & GPIO_PIN_7) ? 1u : 0u;
    __set_PRIMASK(primask);
    return VND_TX_PHASE_STATUS_SIZE;
}

uint16_t vnd_build_relay_status(uint8_t *dst, uint16_t max_len)
{
    if(dst == NULL || max_len < VND_RELAY_STATUS_SIZE) return 0u;
    relay_snapshot_t state;
    relay_get_snapshot(&state);
    memset(dst, 0, VND_RELAY_STATUS_SIZE);
    memcpy(dst, "RLY1", 4u);
    dst[4] = 1u;
    dst[5] = state.enabled;
    dst[6] = state.active;
    dst[7] = state.pin;
    dst[8] = state.mode;
    for (uint8_t i = 0u; i < 4u; ++i) {
        dst[12u + i] = (uint8_t)(state.remaining_ms >> (8u * i));
        dst[16u + i] = (uint8_t)(RELAY_MAX_DURATION_MS >> (8u * i));
    }
    return VND_RELAY_STATUS_SIZE;
}

uint8_t vnd_is_streaming(void){ return streaming; }
uint8_t vnd_is_tx_enabled(void){ return vnd_tx_enable; }
uint8_t vnd_is_tx_requested_enabled(void){ return vnd_tx_requested_enable; }
uint32_t vnd_get_tx_host_cmd_count(void){ return vnd_tx_host_cmd_count; }
uint32_t vnd_get_tx_host_cmd_last_ms(void){ return vnd_tx_host_cmd_last_ms; }
uint8_t vnd_get_tx_host_cmd_last_value(void){ return vnd_tx_host_cmd_last_value; }
uint32_t vnd_get_tx_effective_change_count(void){ return vnd_tx_effective_change_count; }
uint32_t vnd_get_tx_effective_off_count(void){ return vnd_tx_effective_off_count; }
uint32_t vnd_get_tx_effective_last_change_ms(void){ return vnd_tx_effective_last_change_ms; }
uint8_t vnd_get_tx_effective_last_value(void){ return vnd_tx_effective_last_value; }
uint8_t vnd_set_tx_enabled(uint8_t enable)
{
    return vnd_tx_set_enabled_internal(enable, "manual");
}

static void vnd_apply_tx_enable_outputs(void)
{
    /* Reapply common enable with the already latched per-channel phases. */
    adc_stream_refresh_marker_output();
}

static uint8_t vnd_tx_set_enabled_internal(uint8_t enable, const char *reason)
{
    vnd_tx_requested_enable = (enable != 0u) ? 1u : 0u;
    return vnd_tx_refresh_effective(HAL_GetTick(), reason);
}

static uint8_t vnd_tx_refresh_effective(uint32_t now_ms, const char *reason)
{
    /* TX200 is allowed only while both conditions remain true:
       1) the oscilloscope/RPI explicitly requested TX;
       2) the USB stream is logically running.
       Do not gate TX from the short HOST_RX_ACK heartbeat: a transient USB
       scheduling delay must never create a missing TX pulse. */
    uint8_t next = (uint8_t)((vnd_tx_requested_enable != 0u) &&
                             (streaming != 0u));
    if(vnd_tx_enable != next){
        if(next == 0u){
            vnd_tx_effective_off_count++;
        }
        vnd_tx_effective_change_count++;
        vnd_tx_effective_last_change_ms = now_ms;
        vnd_tx_effective_last_value = next;
        vnd_tx_enable = next;
        vnd_apply_tx_enable_outputs();
        cdc_logf("EVT TX_ENABLE=%u req=%u reason=%s",
                 (unsigned)next,
                 (unsigned)vnd_tx_requested_enable,
                 reason ? reason : "?");
    }
    return vnd_tx_enable;
}

/* функция vnd_generate_test_sawtooth() реализована в vnd_testgen.c */

static void vnd_prepare_pair(void)
{
    uint32_t t_start = get_us_approx(); /* Начало измерения */

    dbg_prepare_calls++;
    /* ВАЖНО: полный режим (non-async) отправляет/закрывает пары по pair_send_idx.
       Чтобы не зависать, готовим пару именно в том слоте, который будет отправляться следующим.
       Иначе можно заполнить другой слот и затем бесконечно ждать READY в pair_send_idx. */
    uint8_t active_slot = pair_send_idx;
    if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
        /* В строгих режимах не готовим пары "вперёд" в других слотах.
           Иначе при оборачивании кольца можно накопить READY-кадры вне pair_send_idx
           и получить зависание/перестановку A/B. */
        if(g_frames[active_slot][0].st != FB_FILL || g_frames[active_slot][1].st != FB_FILL){
            return;
        }
    } else {
        for(uint8_t i=0;i<VND_PAIR_BUFFERS;i++){
            uint8_t s = (uint8_t)((pair_send_idx + i) % VND_PAIR_BUFFERS);
            if(g_frames[s][0].st == FB_FILL && g_frames[s][1].st == FB_FILL){ active_slot = s; break; }
        }
    }
    
    /* Убран подробный лог PREPARE_PAIR — счётчики агрегируются в периодическую статистику */
    uint16_t *ch1 = NULL, *ch2 = NULL; uint16_t samples = 0;
    (void)ch1; (void)ch2; /* могут быть неиспользованы в режиме overlay */
    uint16_t crc_a = 0; uint32_t crc_seq = 0;
    uint32_t pair_seq = 0;
    uint8_t used_avg_q = 0;
    uint8_t used_avg_q_idx = 0;
    uint32_t used_avg_ts_ms = 0;
    /* Локальный снапшот staging-буфера, чтобы TC не перезаписал usb_stage_bufA во время копирования */
    static __attribute__((unused)) uint16_t stage_copy[MAX_FRAME_SAMPLES];
    static uint16_t lossless_dc_copy_a[VND_DC_ROI_LEN];
    static uint16_t lossless_dc_copy_b[VND_DC_ROI_LEN];
    uint16_t stage_samples = 0;
    (void)stage_samples; /* может быть неиспользован при ADC_USB_STAGE_ENABLE=0 */
    
#if USE_TEST_SAWTOOTH
    /* Тестовый режим: используем последнюю сгенерированную пару буферов */
    {
        /* Генерируем свежий буфер-пилу (1..N) перед выборкой */
        vnd_generate_test_sawtooth();
        uint16_t *tb0 = NULL, *tb1 = NULL; uint16_t avail = 0;
        if(!vnd_testgen_try_consume_latest(&tb0, &tb1, &avail)){
            return; /* нет новых данных */
        }
        ch1 = tb0; ch2 = tb1;
        samples = (avail != 0) ? avail : 302;  /* МАРКЕР #2 - fallback если avail=0 */
        (void)ch1; (void)ch2; /* используем в тестовом режиме, чтобы подавить предупреждения */
        (void)stage_samples; (void)seq; (void)static_mode; (void)static_seq;
        static uint32_t test_seq = 0; pair_seq = ++test_seq;
        /* Зафиксировать размер кадра, если ещё не задан, чтобы отправка не зависела от профиля АЦП */
        if(cur_samples_per_frame == 0){
            uint16_t eff = samples;
            if(eff > VND_MAX_SAMPLES) eff = VND_MAX_SAMPLES;
            cur_samples_per_frame = eff;
            cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)eff * 2u);
        }
    }
#else
        /* Два режима:
             0) LATEST (как сейчас): "последний заполненный буфер", пропуски допустимы.
                 1) LOSSLESS_ROI: строго по FIFO (без пропусков на стороне прошивки), но отправляем только окно ROI.
                         Окно задаётся win_start0/win_len0; по умолчанию 280..480 (200) и сдвигается по частоте. */
    if (vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI)
    {
        /* ROI окно */
        uint16_t roi_start = win_start0;
        uint16_t roi_len   = win_len0;
        if(roi_len == 0u){
            roi_len = VND_ROI_LEN_DEFAULT;
            if(win_auto){
                vnd_apply_auto_roi_window();
                roi_start = win_start0;
            } else {
                roi_start = 0u;
            }
        }
        if(roi_len > VND_MAX_SAMPLES) roi_len = VND_MAX_SAMPLES;
        if(roi_len > MAX_FRAME_SAMPLES) roi_len = MAX_FRAME_SAMPLES;

        if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI)
        {
            /* Берём следующий кадр строго по очереди (A+B синхронно по DMA seq) */
            if(!adc_peek_frame_pair_fifo(&ch1, &ch2, &samples, &pair_seq)){
                return;
            }
            if(samples < (uint16_t)(roi_start + roi_len)){
                /* Профиль/размер кадра не подходит под ROI — ждём корректного кадра */
                (void)adc_consume_frame_pair_fifo(pair_seq);
                return;
            }
            /* Лочим формат кадра на ROI длину */
            if(cur_samples_per_frame != roi_len){
                cur_samples_per_frame = roi_len;
                cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)cur_samples_per_frame * 2u);
            }
            /* Смещаем указатели на начало ROI. Для 200-sample ROI применяем DC к локальной
               копии, чтобы USB payload был скорректирован, но FIFO/DMA raw буферы не менялись. */
            if(roi_len == (uint16_t)VND_DC_ROI_LEN){
                uint8_t parity = (uint8_t)(adc_get_buffer_parity(pair_seq) & 1u);
                vnd_dc_load_once();
                vnd_dc_ensure_parity_mapping(ch1, ch2, samples, roi_start, roi_len, parity);
                memcpy(lossless_dc_copy_a, ch1 + roi_start, (size_t)roi_len * sizeof(uint16_t));
                memcpy(lossless_dc_copy_b, ch2 + roi_start, (size_t)roi_len * sizeof(uint16_t));
                vnd_dc_apply_only(0, parity, lossless_dc_copy_a, roi_len);
                vnd_dc_apply_only(1, parity, lossless_dc_copy_b, roi_len);
                ch1 = lossless_dc_copy_a;
                ch2 = lossless_dc_copy_b;
            } else {
                ch1 = ch1 + roi_start;
                ch2 = ch2 + roi_start;
            }
            /* В ROI режиме не используем precomputed CRC из staging (оно было для полного кадра). */
            crc_a = 0; crc_seq = 0;
            samples = cur_samples_per_frame;
        }
        else
        {
            /* stream_mode=2: выдаём только готовые усреднённые ROI кадры из очереди.
               Сбор/усреднение идёт в фоне через vnd_avg_drain_fifo(), чтобы не терять входные кадры. */
            if(vnd_avg_q_count == 0){
                return;
            }
            used_avg_q = 1;
            used_avg_q_idx = vnd_avg_q_head;

            /* Инициализируем формат кадра по ROI длине */
            if(cur_samples_per_frame != roi_len){
                cur_samples_per_frame = roi_len;
                cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)cur_samples_per_frame * 2u);
            }

            /* seq в заголовке делаем непрерывным (по stream_seq), а dma_seq кладём в reserved */
            pair_seq = stream_seq;
            used_avg_ts_ms = vnd_avg_q_ts_ms[used_avg_q_idx];
            crc_seq = vnd_avg_q_dma_seq[used_avg_q_idx]; /* временно переносим out_dma_seq */

            /* Указатели на усреднённые данные */
            ch1 = vnd_avg_q_out[used_avg_q_idx][0];
            ch2 = vnd_avg_q_out[used_avg_q_idx][1];
            samples = roi_len;
            crc_a = 0;
        }
    }
    else
    {
        /* ПОЛИТИКА last-buffer-wins: выбираем САМЫЙ ПОСЛЕДНИЙ полный кадр и пропускаем старые.
            Это повышает визуальную частоту при ограниченной пропускной способности USB. */
        // Читаем s_next_ring_index и отслеживаем изменения
        extern volatile uint32_t s_next_ring_index;
        static uint32_t last_current = 0xFFFFFFFF;
        static uint32_t local_seq = 0;
        
        __disable_irq();
        uint32_t current = s_next_ring_index;
        __enable_irq();
        
        // Отправляем данные ТОЛЬКО когда s_next_ring_index изменился
        if (current != last_current) {
            last_current = current;
            local_seq++;  // Инкрементируем счётчик кадров
        } else {
            return;  // Нет новых данных - пропускаем
        }
        
        // Вычисляем индекс последнего заполненного буфера
        uint32_t idx = (current + FIFO_FRAMES - 1) & (FIFO_FRAMES - 1);
        
        if (idx >= FIFO_FRAMES) return;
        
        pair_seq = local_seq;
        #if ADC_USB_STAGE_ENABLE
        __disable_irq();
        stage_samples = adc_stream_get_active_samples();
        if(stage_samples > MAX_FRAME_SAMPLES) stage_samples = MAX_FRAME_SAMPLES;
        memcpy(stage_copy, usb_stage_bufA, stage_samples * sizeof(uint16_t));
        crc_a = adc_stage_crc_a; crc_seq = adc_stage_crc_seq;
        __enable_irq();
        ch1 = stage_copy;
        #else
        // D-cache отключен глобально - можем читать напрямую
        ch1 = adc1_buffers[idx];
        #endif
        ch2 = adc2_buffers[idx];
        /* Используем актуальное значение семплов активного профиля */
        samples = adc_stream_get_active_samples();
    }
#endif
    if(samples == 0){
        /* Нет новых данных от АЦП — ничего не отправляем */
        return;
    }
    /* Выбор целевого размера кадра: профиль ADC с учётом ограничений от хоста */
    uint16_t profile_ns = adc_stream_get_active_samples();
    uint16_t target_ns = profile_ns;
    if(vnd_frame_samples_req && vnd_frame_samples_req < target_ns) target_ns = vnd_frame_samples_req;
    if(vnd_trunc_samples && vnd_trunc_samples < target_ns) target_ns = vnd_trunc_samples;
    if(target_ns > VND_MAX_SAMPLES) target_ns = VND_MAX_SAMPLES;
    /* Фиксируем формат только на target_ns. Никогда не локаемся на меньшем значении. */
    if(cur_samples_per_frame == 0){
        /* Если данных текущего кадра меньше чем target_ns, подождём следующую итерацию. */
        if(samples < target_ns){
            VND_LOG("WAIT_FULL: have=%u need=%u (profile=%u)", samples, target_ns, profile_ns);
            return;
        }
        cur_samples_per_frame = target_ns;
        cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)cur_samples_per_frame * 2u);
        VND_LOG("SIZE_LOCK %u (raw=%u req=%u trunc=%u)", cur_samples_per_frame, samples, vnd_frame_samples_req, vnd_trunc_samples);
        cdc_logf("SIZE_LOCK raw=%u req=%u trunc=%u -> lock=%u", samples, vnd_frame_samples_req, vnd_trunc_samples, cur_samples_per_frame);
    }
    /* После фиксации не отправляем неполные кадры */
    if(samples < cur_samples_per_frame){
        VND_LOG("SKIP_PARTIAL: have=%u locked=%u", samples, cur_samples_per_frame);
        dbg_partial_frame_abort++;
        return;
    }
    ChanFrame *f0 = &g_frames[active_slot][0];
    ChanFrame *f1 = &g_frames[active_slot][1];
    /* Если пара уже подготовлена (оба READY или SENDING), не переписываем */
    if((f0->st == FB_READY || f0->st == FB_SENDING) && (f1->st == FB_READY || f1->st == FB_SENDING)) return;
    /* Сбросим оба кадра в начальное состояние для заполнения */
    memset(f0->buf, 0, sizeof(f0->buf)); memset(f1->buf, 0, sizeof(f1->buf));
    f0->crc16 = f1->crc16 = 0; f0->crc_seq = f1->crc_seq = 0;
    if(crc_a){ f0->crc16 = crc_a; f0->crc_seq = crc_seq; }
    uint32_t pair_timestamp = HAL_GetTick();
    if(vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
          /* В режиме усреднения crc_seq временно хранит out_dma_seq.
              timestamp берём из очереди готового результата (used_avg_ts_ms), если доступен. */
          if(used_avg_ts_ms != 0){ pair_timestamp = used_avg_ts_ms; }
    }
    /* подробный лог пары убран для снижения нагрузки */
    /* Применяем усечение, если задано и меньше доступного */
    uint16_t use_samples = cur_samples_per_frame; /* уже определено и проверено */
    uint16_t stamp_idx = 0, stamp_seq16 = 0; /* диагностические метки в payload */
    (void)stamp_idx; (void)stamp_seq16;

    /* В режиме AVG_ROI (stream_mode=2) DC уже применяется внутри vnd_avg_drain_fifo() перед постановкой в очередь.
       Здесь используем данные как есть, чтобы избежать двойного вычитания DC. */
    const uint16_t *src_a = ch1;
    const uint16_t *src_b = ch2;

    for(uint16_t i = 0; i < use_samples; i++){
#if USE_TEST_SAWTOOTH
        /* Полный тестовый режим (путь был основной ранее, оставлен для совместимости). */
        uint16_t a = (uint16_t)(i + 1);
        uint16_t b = (uint16_t)(i + 1);
#else
    #if TEST_OVERLAY_SAWTOOTH
        /* Мягкая подмена: сохраняем ADC/DMA и async, но данные делаем детерминированной пилой. */
        uint16_t a = (uint16_t)(i + 1);
        uint16_t b = (uint16_t)(i + 1);
    #else
        uint16_t a = src_a[i];
        uint16_t b = src_b[i];
    #endif
#endif
        uint8_t *p0 = f0->buf + VND_FRAME_HDR_SIZE + 2 * i; p0[0] = (uint8_t)(a & 0xFF); p0[1] = (uint8_t)(a >> 8);
        uint8_t *p1 = f1->buf + VND_FRAME_HDR_SIZE + 2 * i; p1[0] = (uint8_t)(b & 0xFF); p1[1] = (uint8_t)(b >> 8);
    }
    f0->samples = f1->samples = use_samples; 
    /* Сохраняем индекс DMA (seq/rd) для привязки отображения на хосте.
       В stream_mode=2 header.seq идёт как stream_seq, а dma_seq берём из последнего кадра группы (передан через crc_seq). */
    if(vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
        uint32_t out_dma_seq = crc_seq;
        f0->dma_seq = f1->dma_seq = out_dma_seq;
        /* crc_seq больше не нужен как временный канал */
        crc_seq = 0;
    } else {
        f0->dma_seq = f1->dma_seq = pair_seq;
    }
    /* CRC финализируется ниже после окончательного заполнения заголовков. */
    f0->crc16 = f1->crc16 = 0u;
    f0->crc_seq = f1->crc_seq = 0u;
    /* seq в заголовке привязан к последовательности DMA (pair_seq), одинаковый для A и B */
    f0->seq = pair_seq;
    f1->seq = pair_seq;
    vnd_frame_hdr_t *h0 = (vnd_frame_hdr_t*)f0->buf; h0->timestamp = pair_timestamp;
    vnd_frame_hdr_t *h1 = (vnd_frame_hdr_t*)f1->buf; h1->timestamp = pair_timestamp;
    vnd_build_frame(f0); vnd_build_frame(f1);

     /* ВАЖНО: reserved2 на хосте используется как buffer_index (0-7).
         Для AVG_ROI нельзя вычислять это значение позже по dma_seq (кольцевой s_buffer_parity перезаписывается),
         поэтому берём сохранённую метку из очереди. */
     uint16_t buf_idx = 0;
     if(used_avg_q){
         buf_idx = (uint16_t)(vnd_avg_q_bufidx[used_avg_q_idx] & 0x07u);
     } else {
         buf_idx = (uint16_t)(adc_get_buffer_parity(f0->dma_seq) & 0x07u);
     }
     h0->reserved2 = buf_idx;
     h1->reserved2 = buf_idx;
    vnd_frame_finalize_crc(f0->buf);
    vnd_frame_finalize_crc(f1->buf);
    f0->crc16 = h0->crc16;
    f1->crc16 = h1->crc16;
    f0->crc_seq = f1->crc_seq = pair_seq;
    if(f0->st == FB_FILL || f1->st == FB_FILL){ dbg_partial_frame_abort++; VND_LOG("build failed"); return; }

    /* Для stream_mode=2: только после успешной подготовки выталкиваем элемент из очереди */
    if(used_avg_q && vnd_avg_q_count){
        vnd_avg_q_head = (uint8_t)((vnd_avg_q_head + 1u) % VND_AVG_OUT_Q);
        vnd_avg_q_count--;
        dbg_avg_tx_pairs++;
    }
    /* Продвигаем индекс заполнения, если кадр успешно подготовлен */
    pair_fill_idx = (uint8_t)((active_slot + 1u) % VND_PAIR_BUFFERS);
    dbg_prepare_ok++;
    /* FPS: счётчик подготовленных пар */
    fps_prepare_count++;
    
    /* Измерение времени prepare */
    uint32_t t_end = get_us_approx();
    uint32_t duration = t_end - t_start;
    perf_stats.prepare_total_us += duration;
    perf_stats.prepare_count++;
}

static uint16_t vnd_wire_frame_len(uint16_t useful_len)
{
#if VND_USB_ROI_PAD_TO_MPS
    if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI ||
       vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
        const uint32_t unit = (uint32_t)VND_USB_ROI_PAD_BYTES;
        if(unit != 0u){
            uint32_t padded = (((uint32_t)useful_len + unit - 1u) / unit) * unit;
            if(padded > (uint32_t)useful_len && padded <= (uint32_t)VND_FRAME_MAX_SIZE){
                return (uint16_t)padded;
            }
        }
    }
#else
    (void)useful_len;
#endif
    return useful_len;
}

static void vnd_build_frame(ChanFrame *cf)
{
    if(cf->samples == 0){ cf->st = FB_FILL; return; }
    uint32_t payload_len = (uint32_t)cf->samples * 2u;
    uint32_t total = VND_FRAME_HDR_SIZE + payload_len;
    vnd_frame_hdr_t *h = (vnd_frame_hdr_t*)cf->buf;
    
    h->magic = 0xA55A;
    h->ver = 0x01;
    h->flags = (cf->flags & VND_FLAGS_ADC0) ? 0x01 : 0x02;
    h->seq = cf->seq;
    h->total_samples = (uint16_t)cf->samples;

    /* Метаданные ROI для хоста:
       - В режиме LOSSLESS_ROI передаём только окно [win_start0 : win_start0+samples)
       - total_samples = samples (обычно 200)
       - zone1_offset/zone1_length позволяют хосту рисовать ось X как 280..479, а не 0..199
    */
    if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
        h->zone_count = 1;
        h->zone1_offset = (uint32_t)win_start0;
        h->zone1_length = (uint32_t)cf->samples;
    } else {
        h->zone_count = 0;
        h->zone1_offset = 0;
        h->zone1_length = 0;
    }
    h->reserved = cf->dma_seq;
    
     /* reserved2: buffer_index (0-7) для GUI. Даже/нечёт можно получить как (buffer_index & 1). */
     h->reserved2 = (uint16_t)(adc_get_buffer_parity(cf->dma_seq) & 0x07u);
    
    h->crc16 = 0u;
    h->flags &= (uint8_t)~VND_FRAME_FLAG_CRC16;
    uint16_t useful_size = (uint16_t)total;
    uint16_t wire_size = vnd_wire_frame_len(useful_size);
    if(wire_size > useful_size){
        memset(cf->buf + useful_size, 0, (uint32_t)wire_size - useful_size);
    }
    cf->frame_size = wire_size;
    if(cur_expected_frame_size && useful_size != cur_expected_frame_size) dbg_size_mismatch++;
    dbg_any_valid_frame = 1; cf->st = FB_READY;
}

/* Поиск индекса пары по seq (линейный поиск по короткому кольцу) */
static int vnd_find_pair_by_seq(uint32_t seq)
{
    for(uint8_t i=0;i<VND_PAIR_BUFFERS;i++){
        if(g_frames[i][0].st != FB_FILL && g_frames[i][0].seq == seq) return (int)i;
        if(g_frames[i][1].st != FB_FILL && g_frames[i][1].seq == seq) return (int)i;
    }
    return -1;
}

static int vnd_find_slot_for_seq_ch(uint32_t seq, uint8_t ch)
{
    if(ch > 1u) return -1;
    for(uint8_t i = 0; i < VND_PAIR_BUFFERS; i++){
        if(g_frames[i][ch].st != FB_FILL && g_frames[i][ch].seq == seq){
            return (int)i;
        }
    }
    return -1;
}

static uint8_t vnd_get_active_stream_slot(uint8_t want_b)
{
    if(async_mode || !full_mode) return pair_send_idx;
    if(vnd_stream_mode != VND_STREAM_MODE_LOSSLESS_ROI && vnd_stream_mode != VND_STREAM_MODE_AVG_ROI){
        return pair_send_idx;
    }

    int slot = want_b ? vnd_find_slot_for_seq_ch(stream_seq, 1u)
                      : vnd_find_slot_for_seq_ch(stream_seq, 0u);
    if(slot < 0){
        slot = vnd_find_pair_by_seq(stream_seq);
    }
    return (slot >= 0) ? (uint8_t)slot : pair_send_idx;
}

static void vnd_clear_pair_slot(uint8_t slot)
{
    if(slot >= VND_PAIR_BUFFERS) return;
    g_frames[slot][0].st = FB_FILL;
    g_frames[slot][1].st = FB_FILL;
}

static void vnd_consume_strict_fifo_pair(uint8_t slot)
{
    if(slot >= VND_PAIR_BUFFERS) return;
    if(vnd_stream_mode != VND_STREAM_MODE_LOSSLESS_ROI) return;

    uint32_t dma_seq = g_frames[slot][0].dma_seq;
    if(g_frames[slot][0].st == FB_FILL && g_frames[slot][1].st != FB_FILL){
        dma_seq = g_frames[slot][1].dma_seq;
    }
    (void)adc_consume_frame_pair_fifo(dma_seq);
}

static void vnd_align_strict_pair_cursor(void)
{
    if(async_mode || !full_mode) return;
    if(vnd_stream_mode != VND_STREAM_MODE_LOSSLESS_ROI && vnd_stream_mode != VND_STREAM_MODE_AVG_ROI) return;

    int exact_slot = -1;
    for(uint8_t i = 0; i < VND_PAIR_BUFFERS; i++){
        uint8_t a_active = (g_frames[i][0].st != FB_FILL);
        uint8_t b_active = (g_frames[i][1].st != FB_FILL);
        if(!a_active && !b_active) continue;

        uint32_t seq = a_active ? g_frames[i][0].seq : g_frames[i][1].seq;
        if(seq == stream_seq){
            if(exact_slot < 0){
                exact_slot = (int)i;
            } else {
                vnd_clear_pair_slot(i);
            }
        }
    }

    if(exact_slot >= 0){
        pair_send_idx = (uint8_t)exact_slot;
        pair_fill_idx = pair_send_idx;
    }
}

static uint8_t vnd_strict_slot_ready_for_stream(uint8_t slot)
{
    if(async_mode || !full_mode) return 1u;
    if(vnd_stream_mode != VND_STREAM_MODE_LOSSLESS_ROI && vnd_stream_mode != VND_STREAM_MODE_AVG_ROI) return 1u;
    if(slot >= VND_PAIR_BUFFERS) return 0u;

    uint8_t a_active = (g_frames[slot][0].st != FB_FILL);
    uint8_t b_active = (g_frames[slot][1].st != FB_FILL);
    if(!a_active && !b_active) return 0u;

    uint32_t seq = a_active ? g_frames[slot][0].seq : g_frames[slot][1].seq;
    if(seq == stream_seq) return 1u;
    if(seq < stream_seq){
        vnd_clear_pair_slot(slot);
        if(slot == pair_send_idx){
            pair_send_idx = (uint8_t)((pair_send_idx + 1u) % VND_PAIR_BUFFERS);
            pair_fill_idx = pair_send_idx;
        }
    }
    return 0u;
}

/* Асинхронный выбор и отправка одного готового кадра (A или B) */
/* Режим строгой парности по желанию: 0 — независимые каналы, 1 — строгая пара A&B на один seq */
static uint8_t vnd_strict_pairing = 0;  /* ОТКЛЮЧЕНО: каналы независимы, отправляем как только готов */
static volatile uint8_t vnd_async_state_reset_req = 0;

static int vnd_async_try_tx(void)
{
#if USE_TEST_SAWTOOTH
    /* В тестовом режиме не используем async-путь, чтобы не ждать ADC/DMA */
    return 0;
#endif
    /* ПРОФИЛИРОВАНИЕ: замер времени выполнения */
    static uint32_t call_count = 0;
    static uint32_t total_time_us = 0;
    static uint32_t max_time_us = 0;
    static uint32_t last_profile_log = 0;
    uint32_t start_cyc = DWT->CYCCNT;
    
    /* Новый вариант async: не полагается на заранее собранную пару.
       Используем per-channel API adc_get_frame_ch() и локальные временные буферы построения кадров.
       Сохраняем on-wire формат (общий seq = stream_seq). */
    if(vnd_ep_busy) return 0;
    if(!full_mode) return 0;
    static uint8_t last_sent_ch = 1; /* чередование при наличии обоих */

    /* Глобальные счетчики текущей пары (для async строгой парности): бит0=A, бит1=B */
    static uint8_t seq_mask = 0;            /* какие каналы уже отправлены для текущего stream_seq */
    static uint32_t seq_mask_first_ms = 0;  /* время первого кадра неполной пары */
    static uint8_t seq_partial_cnt = 0;     /* сколько кадров отправлено без полной пары */

    /* Локальные статические рабочие буферы кадров для независимого построения */
    typedef struct { uint8_t valid; uint8_t ch; uint16_t samples; uint32_t seq; uint32_t dma_seq; uint16_t frame_len; uint8_t buf[VND_FRAME_MAX_SIZE]; } tmp_frame_t;
    static tmp_frame_t tf[2];

    if(vnd_async_state_reset_req){
        vnd_async_state_reset_req = 0;
        last_sent_ch = 1;
        seq_mask = 0;
        seq_mask_first_ms = 0;
        seq_partial_cnt = 0;
        tf[0].valid = 0;
        tf[1].valid = 0;
    }

    if(vnd_stream_mode != VND_STREAM_MODE_LOSSLESS_ROI &&
       vnd_ch_mode == 2 && vnd_strict_pairing && seq_mask != 0 && !vnd_ep_busy && seq_mask_first_ms != 0){
        uint32_t now_reset = HAL_GetTick();
        uint32_t partial_age = (now_reset >= seq_mask_first_ms) ? (now_reset - seq_mask_first_ms) : (0xFFFFFFFFu - seq_mask_first_ms + 1u + now_reset);
        if(partial_age > 40u){
            seq_mask = 0;
            seq_mask_first_ms = 0;
            seq_partial_cnt = 0;
            last_sent_ch = 1;
            tf[0].valid = 0;
            tf[1].valid = 0;
        }
    }

    uint16_t *roi_pair_ptr[2] = { NULL, NULL };
    uint16_t roi_pair_samples = 0;
    uint32_t roi_pair_dma_seq = 0;
    uint8_t roi_pair_valid = 0;
    if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI && vnd_ch_mode == 2 && vnd_strict_pairing &&
       !tf[0].valid && !tf[1].valid){
        if(adc_peek_frame_pair_fifo(&roi_pair_ptr[0], &roi_pair_ptr[1], &roi_pair_samples, &roi_pair_dma_seq)){
            roi_pair_valid = 1;
        }
    }

    /* Обновить / заполнить структуру для канала, если данных ещё нет (valid=0) */
    for(int ch=0; ch<2; ++ch){
        if(ch==1 && vnd_ch_mode==0) continue; /* A-only */
        if(ch==0 && vnd_ch_mode==1) continue; /* B-only */
        if(tf[ch].valid) continue; /* уже подготовлен */
        uint16_t *abuf = NULL; uint16_t samples = 0; uint32_t dma_seq = 0; uint8_t synth = 0;
        /* Снапшоты для staging, чтобы TC не перезаписал во время копирования */
        static uint16_t stage_copy_async[MAX_FRAME_SAMPLES];
        static uint16_t stage_copy_async_b[MAX_FRAME_SAMPLES];
        if(roi_pair_valid){
            abuf = roi_pair_ptr[ch];
            samples = roi_pair_samples;
            dma_seq = roi_pair_dma_seq;
            synth = 0;
        } else if(adc_get_frame_ch((uint8_t)ch, &abuf, &samples, &dma_seq)){
            synth = 0;
        } else if(TEST_OVERLAY_SAWTOOTH){
            /* Если реальный буфер временно не готов, синтезируем кадр, чтобы гарантировать 2 канала. */
            samples = adc_stream_get_active_samples();
            if(samples == 0) samples = VND_FULL_DEFAULT_SAMPLES;
            synth = 1;
        }
        if(samples){
            /* ROI: берём строго окно [win_start0 : win_start0+win_len0) из DMA-буфера */
            uint16_t roi_start = 0;
            uint16_t roi_len = 0;
            if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI){
                roi_start = win_start0;
                roi_len   = win_len0;
                if(roi_len == 0u){ roi_start = 280u; roi_len = 200u; }
                if(roi_len > VND_MAX_SAMPLES) roi_len = VND_MAX_SAMPLES;
                if(!synth){
                    /* Если профиль не подходит под ROI — не шлём «не тот» кусок */
                    if(samples < (uint16_t)(roi_start + roi_len)){
                        /* Чтобы не зависнуть (lossless peek), деградируем к отправке всего доступного буфера */
                        roi_start = 0;
                        roi_len = samples;
                    }
                }
                /* В ROI режиме формат фиксирован длиной окна */
                cur_samples_per_frame = roi_len;
                cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)roi_len * 2u);
            } else {
                if(cur_samples_per_frame == 0){
                    /* Лочим текущий формат по первому пришедшему размеру (реальному или синтетическому) */
                    uint16_t eff = samples;
                    if(vnd_frame_samples_req && vnd_frame_samples_req < eff) eff = vnd_frame_samples_req;
                    if(vnd_trunc_samples && vnd_trunc_samples < eff) eff = vnd_trunc_samples;
                    if(eff > VND_MAX_SAMPLES) eff = VND_MAX_SAMPLES;
                    cur_samples_per_frame = eff;
                    cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)eff*2u);
                    cdc_logf("FRAME_LOCK ch=%u adc_samp=%u req=%u trunc=%u -> eff=%u", ch, samples, vnd_frame_samples_req, vnd_trunc_samples, eff);
                }
            }

            uint16_t eff = cur_samples_per_frame;
            if(vnd_stream_mode != VND_STREAM_MODE_LOSSLESS_ROI){
                if(!synth && eff > samples) eff = samples; /* защита, если размер профиля уменьшился внезапно */
            }
            if(eff > VND_MAX_SAMPLES) eff = VND_MAX_SAMPLES;

            uint16_t frame_r2_diag = 0u;
            uint8_t consume_ok = 0u;
            uint8_t snapshot_seq_captured = 0u;
            uint32_t wr_before = 0u;
            uint32_t wr_after = 0u;
            uint32_t rd_before = 0u;
            uint32_t rd_after = 0u;
            if(!synth){
                wr_before = adc_ch_wr_seq[ch];
                rd_before = adc_ch_rd_seq[ch];
            }

            /* Базовый указатель источника (ROI смещает начало) */
            uint16_t *src = abuf;
            if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI && !synth){
                src = abuf + roi_start;
            }
            
            /* ДИАГНОСТИКА: проверяем последние 100 сэмплов DMA буфера на нули (только реальный буфер) */
            static uint32_t zero_check_count = 0; (void)zero_check_count;
            static uint32_t last_zero_check_ms = 0;
            uint32_t now_check = HAL_GetTick();
            if(!synth && now_check - last_zero_check_ms >= 5000 && eff >= 100){  /* Каждые 5 сек */
                uint16_t zeros_found = 0;
                for(uint16_t i = eff - 100; i < eff; i++){
                    if(abuf[i] == 0) zeros_found++;
                }
                cdc_logf("[USB_DIAG] CH%u: last 100 samples, %u zeros. [%u..%u]=[%u,%u,%u,%u,%u]",
                         ch, zeros_found, eff-100, eff-1,
                         abuf[eff-100], abuf[eff-50], abuf[eff-25], abuf[eff-10], abuf[eff-1]);
                last_zero_check_ms = now_check;
            }
            
            /* Если это staging, скопируем под защитой IRQ в локальный снапшот.
               В ROI режиме копируем только окно, чтобы гарантировать корректный срез. */
            if(!synth && ADC_USB_STAGE_ENABLE){
                __disable_irq();
                uint16_t stage_ns = eff;
                if(stage_ns > MAX_FRAME_SAMPLES) stage_ns = MAX_FRAME_SAMPLES;
                if(ch==0){
                    memcpy(stage_copy_async, src, stage_ns * sizeof(uint16_t));
                    src = stage_copy_async;
                } else {
                    memcpy(stage_copy_async_b, src, stage_ns * sizeof(uint16_t));
                    src = stage_copy_async_b;
                }
                wr_after = adc_ch_wr_seq[ch];
                rd_after = adc_ch_rd_seq[ch];
                snapshot_seq_captured = 1u;
                __enable_irq();
            }
            /* Построить payload: real ADC samples are already little-endian u16 on STM32. */
#if !TEST_OVERLAY_SAWTOOTH && !VND_ENABLE_ADC_SANITIZE
            if(!synth){
                memcpy(tf[ch].buf + VND_FRAME_HDR_SIZE, src, (uint32_t)eff * sizeof(uint16_t));
            } else
#endif
            {
                for(uint16_t i=0;i<eff;i++){
#if TEST_OVERLAY_SAWTOOTH
                    uint16_t v = (uint16_t)(i + 1);
                    if(ch == 1){ v = (uint16_t)(((i + 1u) * 2u + 512u) & 0x0FFFu); }
#else
                    uint16_t v = synth ? (uint16_t)(i + 1) : src[i];
#if VND_ENABLE_ADC_SANITIZE
                    if(!synth){
                        if(v > 4095u){ dbg_gt4095_ch[ch]++; /* считаем, но не правим */ }
                    }
#endif
#endif
                    uint8_t *p = tf[ch].buf + VND_FRAME_HDR_SIZE + 2u*i; p[0]=(uint8_t)(v & 0xFF); p[1]=(uint8_t)(v>>8);
                }
            }
            if(!synth){
                if(snapshot_seq_captured == 0u){
                    wr_after = adc_ch_wr_seq[ch];
                    rd_after = adc_ch_rd_seq[ch];
                }
                frame_r2_diag |= VND_R2_SNAPSHOT_USED;
                dbg_async_snapshot_copies[ch]++;
                dbg_async_last_dma_seq[ch] = dma_seq;
                dbg_async_last_wr_before[ch] = wr_before;
                dbg_async_last_wr_after[ch] = wr_after;
                dbg_async_last_rd_before[ch] = rd_before;
                dbg_async_last_rd_after[ch] = rd_after;
                dbg_async_last_samples[ch] = eff;
                dbg_async_last_ms[ch] = HAL_GetTick();
                if((wr_before != wr_after) || (rd_before != rd_after)){
                    frame_r2_diag |= VND_R2_GENERATION_MOVED;
                    dbg_async_snapshot_gen_move[ch]++;
                }
                if((uint32_t)(wr_after - dma_seq) >= (uint32_t)FIFO_FRAMES){
                    frame_r2_diag |= VND_R2_FIFO_GUARD;
                    dbg_async_snapshot_fifo_guard[ch]++;
                }
            }
            /* Заголовок */
            vnd_frame_hdr_t *h = (vnd_frame_hdr_t*)tf[ch].buf;
            h->magic = 0xA55A; h->ver = 0x01; h->flags = (ch==0)?0x01:0x02; 
            h->seq = (vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI) ? stream_seq : dma_seq;
            h->timestamp = HAL_GetTick(); h->total_samples = eff;
            if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI){
                h->zone_count = 1;
                h->zone1_offset = (uint32_t)win_start0;
                h->zone1_length = (uint32_t)eff;
            } else {
                h->zone_count=0; h->zone1_offset=0; h->zone1_length=0;
            }
            /* Пробрасываем индекс DMA-буфера канала, чтобы хост мог отрисовывать строго в порядке заполнения DMA */
            h->reserved  = dma_seq;

            /* ROI strict FIFO: A/B берутся из одной DMA-пары; FIFO двигаем один раз после копирования пары. */
            if(!synth && !roi_pair_valid){
                consume_ok = adc_consume_frame_ch((uint8_t)ch, dma_seq);
                if(consume_ok != 0u){
                    frame_r2_diag |= VND_R2_CONSUME_OK;
                    dbg_async_consume_ok[ch]++;
                } else {
                    dbg_async_consume_fail[ch]++;
                }
            }

            /* reserved2: low bits stay buffer_index; high bits carry source snapshot diagnostics. */
            h->reserved2 = vnd_pack_frame_reserved2(dma_seq, frame_r2_diag);
            dbg_async_last_reserved2[ch] = h->reserved2;
            
            h->crc16 = 0u;
            h->flags &= (uint8_t)~VND_FRAME_FLAG_CRC16;
            tf[ch].samples = eff; tf[ch].seq = stream_seq; tf[ch].dma_seq = dma_seq; tf[ch].frame_len = (uint16_t)(VND_FRAME_HDR_SIZE + eff*2u); tf[ch].ch = (uint8_t)ch; tf[ch].valid = 1;
        }
    }
    if(roi_pair_valid && tf[0].valid && tf[1].valid){
        uint8_t pair_consume_ok = adc_consume_frame_pair_fifo(roi_pair_dma_seq);
        if(pair_consume_ok != 0u){
            for(uint8_t c = 0u; c < 2u; c++){
                vnd_frame_hdr_t *hh = (vnd_frame_hdr_t*)tf[c].buf;
                hh->reserved2 |= VND_R2_CONSUME_OK;
                dbg_async_consume_ok[c]++;
                dbg_async_last_reserved2[c] = hh->reserved2;
            }
        } else {
            dbg_async_consume_fail[0]++;
            dbg_async_consume_fail[1]++;
        }
    }

    /* Выбор канала:
       1) Если валиден только один — берём его.
       2) Если оба — чередуем относительно last_sent_ch.
       3) Если ни одного — return 0. */
    int haveA = tf[0].valid ? 1:0;
    int haveB = tf[1].valid ? 1:0;
    int pick = -1;
    if(vnd_ch_mode == 2 && vnd_strict_pairing){
        /* Строгая парность: если оба готовы — чередуем, если готов только один и уже отправляли его для текущего seq — ждём второй */
        if(haveA && haveB){ pick = (last_sent_ch==0)?1:0; }
        else if(haveA && !haveB){ if(seq_mask == 0x01) return 0; pick = 0; }
        else if(haveB && !haveA){ if(seq_mask == 0x02) return 0; pick = 1; }
        else return 0;
    } else {
        /* Независимые каналы (дефолт): отправляем что есть, при наличии обоих — чередуем */
        if(haveA && !haveB) pick = 0;
        else if(haveB && !haveA) pick = 1;
        else if(haveA && haveB){ pick = (last_sent_ch==0)?1:0; }
        else return 0;
    }

    tmp_frame_t *sel = &tf[pick];
    if(!sel->valid) return 0;
    
    /* Гарантируем согласованность метаданных заголовка с DMA-кадром */
    vnd_frame_hdr_t *h = (vnd_frame_hdr_t*)sel->buf;
    h->seq = (vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI) ? sel->seq : h->reserved;
    h->reserved2 = vnd_refresh_frame_reserved2_buffer_index(h->reserved2, h->reserved);
    vnd_frame_finalize_crc(sel->buf);
    dbg_async_last_reserved2[pick] = h->reserved2;
    dbg_async_last_crc16[pick] = h->crc16;
    
    if(vnd_transmit_frame(sel->buf, sel->frame_len, 0, 0, pick==0?"ADC0-ASY2":"ADC1-ASY2") == USBD_OK){
        /* Учёт статистики предварительно (окончательная фиксация в TxCplt) */
        if(pick==0) dbg_sent_ch0_total++; else dbg_sent_ch1_total++;
        sending_channel = (uint8_t)pick; sel->valid = 0; last_sent_ch = (uint8_t)pick;
        /* Логика продвижения общего seq в async режиме.
           Базово: ждём кадры A и B (seq_mask==0x3) -> инкремент.
           Проблема: если один канал (например B) долго не приходит, мы зацикливаемся на одном seq.
           Решение: fallback по таймауту или числу односторонних кадров. */
        uint32_t now_ms_local = HAL_GetTick();
        if(vnd_ch_mode==2 && vnd_strict_pairing){
            seq_mask |= (uint8_t)(1u<<pick);
            if(seq_mask_first_ms == 0) seq_mask_first_ms = now_ms_local;
            if(seq_mask == 0x3){
                /* Оба канала отправили по кадру текущего seq — продвигаем */
                seq_mask = 0; seq_mask_first_ms = 0; seq_partial_cnt = 0;
                stream_seq++; dbg_produced_seq++;
            } else {
                /* Строгая парность: не продвигаем seq, пока не отправлены оба канала. */
                seq_partial_cnt++;
                uint32_t dt_ms = (now_ms_local >= seq_mask_first_ms) ? (now_ms_local - seq_mask_first_ms) : (0xFFFFFFFFu - seq_mask_first_ms + 1u + now_ms_local);
                if(dt_ms > 1000 && (seq_partial_cnt % 8) == 0){
                    VND_LOG("ASYNC_WAIT_PAIR seq=%lu mask=0x%02X cnt=%u dt=%lums", (unsigned long)stream_seq, (unsigned)seq_mask, (unsigned)seq_partial_cnt, (unsigned long)dt_ms);
                }
            }
        } else if (vnd_ch_mode==2 && !vnd_strict_pairing){
            /* Независимые каналы: продвигаем seq каждый кадр, сохраняя общую временную шкалу */
            stream_seq++; dbg_produced_seq++;
            seq_mask = 0; seq_mask_first_ms = 0; seq_partial_cnt = 0; /* сброс */
        } else {
            /* В режиме single-channel seq просто инкрементируется каждый кадр */
            stream_seq++; dbg_produced_seq++;
            seq_mask = 0; seq_mask_first_ms = 0; seq_partial_cnt = 0; /* сброс */
        }
        /* ПРОФИЛИРОВАНИЕ: успешная отправка */
        uint32_t end_cyc = DWT->CYCCNT;
        uint32_t elapsed_cyc = (end_cyc >= start_cyc) ? (end_cyc - start_cyc) : (0xFFFFFFFFu - start_cyc + end_cyc + 1);
        uint32_t elapsed_us = elapsed_cyc / (SystemCoreClock / 1000000u);
        call_count++;
        total_time_us += elapsed_us;
        if(elapsed_us > max_time_us) max_time_us = elapsed_us;
        
        uint32_t now_profile = HAL_GetTick();
        if(now_profile - last_profile_log >= 5000){
            __attribute__((unused)) uint32_t avg_us = call_count ? (total_time_us / call_count) : 0;
                 VND_PROF_LOGF("[PROF_TX] calls=%lu avg=%lu.%luus max=%lu.%luus\r\n",
                     call_count, avg_us, (elapsed_us%10), max_time_us, (max_time_us%10));
            call_count = 0; total_time_us = 0; max_time_us = 0;
            last_profile_log = now_profile;
        }
        return 1;
    }
    
    /* ПРОФИЛИРОВАНИЕ: не отправлено (нет данных) */
    uint32_t end_cyc = DWT->CYCCNT;
    uint32_t elapsed_cyc = (end_cyc >= start_cyc) ? (end_cyc - start_cyc) : (0xFFFFFFFFu - start_cyc + end_cyc + 1);
    uint32_t elapsed_us = elapsed_cyc / (SystemCoreClock / 1000000u);
    call_count++;
    total_time_us += elapsed_us;
    if(elapsed_us > max_time_us) max_time_us = elapsed_us;
    
    return 0;
}

/* allow_zero_samples используется как флаги:
 *  bit0 (1): разрешить total_samples==0
 *  bit1 (2): разрешить длину >= ожидаемой и кратную 64 (для паддинга до MPS)
 */
static int vnd_validate_frame(const uint8_t *buf, uint16_t len, uint8_t expect_test, uint8_t allow_flags)
{
    (void)expect_test;
    if (!buf || len < VND_FRAME_HDR_SIZE)
        return 0;
    const vnd_frame_hdr_t *h = (const vnd_frame_hdr_t*)buf;
    if (h->magic != 0xA55A)
        return 0;
    if (h->total_samples > VND_MAX_SAMPLES)
        return 0;
    if (!(allow_flags & 0x01) && h->total_samples == 0)
        return 0;
    {
        uint16_t expected = (uint16_t)(VND_FRAME_HDR_SIZE + h->total_samples * 2u);
        if (len != expected) {
            /* Разрешаем нулевой паддинг до MPS: полезный размер берётся из total_samples. */
            if (len < expected) return 0;
            if ((len % 64u) != 0u) return 0;
            if ((allow_flags & 0x02) == 0) {
                for(uint16_t i = expected; i < len; i++){
                    if(buf[i] != 0u) return 0;
                }
            }
        }
    }
    return 1;
}

static USBD_StatusTypeDef __attribute__((unused)) vnd_transmit_frame(uint8_t *buf, uint16_t len, uint8_t is_test, uint8_t allow_zero_samples, const char *tag)
{
    (void)is_test; dbg_tx_attempt++;
    vnd_last_tx_pace_busy = 0u;
    if(!vnd_validate_frame(buf, len, is_test, allow_zero_samples)){ dbg_tx_reject++; vnd_error_counter++; if(vnd_last_error == 0) vnd_last_error = 3; VND_LOG("TX_REJECT %s", tag ? tag : "?"); return USBD_FAIL; }
    if(!vnd_frame_pace_ready(HAL_GetTick())){
        vnd_last_tx_pace_busy = 1u;
        vnd_tx_kick = 1u;
        return USBD_BUSY;
    }
    if(!vnd_tx_ready || vnd_ep_busy || vnd_inflight){ VND_LOG("TX_SKIP busy/inflight tag=%s", tag ? tag : "?"); return USBD_BUSY; }
    {
        extern uint8_t USBD_VND_TxIsBusy(void);
        if(USBD_VND_TxIsBusy()){
            dbg_resend_blocked++;
            vnd_tx_kick = 1;
            VND_LOG("TX_DEFER ll_busy tag=%s", tag ? tag : "?");
            return USBD_BUSY;
        }
    }
    vnd_tx_ready = 0; vnd_ep_busy = 1; vnd_inflight = 1; vnd_last_tx_len = len; vnd_last_tx_start_ms = HAL_GetTick();

    /* Фиксируем метаданные кадра; НЕ переписываем seq перед отправкой.
       Последовательность пар контролируется строго: seq фиксируется при сборке пары,
       а инкремент выполняется только по завершению B (TxCplt). Это исключает случаи,
       когда задержавшийся B получает «будущий» seq. */
    uint8_t is_frame=0, flags=0; uint32_t seq_field=0; int rewrote_seq = 0;
    if(len >= VND_FRAME_HDR_SIZE){
        vnd_frame_hdr_t *hh = (vnd_frame_hdr_t*)buf;
        if(hh->magic == 0xA55A){ is_frame = 1; flags = hh->flags; seq_field = hh->seq; }
    }

    /* Зафиксируем точный тип текущего кадра в полёте */
    if(len >= VND_FRAME_HDR_SIZE){ const vnd_frame_hdr_t *hh = (const vnd_frame_hdr_t*)buf; if(hh->magic==0xA55A){ inflight_is_frame = 1; inflight_flags = hh->flags; inflight_seq = hh->seq; } else { inflight_is_frame = 0; inflight_flags = 0; inflight_seq = 0; } } else { inflight_is_frame = 0; inflight_flags = 0; inflight_seq = 0; }
    (void)flags; (void)seq_field; /* для сборок с отключёнными логами */
    vnd_tx_meta_before(buf, len);
    USBD_StatusTypeDef rc = USBD_VND_Transmit(&hUsbDeviceHS, buf, len);
    if(rc != USBD_OK){
        vnd_tx_meta_rollback_last();
        dbg_resend_blocked++;
        if(rc != USBD_BUSY){
            vnd_error_counter++;
            if(vnd_last_error == 0) vnd_last_error = 4;
        }
        /* Диагностика LL: получим last rc/len и флаг занятости */
        extern uint8_t USBD_VND_TxIsBusy(void);
        extern uint8_t USBD_VND_LastTxRC(void);
        extern uint16_t USBD_VND_LastTxLen(void);
        uint8_t ll_busy = USBD_VND_TxIsBusy(); uint8_t ll_rc = USBD_VND_LastTxRC(); uint16_t ll_len = USBD_VND_LastTxLen();
        (void)ll_busy; (void)ll_rc; (void)ll_len;
        VND_LOG("TX_FAIL tag=%s rc=%d len=%u ll_busy=%u last_rc=%u last_len=%u", tag?tag:"?", (int)rc, (unsigned)len, (unsigned)ll_busy, (unsigned)ll_rc, (unsigned)ll_len);
        vnd_rollback_tx_start();
        vnd_tx_kick = 1;
    }
    else {
        if(is_frame){
            const vnd_frame_hdr_t *lh = (const vnd_frame_hdr_t*)buf;
            (void)lh;
            if(rewrote_seq){
                VND_LOG("SEND tag=%s hdr.seq=%lu (rewrote) flags=0x%02X cur_stream_seq=%lu len=%u", tag ? tag : "?", (unsigned long)lh->seq, (unsigned)lh->flags, (unsigned long)stream_seq, len);
            } else {
                VND_LOG("SEND tag=%s hdr.seq=%lu flags=0x%02X cur_stream_seq=%lu len=%u", tag ? tag : "?", (unsigned long)lh->seq, (unsigned)lh->flags, (unsigned long)stream_seq, len);
            }
        } else {
            VND_LOG("SEND tag=%s (no-hdr) cur_stream_seq=%lu len=%u", tag ? tag : "?", (unsigned long)stream_seq, len);
        }
        /* Дублирование в CDC (работает для кадров ADC0/ADC1 и диагностических) */
        vnd_cdc_duplicate_preview(buf, len, tag);
    }
    return rc;
}

/* Упрощённая диагностическая пара A/B: подготовка буферов по текущему cur_samples_per_frame */
static void vnd_diag_prepare_pair(uint32_t seq, uint16_t samples)
{
    if(samples == 0) samples = VND_DEFAULT_TEST_SAMPLES;
    if(samples > VND_MAX_SAMPLES) samples = VND_MAX_SAMPLES;
    uint16_t base_len = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)samples*2u);
    /* Паддинг до кратности 512 (HS max packet); кратность 64 обеспечивает совместимость и для FS */
    uint16_t pad_unit = 512u;
    uint16_t padded = (uint16_t)(((uint32_t)(base_len + (pad_unit-1u)) / pad_unit) * pad_unit);
    if (padded < base_len) padded = base_len; /* защита от переполнения (не ожидается) */
    diag_frame_len = padded;
    /* A */
    memset(diag_a_buf, 0, diag_frame_len);
    vnd_frame_hdr_t *ha = (vnd_frame_hdr_t*)diag_a_buf;
    ha->magic = 0xA55A; ha->ver = 0x01; ha->flags = 0x01; ha->seq = seq; ha->timestamp = HAL_GetTick(); ha->total_samples = samples;
    for(uint16_t i=0;i<samples;i++){ uint16_t v=i; diag_a_buf[VND_FRAME_HDR_SIZE+2*i]=(uint8_t)(v & 0xFF); diag_a_buf[VND_FRAME_HDR_SIZE+2*i+1]=(uint8_t)(v>>8); }
    /* B */
    memset(diag_b_buf, 0, diag_frame_len);
    vnd_frame_hdr_t *hb = (vnd_frame_hdr_t*)diag_b_buf;
    hb->magic = 0xA55A; hb->ver = 0x01; hb->flags = 0x02; hb->seq = seq; hb->timestamp = ha->timestamp; hb->total_samples = samples;
    for(uint16_t i=0;i<samples;i++){ uint16_t v=0x0100u+i; diag_b_buf[VND_FRAME_HDR_SIZE+2*i]=(uint8_t)(v & 0xFF); diag_b_buf[VND_FRAME_HDR_SIZE+2*i+1]=(uint8_t)(v>>8); }
    diag_current_pair_seq = seq; /* зафиксируем seq текущей пары для гарантии совпадения A/B */
}

/* Попытка отправки диагностического кадра: A, затем (если не A-only) B */
static int vnd_diag_try_tx(void)
{
    if(vnd_ep_busy) return 0;
    if(diag_frame_len == 0) return 0;
#if VND_DIAG_SEND_A_ONLY
    if(!vnd_validate_frame(diag_a_buf, diag_frame_len, 0, 0x02)) return 0; /* allow padding */
    if(vnd_transmit_frame(diag_a_buf, diag_frame_len, 0, 0, "ADC0") == USBD_OK){
        sending_channel = 0; /* для корректной статистики */
        return 1;
    } else { return 0; }
#else
    /* В DIAG режиме используем pending_B как главный флаг: если он установлен — шлём B, иначе A */
    if(pending_B)
    {
        if(!vnd_validate_frame(diag_b_buf, diag_frame_len, 0, 0x02)) return 0; /* allow padding */
        /* Прямое копирование полей из заголовка A: seq/timestamp/ns всегда совпадают в паре */
        if(diag_frame_len >= VND_FRAME_HDR_SIZE){
            vnd_frame_hdr_t *hb = (vnd_frame_hdr_t*)diag_b_buf;
            const vnd_frame_hdr_t *ha = (const vnd_frame_hdr_t*)diag_a_buf;
            if(hb->magic == 0xA55A && ha->magic == 0xA55A){
                hb->seq = ha->seq;
                hb->timestamp = ha->timestamp;
                hb->total_samples = ha->total_samples;
            }
        }
        if(vnd_transmit_frame(diag_b_buf, diag_frame_len, 0, 0x02, "ADC1") == USBD_OK){
            sending_channel = 1; /* информативно */
            /* печать в CDC отключена для максимальной скорости */
            return 1;
        } else { return 0; }
    }
    /* Иначе шлём A, когда EP свободен */
    /* Allow padded A-frames as well (len >= expected and multiple of 64/512) */
    if(!vnd_validate_frame(diag_a_buf, diag_frame_len, 0, 0x02)) return 0; /* allow padding */
    /* Безопасная синхронизация seq для A: если по какой-то причине новая пара
       ещё не была собрана, принудительно проставим актуальный stream_seq в hdr */
    if(diag_frame_len >= VND_FRAME_HDR_SIZE){
        vnd_frame_hdr_t *ha = (vnd_frame_hdr_t*)diag_a_buf;
        if(ha->magic == 0xA55A){
            if(ha->seq != stream_seq){
                ha->seq = stream_seq;
            }
            /* Всегда фиксируем текущий seq A как seq пары для последующего B */
            diag_current_pair_seq = ha->seq;
        }
    }
    if(vnd_transmit_frame(diag_a_buf, diag_frame_len, 0, 0x02, "ADC0") == USBD_OK){
        sending_channel = 0; /* ожидаем B после TxCplt A */
        /* Закрываем STAT-окно между A и B: сразу помечаем ожидание B */
        pending_B = 1; pending_B_since_ms = HAL_GetTick();
        /* печать в CDC отключена для максимальной скорости */
        return 1;
    } else { return 0; }
#endif
}

/* === Немедленная отправка B после завершения A (внутри TxCplt) === */
static int vnd_try_send_B_immediate(void)
{
    if(vnd_ep_busy) return 0;
    /* DIAG режим: используем заранее подготовленный diag_b_buf с текущим seq */
    if(diag_mode_active){
        if(!pending_B) return 0;
        if(diag_frame_len == 0) return 0;
        if(diag_frame_len >= VND_FRAME_HDR_SIZE){
            vnd_frame_hdr_t *hb = (vnd_frame_hdr_t*)diag_b_buf;
            const vnd_frame_hdr_t *ha = (const vnd_frame_hdr_t*)diag_a_buf;
            /* В DIAG заголовок B копируем из A для гарантированной идентичности пары */
            if(hb->magic == 0xA55A && ha->magic == 0xA55A){
                hb->seq = ha->seq;
                hb->timestamp = ha->timestamp;
                hb->total_samples = ha->total_samples;
            }
        }
        if(!vnd_validate_frame(diag_b_buf, diag_frame_len, 0, 0x02)) return 0;
        if(vnd_transmit_frame(diag_b_buf, diag_frame_len, 0, 0x02, "ADC1-IMM") == USBD_OK){
            sending_channel = 1; /* B в полёте */
            return 1;
        }
        return 0;
    }
    /* Полный режим: отправляем B из текущей пары (pair_send_idx), если READY */
    ChanFrame *fB = &g_frames[pair_send_idx][1];
    if(fB->st != FB_READY) return 0;
    if(!vnd_strict_slot_ready_for_stream(pair_send_idx)) return 0;
    if(vnd_transmit_frame(fB->buf, fB->frame_size, 0, 0, "ADC1-IMM") == USBD_OK){
        fB->st = FB_SENDING; sending_channel = 1;
        return 1;
    }
    return 0;
}

/* === Немедленная отправка A следующей пары после завершения B (внутри TxCplt) === */
static int vnd_try_send_A_nextpair_immediate(void)
{
    if(vnd_ep_busy) return 0;
    /* После B мы уже сдвинули pair_send_idx/seq во внешней логике — тут пытаемся сразу выстрелить A новой пары */
    if(diag_mode_active){
        /* Подготовим следующую пару под новый stream_seq и сразу пошлём A */
        vnd_diag_prepare_pair(stream_seq, cur_samples_per_frame ? cur_samples_per_frame : diag_samples);
        if(!vnd_validate_frame(diag_a_buf, diag_frame_len, 0, 0x02)) return 0;
        if(vnd_transmit_frame(diag_a_buf, diag_frame_len, 0, 0x02, "ADC0-IMM") == USBD_OK){
            sending_channel = 0; pending_B = 1; pending_B_since_ms = HAL_GetTick();
            return 1;
        }
        return 0;
    }
    /* Полный режим: убедимся, что в буфере подготовки есть готовый A текущей пары; если нет — попробуем собрать */
    ChanFrame *fA = &g_frames[pair_send_idx][0];
    if(fA->st != FB_READY){
        vnd_prepare_pair();
        fA = &g_frames[pair_send_idx][0];
        if(fA->st != FB_READY) return 0;
    }
    if(!vnd_strict_slot_ready_for_stream(pair_send_idx)) return 0;
    if(vnd_transmit_frame(fA->buf, fA->frame_size, 0, 0, "ADC0-IMM") == USBD_OK){
        fA->st = FB_SENDING; sending_channel = 0; pending_B = 1; pending_B_since_ms = HAL_GetTick();
        return 1;
    }
    return 0;
}

/* Лог структуры заголовка кадра для отладки */
static void vnd_log_hdr_layout(void){
#if VND_ENABLE_LOG
    VND_LOG("HDR sz=%u off.magic=%u off.seq=%u off.timestamp=%u off.total=%u", (unsigned)sizeof(vnd_frame_hdr_t),
            (unsigned)offsetof(vnd_frame_hdr_t,magic), (unsigned)offsetof(vnd_frame_hdr_t,seq),
            (unsigned)offsetof(vnd_frame_hdr_t,timestamp), (unsigned)offsetof(vnd_frame_hdr_t,total_samples));
#endif
}

/* Экстренный keepalive: формирует короткий тестовый кадр даже если test_sent уже помечен по FALLTHRU,
   при условии что dbg_tx_cplt==0 (ни одного подтверждённого TX) и EP свободен. */
static void __attribute__((unused)) vnd_emergency_keepalive(uint32_t now_ms)
{
    if(vnd_ep_busy) return;
    if(dbg_tx_cplt != 0) return; /* уже что-то передали успешно */
    /* Не чаще чем раз в 40 мс */
    static uint32_t last_emerg_ms = 0;
    if(now_ms - last_emerg_ms < 40) return;
    last_emerg_ms = now_ms;
    uint8_t tbuf[32+16]; memset(tbuf,0,sizeof(tbuf));
    vnd_frame_hdr_t *h = (vnd_frame_hdr_t*)tbuf;
    h->magic = 0xA55A; h->ver = 0x01; h->flags = 0x80; h->seq = 0; h->timestamp = HAL_GetTick(); h->total_samples = 8;
    for(uint16_t i=0;i<8;i++){ tbuf[32+2*i]=(uint8_t)i; tbuf[32+2*i+1]=(uint8_t)(i>>8); }
    vnd_tx_ready = 0; vnd_ep_busy = 1; vnd_last_tx_len = sizeof(tbuf); vnd_last_tx_start_ms = HAL_GetTick();
    vnd_tx_meta_before(tbuf, (uint16_t)sizeof(tbuf));
    if(USBD_VND_Transmit(&hUsbDeviceHS, tbuf, sizeof(tbuf)) == USBD_OK){
        test_in_flight = 1; VND_LOG("EMERG_TEST_TX (no TXCPLT yet) depth=%u", (unsigned)vnd_tx_meta_depth());
    } else { vnd_tx_meta_rollback_last(); vnd_tx_ready = 1; vnd_ep_busy = 0; VND_LOG("EMERG_TEST_BUSY"); }
}

/* Отправка единственного тестового кадра (строго из таска) */
static void vnd_try_send_test_from_task(void)
{
#if VND_DISABLE_TEST
    /* Тестовые кадры запрещены — ничего не делаем */
    return;
#endif
    if(!streaming) return;
    if(diag_mode_active) return;
    /* Как только начали готовить/слать реальные кадры — больше не шлём TEST */
    if(dbg_any_valid_frame) return;
    if(test_sent || test_in_flight) return;
    if(vnd_ep_busy) return;
    /* Бэкофф: не пытаться слать тест чаще, чем раз в 50 мс */
    static uint32_t last_try_ms = 0;
    uint32_t now = HAL_GetTick();
    if (now - last_try_ms < 50) return;
    last_try_ms = now;
    uint8_t tbuf[32+16]; memset(tbuf,0,sizeof(tbuf));
    vnd_frame_hdr_t *h = (vnd_frame_hdr_t*)tbuf;
    h->magic = 0xA55A; h->ver = 0x01; h->flags = 0x80; h->seq = 0; h->timestamp = HAL_GetTick(); h->total_samples = 8;
    for(uint16_t i=0;i<8;i++){ tbuf[32+2*i]=(uint8_t)i; tbuf[32+2*i+1]=(uint8_t)(i>>8); }
    vnd_tx_ready = 0; vnd_ep_busy = 1; vnd_last_tx_len = sizeof(tbuf); vnd_last_tx_start_ms = HAL_GetTick();
    vnd_tx_meta_before(tbuf, (uint16_t)sizeof(tbuf));
    if(USBD_VND_Transmit(&hUsbDeviceHS, tbuf, sizeof(tbuf)) == USBD_OK){
        test_in_flight = 1;
        VND_LOG("TEST_TX from task depth=%u", (unsigned)vnd_tx_meta_depth());
        /* Не пытаемся сразу слать рабочий кадр — ждём завершение TEST,
           чтобы не попасть на BUSY/ZLP гонки. Далее обычная логика отправит A/B. */
    } else {
        vnd_tx_meta_rollback_last();
        VND_LOG("TEST_TX busy/fail");
        vnd_tx_ready = 1; vnd_ep_busy = 0;
    }
}

void __attribute__((unused)) vnd_diag_send64_once(void)
{
    static uint8_t sent = 0;
    if(sent) return;
    if(hUsbDeviceHS.dev_state != USBD_STATE_CONFIGURED) return; /* ждём конфигурации */
    if(streaming) return; /* чтобы не мешать основной логике */
    if(vnd_ep_busy) return; /* подождём освобождения */
    uint8_t diag[64];
    for(int i = 0; i < 64; i++) diag[i] = (uint8_t)i;
    memcpy(diag, "STAT", 4); /* чтобы на хосте легко найти */
    diag[4] = 0x42;           /* тестовая версия */
    vnd_tx_ready = 0; vnd_ep_busy = 1; vnd_last_tx_len = sizeof(diag); vnd_last_tx_start_ms = HAL_GetTick();
    vnd_tx_meta_before(diag, (uint16_t)sizeof(diag));
    USBD_StatusTypeDef rc = USBD_VND_Transmit(&hUsbDeviceHS, diag, (uint16_t)sizeof(diag));
    if(rc == USBD_OK){
        sent = 1;
        VND_LOG("DIAG64 rc=OK");
    } else {
        vnd_tx_meta_rollback_last();
        VND_LOG("DIAG64 rc=%d", rc);
        vnd_tx_ready = 1; vnd_ep_busy = 0; /* откатим флаги при неудаче */
    }
}

/* Основной периодический таск */
void __attribute__((unused)) Vendor_Stream_Task(void)
{
    dbg_task_calls++;
    vnd_note_task_entry(HAL_GetTick());
    /* Сервис EP0: выполняем отложенные SOFT/DEEP RESET без блокировки SETUP */
    USBD_VND_ProcessControlRequests();

    /* Принудительная загрузка DC после reboot: не зависит от stream_mode/ROI. */
    vnd_dc_load_once();

    /* DC (always-on): загрузка по запросу + фоновая адаптация/сохранение не зависят от stream_mode.
       stream_mode влияет только на формирование USB кадров. */
    if(vnd_dc_load_request){
        vnd_dc_load_request = 0;
        vnd_dc_load_once();
    }
    {
        uint16_t roi_start = win_start0;
        uint16_t roi_len   = win_len0;
        if(roi_len == 0u){
            if(win_auto){
                vnd_apply_auto_roi_window();
                roi_start = win_start0;
                roi_len = win_len0;
            } else {
                roi_start = (uint16_t)VND_ROI_BASE_START_200HZ;
                roi_len = (uint16_t)VND_ROI_LEN_DEFAULT;
            }
        }
        /* AVG_ROI owns DC only for the exact 200-sample table. */
        if(!(streaming && full_mode && !diag_mode_active &&
             vnd_stream_mode == VND_STREAM_MODE_AVG_ROI &&
             roi_len == (uint16_t)VND_DC_ROI_LEN)){
            vnd_dc_background_step(roi_start, roi_len);
        }
        vnd_dc_try_save_periodic();
    }

    /* Sync master/slave: только наблюдаем входную частоту; локальный TIM15 остаётся
       на профильной базе и не подстраивается автоматически у SLAVE. */
    {
        uint32_t now_ms = HAL_GetTick();
        vnd_tx_failsafe_service(now_ms);

        if(vnd_sync_mode == VND_SYNC_MODE_MASTER){
            uint16_t hz = adc_stream_get_buf_rate();
            if(hz != 0u && hz != vnd_sync_last_hz){
                vnd_sync_set_master(hz);
            }
            vnd_sync_ok_public = 1u;
        } else if(vnd_sync_mode == VND_SYNC_MODE_SLAVE){
            uint16_t hz = vnd_sync_pending_hz;
            if(hz != 0u && (now_ms - vnd_sync_last_apply_ms) > 200u){
                vnd_sync_pending_hz = 0;
                vnd_sync_last_apply_ms = now_ms;
                /* Frequency capture kept for diagnostics only.
                   Do not change buf_rate/TIM15 divider on slave automatically. */
                if(win_auto && (vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI)){
                    uint16_t prev_start = win_start0;
                    vnd_apply_auto_roi_window();
                    if(win_start0 != prev_start){
                        vnd_avg_reset();
                        vnd_update_lcd_params();
                    }
                }
            }
            {
                extern volatile uint32_t sync_last_edge_ms;
                if(sync_last_edge_ms != 0u && (now_ms - sync_last_edge_ms) <= 1000u){
                vnd_sync_ok_public = 1u;
            } else {
                vnd_sync_ok_public = 0u;
            }
            }
        }
    }

    /* ПРИОРИТЕТ 0: если не сконфигурировано стримингом — обслуживаем оффлайн-STAT
       и параллельно ведём DC адаптацию/сохранение по входному сигналу (если есть кадры в FIFO). */
    if(!streaming)
    {
        if(!vnd_ep_busy && !vnd_inflight){ vnd_try_send_pending_event_from_task(); }
        if(!vnd_ep_busy && !vnd_inflight){ vnd_try_send_pending_status_from_task(); }
        vnd_tick_flag = 0;
        return;
    }
    /* подавляем частый шум лога при каждом заходе в таск */
    if(!dbg_printed_sizes)
    {
        vnd_log_hdr_layout();
        dbg_printed_sizes = 1;
    }

    /* DEBUG: очень шумный вывод sample[95] по всем DMA буферам.
       По умолчанию отключено, включайте только при необходимости. */
#if defined(VND_DEBUG_S95) && (VND_DEBUG_S95 == 1)
    {
        static uint32_t last_s95_ms = 0;
        uint32_t now_ms = HAL_GetTick();
        if (now_ms - last_s95_ms >= 1000u) {
            last_s95_ms = now_ms;
            adc_stream_print_sample95_all_buffers();
        }
    }
#endif

    /* (перезапуск ADC/DMA обработан выше, до выхода при !streaming) */
    /* СУПЕР-ПРИОРИТЕТ: если пришёл STOP — разрешаем только ACK-STAT, полностью блокируем стрим */
    if (stop_request) {
        if (!vnd_ep_busy) {
            if (!pending_status) pending_status = 1; /* гарантируем наличие отложенного STAT */
            vnd_try_send_pending_status_from_task();
        }
        if (vnd_tick_flag) vnd_tick_flag = 0;
        /* Логируем попытки передачи после STOP */
        if (pending_B || test_sent) {
            VND_LOG("BLOCK: попытка передачи после STOP (pending_B=%d, test_sent=%d)", pending_B, test_sent);
            pending_B = 0; test_sent = 0; sending_channel = 0xFF;
        }
        return; /* ждём TxCplt ACK-STOP */
    }

    vnd_usb_in_drop_recovery_poll(HAL_GetTick());

    /* В AVG_ROI B должен уходить сразу после завершения A. Не ставим перед ним
       фоновый drain/DSP, иначе короткий USB hiccup быстро превращается в q=4 и recovery. */
    if(full_mode && !diag_mode_active && vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
        if(pending_B && !vnd_ep_busy && !vnd_inflight){
            if(vnd_try_send_B_immediate()){
                if(vnd_tick_flag) vnd_tick_flag = 0;
                return;
            }
        }
    }

    /* stream_mode=2: постоянно дренируем FIFO и готовим усреднённые ROI кадры в очереди.
       Это критично для "lossless" поведения (потребление ADC не должно зависеть от скорости USB). */
    if(full_mode && !diag_mode_active && vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
        /* Выполняем загрузку DC из Flash в main-loop как можно раньше (после SET_STREAM_MODE).
           Это помогает после перезагрузки не начинать адаптацию "с нуля" из-за задержки загрузки. */
        if(vnd_dc_load_request){
            vnd_dc_load_request = 0;
            vnd_dc_load_once();
        }
        uint16_t roi_start = win_start0;
        uint16_t roi_len   = win_len0;
        if(roi_len == 0u){ roi_start = 280u; roi_len = 200u; }
        vnd_avg_drain_fifo(roi_start, roi_len);

        /* Периодическое сохранение DC в Flash (если менялся): вызывать всегда, а не только в 1Hz сводке.
           Внутри есть троттлинг по времени и флаг dirty. */
        vnd_dc_try_save_periodic();

        /* Периодическая сводка (UART): помогает понять реальный коэффициент усреднения и состояние очереди */
        uint32_t now_ms = HAL_GetTick();
        if(dbg_avg_last_print_ms == 0){ dbg_avg_last_print_ms = now_ms; }
        if((now_ms - dbg_avg_last_print_ms) >= 1000u){
            uint32_t in_now = dbg_avg_in_frames;
            uint32_t out_now = dbg_avg_out_frames;
            uint32_t tx_now = dbg_avg_tx_pairs;
            uint32_t din = in_now - dbg_avg_in_last;
            uint32_t dout = out_now - dbg_avg_out_last;
            uint32_t dtx = tx_now - dbg_avg_tx_last;
            dbg_avg_in_last = in_now; dbg_avg_out_last = out_now; dbg_avg_tx_last = tx_now;
            dbg_avg_last_print_ms = now_ms;
                 uint32_t dsp_avg_us = (vnd_dsp.dsp_us_cnt ? (vnd_dsp.dsp_us_total / vnd_dsp.dsp_us_cnt) : 0u);
  if (VND_AVG_DIAG_PRINTF) {
                                 printf("[AVG] n=%u q=%u drop=%lu cnt0=%u cnt1=%u in=%lu(+%lu/s) out=%lu(+%lu/s) tx=%lu(+%lu/s) dsp=%luus(avg) %luus(max) corr_eo=(%.3f,%.3f) corr_ab=(e=%.3f,o=%.3f)\r\n",
                                     (unsigned)vnd_avg_n, (unsigned)vnd_avg_q_count,
                                     (unsigned long)dbg_avg_drop_frames,
                                     (unsigned)vnd_avg_cnt[0], (unsigned)vnd_avg_cnt[1],
                                     (unsigned long)in_now, (unsigned long)din,
                                     (unsigned long)out_now, (unsigned long)dout,
                                         (unsigned long)tx_now, (unsigned long)dtx,
                                         (unsigned long)dsp_avg_us, (unsigned long)vnd_dsp.dsp_us_max,
                                         (double)vnd_dsp.corr_eo[0], (double)vnd_dsp.corr_eo[1],
                                         (double)vnd_dsp.corr_ab[0], (double)vnd_dsp.corr_ab[1]);
  }

                     /* DC save вызывается выше (вне 1Hz блока), чтобы не зависеть от печати. */

                 /* сбрасываем только тайминг, оставляя последние corr значения */
                 vnd_dsp.dsp_us_total = 0;
                 vnd_dsp.dsp_us_cnt = 0;
                 vnd_dsp.dsp_us_max = 0;
        }
    }

    /* ACK-STAT на START: отключено, чтобы не занимать Vendor IN перед первой парой.
       Хост может опрашивать состояние через GET_STATUS (EP0). */
    if(status_ack_pending){ start_ack_done = 1; status_ack_pending = 0; }

    uint32_t now = HAL_GetTick();
    vnd_uart_stream_stats(now);
    vnd_recover_avg_pending_b_stall(now);
    /* Fallback: если ACK так и не ушёл в полёт (status_ack_pending держится),
       не ждём бесконечно — считаем ACK выполненным и продолжаем к TEST. */
    if(!test_sent && !start_ack_done && status_ack_pending){
        if(now - start_cmd_ms > 200){
            start_ack_done = 1; status_ack_pending = 0;
            vnd_ep_busy = 0; vnd_tx_ready = 1;
            extern void USBD_VND_ForceTxIdle(void); USBD_VND_ForceTxIdle();
            VND_LOG("ACK_FALLBACK(no inflight) -> allow TEST");
            if(!vnd_ep_busy){ vnd_try_send_test_from_task(); }
        }
    }

    if(!test_sent && start_stat_inflight) {
        uint32_t start_stat_age_ms = 0u;
        if(vnd_last_tx_start_ms == 0u ||
           (vnd_tick_age_ms(now, vnd_last_tx_start_ms, &start_stat_age_ms) && start_stat_age_ms > 80u)) {
            /* На некоторых хостах ACK-STAT может не завершиться DataIn/ZLP. Разблокируем вручную. */
            start_stat_inflight = 0; start_ack_done = 1; vnd_ep_busy = 0; vnd_tx_ready = 1;
            extern void USBD_VND_ForceTxIdle(void); USBD_VND_ForceTxIdle();
            VND_LOG("ACK_TIMEOUT -> unlock test");
            /* Сразу отдадим ещё один STAT (если был queued) и попробуем отправить TEST */
            if(pending_status && !vnd_ep_busy){
                vnd_try_send_pending_status_from_task();
            }
            if(!vnd_ep_busy){
#if !VND_DISABLE_TEST
                vnd_try_send_test_from_task();
#endif
            }
        }
    }
    /* Аварийный обход: если тест не ушёл за разумное время после START — считаем его выполненным и продолжаем */
    if(!test_sent && (now - start_cmd_ms) > 160) {
        test_in_flight = 0;
        test_sent = 1;
        start_ack_done = 1;
        VND_LOG("TEST_FALLTHRU after %lums -> proceed to A/B", (unsigned long)(now - start_cmd_ms));
    }

    /* ASYNC MODE: используем только vnd_async_try_tx() (без legacy prepare_pair/pump).
       Иначе старый парный путь может потреблять/копировать ADC и перегружать CPU/логи,
       что приводит к остановке/редким кадрам на хосте после первых нескольких фреймов. */
#if !USE_TEST_SAWTOOTH
    if(async_mode && full_mode && !diag_mode_active){
        if(!vnd_ep_busy && !vnd_inflight && vnd_can_preempt_stream_with_event()){
            vnd_try_send_pending_event_from_task();
            if(vnd_ep_busy){ if(vnd_tick_flag) vnd_tick_flag = 0; return; }
        }
        if(!vnd_ep_busy){ (void)vnd_async_try_tx(); }
        if(!vnd_ep_busy && !vnd_inflight && vnd_has_pending_event()){
            vnd_try_send_pending_event_from_task();
        }
        if(vnd_tick_flag) vnd_tick_flag = 0;
        vnd_cdc_periodic_stats(now);
        return;
    }
#endif
    vnd_align_strict_pair_cursor();
    /* ВАЖНО: сначала попробуем подготовить пару A/B, чтобы не зациклиться на ранних STAT.
       Подготовка пары не зависит от занятости EP, поэтому убираем лишний гейтинг по vnd_ep_busy. */
    {
        ChanFrame *fA0 = &g_frames[pair_send_idx][0];
        if(fA0->st != FB_READY){ vnd_prepare_pair(); }
    }
    /* Раннее окно для GET_STATUS до первой пары — отключено: STAT по IN только между парами. */
    /* Подавляем TEST в фазе pending_init: сосредоточиться на ускорении первой A пары */
    if(vnd_pending_init){
        /* Быстрый init-pump: до 200 мс после START каждые ~2 мс пробуем подготовить и отправить A
           Расширено: используем текущий pair_fill_idx вместо жёсткого [0], добавлен ранний STAT и ослабленный fresh gating. */
        static uint32_t last_pump_ms = 0;
        extern volatile uint32_t frame_wr_seq;
        static uint32_t start_wr_seq_snapshot = 0; /* первый wr_seq на момент START */
        if(start_wr_seq_snapshot == 0){ start_wr_seq_snapshot = frame_wr_seq; }
        if(start_cmd_ms && (now - start_cmd_ms) < 200){
            if(now - last_pump_ms > 2){
                last_pump_ms = now;
                init_pump_attempts++;
                ChanFrame *fAfill = &g_frames[pair_send_idx][0];
                if(fAfill->st != FB_READY){ vnd_prepare_pair(); fAfill = &g_frames[pair_send_idx][0]; }
                     /* Ранний relax: первые 20 мс достаточно одного инкремента wr_seq, далее требуем +2.
                         Доп. послабление: после 100 мс позволяем отправить первую A даже без прироста wr_seq
                         (на случай, если ADC успел подготовить кадр, но счётчик ещё не вырос). */
                 uint32_t age_ms = now - start_cmd_ms;
                 #if USE_TEST_SAWTOOTH
                     uint8_t fresh_ok = 1u; /* в тестовом режиме не ждём рост wr_seq от ADC/DMA */
                 #else
                     uint8_t fresh_ok = (age_ms < 20) ? (frame_wr_seq > start_wr_seq_snapshot ? 1u : 0u)
                                                        : (frame_wr_seq > start_wr_seq_snapshot + 1 ? 1u : 0u);
                 #endif
                /* Защитная инициализация размера кадра если ADC уже дал конфигурацию, но SIZE_LOCK не прошёл */
                if(cur_samples_per_frame == 0 && age_ms > 25){
                    uint16_t prof_s = adc_stream_get_active_samples();
                    uint16_t eff_s = prof_s;
                    if(vnd_frame_samples_req && vnd_frame_samples_req < eff_s) eff_s = vnd_frame_samples_req;
                    if(vnd_trunc_samples && vnd_trunc_samples < eff_s) eff_s = vnd_trunc_samples;
                    if(eff_s > VND_MAX_SAMPLES) eff_s = VND_MAX_SAMPLES;
                    if(eff_s){
                        cur_samples_per_frame = eff_s;
                        cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)cur_samples_per_frame*2u);
                    }
                }
                /* Ещё один страховочный замок: после 60 мс если размер всё ещё 0 — попробуем взять текущий active_samples и вывести диагностику */
                if(cur_samples_per_frame == 0 && age_ms == 60){
                    uint16_t prof_s2 = adc_stream_get_active_samples();
                    uint16_t eff_s2 = prof_s2;
                    if(vnd_frame_samples_req && vnd_frame_samples_req < eff_s2) eff_s2 = vnd_frame_samples_req;
                    if(vnd_trunc_samples && vnd_trunc_samples < eff_s2) eff_s2 = vnd_trunc_samples;
                    if(eff_s2 > VND_MAX_SAMPLES) eff_s2 = VND_MAX_SAMPLES;
                    if(eff_s2){
                        cur_samples_per_frame = eff_s2;
                        cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + (uint32_t)cur_samples_per_frame*2u);
                    }
                    cdc_logf("INIT_DBG age=%lu wr=%lu fA_st=%u cur_s=%u ep_busy=%u",
                             (unsigned long)age_ms, (unsigned long)frame_wr_seq, (unsigned)fAfill->st,
                             (unsigned)cur_samples_per_frame, (unsigned)vnd_ep_busy);
                }
                /* Разрешаем первую A, если кадр готов и либо fresh_ok, либо прошло уже >100 мс (fallback) */
                if(fAfill->st == FB_READY && (fresh_ok || age_ms > 100) && !vnd_ep_busy){
                    if(!vnd_strict_slot_ready_for_stream(pair_send_idx)){ if(vnd_tick_flag) vnd_tick_flag = 0; return; }
                    if(vnd_transmit_frame(fAfill->buf, fAfill->frame_size, 0, 0, "ADC0-PUMP") == USBD_OK){
                        fAfill->st = FB_SENDING; sending_channel = 0;
                        pending_B = (vnd_ch_mode == 0)?0:1; if(pending_B) pending_B_since_ms = HAL_GetTick(); else pending_B_since_ms = 0;
                        vnd_pending_init = 0; vnd_stream_active = 1; init_pump_a_sent++;
                        VND_LOG("INIT_PUMP_A queued size=%u wr_seq=%lu age=%lums fresh=%u", (unsigned)fAfill->frame_size, (unsigned long)frame_wr_seq, (unsigned long)age_ms, (unsigned)fresh_ok);
                        /* После первой A выходим из init-pump */
                    }
                }
            }
        }
    } else {
        /* Старое окно отправки TEST переносим сюда (вне pending_init), если TEST разрешён */
        if(!test_sent && !test_in_flight){
            if(!vnd_ep_busy && (now - start_cmd_ms) > 50){
#if !VND_DISABLE_TEST
                vnd_try_send_test_from_task();
#endif
                if(vnd_ep_busy){ if(vnd_tick_flag) vnd_tick_flag = 0; return; }
            }
        }
    }
    /* CRITICAL WATCHDOG: если TxCplt не пришёл слишком долго, сбрасываем inflight.
       Причина: на Windows хост может "забыть" забрать данные или ZLP не отправился.
       Без этого устройство зависает с vnd_inflight=1 навсегда. */
    if(vnd_stream_mode == VND_STREAM_MODE_LATEST && vnd_inflight){
        uint32_t dt_ms = 0u;
        if(vnd_tick_age_ms(now, vnd_last_tx_start_ms, &dt_ms) && dt_ms > VND_USB_IN_BUSY_STALL_MS){
            extern uint8_t USBD_VND_TxIsBusy(void);
            uint8_t ll_busy = USBD_VND_TxIsBusy();
            if(!vnd_usb_in_active_abort_allowed(ll_busy, dt_ms)){
                vnd_usb_in_note_active_hold("latest_inflight", now, dt_ms);
            } else {
                VND_LOG("WATCHDOG: vnd_inflight stuck for %lums, drop current unit", (unsigned long)dt_ms);
                cdc_logf("!!! WATCHDOG: TX stuck, drop current unit (dt=%lu ms)", (unsigned long)dt_ms);
                vnd_usb_in_drop_recover("latest_inflight", now, dt_ms);
            }
        }
    }
    if((vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI) &&
       vnd_inflight && vnd_last_tx_start_ms != 0 && sending_channel == 0 && pending_B){
        uint32_t dt_ms = 0u;
        if(vnd_tick_age_ms(now, vnd_last_tx_start_ms, &dt_ms) && dt_ms > VND_USB_IN_BUSY_STALL_MS){
            uint8_t wd_slot = vnd_get_active_stream_slot(pending_B ? 1u : 0u);
            ChanFrame *wdA = &g_frames[wd_slot][0];
            uint32_t wd_seq = wdA->seq;
            extern uint8_t USBD_VND_TxIsBusy(void);
            uint8_t ll_busy = USBD_VND_TxIsBusy();
            if(!vnd_usb_in_active_abort_allowed(ll_busy, dt_ms)){
                vnd_usb_in_note_active_hold("lossless_a_wd", now, dt_ms);
                goto lossless_a_wd_done;
            }
            vnd_usb_in_drop_recover("lossless_a_wd", now, dt_ms);
            (void)wd_seq;
            VND_LOG("LOSSLESS_A_DROP dt=%lums seq=%lu slot=%u", (unsigned long)dt_ms, (unsigned long)wd_seq, (unsigned)wd_slot);
        }
    }
lossless_a_wd_done:
    if((vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI) &&
       vnd_inflight && vnd_last_tx_start_ms != 0 && sending_channel == 1 && pending_B){
        uint32_t dt_ms = 0u;
        if(vnd_tick_age_ms(now, vnd_last_tx_start_ms, &dt_ms) && dt_ms > VND_USB_IN_BUSY_STALL_MS){
            uint8_t wd_slot = vnd_get_active_stream_slot(1u);
            ChanFrame *wdB = &g_frames[wd_slot][1];
            uint32_t wd_seq = wdB->seq;
            extern uint8_t USBD_VND_TxIsBusy(void);
            uint8_t ll_busy = USBD_VND_TxIsBusy();
            if(!vnd_usb_in_active_abort_allowed(ll_busy, dt_ms)){
                vnd_usb_in_note_active_hold("lossless_b_wd", now, dt_ms);
                goto lossless_b_wd_done;
            }
            vnd_usb_in_drop_recover("lossless_b_wd", now, dt_ms);
            if(!first_pair_done){ first_pair_done = 1; }
            (void)wd_seq;
            VND_LOG("LOSSLESS_B_DROP dt=%lums seq=%lu slot=%u", (unsigned long)dt_ms, (unsigned long)wd_seq, (unsigned)wd_slot);
        }
    }
lossless_b_wd_done:
    
    uint32_t test_tx_age_ms = 0u;
    if(test_in_flight &&
       vnd_tick_age_ms(now, vnd_last_tx_start_ms, &test_tx_age_ms) &&
       test_tx_age_ms > 100u){
        /* На некоторых хостах (FS/RPi) DataIn может не вызваться после короткого TEST.
           Чтобы не зависнуть с занятым EP, снимаем busy и продолжаем. */
    test_in_flight = 0;
    test_sent = 1;
    vnd_ep_busy = 0;
    vnd_tx_ready = 1;
    extern void USBD_VND_ForceTxIdle(void); USBD_VND_ForceTxIdle();
        vnd_tx_kick = 1;
        VND_LOG("TEST_TIMEOUT -> unlock EP");
    }
    if(!test_sent && !vnd_pending_init){
        if(!vnd_ep_busy){
#if !VND_DISABLE_TEST
            vnd_try_send_test_from_task();
#endif
        }
        /* Не выходим раньше времени: позволим подготовку/отправку A/B идти параллельно. */
    }

    if(diag_mode_active){
        /* Зафиксируем размер один раз */
        if(cur_samples_per_frame == 0){
            uint16_t s = diag_samples; if(s > VND_MAX_SAMPLES) s = VND_MAX_SAMPLES;
            cur_samples_per_frame = s;
            cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + cur_samples_per_frame*2u);
        }
        /* Подготовить пару для текущего stream_seq, если ещё не подготовлена и не идёт передача */
        if(sending_channel == 0xFF && !pending_B && diag_prepared_seq != stream_seq){
            vnd_diag_prepare_pair(stream_seq, cur_samples_per_frame);
            diag_prepared_seq = stream_seq;
        }
        /* В DIAG STAT через bulk полностью заблокирован (см. vnd_try_send_pending_status_from_task) */
        /* Отправка диагностических кадров без темпирования: A затем B */
        if(!vnd_ep_busy){ (void)vnd_diag_try_tx(); }
        if(vnd_tick_flag) vnd_tick_flag = 0;
        vnd_cdc_periodic_stats(now);
        return;
    }
    
    if(!full_mode){ if(vnd_tick_flag) vnd_tick_flag = 0; return; }

    /* Новый упрощённый путь: асинхронная передача A/B без ожидания пары.
       В тестовом режиме (USE_TEST_SAWTOOTH) async отключаем, чтобы не выйти
       из таска без фактической отправки кадров. */
#if !USE_TEST_SAWTOOTH
    if(async_mode){
        /* Всегда стараться иметь подготовленные пары */
        ChanFrame *fa0 = &g_frames[pair_fill_idx][0];
        if(fa0->st != FB_READY){ vnd_prepare_pair(); }
        if(!vnd_ep_busy && !vnd_inflight && vnd_can_preempt_stream_with_event()){
            vnd_try_send_pending_event_from_task();
            if(vnd_ep_busy){ if(vnd_tick_flag) vnd_tick_flag = 0; return; }
        }
        if(!vnd_ep_busy){ (void)vnd_async_try_tx(); }
        if(!vnd_ep_busy && !vnd_inflight && vnd_has_pending_event()){
            vnd_try_send_pending_event_from_task();
        }
        if(vnd_tick_flag) vnd_tick_flag = 0;
        vnd_cdc_periodic_stats(now);
        return;
    }
#endif

    /* Упреждающая подготовка пары: когда TEST уже завершён и B не ожидается. */
    if(test_sent && !pending_B){
        ChanFrame *fa_chk = &g_frames[pair_send_idx][0];
        if(fa_chk->st != FB_READY){ vnd_prepare_pair(); }
    }

    /* Окно для GET_STATUS: отправлять STAT строго между парами, чтобы не разрывать A/B. */
    if(!vnd_ep_busy && !vnd_inflight && vnd_has_pending_event()){
        if (test_sent && !pending_B && first_pair_done && sending_channel == 0xFF) {
            vnd_try_send_pending_event_from_task();
            if(vnd_ep_busy){ if(vnd_tick_flag) vnd_tick_flag = 0; return; }
        }
    }

    if(!vnd_ep_busy && !vnd_inflight && pending_status){
        if (test_sent && !pending_B && first_pair_done && sending_channel == 0xFF) {
            vnd_try_send_pending_status_from_task();
            if(vnd_ep_busy){ if(vnd_tick_flag) vnd_tick_flag = 0; return; }
        }
    }

    if(vnd_tx_kick) vnd_tx_kick = 0;
    
    /* Разрешаем подготовку следующей пары даже если EP занят (параллельная заполнение буферов) */
    /* if(vnd_ep_busy){ if(vnd_tick_flag) vnd_tick_flag = 0; return; } */

    /* Если TEST уже логически завершён, но его мета застряла в FIFO (нет TxCplt) —
       через ~60 мс превращаем её в служебную, чтобы не блокировать отправку A. */
    vnd_force_complete_test_meta_if_stale();

    static __attribute__((unused)) uint8_t first_pair_logged = 0; /* диагностический лог первой пары */

    static uint8_t first_bq_logged = 0; /* однократный лог первой постановки B */
    if(pending_B){
        /* В A-only режиме не ждём B, сразу продолжим к следующему A */
        if(vnd_ch_mode == 0){
            ChanFrame *f0 = &g_frames[pair_send_idx][0];
            ChanFrame *f1 = &g_frames[pair_send_idx][1];
            f0->st = f1->st = FB_FILL;
            pair_send_idx = (uint8_t)((pair_send_idx + 1u) % VND_PAIR_BUFFERS);
            stream_seq++; dbg_produced_seq++;
            pending_B = 0; pending_B_since_ms = 0; sending_channel = 0xFF;
            /* Попробуем запланировать немедленную отправку следующего A */
            ChanFrame *fA2 = &g_frames[pair_send_idx][0];
            if(fA2->st != FB_READY){ vnd_prepare_pair(); }
            if(fA2->st == FB_READY && !vnd_ep_busy){
                if(!vnd_strict_slot_ready_for_stream(pair_send_idx)){ return; }
                if (vnd_transmit_frame(fA2->buf, fA2->frame_size, 0, 0, "ADC0-IMM-AONLY") == USBD_OK){
                    fA2->st = FB_SENDING; sending_channel = 0; return; }
            }
            /* если не получилось — просто продолжим общий цикл */
        }
        /* В режиме ожидания B нельзя пересобирать текущий слот:
           A уже мог уйти на хост, и новая подготовка здесь приведёт к "B без A". */
        uint8_t b_slot = vnd_get_active_stream_slot(1u);
        ChanFrame *fB = &g_frames[b_slot][1];
        if(fB->st == FB_READY && !vnd_strict_slot_ready_for_stream(b_slot)){
            if(vnd_tick_flag) vnd_tick_flag = 0;
            return;
        }
        if(fB->st == FB_READY){
            USBD_StatusTypeDef rcB = vnd_transmit_frame(fB->buf, fB->frame_size, 0, 0, "ADC1");
            if (rcB == USBD_OK) {
                if(!first_bq_logged){ first_bq_logged = 1; VND_LOG("FIRST_B queued size=%u", (unsigned)fB->frame_size); }
                fB->st = FB_SENDING; sending_channel = 1; return;
            } else if (rcB == USBD_BUSY) {
                static uint32_t b_busy_retry = 0; b_busy_retry++;
                if (!vnd_last_tx_pace_busy && (b_busy_retry == 1 || (b_busy_retry % 10) == 0)) {
                    VND_LOG("B_BUSY_RETRY cnt=%lu", (unsigned long)b_busy_retry);
                }
                /* оставляем кадр в READY и попробуем позже */
            } else {
                VND_LOG("B_TX_FAIL rc=%d", (int)rcB);
            }
        } else {
            /* Диагностируем, почему ждём B: выводим периодически и в CDC (1 Гц) текущее состояние */
            static uint32_t last_log_ms = 0;
            static uint32_t last_cdc_ms = 0;
            uint32_t now_ms = HAL_GetTick();
            if(now_ms - last_log_ms > 200){
                VND_LOG("WAIT_B st=%u seq=%lu cur_seq=%lu", (unsigned)fB->st, (unsigned long)fB->seq, (unsigned long)stream_seq);
                last_log_ms = now_ms;
            }
            if(now_ms - last_cdc_ms > 1000){
                extern uint8_t USBD_VND_TxIsBusy(void);
                uint8_t ll_busy = USBD_VND_TxIsBusy();
                const char *stA = (g_frames[0][0].st==FB_READY?"READY":(g_frames[0][0].st==FB_SENDING?"SENDING":"FILL"));
                const char *stB = (g_frames[0][1].st==FB_READY?"READY":(g_frames[0][1].st==FB_SENDING?"SENDING":"FILL"));
                uint32_t age_ms = 0u;
                if(!vnd_tick_age_ms(now_ms, pending_B_since_ms, &age_ms)){
                    age_ms = 0u;
                }
                cdc_logf("DBG WAIT_B age=%lums A=%s B=%s ep_busy=%u ll_busy=%u metaDepth=%u lastTX=%u", (unsigned long)age_ms, stA, stB, (unsigned)vnd_ep_busy, (unsigned)ll_busy, (unsigned)vnd_tx_meta_depth(), (unsigned)vnd_last_tx_len);
                last_cdc_ms = now_ms;
            }
            /* Watchdog B: если B уже ушёл в полёт и TxCplt потерялся,
               считаем текущую единицу потока потерянной и идём дальше без повтора. */
            uint32_t b_wd_age_ms = 0u;
            if(fB->st == FB_SENDING &&
               vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &b_wd_age_ms) &&
               b_wd_age_ms > VND_USB_IN_BUSY_STALL_MS){
                uint32_t b_wd_seq = g_frames[b_slot][1].seq;
                extern uint8_t USBD_VND_TxIsBusy(void);
                uint8_t ll_busy = USBD_VND_TxIsBusy();
                if(!vnd_usb_in_active_abort_allowed(ll_busy, b_wd_age_ms)){
                    vnd_usb_in_note_active_hold("b_txcplt_wd", now_ms, b_wd_age_ms);
                    goto wait_b_watchdog_done;
                }
                vnd_usb_in_drop_recover("b_txcplt_wd", now_ms, b_wd_age_ms);
                (void)b_wd_seq;
                VND_LOG("B_TXCPLT_DROP seq=%lu slot=%u age=%lums", (unsigned long)b_wd_seq, (unsigned)b_slot, (unsigned long)b_wd_age_ms);
            }
wait_b_watchdog_done:
            /* Не синтезируем B: ждём реальные данные, пока EP свободен */
        }
        /* Дополнительный watchdog зависшего pending_B, даже если fB->st перешёл из READY в FILL из-за сброса */
        do {
            uint32_t now_ms2 = HAL_GetTick();
            uint32_t last_txcplt_age_ms = 0u;
            if(vnd_stream_mode == VND_STREAM_MODE_LATEST &&
               !vnd_ep_busy && sending_channel == 0xFF &&
               vnd_tick_age_ms(now_ms2, vnd_last_txcplt_ms, &last_txcplt_age_ms) &&
               last_txcplt_age_ms > 40u){
                uint8_t chk_slot = vnd_get_active_stream_slot(1u);
                ChanFrame *fBchk = &g_frames[chk_slot][1];
                ChanFrame *fAchk = &g_frames[chk_slot][0];
                if(fAchk->st != FB_SENDING && fBchk->st != FB_SENDING){
                    if(fBchk->st == FB_READY){
                        pair_send_idx = chk_slot;
                        if (vnd_transmit_frame(fBchk->buf, fBchk->frame_size, 0, 0, "ADC1-WDG") == USBD_OK){
                            fBchk->st = FB_SENDING; sending_channel = 1; VND_LOG("PEND_B_WDG_RETRY len=%u slot=%u", (unsigned)fBchk->frame_size, (unsigned)chk_slot); return; }
                    }
                    /* Строгий порядок A→B: НЕ сбрасываем pending_B.
                       Ждём или синтезируем B выше (см. B_SYNTH_READY), чтобы закрыть пару. */
                    if(fBchk->st != FB_READY){
                        VND_LOG("PEND_B_WDG_WAIT (slot=%u a_st=%u b_st=%u seq=%lu)", (unsigned)chk_slot, (unsigned)fAchk->st, (unsigned)fBchk->st, (unsigned long)stream_seq);
                    }
                }
            }
        } while(0);
    } else {
    uint8_t a_slot = vnd_get_active_stream_slot(0u);
    pair_send_idx = a_slot;
    ChanFrame *fA = &g_frames[a_slot][0];
        /* Watchdog: если A завис в SENDING и долго нет TxCplt — сбрасываем его без повтора. */
        do {
            uint32_t now_ms = HAL_GetTick();
            uint32_t a_wd_age_ms = 0u;
            if (vnd_stream_mode == VND_STREAM_MODE_LATEST &&
                fA->st == FB_SENDING &&
                vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &a_wd_age_ms) &&
                a_wd_age_ms > VND_USB_IN_BUSY_STALL_MS) {
                extern uint8_t USBD_VND_TxIsBusy(void);
                uint8_t ll_busy = USBD_VND_TxIsBusy();
                if(!vnd_usb_in_active_abort_allowed(ll_busy, a_wd_age_ms)){
                    vnd_usb_in_note_active_hold("a_txcplt_wd", now_ms, a_wd_age_ms);
                } else {
                    VND_LOG("A_TXCPLT_WD -> drop current unit");
                    vnd_usb_in_drop_recover("a_txcplt_wd", now_ms, a_wd_age_ms);
                }
            }
        } while(0);
        if(fA->st != FB_READY){ 
            vnd_prepare_pair(); 
            a_slot = vnd_get_active_stream_slot(0u);
            pair_send_idx = a_slot;
            fA = &g_frames[a_slot][0]; 
        }
    if(fA->st == FB_READY){
            if(!vnd_strict_slot_ready_for_stream(a_slot)){
                if(vnd_tick_flag) vnd_tick_flag = 0;
                return;
            }
            /* Искусственных задержек между кадрами нет: отправляем A сразу при готовности EP и данных */
            /* Отправляем A: в режиме без TEST не проверяем test_in_flight вовсе */
#if VND_DISABLE_TEST
            VND_LOG("TRY_A len=%u hdr_seq=%lu", (unsigned)fA->frame_size, (unsigned long)((vnd_frame_hdr_t*)fA->buf)->seq);
            if (vnd_transmit_frame(fA->buf, fA->frame_size, 0, 0, "ADC0") == USBD_OK) {
                static uint8_t first_a_logged = 0;
                if(!first_a_logged){ first_a_logged = 1; VND_LOG("FIRST_A queued size=%u", (unsigned)fA->frame_size); }
                fA->st = FB_SENDING; sending_channel = 0;
                pending_B = (vnd_ch_mode == 0) ? 0 : 1; if(pending_B) pending_B_since_ms = HAL_GetTick(); else pending_B_since_ms = 0;
                return;
            } else {
                /* ДИАГНОСТИКА: почему не удалось отправить A */
                static uint32_t last_tx_fail_log = 0;
                if((now - last_tx_fail_log) > 500){
                    last_tx_fail_log = now;
                    extern uint8_t USBD_VND_TxIsBusy(void);
                    cdc_logf("FAIL_TX_A ep_busy=%u ll_busy=%u inflight=%u ready=%u",
                        (unsigned)vnd_ep_busy, (unsigned)USBD_VND_TxIsBusy(), (unsigned)vnd_inflight, (unsigned)vnd_tx_ready);
                }
            }
#else
            /* Отправляем A только если нет теста в полёте и нет необработанного TEST в FIFO */
            if(!test_in_flight){
                if (vnd_transmit_frame(fA->buf, fA->frame_size, 0, 0, "ADC0") == USBD_OK) {
                    static uint8_t first_a_logged = 0;
                    if(!first_a_logged){ first_a_logged = 1; VND_LOG("FIRST_A queued size=%u", (unsigned)fA->frame_size); }
                    fA->st = FB_SENDING; sending_channel = 0;
                    pending_B = 1; pending_B_since_ms = HAL_GetTick();
                    return;
                }
            }
#endif
        }
    }
    if(vnd_tick_flag) vnd_tick_flag = 0;
    if(cur_samples_per_frame == 0 && start_cmd_ms && (now - start_cmd_ms) > VND_DMA_TIMEOUT_MS && !no_dma_status_sent){
        adc_stream_debug_t dbg; adc_stream_get_debug(&dbg);
        if(dbg.dma_full0 == dma_snapshot_full0 && dbg.dma_full1 == dma_snapshot_full1){ no_dma_status_sent = 1; if(vnd_last_error == 0) vnd_last_error = 1; VND_LOG("ERR DMA_TIMEOUT"); }
    }
    /* Периодическая CDC-статистика по байтам/скорости */
    vnd_cdc_periodic_stats(now);
    
    /* ДИАГНОСТИКА: детальное состояние передачи каждые 2 секунды */
    {
        static uint32_t last_diag_detail_ms = 0;
        if(streaming && (now - last_diag_detail_ms) > 2000){
            last_diag_detail_ms = now;
            extern uint8_t USBD_VND_TxIsBusy(void);
            uint8_t ll_busy = USBD_VND_TxIsBusy();
            ChanFrame *fA = &g_frames[0][0];
            ChanFrame *fB = &g_frames[0][1];
            const char *stA = (fA->st==FB_READY?"RDY":(fA->st==FB_SENDING?"SND":"FIL"));
            const char *stB = (fB->st==FB_READY?"RDY":(fB->st==FB_SENDING?"SND":"FIL"));
            cdc_logf("DBG ep_busy=%u ll_busy=%u ch=%u pendB=%u A_st=%s B_st=%s metaD=%u",
                (unsigned)vnd_ep_busy, (unsigned)ll_busy, (unsigned)sending_channel, (unsigned)pending_B,
                stA, stB, (unsigned)vnd_tx_meta_depth());
        }
    }
    
    /* Периодическое обновление дисплея LCD с информацией о потоке */
    // stream_display_periodic_update();
    vnd_usb_in_drop_recovery_poll(now);
    /* Аварийный keepalive тестом — только в диагностике; в полном режиме не посылаем TEST повторно */
    if(!full_mode){
        /* В DIAG режиме можно слать keepalive TEST — оставляем как было. */
    if(dbg_tx_cplt == 0 && (now - start_cmd_ms) > 150 && !vnd_ep_busy){
#if !VND_DISABLE_TEST
        vnd_emergency_keepalive(now);
#endif
    }
    }
    /* Периодический диагностический лог ранней стадии: пока нет ни одного TXCPLT или отсутствует прогресс */
    do {
        static uint32_t last_diag_ms = 0;
        static uint32_t last_diag_txcplt = 0;
        if(now - last_diag_ms > 200){
            if(dbg_tx_cplt == 0 || dbg_tx_cplt != last_diag_txcplt){
                /* Получим отладочные счётчики DMA, если доступны */
                VND_LOG("DIAG txcplt=%lu test_sent=%u test_in_flight=%u pendB=%u ep_busy=%u inflight=%u ch=%u ackPend=%u seq=%lu prod=%lu sent0=%lu sent1=%lu wr=%lu rd=%lu metaDepth=%u", (unsigned long)dbg_tx_cplt, (unsigned)test_sent, (unsigned)test_in_flight, (unsigned)pending_B, (unsigned)vnd_ep_busy, (unsigned)vnd_inflight, (unsigned)sending_channel, (unsigned)status_ack_pending, (unsigned long)stream_seq, (unsigned long)dbg_produced_seq, (unsigned long)dbg_sent_ch0_total, (unsigned long)dbg_sent_ch1_total, (unsigned long)frame_wr_seq, (unsigned long)frame_rd_seq, (unsigned)vnd_tx_meta_depth());
                last_diag_txcplt = dbg_tx_cplt;
            }
            last_diag_ms = now;
        }
    } while(0);
    
    /* === FPS отчёт каждые 2 секунды === */
    if(streaming && (now - fps_last_report_ms) > 2000){
        vnd_report_fps_stats();
        fps_last_report_ms = now;
    }

    /* Ускоренный watchdog: считаем зависанием при > 3000мс без TXCPLT и мягко пинаем TX */
    uint32_t txcplt_kick_age = 0u;
    if(streaming &&
       vnd_usb_in_has_recoverable_state() &&
       vnd_tick_age_ms(now, vnd_last_txcplt_ms, &txcplt_kick_age) &&
       txcplt_kick_age > 3000u){
        VND_LOG("WDG_KICK (no TXCPLT >3s) drop current unit");
        vnd_tx_drop_recovery_request = 1u;
        vnd_usb_in_drop_recovery_poll(now);
        /* Важно: не использовать async-путь в ROI режимах, иначе он обходит prepare_pair/AVG очередь
           и начинает слать "сырой" поток. */
        if(async_mode && full_mode && !diag_mode_active && (vnd_stream_mode == VND_STREAM_MODE_LATEST)){
            (void)vnd_async_try_tx();
        }
    }

    /* Fallback стартовой инициализации: если после START прошло >20 мс и ни одного рабочего кадра не ушло,
       пытаемся принудительно подготовить и отправить A кадр первой пары. */
    if(streaming && vnd_pending_init && !vnd_stream_active){
        if(start_cmd_ms && (now - start_cmd_ms) > 20){
            ChanFrame *fA = &g_frames[pair_send_idx][0];
            if(fA->st != FB_READY){ vnd_prepare_pair(); fA = &g_frames[pair_send_idx][0]; }
            if(fA->st == FB_READY && !vnd_ep_busy){
                if(!vnd_strict_slot_ready_for_stream(pair_send_idx)){ return; }
                if(vnd_transmit_frame(fA->buf, fA->frame_size, 0, 0, "ADC0-KICK") == USBD_OK){
                    fA->st = FB_SENDING; sending_channel = 0;
                    pending_B = (vnd_ch_mode == 0) ? 0 : 1; if(pending_B) pending_B_since_ms = HAL_GetTick(); else pending_B_since_ms = 0;
                    vnd_pending_init = 0; /* считаем инициализацию выполненной */
                    vnd_stream_active = 1; /* поток активен */
                    VND_LOG("START_FALLBACK_KICK A queued size=%u", (unsigned)fA->frame_size);
                }
            }
        }
    }

    /* Если нет прогресса — не синтезируем кадры; ждём реальные данные от АЦП */
}

/* TIM16 input-capture callback (slave sync) */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    if(!htim) return;
    if(htim->Instance != TIM16) return;
    if(vnd_sync_mode != VND_SYNC_MODE_SLAVE) return;

    uint32_t cap = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
    if(!vnd_sync_capture_valid){
        vnd_sync_last_capture = cap;
        vnd_sync_capture_valid = 1;
        vnd_sync_last_capture_ms = HAL_GetTick();
        return;
    }
    uint32_t last = vnd_sync_last_capture;
    vnd_sync_last_capture = cap;
    vnd_sync_last_capture_ms = HAL_GetTick();

    uint32_t diff = (cap >= last) ? (cap - last) : ((0x10000u - last) + cap);
    if(diff == 0u) return;

    uint32_t tick_hz = vnd_sync_tick_hz ? vnd_sync_tick_hz : 1000000u;
    uint32_t hz = tick_hz / diff;
    if(hz < 20u || hz > 1000u) return;

    vnd_sync_pending_hz = (uint16_t)hz;
}

/* Обработчик завершения передачи */
void USBD_VND_TxCplt(void)
{
    uint8_t prev_sending = sending_channel;
    dbg_tx_cplt++;
    vnd_tx_ready = 1;
    vnd_ep_busy = 0;
    vnd_inflight = 0;
    
    /* ПРОФИЛИРОВАНИЕ: интервал между TxCplt */
    static uint32_t last_txcplt_time = 0;
    static uint32_t txcplt_interval_sum = 0;
    static uint32_t txcplt_interval_count = 0;
    static uint32_t txcplt_interval_max = 0;
    static uint32_t last_txcplt_log = 0;
    
    uint32_t now_txcplt = HAL_GetTick();
    if(last_txcplt_time > 0){
        uint32_t interval = now_txcplt - last_txcplt_time;
        txcplt_interval_sum += interval;
        txcplt_interval_count++;
        if(interval > txcplt_interval_max) txcplt_interval_max = interval;
        
        if(now_txcplt - last_txcplt_log >= 5000){
            __attribute__((unused)) uint32_t avg = txcplt_interval_count ? (txcplt_interval_sum / txcplt_interval_count) : 0;
                 VND_PROF_LOGF("[PROF_TxCplt] cnt=%lu avg=%lums max=%lums (rate=%.1fHz)\r\n",
                     txcplt_interval_count, avg, txcplt_interval_max,
                     avg > 0 ? (1000.0f / avg) : 0.0f);
            txcplt_interval_sum = 0;
            txcplt_interval_count = 0;
            txcplt_interval_max = 0;
            last_txcplt_log = now_txcplt;
        }
    }
    last_txcplt_time = now_txcplt;
    
    vnd_last_txcplt_ms = now_txcplt;
    /* Убран подробный лог TXCPLT — используется агрегированная статистика раз в 10 сек */
    vnd_total_tx_bytes += vnd_last_tx_len; /* учитывать и тестовые, и статусные, и рабочие */
    /* Зафиксировать завершение стартового ACK (если был) */
    if(start_stat_inflight){ start_stat_inflight = 0; start_ack_done = 1; }

    /* Надёжная классификация завершившегося буфера (приоритет inflight_* затем meta FIFO).
       Если источника классификации нет, считаем callback повторным/запоздавшим и игнорируем,
       иначе можно повторно закрыть уже завершённую пару и искусственно создать seq gap. */
    vnd_tx_meta_t meta; int have_meta = vnd_tx_meta_pop(&meta);
    uint8_t eff_is_frame = 0; uint8_t eff_flags = 0; uint32_t eff_seq = 0;
    if(inflight_is_frame){ eff_is_frame = 1; eff_flags = inflight_flags; eff_seq = inflight_seq; }
    else if(have_meta && meta.is_frame){ eff_is_frame = 1; eff_flags = meta.flags; eff_seq = meta.seq_field; }
    else if(have_meta){ eff_is_frame = 0; }
    else {
        inflight_is_frame = 0; inflight_flags = 0; inflight_seq = 0;
        vnd_tx_kick = 1;
        VND_LOG("SPURIOUS_TXCPLT: no inflight/meta, prev_sending=%u last_flags=0x%02X", (unsigned)prev_sending, (unsigned)last_tx_flags);
        return;
    }
    inflight_is_frame = 0; inflight_flags = 0; inflight_seq = 0;
    /* Убран подробный лог TXCPLT_CLASS — используется агрегированная статистика */

    /* Если это был ACK на STOP — после него переводим систему в остановленное состояние */
    if(stop_stat_inflight){
        stop_stat_inflight = 0;
        stop_request = 0;
        if(streaming){ streaming = 0; VND_LOG("STOP_STREAM after STAT"); }
        vnd_last_host_rx_ack_ms = 0;
        vnd_host_rx_last_counter = 0;
        vnd_host_rx_counter_valid = 0;
        diag_mode_active = 0;
        vnd_reset_buffers();
        sending_channel = 0xFF; pending_B = 0; test_sent = 0; test_in_flight = 0; vnd_inflight = 0;
        /* STOP is USB-only: acquisition, marker and master SYNC continue. */
        /* Индикация STOP: погасить пин Data_ready и вывести CDC-событие */
        HAL_GPIO_WritePin(Data_ready_GPIO22_GPIO_Port, Data_ready_GPIO22_Pin, GPIO_PIN_RESET);
        (void)vnd_tx_refresh_effective(HAL_GetTick(), "stop_ack");
        {
            uint64_t cur = vnd_total_tx_bytes;
            uint64_t delta = (cur >= vnd_tx_bytes_at_start) ? (cur - vnd_tx_bytes_at_start) : 0ULL;
            cdc_logf("EVT STOP total=%llu delta=%llu", (unsigned long long)cur, (unsigned long long)delta);
        }
        vnd_tx_kick = 1; /* пнуть таск на всякий случай */
        return;
    }
    if(!eff_is_frame){
        if(vnd_event_inflight_type != 0xFFu){
            dbg_event_tx_cplt++;
            dbg_event_last_cplt_type = vnd_event_inflight_type;
            vnd_event_inflight_type = 0xFFu;
            vnd_event_inflight_len = 0u;
        }
        /* STAT/EVT1/DCCF are service packets, not ADC/TEST frames. */
        vnd_tx_kick = 1;
        return;
    }
    if(test_in_flight)
    {
        test_in_flight = 0;
        test_sent = 1; /* помечаем тест выполненным ровно один раз, не сбрасывать вне START */
        first_test_sent_ms = HAL_GetTick();
        VND_LOG("TEST_TXCPLT");
        return;
    }
    if(!streaming){ vnd_tx_kick = 1; return; }

    /* Первая успешная рабочая передача (A или B): зафиксировать метку, если ещё не установлена */
    uint8_t eff_ch_bits_pre = (uint8_t)(eff_flags & 0x03u);
    if(vnd_stage_first_frame_ms == 0 && eff_is_frame && (eff_ch_bits_pre == 0x01 || eff_ch_bits_pre == 0x02)){
        vnd_stage_first_frame_ms = HAL_GetTick();
    }
    if(eff_is_frame && (eff_ch_bits_pre == 0x01 || eff_ch_bits_pre == 0x02)){
        vnd_last_frame_txcplt_ms = now_txcplt;
        vnd_frame_pace_arm(now_txcplt);
        if(vnd_last_error != 0u){
            vnd_last_error = 0;
        }
    }
    if(eff_is_frame && ((eff_flags & 0x03u) == 0x01u || (eff_flags & 0x03u) == 0x02u)){
        vnd_tx_kick = 1;
    }
#if VND_TXCPLT_START_RAW_NEXT
    if(streaming && !vnd_ep_busy && async_mode && full_mode && !diag_mode_active &&
       (vnd_stream_mode == VND_STREAM_MODE_LATEST)){
        (void)vnd_async_try_tx();
    }
#endif

    /* Асинхронный режим: считаем канал по eff_flags, закрываем соответствующий подкадр.
       В A-only/B-only режиме закрываем сразу всю пару и сдвигаем seq. */
    if(async_mode && streaming && full_mode){
        uint8_t eff_ch_bits = (uint8_t)(eff_flags & 0x03u);
        if(eff_is_frame && (eff_ch_bits == 0x01 || eff_ch_bits == 0x02)){
            int ch = (eff_ch_bits == 0x01) ? 0 : 1;
            if(vnd_pending_init){ vnd_pending_init = 0; }
            vnd_stream_active = 1;
            /* Учёт статистики по каналам (оценка сэмплов по текущему размеру кадра) */
            /* Статистика: если размер ещё не зафиксирован, используем активный профиль с учётом ограничений */
            uint16_t ns = cur_samples_per_frame;
            if(ns == 0){
                uint16_t eff = adc_stream_get_active_samples();
                if(eff == 0) eff = 1;
                if(vnd_frame_samples_req && vnd_frame_samples_req < eff) eff = vnd_frame_samples_req;
                if(vnd_trunc_samples && vnd_trunc_samples < eff) eff = vnd_trunc_samples;
                if(eff > VND_MAX_SAMPLES) eff = VND_MAX_SAMPLES;
                ns = eff;
            }
            if(ch==0){ dbg_tx_sent++; dbg_sent_ch0_total++; dbg_sent_seq_adc0++; vnd_total_tx_samples += (uint64_t)ns; fps_frame_a_count++; }
            else      { dbg_tx_sent++; dbg_sent_ch1_total++; dbg_sent_seq_adc1++; vnd_total_tx_samples += (uint64_t)ns; fps_frame_b_count++; }
            /* Отпускаем канал */
            sending_channel = 0xFF;
            if(vnd_stage_first_frame_ms == 0){ vnd_stage_first_frame_ms = HAL_GetTick(); cdc_logf("EVT FIRST_FRAME ch=%c", ch==0?'A':'B'); }
            vnd_tx_kick = 1;
#if VND_TXCPLT_START_RAW_NEXT
            if(!vnd_ep_busy && !diag_mode_active &&
               (vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI)){
                (void)vnd_async_try_tx();
            }
#endif
        }
        return;
    }

    /* Диагностический режим: используем eff_flags для точной классификации (устраняет гонку по sending_channel) */
    if(diag_mode_active){
        if(!eff_is_frame){
            /* STAT/ZLP — просто продолжим */
            vnd_tx_kick = 1; return;
        }
        uint8_t diag_ch_bits = (uint8_t)(eff_flags & 0x03u);
        if(diag_ch_bits == 0x01u){
            /* Завершился A: считаем и просим отправить B */
            dbg_tx_sent++; dbg_sent_ch0_total++; dbg_sent_seq_adc0++;
            /* В DIAG считаем семплы по текущему размеру кадра */
            vnd_total_tx_samples += (uint64_t)((cur_samples_per_frame != 0) ? cur_samples_per_frame : diag_samples);
            sending_channel = 0; /* завершили A */
            pending_B = 1; pending_B_since_ms = HAL_GetTick();
            /* Зафиксируем seq этой пары для B */
            diag_current_pair_seq = eff_seq;
            /* Немедленно пытаемся отправить B, чтобы убрать паузу между A и B */
            if(!vnd_try_send_B_immediate()){
                /* печать в CDC отключена для максимальной скорости */
                vnd_tx_kick = 1; return;
            } else {
                /* B пошёл в полёт — дальше обычная обработка после его завершения */
                return;
            }
        } else if(diag_ch_bits == 0x02u){
            /* Завершился B: закрываем пару, двигаем seq */
            dbg_tx_sent++; dbg_sent_ch1_total++; dbg_sent_seq_adc1++;
            vnd_total_tx_samples += (uint64_t)((cur_samples_per_frame != 0) ? cur_samples_per_frame : diag_samples);
            stream_seq++; dbg_produced_seq++;
            pending_B = 0; pending_B_since_ms = 0; sending_channel = 0xFF;
            diag_prepared_seq = 0xFFFFFFFFu; /* заставим подготовить новую пару */
            if(!first_pair_done){ first_pair_done = 1; }
            /* Сразу пытаемся отправить следующий A новой пары */
            if(!vnd_try_send_A_nextpair_immediate()){
                /* печать в CDC отключена для максимальной скорости */
                vnd_tx_kick = 1; return;
            } else {
                return;
            }
        } else if((eff_flags & 0x80u) != 0u){
            /* TEST */
            sending_channel = 0xFF;
            vnd_tx_kick = 1; return;
        } else {
            /* неизвестный флаг — игнорируем */
            vnd_tx_kick = 1; return;
        }
    }

    /* Ниже — обычная ветка для полнофункционального режима */
    if(!eff_is_frame){
        /* STAT/DCCF/служебные ответы не должны закрывать A/B пару.
           Раньше этот callback мог двигать pending_B/stream_seq по старому sending_channel,
           что давало редкую рассинхронизацию после bulk GET_STATUS или позднего TxCplt. */
        (void)prev_sending;
        vnd_tx_kick = 1;
        return;
    }
    uint8_t fl = eff_flags;
    uint8_t fl_ch_bits = (uint8_t)(fl & 0x03u);
    if((fl & 0x80u) != 0u){
        /* TEST */
        sending_channel = 0xFF; /* тест одиночный */
        vnd_tx_kick = 1; return;
    }
    uint8_t tx_slot = pair_send_idx;
    if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
        vnd_align_strict_pair_cursor();
        int seq_slot = vnd_find_pair_by_seq(eff_seq);
        if(seq_slot >= 0){
            tx_slot = (uint8_t)seq_slot;
        }
    }
    if(fl_ch_bits == 0x01){
        /* Это канал A */
        if(pending_B){ VND_LOG("WARN A_WHILE_PENDING_B seq=%lu hdr.seq=%lu", (unsigned long)stream_seq, (unsigned long)eff_seq); }
        if(eff_seq != stream_seq){
            VND_LOG("WARN A_SEQ_MISMATCH hdr=%lu stream_seq=%lu", (unsigned long)eff_seq, (unsigned long)stream_seq);
        }
        static uint8_t first_a_txcplt_logged = 0; if(!first_a_txcplt_logged){ first_a_txcplt_logged = 1; VND_LOG("FIRST_A txcplt seq=%lu", (unsigned long)eff_seq); }
        dbg_tx_sent++; dbg_sent_ch0_total++; dbg_sent_seq_adc0++;
        /* Добавим число сэмплов канала A из текущей пары */
        vnd_total_tx_samples += (uint64_t)g_frames[tx_slot][0].samples;
        if(vnd_ch_mode == 0){
            /* A-only: закрываем пару сразу */
            vnd_consume_strict_fifo_pair(tx_slot);
            vnd_clear_pair_slot(tx_slot);
            sending_channel = 0xFF;
            pending_B = 0; pending_B_since_ms = 0;
            if(eff_seq == stream_seq){
                pair_send_idx = (uint8_t)((tx_slot + 1u) % VND_PAIR_BUFFERS);
                stream_seq++; dbg_produced_seq++; if(!first_pair_done){ first_pair_done = 1; }
            }
            /* Пытаемся немедленно отправить следующий A */
#if VND_TXCPLT_START_RAW_NEXT
            if(!vnd_try_send_A_nextpair_immediate()){ vnd_tx_kick = 1; return; } else { return; }
#endif
            vnd_tx_kick = 1; return;
        } else {
            /* пометим A как завершённый для наглядности статуса */
            g_frames[tx_slot][0].st = FB_FILL;
            sending_channel = 0xFF;
            if(eff_seq == stream_seq){
                pair_send_idx = tx_slot;
                /* Запускаем ожидание B ровно здесь */
                pending_B = 1; pending_B_since_ms = HAL_GetTick();
            }
            /* Не стартуем следующий рабочий USB IN прямо из DataIn/TxCplt.
               У master это окно может задерживать сервис синхронизации; Vendor_Stream_Task
               отправит B на следующем проходе, сохранив порядок A->B. */
#if VND_TXCPLT_START_RAW_NEXT
            if(vnd_stream_mode == VND_STREAM_MODE_LATEST){
                if(!vnd_try_send_B_immediate()){
                    vnd_tx_kick = 1; return;
                } else { return; }
            }
#endif
            vnd_tx_kick = 1; return;
        }
    } else if(fl_ch_bits == 0x02){
    /* Канал B завершён — закрываем пару */
        if(!pending_B){ VND_LOG("WARN B_WITHOUT_PENDING seq=%lu hdr.seq=%lu", (unsigned long)stream_seq, (unsigned long)eff_seq); }
        if(eff_seq != stream_seq){
            VND_LOG("WARN B_SEQ_MISMATCH hdr=%lu stream_seq=%lu", (unsigned long)eff_seq, (unsigned long)stream_seq);
        }
        static uint8_t first_b_logged = 0; if(!first_b_logged){ first_b_logged = 1; VND_LOG("FIRST_B txcplt seq=%lu", (unsigned long)eff_seq); }
    dbg_tx_sent++; dbg_sent_ch1_total++; dbg_sent_seq_adc1++;
    vnd_total_tx_samples += (uint64_t)g_frames[tx_slot][1].samples;
        vnd_consume_strict_fifo_pair(tx_slot);
        vnd_clear_pair_slot(tx_slot);
        if(eff_seq == stream_seq){
            pair_send_idx = (uint8_t)((tx_slot + 1u) % VND_PAIR_BUFFERS);
            stream_seq++; dbg_produced_seq++;
        }
        pending_B = 0; pending_B_since_ms = 0; sending_channel = 0xFF;
        if(!first_pair_done){ first_pair_done = 1; }
        /* Рабочий поток продолжает из task-loop, без нового USB IN из TxCplt. */
#if VND_TXCPLT_START_RAW_NEXT
        if(vnd_stream_mode == VND_STREAM_MODE_LATEST){
            if(!vnd_try_send_A_nextpair_immediate()){
                /* Без планирования задержек: следующая пара начнётся как только готова */
                vnd_tx_kick = 1; return;
            } else { return; }
        }
#endif
        vnd_tx_kick = 1; return;
    } else {
        VND_LOG("WARN UNKNOWN FLAGS 0x%02X in TxCplt", (unsigned)fl);
        sending_channel = 0xFF;
        /* РЕЗЕРВ: если классификация не распознала, но прямо перед этим слали B — закроем пару */
        if(pending_B && (prev_sending == 1 || ((last_tx_flags & 0x03u) == 0x02u))){
            vnd_consume_strict_fifo_pair(pair_send_idx);
            ChanFrame *f0 = &g_frames[pair_send_idx][0];
            ChanFrame *f1 = &g_frames[pair_send_idx][1];
            f0->st = f1->st = FB_FILL;
            pair_send_idx = (pair_send_idx + 1u) % VND_PAIR_BUFFERS;
            stream_seq++; dbg_produced_seq++;
            pending_B = 0; pending_B_since_ms = 0; sending_channel = 0xFF;
            /* Без планирования задержек */
            VND_LOG("FALLBACK_CLOSE_PAIR after UNKNOWN meta (assume B)");
            vnd_tx_kick = 1; return;
        }
        vnd_tx_kick = 1; return;
    }
}

/* Приём команд */
void USBD_VND_DataReceived(const uint8_t *data, uint32_t len)
{
    if(!len) return;
    vnd_optic_source_diag.rx_total++;
    dynamic_led_note_usb_exchange();
    uint8_t cmd = data[0];
    static uint32_t rcv_count = 0;
    rcv_count++;
    VND_LOG("CMD 0x%02X len=%lu", cmd, (unsigned long)len);
    vnd_log_dc_cmd_rx(data, len);
    switch(cmd)
    {
        case VND_CMD_START_STREAM:
        {
            uint8_t was_streaming = streaming;
            /* ДИАГНОСТИКА: фиксируем прием команды START */
            last_cmd_received = 0x20;
            last_cmd_timestamp_ms = HAL_GetTick();
            cmd_start_count++;
            vnd_update_cmd_indicator();
            
            /* Разрешаем START в любое время: мягко перезапускаем поток */
                VND_LOG("START_STREAM received");
                vnd_reset_buffers();
                pair_send_idx = 0; pair_fill_idx = 0; sending_channel = 0xFF; pending_B = 0; pending_B_since_ms = 0;
                /* Сброс фиксации размера и планировщика */
                cur_samples_per_frame = 0; cur_expected_frame_size = 0;
                vnd_next_pair_ms = 0;
                /* Состояние теста/ACK */
                test_in_flight = 0; test_pending = 0;
                vnd_async_state_reset_req = 1;
#if VND_DISABLE_TEST
                test_sent = 1; /* тест отключён: считать выполненным */
#else
                test_sent = 0;
#endif
                start_stat_planned = 0; start_stat_inflight = 0; start_ack_done = 1; /* ACK считаем выполненным логически */
                pending_status = 0; status_ack_pending = 0; /* не пытаться слать STAT через IN */
                vnd_error_counter = 0;
                vnd_last_error = 0;
                vnd_last_frame_txcplt_ms = 0;
                vnd_last_host_rx_ack_ms = 0;
                vnd_host_rx_last_counter = 0;
                vnd_host_rx_counter_valid = 1u;
                /* Синхронизация последовательностей пар */
                stream_seq = 0; next_seq_to_assign = 0; dbg_produced_seq = 0;
                first_pair_done = 0;
                dbg_sent_ch0_total = 0; dbg_sent_ch1_total = 0;
                start_cmd_ms = HAL_GetTick();
                /* Помечаем состояние ожидания первой передачи */
                vnd_pending_init = 1;
                vnd_stream_active = 0;
                /* Снимем DMA снапшот для контроля таймаута */
                adc_stream_debug_t dbg; adc_stream_get_debug(&dbg);
                dma_snapshot_full0 = dbg.dma_full0; dma_snapshot_full1 = dbg.dma_full1;
                /* Зафиксировать размер кадра для полного режима из vnd_frame_samples_req (если не задан хостом, используем дефолт) */
                if (full_mode) {
                    uint16_t before = vnd_frame_samples_req;
                    /* Если хост не задал vnd_frame_samples_req через SET_FRAME_SAMPLES, используем дефолт */
                    if(vnd_frame_samples_req == 0) {
                        /* Если хост не задал размер кадра, используем активный размер профиля ADC */
                        uint16_t prof_ns = adc_stream_get_active_samples();
                        if(prof_ns == 0) prof_ns = 1; /* защита от нуля */
                        vnd_frame_samples_req = prof_ns;
                    }
                    VND_LOG("START_CFG req=%u trunc=%u", vnd_frame_samples_req, vnd_trunc_samples);
                    cdc_logf("START_CFG full_mode req_before=%u req_after=%u trunc=%u", before, vnd_frame_samples_req, vnd_trunc_samples);
                    vnd_recompute_pair_timing(vnd_frame_samples_req);
                    cur_samples_per_frame = 0; /* снять lock, чтобы применилось немедленно */
                    cur_expected_frame_size = 0;
                }
                /* START applies the saved host TX request and only rebuilds the
                   USB pipeline. It must not restart continuous ADC/DMA. */
                /* Синхронизация всегда активна и не должна сбрасываться при START */
                if(!was_streaming && vnd_sync_mode_public == VND_SYNC_MODE_SLAVE){
                    extern volatile uint8_t sync_restart_on_edge;
                    extern volatile uint8_t g_arr_manual_mode;
                    sync_restart_on_edge = g_arr_manual_mode ? 0u : 1u; /* В ручном ARR-режиме запрещаем жёсткий перезапуск по первому фронту */
                    HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
                    vnd_sync_start_tim5_base();
                }

                /* ПРОАКТИВНО: очистим возможный "хвост" занятости IN EP с прошлой сессии */
                do {
                    extern void USBD_VND_ForceTxIdle(void);
                    USBD_VND_ForceTxIdle();
                    vnd_ep_busy = 0; vnd_tx_ready = 1; vnd_inflight = 0;
                    vnd_last_tx_start_ms = 0; /* чтобы WDG не сработал по старой метке */
                    /* Полностью очистим meta-FIFO для корректной классификации первой пары */
                    vnd_tx_meta_head = vnd_tx_meta_tail = 0;
                    meta_push_total = meta_pop_total = meta_empty_events = meta_overflow_events = 0;
                } while(0);
                streaming = 1;
                (void)vnd_tx_refresh_effective(start_cmd_ms, "start_stream");
                /* Включаем async декуплинг по умолчанию в полном режиме.
                   В тестовом режиме принудительно держим async=0, чтобы использовать
                   парный пайплайн с синтетической пилой. */
#if USE_TEST_SAWTOOTH
                async_mode = 0;
                vnd_strict_pairing = 0;
                cdc_logf("START: TEST mode forces async=0 (pair pipeline)");
#else
                        /* LOSSLESS_ROI держим на парном FIFO-пути: DMA всегда 600, USB отдаёт ROI 200 без latest/snapshot. */
                if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI){
                            async_mode = 0;
                            vnd_strict_pairing = 0;
                } else if(!async_mode_host_set){
                    async_mode = 1;
                }
#endif
                dbg_last_forced_stat_ms = start_cmd_ms;
                vnd_tx_ready = 1; vnd_ep_busy = 0; vnd_inflight = 0;
                vnd_last_txcplt_ms = HAL_GetTick();
                /* Разрешим STAT только после первой завершённой пары */
                first_pair_done = 0; pending_status = 0; vnd_status_permit_once = 0;
                /* Инициализация FPS измерения */
                fps_measurement_start_ms = HAL_GetTick();
                fps_last_report_ms = fps_measurement_start_ms;
                fps_pair_count = 0;
                fps_frame_a_count = 0;
                fps_frame_b_count = 0;
                fps_prepare_count = 0;
                /* Инициализация профилирования */
                memset(&perf_stats, 0, sizeof(perf_stats));
                /* Индикация START */
                vnd_tx_bytes_at_start = vnd_total_tx_bytes;
                HAL_GPIO_WritePin(Data_ready_GPIO22_GPIO_Port, Data_ready_GPIO22_Pin, GPIO_PIN_SET);
                     VND_LOG("START_STREAM: USB transmission enabled; ADC stays continuous");
                /* ДИАГНОСТИКА: выводим активный профиль и параметры */
                {
                    uint8_t prof = adc_stream_get_profile();
                    uint16_t samp = adc_stream_get_active_samples();
                    uint16_t rate = adc_stream_get_buf_rate();
                    cdc_logf("EVT START t=%lu profile=%u samples=%u rate=%u Hz bytes=%llu", 
                             (unsigned long)start_cmd_ms, prof, samp, rate, (unsigned long long)vnd_tx_bytes_at_start);
                    
                    /* Обновляем дисплей с параметрами потока */
                    // stream_info_t stream_info = {
                    //     .frequency_hz = rate,
                    //     .start_sample = 0,
                    //     .sample_count = samp,
                    //     .frames_sent = 0,
                    //     .is_streaming = 1
                    // };
                    // stream_display_update(&stream_info);
                    /* Параметры хоста (профиль/окна/частоты) */
                    vnd_update_lcd_params();
                    cdc_logf("INIT_DBG ASYNC_EN=1 pending_init=%u seq=%lu", (unsigned)vnd_pending_init, (unsigned long)stream_seq);
                }
                if(!full_mode){ diag_mode_active = 1; }
                VND_LOG("START_STREAM");
                vnd_change_event_force_report();
                /* Не отправляем ACK-STAT через IN на старте — позволим сразу начать A/B. */
                /* Не формируем синтетическую первую пару: ждём реальные данные */
#if !VND_DISABLE_TEST
                if(!test_sent && !test_in_flight && !vnd_ep_busy){ vnd_try_send_test_from_task(); }
#endif
                cdc_logf("START: USB pipeline reset; ADC/DMA unchanged");
                vnd_tx_kick = 1;
                /* Диагностический режим: подготовка и первая отправка */
                if(diag_mode_active){
                    if(cur_samples_per_frame == 0){
                        /* если хост задал samples_per_frame — используем его для DIAG */
                        uint16_t ds = (vnd_frame_samples_req != 0) ? vnd_frame_samples_req : diag_samples;
                        if(ds > VND_MAX_SAMPLES) ds = VND_MAX_SAMPLES;
                        diag_samples = ds;
                        cur_samples_per_frame = diag_samples;
                        cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + cur_samples_per_frame*2u);
                    }
                    diag_prepared_seq = 0xFFFFFFFFu; diag_current_pair_seq = 0xFFFFFFFFu;
                    vnd_diag_prepare_pair(stream_seq, cur_samples_per_frame);
                    diag_prepared_seq = stream_seq; diag_current_pair_seq = stream_seq;
                    if(!vnd_ep_busy){ (void)vnd_diag_try_tx(); }
                }
                /* Передача стартует из Vendor_Stream_Task после ADC restart */
        }
        break;
        case VND_CMD_SET_FRAME_SAMPLES:
            if(len >= 3){
                uint16_t ns = (uint16_t)(data[1] | (data[2] << 8));
                if(ns > VND_MAX_SAMPLES) ns = VND_MAX_SAMPLES;
                vnd_frame_samples_req = ns; /* Использовать значение хоста напрямую */
                /* Применим к диагностике сразу, чтобы DIAG шёл с нужным размером */
                diag_samples = (ns != 0) ? ns : diag_samples;
                vnd_recompute_pair_timing(vnd_frame_samples_req);
                /* Снимем фиксацию размера, чтобы применилось при следующем build */
                cur_samples_per_frame = 0; cur_expected_frame_size = 0;
                VND_LOG("SET_FRAME_SAMPLES %u -> period=%ums", (unsigned)vnd_frame_samples_req, (unsigned)vnd_pair_period_ms);
                cdc_logf("EVT SET_FRAME_SAMPLES %u", (unsigned)vnd_frame_samples_req);
                vnd_update_lcd_params();
            }
            break;
        case VND_CMD_STOP_STREAM:
        {
            /* ДИАГНОСТИКА: фиксируем прием команды STOP, сбрасываем счётчик START */
            last_cmd_received = 0x21;
            last_cmd_timestamp_ms = HAL_GetTick();
            cmd_stop_count++;
            cmd_start_count = 0;  /* Сброс счётчика START по команде STOP */
            vnd_update_cmd_indicator();
            /* No local USB stream means the Raspberry IP data path cannot be
               healthy. Restore the full wired fallback immediately. */
            rs485_wire_mode_force_full(RS485_WIRE_FALLBACK_USB_STOP);
            
            /* В полном режиме: STOP с ACK-STAT между парами; в DIAG — немедленная остановка без STAT по bulk */
            if(diag_mode_active){
                /* Мгновенно останавливаем стрим без ACK-STAT в bulk, чтобы не нарушать DIAG поток */
                stop_request = 0; pending_status = 0;
                if(streaming){ streaming = 0; VND_LOG("STOP_STREAM (diag, immediate)"); }
                diag_mode_active = 0;
                vnd_reset_buffers();
                sending_channel = 0xFF; pending_B = 0; pending_B_since_ms = 0; test_sent = 0; test_in_flight = 0; vnd_inflight = 0;
                /* КРИТИЧНО: полный сброс состояния для возможности повторного START */
                vnd_pending_init = 0;
                vnd_stream_active = 0;
                vnd_last_frame_txcplt_ms = 0;
                vnd_last_host_rx_ack_ms = 0;
                vnd_host_rx_last_counter = 0;
                vnd_host_rx_counter_valid = 0;
                vnd_ep_busy = 0;
                vnd_tx_ready = 1;
                /* ADC/DMA продолжают работать в фоне, STOP только выключает передачу по USB */
                HAL_GPIO_WritePin(Data_ready_GPIO22_GPIO_Port, Data_ready_GPIO22_Pin, GPIO_PIN_RESET);
                (void)vnd_tx_refresh_effective(HAL_GetTick(), "stop_stream");
                {
                    uint64_t cur = vnd_total_tx_bytes;
                    uint64_t delta = (cur >= vnd_tx_bytes_at_start) ? (cur - vnd_tx_bytes_at_start) : 0ULL;
                    cdc_logf("EVT STOP total=%llu delta=%llu", (unsigned long long)cur, (unsigned long long)delta);
                    
                    /* Обновляем дисплей: поток остановлен */
                    // stream_info_t stream_info = {
                    //     .frequency_hz = 0,
                    //     .start_sample = 0,
                    //     .sample_count = 0,
                    //     .frames_sent = dbg_sent_ch0_total + dbg_sent_ch1_total,
                    //     .is_streaming = 0
                    // };
                    // stream_display_update(&stream_info);
                    vnd_update_lcd_params();
                }
                vnd_tx_kick = 1; /* пнуть таск на всякий случай */
            } else {
                /* STOP в полном режиме: мгновенная остановка, полный сброс ВСЕХ флагов */
                streaming = 0;  /* Главное: остановить передачу */
                VND_LOG("STOP_STREAM (full mode)");
                
                /* Сброс запросов на STAT — они больше не нужны */
                stop_request = 0;
                pending_status = 0;
                status_ack_pending = 0;
                stop_stat_inflight = 0;
                
                /* Сброс состояния передачи для разрешения следующего START */
                vnd_pending_init = 0;
                vnd_stream_active = 0;
                vnd_last_frame_txcplt_ms = 0;
                vnd_last_host_rx_ack_ms = 0;
                vnd_host_rx_last_counter = 0;
                vnd_host_rx_counter_valid = 0;
                vnd_ep_busy = 0;
                vnd_tx_ready = 1;
                vnd_inflight = 0;
                vnd_tx_kick = 0;  /* Сбросить флаг kick */
                vnd_async_state_reset_req = 1;
                inflight_is_frame = 0;
                inflight_flags = 0;
                inflight_seq = 0;

                /* STOP должен полностью освобождать IN endpoint и кадры, включая ROI B_SENDING. */
                do {
                    extern void USBD_VND_ForceTxIdle(void);
                    USBD_VND_ForceTxIdle();
                    vnd_tx_meta_head = vnd_tx_meta_tail = 0;
                    meta_push_total = meta_pop_total = meta_empty_events = meta_overflow_events = 0;
                    vnd_reset_buffers();
                } while(0);
                
                /* Сброс флагов пар и статусов */
                first_pair_done = 0;
                start_ack_done = 1;
                vnd_status_permit_once = 0;
                
                /* КРИТИЧНО: НЕ сбрасываем async_mode и full_mode - они устанавливаются START */
                /* async_mode должен остаться 1 после первого START */
                
                HAL_GPIO_WritePin(Data_ready_GPIO22_GPIO_Port, Data_ready_GPIO22_Pin, GPIO_PIN_RESET);
                (void)vnd_tx_refresh_effective(HAL_GetTick(), "stop_stream");
                cdc_logf("EVT STOP t=%lu async=%d full=%d ep_busy=%d", 
                         (unsigned long)HAL_GetTick(), async_mode, full_mode, vnd_ep_busy);
            }
        }
        break;
        
        case VND_CMD_DEVICE_RESET:
        {
            VND_LOG("DEVICE_RESET commanded!");
#if VND_DEVICE_RESET_SOFT_ONLY
            /* Мягкий путь: просим main выполнить soft USB recovery без полного MCU reset */
            cdc_logf("[VND] soft USB recovery requested by 0x22 at t=%lu ms", (unsigned long)HAL_GetTick());
            need_recovery = 1;
#else
            /* Жёсткий путь: ставим флаг для main-loop (выполнит корректный disconnect+NVIC_SystemReset) */
            extern volatile uint8_t need_hard_reset;
            cdc_logf("!!! HARD_RESET scheduled by host 0x22 at t=%lu ms", (unsigned long)HAL_GetTick());
            need_hard_reset = 1;
#endif
        }
        break;
        
        case VND_CMD_GET_STATUS:
        {
            /* GET_STATUS всегда допускается: во время стрима — только между парами */
            /* Диагностическая вставка: классификация паузы при запросе статуса (редкая, чтобы не тормозить) */
            vnd_diag_log_possible_stall();

            /* Автокик: если во время стрима ничего не летит (EP свободен, нет inflight и пустая meta-очередь),
               попробуем мягко сдвинуть пайплайн. Это лечит зависания вида ADC_IDLE/A_READY_NOT_TX. */
            if(streaming && !vnd_ep_busy && !vnd_inflight && (vnd_tx_meta_depth() == 0))
            {
                int kicked = 0;
                if(async_mode){
                    kicked = vnd_async_try_tx();
                } else {
                    if(pending_B){ kicked = vnd_try_send_B_immediate(); }
                    if(!kicked){ kicked = vnd_try_send_A_nextpair_immediate(); }
                    if(!kicked){ vnd_prepare_pair(); kicked = vnd_try_send_A_nextpair_immediate(); }
                }
                if(kicked){ VND_LOG("KICK_TX by GET_STATUS"); }
            }

            if(streaming){
                /* В DIAG-режиме исключаем любые STAT в bulk-потоке: используйте EP0 (ctrl) */
                if(diag_mode_active){ VND_LOG("GET_STATUS bulk ignored in DIAG (use EP0)"); break; }
                pending_status = 1; VND_LOG("GET_STATUS queued"); break;
            }
            if(!vnd_ep_busy)
            {
                    vnd_status_permit_once = 1;
                    uint16_t l = vnd_build_status((uint8_t*)status_buf, sizeof(status_buf));
                    if(l)
                    {
                        vnd_tx_ready = 0; vnd_ep_busy = 1; vnd_last_tx_len = l; vnd_last_tx_start_ms = HAL_GetTick();
                        vnd_mark_service_inflight();
                        vnd_tx_meta_before((uint8_t*)status_buf, l);
                        if(USBD_VND_Transmit(&hUsbDeviceHS, (uint8_t*)status_buf, l) == USBD_OK){
                            VND_LOG("STAT_TX req len=%u", l);
                        } else {
                            vnd_tx_meta_rollback_last();
                            VND_LOG("STAT_BUSY_FAIL");
                        vnd_status_permit_once = 0;
                        vnd_rollback_tx_start();
                    }
                }
            } else {
                pending_status = 1; VND_LOG("STAT_PENDING on GET_STATUS");
            }
        }
        break;

        case VND_CMD_HOST_RX_ACK:
        {
            if (len >= 5u) {
                uint32_t host_frames = (uint32_t)data[1] |
                                       ((uint32_t)data[2] << 8) |
                                       ((uint32_t)data[3] << 16) |
                                       ((uint32_t)data[4] << 24);
                if ((!vnd_host_rx_counter_valid) || (host_frames != vnd_host_rx_last_counter)) {
                    vnd_last_host_rx_ack_ms = HAL_GetTick();
                    (void)vnd_tx_refresh_effective(vnd_last_host_rx_ack_ms, "host_ack");
                }
                vnd_host_rx_last_counter = host_frames;
                vnd_host_rx_counter_valid = 1u;
            }
        }
        break;

        case VND_CMD_HOST_RX_CLEAR:
        {
            vnd_last_host_rx_ack_ms = 0;
            vnd_host_rx_last_counter = 0;
            vnd_host_rx_counter_valid = 0;
            rs485_wire_mode_force_full(RS485_WIRE_FALLBACK_HOST_CLEAR);
            /* Heartbeat reset must not alter TX; reapply the unchanged host request. */
            (void)vnd_tx_refresh_effective(HAL_GetTick(), "host_clear");
        }
        break;

        case VND_CMD_TOGGLE_TIM2CH3_INV:
        {
            /* Переключаем полярность CH3 на лету (PA2 = TIM2_CH3). */
            uint32_t ccer = TIM2->CCER;
            ccer ^= TIM_CCER_CC3P;
            TIM2->CCER = ccer;
        }
        break;

        case VND_CMD_SET_TX_ENABLE:
        {
            if(len >= 2){
                uint8_t en = (data[1] != 0u) ? 1u : 0u;
                last_cmd_received = VND_CMD_SET_TX_ENABLE;
                last_cmd_timestamp_ms = HAL_GetTick();
                vnd_tx_host_cmd_count++;
                vnd_tx_host_cmd_last_ms = last_cmd_timestamp_ms;
                vnd_tx_host_cmd_last_value = en;
                (void)vnd_tx_set_enabled_internal(en, "host_cmd");
            }
        }
        break;

        case VND_CMD_SET_RELAY_ENABLE:
            if(len == 2u && data[1] <= 1u) relay_set_enabled(data[1]);
            break;
        case VND_CMD_ACK_COMM_RECOVERY:
            if (len == 3u) vnd_ack_comm_recovery((uint16_t)data[1] | ((uint16_t)data[2] << 8));
            break;
        case VND_CMD_SET_RELAY_TEST:
            if(len == 2u && data[1] <= 1u) relay_set_test(data[1]);
            break;
        case VND_CMD_RELAY_EVENT:
            if(len == 5u) {
                relay_trigger((uint32_t)data[1] | ((uint32_t)data[2] << 8) |
                    ((uint32_t)data[3] << 16) | ((uint32_t)data[4] << 24));
            }
            break;

        case VND_CMD_SET_TX1_PHASE:
        case VND_CMD_SET_TX2_PHASE:
        {
            /* Absolute, idempotent settings. Only the selected physical TX
               changes on the next marker boundary; no sync/ADC reconfigure. */
            if(len == 2u) {
                (void)adc_stream_set_tx_phase(
                    (cmd == VND_CMD_SET_TX1_PHASE) ? 1u : 2u, data[1]);
            }
        }
        break;

        case VND_CMD_SET_OPTIC_POWER:
        {
            if(len >= 2){
                uint8_t applied = optic_tx_set_power(data[1]);
                cdc_logf("EVT OPTIC_POWER=%u", (unsigned)applied);
            }
        }
        break;

        case VND_CMD_SET_OPTIC_HOLD:
        {
            if(len >= 3){
                uint16_t deciseconds = (uint16_t)(data[1] | (data[2] << 8));
                uint16_t applied = optic_sensor_set_hold_deciseconds(deciseconds);
                cdc_logf("EVT OPTIC_HOLD_DS=%u", (unsigned)applied);
            } else if(len >= 2){
                uint8_t applied = optic_sensor_set_hold_seconds(data[1]);
                cdc_logf("EVT OPTIC_HOLD_S_LEGACY=%u", (unsigned)applied);
            }
        }
        break;

        case VND_CMD_SET_LED_PATTERN:
        {
            if(len >= 2){
                uint8_t applied = dynamic_led_set_pattern(data[1]);
                cdc_logf("EVT LED_PATTERN=%u", (unsigned)applied);
            }
        }
        break;

        case VND_CMD_SET_OPTIC_REACTION_SOURCE:
        {
            vnd_optic_source_diag.cmd_count++;
            vnd_optic_source_diag.cmd_len = len;
            vnd_optic_source_diag.cmd_value = (len >= 2u) ? data[1] : 0xFFFFFFFFu;
            vnd_optic_source_diag.cmd_ms = HAL_GetTick();
            if(len >= 2){
                uint8_t applied =
                    ws2812_spi_set_optic_reaction_source(data[1]);
                vnd_optic_source_diag.applied = applied;
                cdc_logf("EVT OPTIC_REACTION_SOURCE=%u",
                         (unsigned)applied);
            }
        }
        break;

        case VND_CMD_SET_WIRE_MODE:
        {
            if((len == 9u) && (data[1] == 1u)) {
                uint8_t requested_mode = data[2];
                uint16_t lease_ms = (uint16_t)data[3] |
                                    ((uint16_t)data[4] << 8);
                uint32_t transport_epoch = (uint32_t)data[5] |
                                           ((uint32_t)data[6] << 8) |
                                           ((uint32_t)data[7] << 16) |
                                           ((uint32_t)data[8] << 24);
                uint8_t applied = rs485_wire_mode_apply(requested_mode,
                                                        lease_ms,
                                                        transport_epoch);
                if(applied != 0xFFu) {
                    /* Lease renewals must not inject STAT/EVT1 packets into
                       the ADC stream. GET_SYNC_DIAG is the authoritative
                       readback and reports the live remaining lease. */
                    cdc_logf("EVT WIRE_MODE=%u lease_ms=%u epoch=%lu",
                             (unsigned)applied,
                             (unsigned)lease_ms,
                             (unsigned long)transport_epoch);
                } else {
                    cdc_logf("EVT WIRE_MODE_REJECT mode=%u lease_ms=%u",
                             (unsigned)requested_mode,
                             (unsigned)lease_ms);
                }
            } else {
                cdc_logf("EVT WIRE_MODE_REJECT len=%lu version=%u",
                         (unsigned long)len,
                         (unsigned)((len >= 2u) ? data[1] : 0u));
            }
        }
        break;

        case VND_CMD_SET_DET_ADC:
        {
            if(len >= 2){
                uint8_t applied = rs485_status_set_det_adc_bits(data[1]);
                pending_status = 1u;
                vnd_change_event_force_report();
                cdc_logf("EVT DET_ADC=0x%02X", (unsigned)applied);
            }
        }
        break;

        case VND_CMD_SET_RS485_IP:
        {
            if (len >= 5u) {
                rs485_identity_set_local_ip4(&data[1]);
                cdc_logf("EVT RS485_IP=%u.%u.%u.%u",
                         (unsigned)data[1],
                         (unsigned)data[2],
                         (unsigned)data[3],
                         (unsigned)data[4]);
            }
        }
        break;

        case VND_CMD_SET_RPI_INFO:
        {
            if (len == 7u) {
                uint16_t rpi_number =
                    (uint16_t)data[1] | ((uint16_t)data[2] << 8);
                rs485_identity_set_local_rpi_info(rpi_number, &data[3]);
                cdc_logf("EVT RPI_INFO number=%u ip=%u.%u.%u.%u",
                         (unsigned)rpi_number,
                         (unsigned)data[3],
                         (unsigned)data[4],
                         (unsigned)data[5],
                         (unsigned)data[6]);
            }
        }
        break;

        case VND_CMD_REQUEST_RS485_IDENT:
        {
            rs485_identity_request_scan();
            cdc_logf("EVT RS485_IDENT_SCAN_REQUEST");
        }
        break;

        case VND_CMD_GET_RS485_IDENT:
        {
            uint8_t node_id = (len >= 2u) ? data[1] : 0xFFu;
            if (streaming) {
                VND_LOG("GET_RS485_IDENT bulk ignored while streaming (use EP0)");
                break;
            }
            if (!vnd_ep_busy) {
                uint16_t l = vnd_build_rs485_ident(node_id, (uint8_t*)status_buf, sizeof(status_buf));
                if (l != 0u) {
                    vnd_tx_ready = 0;
                    vnd_ep_busy = 1;
                    vnd_last_tx_len = l;
                    vnd_last_tx_start_ms = HAL_GetTick();
                    vnd_mark_service_inflight();
                    vnd_tx_meta_before((uint8_t*)status_buf, l);
                    if (USBD_VND_Transmit(&hUsbDeviceHS, (uint8_t*)status_buf, l) == USBD_OK) {
                        VND_LOG("RID1_TX req len=%u", l);
                    } else {
                        vnd_tx_meta_rollback_last();
                        VND_LOG("RID1_BUSY_FAIL");
                        vnd_rollback_tx_start();
                    }
                }
            }
        }
        break;

        case VND_CMD_LED_EVENT:
#if VND_LED_EVENTS_ENABLE
        {
            if (len >= 4) {
                uint8_t pattern_id = data[1];
                uint16_t duration_ms = (uint16_t)(data[2] | (data[3] << 8));

                if (duration_ms == 0u) {
                    duration_ms = 1600u;
                }

                if (pattern_id >= (uint8_t)WS2812_PATTERN_COUNT) {
                    pattern_id = (uint8_t)WS2812_PATTERN_OFF;
                }
                ws2812_spi_trigger_pattern((ws2812_pattern_t)pattern_id, duration_ms);
                cdc_logf("EVT LED_EVENT pattern=%u dur=%u", (unsigned)pattern_id, (unsigned)duration_ms);
            }
        }
#endif
        break;

        case VND_CMD_SET_WINDOWS:
            if(len >= 9)
            {
                /* 1 + 8 байт */
                win_start0 = (uint16_t)(data[1] | (data[2] << 8));
                win_len0   = (uint16_t)(data[3] | (data[4] << 8));
                win_start1 = (uint16_t)(data[5] | (data[6] << 8));
                win_len1   = (uint16_t)(data[7] | (data[8] << 8));
                win_auto = 0; /* ручное окно отключает авто-смещение */
                VND_LOG("SET_WINDOWS s0=%u l0=%u s1=%u l1=%u", win_start0, win_len0, win_start1, win_len1);
                /* При смене ROI сбросить накопители усреднения, чтобы не смешивать разные окна */
                vnd_avg_reset();
                vnd_update_lcd_params();
            }
            break;

        case VND_CMD_SET_STREAM_MODE:
            if(len >= 2)
            {
                uint8_t m = data[1];
                if(m > VND_STREAM_MODE_AVG_ROI) m = VND_STREAM_MODE_LATEST;
                vnd_stream_mode = m;

                if(vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
                    /* avg_n: опционально */
                    uint8_t n = (len >= 3) ? data[2] : 24;
                    if(n < (uint8_t)VND_AVG_MIN_N) n = (uint8_t)VND_AVG_MIN_N;
                    if(n > VND_AVG_MAX_N) n = VND_AVG_MAX_N;
                    vnd_avg_n = n;
                    vnd_avg_reset();

                    /* ВАЖНО: не делаем vnd_dc_load_once() здесь — этот обработчик может быть в USB IRQ.
                       Просим выполнить загрузку DC в main-loop (Vendor_Stream_Task) как можно раньше. */
                    vnd_dc_load_request = 1;
                }

                /* Печать в UART (COM4) — чтобы однозначно видеть применённый режим/avg_n */
                printf("[CMD_IND] SET_STREAM_MODE m=%u len=%u avg_n=%u\r\n", (unsigned)vnd_stream_mode, (unsigned)len, (unsigned)vnd_avg_n);

                /* LOSSLESS_ROI идёт через обычный парный FIFO-путь. AVG_ROI остаётся
                   на отдельной AVG-очереди; async для обоих ROI-режимов запрещён. */
                if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI){
                    vnd_ch_mode = 2;
                    async_mode = 0;
                    vnd_strict_pairing = 0;
                    async_mode_host_set = 1;
                } else if(vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
                    vnd_ch_mode = 2;
                    async_mode = 0;
                    async_mode_host_set = 1;
                }

                /* При смене режима сбрасываем lock размера кадра, чтобы избежать рассинхронизации формата. */
                cur_samples_per_frame = 0;
                cur_expected_frame_size = 0;

                /* Для требуемого режима "lossless ROI" выставляем дефолтное окно 200 семплов
                   со сдвигом по частоте (база 200 Гц -> старт 280).
                   Хост всё равно может переопределить через SET_WINDOWS.
                   Не перезаписываем ROI, если хост уже установил его (win_auto==0). */
                if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI){
                    if(win_auto != 0){
                        vnd_apply_auto_roi_window();
                    }
                }
                if(streaming){
                    /* USB-only switch: do not restart ADC/DMA/TIM15/sync on payload
                       mode changes. The ADC cadence stays the timing reference; only
                       the software frame builder must forget cached async frames. */
                    vnd_async_state_reset_req = 1u;
                    vnd_tx_kick = 1u;
                    cdc_logf("SET_STREAM_MODE: USB-only switch m=%u, ADC restart skipped",
                             (unsigned)vnd_stream_mode);
                }
                vnd_update_lcd_params();
            }
            break;

        case VND_CMD_SET_DC_SPEED:
            /* Complete runtime contract: one LE u32 millisecond value.
               0 disables learning, 1 is fastest, 1000 is one second. */
            if((len == 5u) && vnd_dc_apply_speed_payload(&data[1], 4u))
            {
                printf("[DC_SPEED] settle=%lums enabled=%u\r\n",
                       (unsigned long)vnd_dc_speed_settle_ms,
                       (unsigned)(vnd_dc_speed_settle_ms != 0u));
                cdc_logf("EVT SET_DC_SPEED settle=%lu enabled=%u",
                         (unsigned long)vnd_dc_speed_settle_ms,
                         (unsigned)(vnd_dc_speed_settle_ms != 0u));
            }
            else
            {
                vnd_dc_speed_reject_count++;
                printf("[DC_SPEED] rejected len=%lu expected=5\r\n", (unsigned long)len);
                cdc_logf("EVT SET_DC_SPEED rejected len=%lu", (unsigned long)len);
            }
            break;

        case VND_CMD_GET_DC_CONFIG:
            {
                uint8_t cfg[VND_DC_CONFIG_MAX];
                uint16_t l = vnd_build_dc_config(cfg, sizeof(cfg));
                if(l && !vnd_ep_busy && !vnd_inflight){
                    vnd_tx_ready = 0; vnd_ep_busy = 1; vnd_last_tx_len = l; vnd_last_tx_start_ms = HAL_GetTick();
                    vnd_mark_service_inflight();
                    vnd_tx_meta_before(cfg, l);
                    if(USBD_VND_Transmit(&hUsbDeviceHS, cfg, l) == USBD_OK){
                    } else {
                        vnd_tx_meta_rollback_last();
                        vnd_rollback_tx_start();
                    }
                }
            }
            break;

        case VND_CMD_SAVE_DC_TO_FLASH:
            vnd_dc_request_save_to_flash();
            printf("[CMD_IND] SAVE_DC_TO_FLASH requested\r\n");
            cdc_logf("EVT SAVE_DC_TO_FLASH requested");
            break;
            
        case VND_CMD_SET_LCD_ROLE_OVERLAY:
            if(len >= 2)
            {
                uint8_t enable = (data[1] != 0u) ? 1u : 0u;
                uint8_t period_s = vnd_lcd_role_overlay_period_s;
                uint8_t duration_s = vnd_lcd_role_overlay_duration_s;
                if(len >= 3u) {
                    period_s = data[2];
                }
                if(len >= 4u) {
                    duration_s = data[3];
                }
                vnd_lcd_role_overlay_configure(enable, period_s, duration_s);
                printf("[CMD_IND] SET_LCD_ROLE_OVERLAY en=%u period=%u duration=%u\r\n",
                       (unsigned)enable,
                       (unsigned)vnd_lcd_role_overlay_period_s,
                       (unsigned)vnd_lcd_role_overlay_duration_s);
                cdc_logf("EVT LCD_ROLE_OVERLAY en=%u period=%u duration=%u",
                         (unsigned)enable,
                         (unsigned)vnd_lcd_role_overlay_period_s,
                         (unsigned)vnd_lcd_role_overlay_duration_s);
            }
            break;

        case VND_CMD_SET_SYNC_MODE:
            if(len >= 2)
            {
                uint8_t mode = data[1];
                if ((mode == VND_SYNC_MODE_AUTO) || (mode == VND_SYNC_MODE_AUTO_LEGACY)) {
                    vnd_sync_release_host_forced();
                    printf("[CMD_IND] SET_SYNC_MODE AUTO\r\n");
                    cdc_logf("EVT SET_SYNC_MODE AUTO");
                } else if ((mode == VND_SYNC_MODE_MASTER) ||
                           (mode == VND_SYNC_MODE_SLAVE)) {
                    /* Persistent local MASTER/SLAVE assignments require host
                       UTC Unix time in milliseconds for wire compatibility. */
                    if(len >= 10u) {
                        uint64_t assigned_unix_ms =
                            (uint64_t)vnd_dc_rd_le32(data + 2u) |
                            ((uint64_t)vnd_dc_rd_le32(data + 6u) << 32);
                        uint8_t accepted = (mode == VND_SYNC_MODE_MASTER)
                            ? rs485_role_assign_master_from_host(assigned_unix_ms)
                            : rs485_role_assign_slave_from_host(assigned_unix_ms);
                        const char *role_name = (mode == VND_SYNC_MODE_MASTER)
                            ? "MASTER" : "SLAVE";
                        if(accepted != 0u) {
                            printf("[CMD_IND] SET_SYNC_MODE %s unix_ms=%llu\r\n",
                                   role_name,
                                   (unsigned long long)assigned_unix_ms);
                            cdc_logf("EVT SET_SYNC_MODE %s unix_ms=%llu",
                                     role_name,
                                     (unsigned long long)assigned_unix_ms);
                        } else {
                            printf("[CMD_IND] SET_SYNC_MODE %s rejected\r\n", role_name);
                            cdc_logf("EVT SET_SYNC_MODE %s rejected", role_name);
                        }
                    } else {
                        printf("[CMD_IND] SET_SYNC_MODE role=%u rejected: timestamp required\r\n",
                               (unsigned)mode);
                        cdc_logf("EVT SET_SYNC_MODE role=%u rejected timestamp_required",
                                 (unsigned)mode);
                    }
                } else {
                    if(mode > VND_SYNC_MODE_OFF) {
                        mode = VND_SYNC_MODE_OFF;
                    }
                    vnd_sync_apply_host_forced_mode(mode);
                    printf("[CMD_IND] SET_SYNC_MODE %u\r\n", (unsigned)mode);
                    cdc_logf("EVT SET_SYNC_MODE mode=%u", (unsigned)mode);
                }
            }
            break;

        case VND_CMD_SET_RS485_ID:
            if(len >= 2)
            {
                uint8_t node_id = data[1];
                if(node_id <= 31u) {
                    rs485_set_local_node_id_from_host(node_id);
                    printf("[CMD_IND] SET_RS485_ID %u\r\n", (unsigned)node_id);
                } else {
                    printf("[CMD_IND] SET_RS485_ID rejected %u\r\n",
                           (unsigned)node_id);
                }
            }
            break;

        case VND_CMD_SET_BLOCK_HZ:
            if(len >= 3)
            {
                uint16_t hz = (uint16_t)(data[1] | (data[2] << 8));
                if(hz == 0xFFFF) hz = 100;
                if(hz < 20) hz = 20;
                if(hz > 400) hz = 400;
                diag_hz = hz;
                diag_period_ms = 1000 / diag_hz;
                VND_LOG("SET_BLOCK_HZ %u", diag_hz);
                cdc_logf("EVT SET_BLOCK_HZ %u", (unsigned)diag_hz);
                /* NEW: авто-подбор профиля под желаемую частоту блоков, если мы в полном режиме (full_mode) */
                if(full_mode){
                    /* Целевые buf_rate_hz профилей: 200(A), 300(B/C/D), 400(E) */
                    uint16_t target = hz; /* запрос хоста: кадров в секунду */
                    uint8_t new_prof = adc_stream_get_profile();
                    if(target >= 380){ new_prof = ADC_PROFILE_E_400HZ; }
                    else if(target >= 250){ new_prof = ADC_PROFILE_B_DEFAULT; }
                    else { new_prof = ADC_PROFILE_A_200HZ; }
                    if(new_prof != adc_stream_get_profile()){
                        int rc = adc_stream_set_profile(new_prof);
                        VND_LOG("AUTO_PROFILE_BY_BLOCK_HZ hz=%u -> prof=%u rc=%d", target, new_prof, rc);
                        if(rc == 0){
                            uint16_t cur_samples = adc_stream_get_active_samples();
                            uint16_t cur_rate = adc_stream_get_buf_rate();
                            cdc_logf("EVT AUTO_PROFILE hz=%u prof=%u samples=%u rate=%u", (unsigned)target, (unsigned)new_prof, (unsigned)cur_samples, (unsigned)cur_rate);
                            /* Сброс lock размера, чтобы новые параметры применились */
                            cur_samples_per_frame = 0; cur_expected_frame_size = 0;
                        }
                    }
                }
                vnd_update_lcd_params();
            }
            break;
        case VND_CMD_SET_ASYNC_MODE:
            if(len >= 2){
                uint8_t mode = data[1];
#if USE_TEST_SAWTOOTH
                /* Игнорируем запросы async в тестовом режиме — нужен парный путь */
                async_mode = 0; vnd_strict_pairing = 0;
                cdc_logf("EVT SET_ASYNC ignored (test mode)");
#else
                async_mode = (mode & 0x01) ? 1 : 0;
                async_mode_host_set = 1;
                /* bit7 включает строгую парность (A&B на один seq); по умолчанию 0 = независимые каналы */
                vnd_strict_pairing = (mode & 0x80) ? 1 : 0;
                /* ROI-режимы требуют собственного FIFO/AVG пайплайна: async для них запрещён. */
                if((vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI) && async_mode){
                    async_mode = 0;
                }
                if(vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI){
                    vnd_ch_mode = 2;
                    async_mode = 0;
                    vnd_strict_pairing = 0;
                }
                /* Запретить async при одноканальном режиме (A-only/B-only) для стабильности.
                   LOSSLESS_ROI сам принудительно включает BOTH выше. */
                if(vnd_ch_mode != 2 && async_mode){ async_mode = 0; }
                VND_LOG("SET_ASYNC_MODE async=%u strict_pair=%u", (unsigned)async_mode, (unsigned)vnd_strict_pairing);
                cdc_logf("EVT SET_ASYNC async=%u strict=%u", (unsigned)async_mode, (unsigned)vnd_strict_pairing);
                /* Сбросим ожидания и канал передачи */
                pending_B = 0; sending_channel = 0xFF;
#endif
            }
            break;
        case VND_CMD_SET_CHMODE:
            if(len >= 2){
                uint8_t m = data[1];
#if USE_TEST_SAWTOOTH
                /* В тестовом режиме принудительно оба канала */
                vnd_ch_mode = 2; async_mode = 0;
                cdc_logf("EVT SET_CHMODE forced BOTH (test mode)");
#else
                if(m > 2) m = 2; /* default both */
                vnd_ch_mode = m;
                /* При A-only/B-only принудительно выключаем async */
                if(vnd_ch_mode != 2 && async_mode){ async_mode = 0; }
                VND_LOG("SET_CHMODE %u", (unsigned)vnd_ch_mode);
                cdc_logf("EVT SET_CHMODE %u", (unsigned)vnd_ch_mode);
#endif
                /* Переключение режимов на лету: сброс ожиданий B, чтобы не зависать */
                pending_B = 0; sending_channel = 0xFF;
            }
            break;
        case VND_CMD_SET_FULL_MODE:
            if(len >= 2)
            {
                uint8_t full = data[1] ? 1 : 0;
                full_mode = full;
                VND_LOG("SET_FULL_MODE %u", full_mode);
                cdc_logf("EVT SET_FULL_MODE %u", (unsigned)full_mode);
                if(streaming){
                    /* Переключение режима на лету: сброс пары и разрешение TEST не требуется */
                    pending_B = 0; sending_channel = 0xFF;
                }
                if(full_mode){
                    /* Возврат к нормальному режиму ADC */
                    diag_mode_active = 0; diag_prepared_seq = 0xFFFFFFFFu;
                    /* При входе в полный режим – использовать фактический размер профиля ADC, снять lock и пересчитать период */
                    vnd_frame_samples_req = 0; /* 0 = использовать g_active_samples из профиля */
                    cur_samples_per_frame = 0;
                    cur_expected_frame_size = 0;
                    vnd_recompute_pair_timing(vnd_frame_samples_req);
                } else {
                    /* Включаем диагностический режим (пила) */
                    diag_mode_active = 1;
                    diag_samples = (cur_samples_per_frame != 0) ? cur_samples_per_frame : VND_DEFAULT_TEST_SAMPLES;
                    if(diag_samples > VND_MAX_SAMPLES) diag_samples = VND_MAX_SAMPLES;
                    cur_samples_per_frame = diag_samples;
                    cur_expected_frame_size = (uint16_t)(VND_FRAME_HDR_SIZE + cur_samples_per_frame*2u);
                    /* Разрешаем немедленную отправку диагностических кадров */
                    diag_next_ms = HAL_GetTick(); diag_prepared_seq = 0xFFFFFFFFu;
                }
                vnd_update_lcd_params();
            }
            break;
        case VND_CMD_SET_TRUNC_SAMPLES:
            if(len >= 3){
                uint16_t ns = (uint16_t)(data[1] | (data[2] << 8));
                vnd_trunc_samples = ns;
                VND_LOG("SET_TRUNC_SAMPLES %u", (unsigned)vnd_trunc_samples);
                cdc_logf("EVT SET_TRUNC %u", (unsigned)vnd_trunc_samples);
                /* Сбросим текущий lock размера, чтобы статус отразил новые размеры, применится при следующем кадре */
                cur_samples_per_frame = 0;
                cur_expected_frame_size = 0;
            }
            break;
        case VND_CMD_SET_PROFILE:
            if(len >= 2)
            {
                uint8_t profile = data[1];
                uint8_t prof_id = ADC_PROFILE_B_DEFAULT;
                // Маппинг host profile -> firmware profile ID:
                // 0 -> ADC_PROFILE_A_200HZ (1360 samples @ 200Hz)
                // 1 -> ADC_PROFILE_B_DEFAULT (912 samples @ 300Hz)
                // 2 -> ADC_PROFILE_C_HIGH (944 samples @ 300Hz)
                // 3 -> ADC_PROFILE_D_MAX (976 samples @ 300Hz)
                // 4 -> ADC_PROFILE_E_400HZ (680 samples @ 400Hz HIGH-FPS)
                if(profile == 0) prof_id = ADC_PROFILE_A_200HZ;
                else if(profile == 1) prof_id = ADC_PROFILE_B_DEFAULT;
                else if(profile == 2) prof_id = ADC_PROFILE_C_HIGH;
                else if(profile == 3) prof_id = ADC_PROFILE_D_MAX;
                else if(profile == 4) prof_id = ADC_PROFILE_E_400HZ;
                int rc = adc_stream_set_profile(prof_id);
                VND_LOG("SET_PROFILE %u -> prof_id=%u rc=%d", profile, prof_id, rc);
                /* ДИАГНОСТИКА: вывести текущее состояние после смены профиля */
                if(rc == 0) {
                    host_profile = profile; /* запомним для LCD ровно то, что прислал хост */
                    uint16_t cur_samples = adc_stream_get_active_samples();
                    uint16_t cur_rate = adc_stream_get_buf_rate();
                    cdc_logf("EVT SET_PROFILE p=%u samples=%u rate=%u Hz", profile, cur_samples, cur_rate);
                    vnd_update_lcd_params();
                }
            }
            break;
        case VND_CMD_SET_ROI_US:
            if(len >= 5)
            {
                uint32_t start_sample = (uint32_t)(data[1] | (data[2] << 8) | (data[3] << 16) | (data[4] << 24));
                uint16_t samples = adc_stream_get_active_samples();
                uint16_t roi_len = (uint16_t)VND_ROI_LEN_DEFAULT;
                if(samples == 0u) samples = 600u;
                if(samples < roi_len) roi_len = samples;
                uint32_t max_start = (samples > roi_len) ? (uint32_t)(samples - roi_len) : 0u;
                if(start_sample > max_start) start_sample = max_start;
                win_start0 = (uint16_t)start_sample;
                win_len0 = roi_len;
                win_start1 = 0u;
                win_len1 = 0u;
                win_auto = 0;
                VND_LOG("SET_ROI_US start=%lu -> s0=%u l0=%u", (unsigned long)start_sample, win_start0, win_len0);
                /* При смене ROI сбросить накопители усреднения, чтобы не смешивать разные окна */
                vnd_avg_reset();
                vnd_update_lcd_params();
            }
            break;
        case VND_CMD_SET_BUF_RATE_FINE:
            if(len >= 3)
            {
                uint16_t buf_rate_hz = (uint16_t)(data[1] | (data[2] << 8));
                adc_stream_set_buf_rate_fine(buf_rate_hz);
                VND_LOG("CMD_IND SET_BUF_RATE_FINE %u Hz OK", (unsigned)buf_rate_hz);
                cdc_logf("CMD_IND SET_BUF_RATE_FINE %u Hz OK", (unsigned)buf_rate_hz);
                if(win_auto && (vnd_stream_mode == VND_STREAM_MODE_LOSSLESS_ROI || vnd_stream_mode == VND_STREAM_MODE_AVG_ROI)){
                    uint16_t prev_start = win_start0;
                    vnd_apply_auto_roi_window();
                    if(win_start0 != prev_start){
                        vnd_avg_reset();
                        vnd_update_lcd_params();
                        VND_LOG("AUTO_WINDOW s0=%u l0=%u", win_start0, win_len0);
                    }
                }
            }
            break;
        default:
            VND_LOG("IGN %02X", cmd);
            break;
    }
}

/* Duplicate vnd_diag_send64_once removed */
uint32_t vnd_get_last_txcplt_ms(void)
{
    return vnd_last_txcplt_ms;
}

uint32_t vnd_get_last_frame_txcplt_ms(void)
{
    return vnd_last_frame_txcplt_ms;
}

uint32_t vnd_get_last_host_rx_ack_ms(void)
{
    return vnd_last_host_rx_ack_ms;
}

uint32_t vnd_get_last_error(void)
{
    return vnd_last_error;
}

uint32_t vnd_get_stream_tx_cplt_count(void)
{
    return dbg_tx_cplt;
}

uint32_t vnd_get_stream_recovery_count(void)
{
    return dbg_tx_drop_recovery_count;
}

uint32_t vnd_get_stream_force_idle_count(void)
{
    return dbg_tx_force_idle_count;
}

void vnd_get_stream_recovery_diag(vnd_usb_recovery_diag_t *out)
{
    if(out == NULL) return;
    *out = dbg_tx_drop_recovery_diag;
}

/* Общее число переданных байт (все передачи) */
uint64_t vnd_get_total_tx_bytes(void)
{
    return vnd_total_tx_bytes;
}

/* Общее число переданных сэмплов (оба канала суммарно) */
uint64_t vnd_get_total_tx_samples(void)
{
    return vnd_total_tx_samples;
}

void vnd_log_usb_close_snapshot(const char *reason)
{
    uint32_t now_ms = HAL_GetTick();
    extern uint8_t USBD_VND_TxIsBusy(void);
    extern uint16_t USBD_VND_InTotalLength(void);
    extern uint32_t USBD_VND_DataInCount(void);
    extern volatile uint32_t main_loop_heartbeat;
    extern volatile uint32_t last_heartbeat_ms;
    extern volatile uint32_t loop_cycle_last_avg;
    extern volatile uint32_t g_usb_last_sof_ms;

    uint32_t last_age = 0xFFFFFFFFu;
    uint32_t frame_age = 0xFFFFFFFFu;
    uint32_t tx_age = 0xFFFFFFFFu;
    uint32_t host_rx_age = 0xFFFFFFFFu;
    uint32_t hb_age = 0xFFFFFFFFu;
    uint32_t sof_age = 0xFFFFFFFFu;
    uint32_t force_idle_age = 0xFFFFFFFFu;
    (void)vnd_tick_age_ms(now_ms, vnd_last_txcplt_ms, &last_age);
    (void)vnd_tick_age_ms(now_ms, vnd_last_frame_txcplt_ms, &frame_age);
    (void)vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &tx_age);
    (void)vnd_tick_age_ms(now_ms, vnd_last_host_rx_ack_ms, &host_rx_age);
    (void)vnd_tick_age_ms(now_ms, last_heartbeat_ms, &hb_age);
    (void)vnd_tick_age_ms(now_ms, g_usb_last_sof_ms, &sof_age);
    (void)vnd_tick_age_ms(now_ms, dbg_tx_force_idle_last_ms, &force_idle_age);

    adc_stream_debug_t dbg;
    adc_stream_get_debug(&dbg);
    const char *stA = (g_frames[0][0].st==FB_READY?"READY":(g_frames[0][0].st==FB_SENDING?"SENDING":"FILL"));
    const char *stB = (g_frames[0][1].st==FB_READY?"READY":(g_frames[0][1].st==FB_SENDING?"SENDING":"FILL"));

    printf("[USB_CLOSE_SNAPSHOT] reason=%s t=%lu stream=%u active=%u mode=%u async=%u ch=%u ep=%u ll=%u infl=%u pendB=%u sendch=%u meta=%u q=%u err=%lu kick=%u last=%lu frame=%lu txage=%lu len=%u tl=%u din=%lu rxage=%lu rx=%lu txcplt=%lu A=%lu B=%lu wr=%lu rd=%lu avg=%lu/%lu/%lu force=%lu/%lu drop=%lu/%lu hb=%lu hbage=%lu sof=%lu loop=%lu dma=%lu/%lu A_st=%s B_st=%s\r\n",
           reason ? reason : "?",
           (unsigned long)now_ms,
           (unsigned)streaming,
           (unsigned)vnd_stream_active,
           (unsigned)vnd_stream_mode,
           (unsigned)async_mode,
           (unsigned)vnd_ch_mode,
           (unsigned)vnd_ep_busy,
           (unsigned)USBD_VND_TxIsBusy(),
           (unsigned)vnd_inflight,
           (unsigned)pending_B,
           (unsigned)sending_channel,
           (unsigned)vnd_tx_meta_depth(),
           (unsigned)vnd_avg_q_count,
           (unsigned long)vnd_last_error,
           (unsigned)vnd_tx_kick,
           (unsigned long)last_age,
           (unsigned long)frame_age,
           (unsigned long)tx_age,
           (unsigned)vnd_last_tx_len,
           (unsigned)USBD_VND_InTotalLength(),
           (unsigned long)USBD_VND_DataInCount(),
           (unsigned long)host_rx_age,
           (unsigned long)vnd_host_rx_last_counter,
           (unsigned long)dbg_tx_cplt,
           (unsigned long)dbg_sent_ch0_total,
           (unsigned long)dbg_sent_ch1_total,
           (unsigned long)frame_wr_seq,
           (unsigned long)frame_rd_seq,
           (unsigned long)dbg_avg_in_frames,
           (unsigned long)dbg_avg_out_frames,
           (unsigned long)dbg_avg_tx_pairs,
           (unsigned long)dbg_tx_force_idle_count,
           (unsigned long)force_idle_age,
           (unsigned long)dbg_tx_drop_recovery_count,
           (unsigned long)dbg_tx_drop_recovery_request_count,
           (unsigned long)main_loop_heartbeat,
           (unsigned long)hb_age,
           (unsigned long)sof_age,
           (unsigned long)loop_cycle_last_avg,
           (unsigned long)dbg.dma_full0,
           (unsigned long)dbg.dma_full1,
           stA,
           stB);
}

void vnd_get_change_event_diag(vnd_change_event_diag_t *out)
{
    uint32_t primask;

    if(out == NULL){
        return;
    }

    primask = __get_PRIMASK();
    __disable_irq();
    out->enqueued = dbg_event_enqueued;
    out->tx_ok = dbg_event_tx_ok;
    out->tx_cplt = dbg_event_tx_cplt;
    out->dropped = dbg_event_dropped;
    out->queued = vnd_event_count;
    out->last_enqueue_type = dbg_event_last_enqueue_type;
    out->last_tx_type = dbg_event_last_tx_type;
    out->last_cplt_type = dbg_event_last_cplt_type;
    if(primask == 0u){
        __enable_irq();
    }
}

void Vendor_ChangeEvent_DiagPrint(void)
{
    uint32_t now_ms = HAL_GetTick();
    uint32_t enqueue_age_ms = 0xFFFFFFFFu;
    int32_t next_tx_in_ms = 0;

    if(vnd_event_last_enqueue_ms != 0u){
        (void)vnd_tick_age_ms(now_ms, vnd_event_last_enqueue_ms, &enqueue_age_ms);
    }
    if(vnd_event_next_tx_ms != 0u){
        next_tx_in_ms = (int32_t)(vnd_event_next_tx_ms - now_ms);
        if(next_tx_in_ms < 0){
            next_tx_in_ms = 0;
        }
    }

    printf("[EVT1] q=%u head=%u tail=%u seq=%lu enq=%lu tx_try=%lu tx_ok=%lu tx_fail=%lu tx_defer=%lu tx_cplt=%lu drop=%lu\r\n",
           (unsigned)vnd_event_count,
           (unsigned)vnd_event_head,
           (unsigned)vnd_event_tail,
           (unsigned long)vnd_event_seq,
           (unsigned long)dbg_event_enqueued,
           (unsigned long)dbg_event_tx_attempt,
           (unsigned long)dbg_event_tx_ok,
           (unsigned long)dbg_event_tx_fail,
           (unsigned long)dbg_event_tx_defer,
           (unsigned long)dbg_event_tx_cplt,
           (unsigned long)dbg_event_dropped);
    printf("[EVT1] last_enq=0x%02X last_tx=0x%02X last_cplt=0x%02X infl=0x%02X infl_len=%u last_age=%lu ms next_tx_in=%ld ms\r\n",
           (unsigned)dbg_event_last_enqueue_type,
           (unsigned)dbg_event_last_tx_type,
           (unsigned)dbg_event_last_cplt_type,
           (unsigned)vnd_event_inflight_type,
           (unsigned)vnd_event_inflight_len,
           (unsigned long)enqueue_age_ms,
           (long)next_tx_in_ms);
    printf("[EVT1] stream=%u active=%u first_pair=%u pendingB=%u send_ch=%u ep_busy=%u inflight=%u tx_kick=%u mode=%u async=%u full=%u\r\n",
           (unsigned)streaming,
           (unsigned)vnd_stream_active,
           (unsigned)first_pair_done,
           (unsigned)pending_B,
           (unsigned)sending_channel,
           (unsigned)vnd_ep_busy,
           (unsigned)vnd_inflight,
           (unsigned)vnd_tx_kick,
           (unsigned)vnd_stream_mode,
           (unsigned)async_mode,
           (unsigned)full_mode);
}

void Vendor_StreamDiagPrint(void)
{
    adc_stream_debug_t d;
    memset(&d, 0, sizeof(d));
    adc_stream_get_debug(&d);

    extern uint8_t USBD_VND_TxIsBusy(void);
    uint8_t ll_busy = USBD_VND_TxIsBusy();

    vnd_log_usb_close_snapshot("UART_VND");
    printf("[VNDSTR] stream=%u active=%u mode=%u full=%u async=%u ch=%u samples=%u req=%u frame=%u ep=%u ll=%u infl=%u tx_ready=%u txcplt=%lu crc_fin=%lu crc_last=0x%04X\r\n",
           (unsigned)streaming,
           (unsigned)vnd_stream_active,
           (unsigned)vnd_stream_mode,
           (unsigned)full_mode,
           (unsigned)async_mode,
           (unsigned)vnd_ch_mode,
           (unsigned)cur_samples_per_frame,
           (unsigned)vnd_frame_samples_req,
           (unsigned)cur_expected_frame_size,
           (unsigned)vnd_ep_busy,
           (unsigned)ll_busy,
           (unsigned)vnd_inflight,
           (unsigned)vnd_tx_ready,
           (unsigned long)dbg_tx_cplt,
           (unsigned long)dbg_frame_crc_finalized,
           (unsigned)dbg_frame_crc_last);
    printf("[VNDSTR] adc wr=%lu/%lu rd=%lu/%lu drops=%lu/%lu adc_pause=%u pause_events=%lu fifo=%u\r\n",
           (unsigned long)d.ch_wr_seq[0],
           (unsigned long)d.ch_wr_seq[1],
           (unsigned long)d.ch_rd_seq[0],
           (unsigned long)d.ch_rd_seq[1],
           (unsigned long)d.ch_overflow_drops[0],
           (unsigned long)d.ch_overflow_drops[1],
           (unsigned)adc_stream_paused,
           (unsigned long)adc_stream_pause_events,
           (unsigned)FIFO_FRAMES);
    printf("[VNDSTR] avg n=%u q=%u cnt=%u/%u in=%lu out=%lu tx_pairs=%lu drop=%lu min=%u max=%u pace_active=%u\r\n",
           (unsigned)vnd_avg_n,
           (unsigned)vnd_avg_q_count,
           (unsigned)vnd_avg_cnt[0],
           (unsigned)vnd_avg_cnt[1],
           (unsigned long)dbg_avg_in_frames,
           (unsigned long)dbg_avg_out_frames,
           (unsigned long)dbg_avg_tx_pairs,
           (unsigned long)dbg_avg_drop_frames,
           (unsigned)VND_AVG_MIN_N,
           (unsigned)VND_AVG_MAX_N,
           (unsigned)vnd_frame_pace_applies());
    for(uint8_t ch = 0u; ch < 2u; ch++){
        uint32_t age_ms = 0xFFFFFFFFu;
        if(dbg_async_last_ms[ch] != 0u){
            (void)vnd_tick_age_ms(HAL_GetTick(), dbg_async_last_ms[ch], &age_ms);
        }
        printf("[VNDSTR] ch%u snap=%lu gen_move=%lu fifo_guard=%lu cons_ok=%lu cons_fail=%lu last_seq=%lu slot=%lu samples=%u wr=%lu->%lu rd=%lu->%lu r2=0x%04X crc=0x%04X age=%lu\r\n",
               (unsigned)ch,
               (unsigned long)dbg_async_snapshot_copies[ch],
               (unsigned long)dbg_async_snapshot_gen_move[ch],
               (unsigned long)dbg_async_snapshot_fifo_guard[ch],
               (unsigned long)dbg_async_consume_ok[ch],
               (unsigned long)dbg_async_consume_fail[ch],
               (unsigned long)dbg_async_last_dma_seq[ch],
               (unsigned long)(dbg_async_last_dma_seq[ch] % (uint32_t)FIFO_FRAMES),
               (unsigned)dbg_async_last_samples[ch],
               (unsigned long)dbg_async_last_wr_before[ch],
               (unsigned long)dbg_async_last_wr_after[ch],
               (unsigned long)dbg_async_last_rd_before[ch],
               (unsigned long)dbg_async_last_rd_after[ch],
               (unsigned)dbg_async_last_reserved2[ch],
               (unsigned)dbg_async_last_crc16[ch],
               (unsigned long)age_ms);
    }
    printf("[VNDSTR] reserved2 bits: 0..2=buffer_index 3..7=source_slot 8=snapshot 9=gen_changed 10=fifo_guard 11=consume_ok 12..15=txcplt_lsb\r\n");
    printf("[VNDSTR] event q=%u enq=%lu tx_ok=%lu tx_cplt=%lu drop=%lu\r\n",
           (unsigned)vnd_event_count,
           (unsigned long)dbg_event_enqueued,
           (unsigned long)dbg_event_tx_ok,
           (unsigned long)dbg_event_tx_cplt,
           (unsigned long)dbg_event_dropped);
}

/* Общая диагностическая функция: при обращении хоста за статусом проверяет признаки паузы
   и печатает STALL_WARN не чаще чем раз в 2 секунды. Вызывается как из bulk-пути, так и из EP0. */
/* Беззнаковая разность тиков (обработка переполнения 32-бит HAL_GetTick()). */
static inline uint32_t tick_diff32(uint32_t now, uint32_t before){
    return (now >= before) ? (now - before) : (0xFFFFFFFFu - before + 1u + now);
}

void vnd_diag_log_possible_stall(void)
{
    static uint32_t last_stall_warn_ms = 0;
    if(!streaming) return;
    uint32_t now_ms = HAL_GetTick();
    uint32_t dt = tick_diff32(now_ms, vnd_last_txcplt_ms);
    if(dt <= 600 || dt >= 3000) return;
    if(last_stall_warn_ms != 0 && (now_ms - last_stall_warn_ms) <= 2000) return;
    extern uint8_t USBD_VND_TxIsBusy(void);
    uint8_t ll_busy = USBD_VND_TxIsBusy();
    const char *stA = (g_frames[0][0].st==FB_READY?"READY":(g_frames[0][0].st==FB_SENDING?"SENDING":"FILL"));
    const char *stB = (g_frames[0][1].st==FB_READY?"READY":(g_frames[0][1].st==FB_SENDING?"SENDING":"FILL"));
    adc_stream_debug_t dbg; adc_stream_get_debug(&dbg);
    const char *stall_class = "UNKNOWN";
    uint8_t have_meta = (vnd_tx_meta_depth() > 0);
    uint32_t wr = frame_wr_seq, rd = frame_rd_seq;
    if(!have_meta && !pending_B && !ll_busy && !vnd_ep_busy){
        stall_class = "ADC_IDLE";
    } else if((vnd_ep_busy || ll_busy) && vnd_inflight){
        stall_class = "USB_BUSY";
    } else if(pending_B){
        if(g_frames[0][1].st!=FB_READY && g_frames[0][1].st!=FB_SENDING){ stall_class = "WAIT_B_FILL"; }
        else if(g_frames[0][1].st==FB_READY && !vnd_ep_busy){ stall_class = "B_READY_NOT_TX"; }
        else if(g_frames[0][1].st==FB_SENDING){
            uint32_t b_age_ms = 0u;
            if(vnd_tick_age_ms(now_ms, vnd_last_tx_start_ms, &b_age_ms) && b_age_ms > 120u){
                stall_class = "B_INFLIGHT_LONG";
            } else {
                stall_class = "PEND_B";
            }
        }
        else stall_class = "PEND_B";
    } else if(!pending_B && g_frames[0][0].st==FB_READY && !vnd_ep_busy){
        stall_class = "A_READY_NOT_TX";
    } else if(have_meta && !vnd_inflight && !vnd_ep_busy){
        stall_class = "META_WAIT";
    }
    static uint32_t last_wr_seq = 0; static uint32_t last_wr_ms = 0;
    if(wr != last_wr_seq){ last_wr_seq = wr; last_wr_ms = now_ms; }
    else if(tick_diff32(now_ms, last_wr_ms) > 300 && strcmp(stall_class,"ADC_IDLE")!=0){ stall_class = "ADC_STALL"; }
    cdc_logf("STALL_WARN class=%s dt=%lums ep_busy=%u ll_busy=%u inflight=%u pendB=%u ch=%u A=%s B=%s metaD=%u wr=%lu rd=%lu prod=%lu sentA=%lu sentB=%lu dmaF0=%lu dmaF1=%lu",
        stall_class,
        (unsigned long)dt,
        (unsigned)vnd_ep_busy,
        (unsigned)ll_busy,
        (unsigned)vnd_inflight,
        (unsigned)pending_B,
        (unsigned)sending_channel,
        stA, stB,
        (unsigned)vnd_tx_meta_depth(),
        (unsigned long)wr,
        (unsigned long)rd,
        (unsigned long)dbg_produced_seq,
        (unsigned long)dbg_sent_ch0_total,
        (unsigned long)dbg_sent_ch1_total,
        (unsigned long)dbg.dma_full0,
        (unsigned long)dbg.dma_full1);
    VND_LOG("STALL_WARN class=%s dt=%lums ep_busy=%u ll_busy=%u pendB=%u A=%s B=%s metaD=%u wr=%lu rd=%lu",
        stall_class,
        (unsigned long)dt,
        (unsigned)vnd_ep_busy,
        (unsigned)ll_busy,
        (unsigned)pending_B,
        stA, stB,
        (unsigned)vnd_tx_meta_depth(),
        (unsigned long)wr,
        (unsigned long)rd);
    last_stall_warn_ms = now_ms;
}

/* Хук от цепочки ADC: когда появились новые кадры — пинаем таск */
void adc_stream_on_new_frames(uint32_t frames_added)
{
    (void)frames_added;
    /* минимальный kick: если не заняты и идёт стрим — дать шанс таску отправить */
    if(streaming){ vnd_tx_kick = 1; }
}

/* Получить текущие min/max АЦП значения из последних отправленных кадров */
void vnd_get_adc_minmax(int16_t *adc0_min, int16_t *adc0_max, 
                        int16_t *adc1_min, int16_t *adc1_max)
{
    static int16_t cached_adc0_min = 0;
    static int16_t cached_adc0_max = 0;
    static int16_t cached_adc1_min = 0;
    static int16_t cached_adc1_max = 0;
    static uint32_t cached_seq = 0;
    static uint32_t log_count = 0;
    
    if(!adc0_min || !adc0_max || !adc1_min || !adc1_max) {
        return;
    }
    
    /* Пытаемся найти последний готовый кадр для получения min/max */
    uint8_t idx = (pair_send_idx > 0) ? (pair_send_idx - 1) : (VND_PAIR_BUFFERS - 1);
    
    /* Логируем состояние буферов каждые 50 вызовов */
    if(log_count++ % 50 == 0) {
        printf("[VND_GET_MINMAX] idx=%u seq_cached=%lu seq_current=%lu st=%u samples0=%u samples1=%u\r\n",
               idx, cached_seq, g_frames[idx][0].seq, g_frames[idx][0].st,
               g_frames[idx][0].samples, g_frames[idx][1].samples);
    }
    
    /* Проверяем, был ли кадр уже обработан */
    if(g_frames[idx][0].seq != cached_seq && g_frames[idx][0].st != FB_FILL) {
        cached_seq = g_frames[idx][0].seq;
        printf("[VND_GET_MINMAX] Processing frame seq=%lu\r\n", cached_seq);
        
        /* Декодируем min/max из кадра ADC0 */
        const uint8_t *buf = g_frames[idx][0].buf;
        uint16_t samples = g_frames[idx][0].samples;
        
        if(samples > 0 && g_frames[idx][0].frame_size >= 32 + 2*samples) {
            const int16_t *data = (const int16_t *)(buf + 32);
            cached_adc0_min = data[0];
            cached_adc0_max = data[0];
            
            for(uint16_t i = 1; i < samples; i++) {
                if(data[i] < cached_adc0_min) cached_adc0_min = data[i];
                if(data[i] > cached_adc0_max) cached_adc0_max = data[i];
            }
        }
        
        /* Декодируем min/max из кадра ADC1 */
        buf = g_frames[idx][1].buf;
        samples = g_frames[idx][1].samples;
        
        if(samples > 0 && g_frames[idx][1].frame_size >= 32 + 2*samples) {
            const int16_t *data = (const int16_t *)(buf + 32);
            cached_adc1_min = data[0];
            cached_adc1_max = data[0];
            
            for(uint16_t i = 1; i < samples; i++) {
                if(data[i] < cached_adc1_min) cached_adc1_min = data[i];
                if(data[i] > cached_adc1_max) cached_adc1_max = data[i];
            }
        }
        
        printf("[VND_GET_MINMAX] Decoded: CH0=%d..%d CH1=%d..%d\r\n",
               cached_adc0_min, cached_adc0_max, cached_adc1_min, cached_adc1_max);
    }
    
    *adc0_min = cached_adc0_min;
    *adc0_max = cached_adc0_max;
    *adc1_min = cached_adc1_min;
    *adc1_max = cached_adc1_max;
}

/* EOF (clean version) */
