#!/usr/bin/env bash
# USBv2: legacy live-root copy/activation is not a lower-only transaction.
if [ -f /opt/bmi30-universal/app-manifest.json ]; then
    printf '%s\n' 'USBv2: this legacy mutation is disabled until the reviewed lower-only/native transaction is installed.' >&2
    exit 64
fi
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    cat <<'EOF'
Использование:
    sudo ./utilities/sync_system_to_usb.sh [--yes] [--skip-eeprom] [--no-pause-services]

Назначение:
    Синхронизирует текущую eMMC-систему на USB без переразметки диска.

Важно:
    На USB уже должны существовать разделы boot (vfat) и root (ext4).
    Копирование выполняется через rsync --delete, поэтому лишние файлы на цели будут удалены.
    При копировании живой системы bmi30-core.service временно останавливается.
EOF
    exit 0
fi

exec "$SCRIPT_DIR/migrate_system_between_disks.sh" --source-role internal --target-role usb --sync-only "$@"
