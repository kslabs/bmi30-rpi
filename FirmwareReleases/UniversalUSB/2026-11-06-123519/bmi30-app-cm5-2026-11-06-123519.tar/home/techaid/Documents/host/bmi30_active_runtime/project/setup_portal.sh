#!/bin/sh
printf "%s\n" "CM5-family Portal is installed by the reviewed APP image builder; legacy setup/EEPROM/DNS mutation is disabled." >&2
exit 64
