#!/usr/bin/env bash
# USBv2: legacy live-root copy/activation is not a lower-only transaction.
if [ -f /opt/bmi30-universal/app-manifest.json ]; then
    printf '%s\n' 'USBv2: this legacy mutation is disabled until the reviewed lower-only/native transaction is installed.' >&2
    exit 64
fi
# Compatibility wrapper. The split BMI30 project is versioned as a whole system now.

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
exec "$SCRIPT_DIR/switch_bmi30_split_versions.sh" "$@"
