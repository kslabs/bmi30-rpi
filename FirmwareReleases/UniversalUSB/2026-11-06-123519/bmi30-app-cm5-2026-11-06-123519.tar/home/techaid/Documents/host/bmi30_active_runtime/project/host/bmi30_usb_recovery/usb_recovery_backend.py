"""Read-only USBv2 portal state. Legacy live-overlay writers are not shipped.

The later reviewed lower-only target transaction must replace this boundary;
the presence of an APP artifact alone never authorizes formatting/copying.
"""
import http.client
import json
from pathlib import Path

class Refused(RuntimeError):pass

def state():
    manifest=json.loads(Path('/opt/bmi30-universal/app-manifest.json').read_bytes())
    return {'ok':True,'version':manifest['bundle_id'],'purpose':'universal-usb-v2',
      'can_write':False,'blocked_reason':'USBv2 lower-only target installation has not been qualified. No live overlay copy is allowed.',
      'disks':[],'operation':{'stage':'idle','progress':0,'safe_to_remove':False},
      'emmc':{'available':False,'can_restore':False,'target':None},
      'copy':{'kind':None,'target':None},'boot':{'from_recovery_usb':True,'adoption':{}}}

def dispatch(method,data=None):
    if method=='status':return state()
    if method=='read-stm32':
        connection=http.client.HTTPConnection('127.0.0.1',8765,timeout=2)
        try:
            connection.request('GET','/api/status');response=connection.getresponse();value=json.loads(response.read(1048576))
        finally:connection.close()
        link=value.get('connection')or{};sync=value.get('sync')or{}
        if (response.status!=200 or value.get('ok')is not True or value.get('stale')or link.get('connected')is not True
                or not isinstance(link.get('last_frame_age_s'),(int,float))or not 0<=link['last_frame_age_s']<3
                or sync.get('device_responded')is not True):
            raise Refused('No currently connected STM32; saved firmware/role is not a live device')
        # Existing acquisition owner remains the only USB owner.
        return {'ok':True,'stm32':{'source':'current-Core-owner-cache','sync':value.get('sync'),'connection':{'connected':True}}}
    raise Refused('Legacy USB/eMMC writer is disabled for USBv2; use the separately reviewed lower-only target transaction')
