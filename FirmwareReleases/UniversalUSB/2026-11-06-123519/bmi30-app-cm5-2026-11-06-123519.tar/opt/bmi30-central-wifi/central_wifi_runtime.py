"""Network0.2.11 opt-in credential policy; no catalog/PSK migration or logs."""
from pathlib import Path
import os
import stat

MARKER = Path('/etc/bmi30-network/central-wifi-ram-only')
RAM = Path('/run/bmi30-network/credentials-ram')
PREFIX = 'BMI30-central-'


def enabled(marker=MARKER):
    if not marker.exists() and not marker.is_symlink():
        return False
    info = marker.lstat()
    if marker.is_symlink() or not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise RuntimeError('Unsafe central Wi-Fi policy marker')
    if marker.read_bytes() != b'1\n':
        raise RuntimeError('Invalid central Wi-Fi policy marker')
    return True


def volatile(path, mountinfo=Path('/proc/self/mountinfo')):
    target = str(path.resolve())
    matches = []
    for line in mountinfo.read_text().splitlines():
        before, separator, after = line.partition(' - ')
        if not separator:
            continue
        fields = before.split()
        mount = fields[4].replace('\\040', ' ').replace('\\134', '\\')
        if target == mount or target.startswith(mount.rstrip('/') + '/'):
            matches.append((len(mount), after.split()[0]))
    return bool(matches and max(matches)[1] in ('tmpfs', 'ramfs'))


class CredentialPolicy:
    def __init__(self, central, directory):
        self.central = central
        self.catalog = directory / 'credentials.json'

    def accept(self, key):
        return not self.central or not isinstance(key, str) or not key.startswith('wifi:')

    def shared(self, records):
        return {key: value for key, value in records.items() if self.accept(key)}


def credential_policy(config, marker=MARKER, ram=RAM):
    central = enabled(marker)
    if not central:
        return CredentialPolicy(False, Path(config.get('state_dir', '/var/lib/bmi30-network')))
    if os.geteuid() != 0 or not str(ram).startswith('/run/') or not volatile(ram):
        raise RuntimeError('Central Wi-Fi requires root-owned volatile runtime storage')
    for parent in (ram,) + tuple(ram.parents):
        if parent.is_symlink():
            raise RuntimeError('Central Wi-Fi runtime symlink refused')
    ram.mkdir(parents=True, mode=0o700, exist_ok=True)
    info = ram.stat()
    if info.st_uid != 0 or not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o700:
        raise RuntimeError('Unsafe central Wi-Fi runtime directory')
    return CredentialPolicy(True, ram)


def central_profile(name):
    return enabled() and isinstance(name, str) and name.startswith(PREFIX)
