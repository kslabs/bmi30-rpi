#!/usr/bin/env python3
"""Generic own-bound CM5 service. No board allowlist, installer or USB writes."""
import sys
sys.dont_write_bytecode = True
import http.client
import json
import os
from pathlib import Path
import signal
import threading
import uuid
from central_wifi_client import ClientError, RamWifiClient, require
from lifecycle import Lifecycle, RuntimeNm
import central_wifi_runtime

RUNTIME = Path('/run/bmi30-central-wifi')


def report_file(name, value):
    # Counts/status only, tmpfs only, no catalog, SSID, UUID, PSK or token.
    require(central_wifi_runtime.volatile(RUNTIME) and not RUNTIME.is_symlink(), 'runtime_not_volatile')
    RUNTIME.mkdir(mode=0o700, exist_ok=True)
    info = RUNTIME.stat()
    require(info.st_uid == 0 and info.st_mode & 0o077 == 0, 'unsafe_runtime_directory')
    temporary = RUNTIME / ('.status-' + uuid.uuid4().hex)
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, 'w') as stream:
        json.dump(value, stream, sort_keys=True)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, RUNTIME / name)


def guard():
    require(os.geteuid() == 0, 'root_required')
    require('Compute Module 5' in Path('/proc/device-tree/model').read_text().strip('\0'), 'unsupported_hardware')
    require(central_wifi_runtime.enabled(), 'central_authority_not_enabled')
    require(not Path('/run/bmi30-access/busy').exists(), 'maintenance_busy')
    connection = http.client.HTTPConnection('127.0.0.1', 8791, timeout=4)
    try:
        connection.request('GET', '/status')
        reply = connection.getresponse()
        value = json.loads(reply.read(1048576))
        require(reply.status == 200 and value.get('version') == '0.2.11', 'network_authority_not_running')
        require(value.get('credential_authority') == 'server-ram', 'network_authority_not_running')
    except ClientError:
        raise
    except Exception:
        raise ClientError('network_authority_not_running') from None
    finally:
        connection.close()


def main():
    stop = threading.Event()
    for number in (signal.SIGTERM, signal.SIGINT):
        signal.signal(number, lambda *args: stop.set())
    try:
        worker = Lifecycle(RuntimeNm(), RamWifiClient(), guard)
    except Exception:
        print(json.dumps({'ok': False, 'status': 'startup_unavailable'}), flush=True)
        sys.exit(1)
    generation = os.environ.get('INVOCATION_ID', '')
    if len(generation) != 32 or any(c not in '0123456789abcdef' for c in generation):
        generation = uuid.uuid4().hex
    try:
        while not stop.is_set():
            # Counts/static status only; never print exception/body/profile data.
            status = worker.tick()
            status['generation'] = generation
            report_file('status.json', status)
            print(json.dumps(status, sort_keys=True), flush=True)
            stop.wait(60)
    finally:
        worker.client.clear()
        result = dict(status='stopped', generation=generation, owned_remaining=len(worker.owned), **worker.cleanup())
        result['owned_remaining'] = len(worker.owned)
        result['ok'] = result['owned_remaining'] == 0
        report_file('cleanup.json', result)
        print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
