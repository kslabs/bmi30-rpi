"""Called BEFORE restoring a legacy network. Never deletes/disconnects profiles."""
import json
from pathlib import Path
import subprocess
from adapter import NmAdapter

UNIT = 'bmi30-central-wifi.service'


def reserved_count(nm):
    paths = list(nm.backend.connections())
    if len(paths) > 256:
        raise RuntimeError('NM inventory limit prevents safe legacy restore')
    return sum(str(nm.backend.settings(path).get('connection', {}).get('id', '')).startswith('BMI30-central-') for path in paths)


def assert_legacy_safe(nm=None, command=None):
    """Explicit updater rollback action only; stop this daemon, not NM/radio/Core."""
    def default_command(args):
        result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
        if result.returncode:
            raise RuntimeError('Central Wi-Fi stop/status guard failed')
        return result.stdout.decode().strip()
    command = command or default_command
    state = command(['systemctl', 'show', UNIT, '-p', 'LoadState', '-p', 'MainPID'])
    values = dict(line.split('=', 1) for line in state.splitlines() if '=' in line)
    if values.get('LoadState') != 'not-found':
        command(['systemctl', 'stop', UNIT])
        after = command(['systemctl', 'show', UNIT, '-p', 'MainPID'])
        if dict(line.split('=', 1) for line in after.splitlines() if '=' in line).get('MainPID') != '0':
            raise RuntimeError('Central Wi-Fi still running; legacy restore blocked')
    count = reserved_count(nm or NmAdapter())
    if count:
        raise RuntimeError('Central RAM profiles remain; legacy restore blocked pending explicit manual cleanup. No profile was disconnected or deleted.')
    return {'ok': True, 'central_daemon_stopped': True, 'central_RAM_profile_count': 0,
            'profile_delete_or_disconnect': False}
