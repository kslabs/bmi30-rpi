"""Local candidate. RAM catalog only; no CLI, persistence, or live NM adapter.

The caller must never log credentials, response bodies, observations or plans.
No token generation, identity adoption, network activation, or fallback store.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import re
import ssl
import stat
import time
import uuid
from urllib.parse import urlsplit

BASE = 'https://www.teiots.net/bmi30'
GET = '/api/v1/wifi/catalog'
MERGE = '/api/v1/wifi/catalog/merge'
MAX_BODY = 65536
MAX_REPLY = 2 * 1024 * 1024
FIELDS = {'ssid', 'psk', 'security', 'origin', 'revision', 'updated'}
IN_MEMORY_BLOCK_AUTOCONNECT = 0x2 | 0x20


class ClientError(RuntimeError):
    """Only static local codes; never propagate a remote exception/body."""
    def __init__(self, code, status=None):
        super().__init__(code)
        self.code, self.status = code, status


def require(value, code='invalid_data'):
    if not value:
        raise ClientError(code)


def _pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, 'duplicate_json_key')
        result[key] = value
    return result


def decode(data, limit=MAX_REPLY):
    require(isinstance(data, bytes) and len(data) <= limit, 'response_too_large')
    try:
        return json.loads(data, object_pairs_hook=_pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ClientError('invalid_json')))
    except ClientError:
        raise
    except Exception:
        raise ClientError('invalid_json') from None


def encode(value):
    try:
        data = json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    except Exception:
        raise ClientError('invalid_data') from None
    require(len(data) <= MAX_BODY, 'request_too_large')
    return data


def _integer(value, minimum=0):
    require(type(value) is int and minimum <= value <= 2**53 - 1)


def _finite(value):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0)


def validate_record(key, record):
    require(isinstance(record, dict) and set(record) == FIELDS)
    ssid, psk, security = record['ssid'], record['psk'], record['security']
    try:
        require(isinstance(ssid, str) and 1 <= len(ssid.encode('utf-8')) <= 32 and '\0' not in ssid)
        require(key == 'wifi:' + ssid and isinstance(psk, str) and '\0' not in psk)
        n = len(psk.encode('utf-8'))
    except (UnicodeError, TypeError):
        raise ClientError('invalid_data') from None
    require((security == 'open' and psk == '') or
            (security == 'wpa-psk' and (8 <= n <= 63 or bool(re.fullmatch('[a-fA-F0-9]{64}', psk)))) or
            (security == 'sae' and 1 <= n <= 63))
    require(isinstance(record['origin'], str) and bool(re.fullmatch('BMI30-[A-F0-9]{16}', record['origin'])))
    _integer(record['revision'], 1)
    _finite(record['updated'])


@dataclass(frozen=True, repr=False)
class Credentials:
    device_id: str
    token: str = field(repr=False)
    base_url: str = BASE

    def validate(self):
        require(self.base_url == BASE, 'unapproved_server')
        require(bool(re.fullmatch('BMI30-[A-F0-9]{16}', self.device_id)), 'invalid_identity')
        require(isinstance(self.token, str) and 40 <= len(self.token) <= 512 and
                all(33 <= ord(c) <= 126 for c in self.token), 'invalid_token')
        return self


def _private_read(path, limit):
    """Read an existing regular private file without following a final symlink."""
    fd = None
    try:
        path = Path(path)
        require(not path.is_symlink(), 'unsafe_agent_file')
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode) and info.st_size <= limit, 'unsafe_agent_file')
        require((info.st_dev, info.st_ino) == (path.lstat().st_dev, path.lstat().st_ino), 'unsafe_agent_file')
        if os.name == 'posix':
            require(not info.st_mode & 0o077 and info.st_uid in (0, os.geteuid()), 'unsafe_agent_file')
        data = os.read(fd, limit + 1)
        require(len(data) <= limit, 'unsafe_agent_file')
        return data
    except ClientError:
        raise
    except Exception:
        raise ClientError('agent_unavailable') from None
    finally:
        if fd is not None:
            os.close(fd)


def load_agent_credentials(config_path=Path('/etc/bmi30-agent/config.json'),
                           state_dir=Path('/var/lib/bmi30-agent'),
                           serial_path=Path('/proc/device-tree/serial-number')):
    """Use only pre-existing, locally approved, physically bound Agent identity.

    Server authorization is checked again on every request. No Agent import or
    check-in is invoked. Paths are injectable solely for offline fixture tests.
    """
    try:
        config = decode(_private_read(config_path, MAX_BODY), MAX_BODY)
        require(config.get('server_url') == BASE, 'unapproved_server')
        state_dir = Path(state_dir)
        token_path = Path(str(config.get('device_api_token_path', state_dir / 'device_api_token')))
        require(token_path == state_dir / 'device_api_token', 'unsafe_token_path')
        state = decode(_private_read(state_dir / 'state.json', MAX_BODY), MAX_BODY)
        require(state.get('server_state') == 'approved', 'agent_not_approved')
        serial = Path(serial_path).read_text().strip('\0\r\n ').upper()
        require(bool(re.fullmatch('[A-F0-9]{16}', serial)), 'invalid_identity')
        bound = _private_read(state_dir / 'bound_raspberry_serial', 128).decode().strip().upper()
        require(bound == serial, 'foreign_agent_identity')
        token = _private_read(token_path, 1024).decode('ascii').strip()
        return Credentials('BMI30-' + serial, token).validate()
    except ClientError:
        raise
    except Exception:
        raise ClientError('agent_unavailable') from None


class HttpsTransport:
    """http.client does not follow redirects; only exact fixed routes allowed."""
    def __init__(self, timeout=8, connection_factory=None):
        require(type(timeout) in (int, float) and 0 < timeout <= 15)
        self.timeout = timeout
        self._factory = connection_factory or http.client.HTTPSConnection

    def __call__(self, credentials, method, path, body=None):
        credentials.validate()
        require((method, path) in {('GET', GET), ('POST', MERGE)}, 'unapproved_route')
        require(body is None or isinstance(body, bytes) and len(body) <= MAX_BODY)
        connection = None
        try:
            target = urlsplit(credentials.base_url)
            context = ssl.create_default_context()
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            connection = self._factory(target.hostname, 443, timeout=self.timeout, context=context)
            headers = {'Authorization': 'Bearer ' + credentials.token, 'Accept': 'application/json',
                       'Cache-Control': 'no-store', 'Connection': 'close', 'User-Agent': 'BMI30-CentralWifi-Candidate/1'}
            if body is not None:
                headers['Content-Type'] = 'application/json; charset=utf-8'
            connection.request(method, target.path + path, body=body, headers=headers)
            response = connection.getresponse()
            status = response.status
            if 300 <= status < 400:
                raise ClientError('redirect_rejected', status)
            if status != 200:
                raise ClientError('revision_conflict' if status == 409 else 'server_unavailable', status)
            require(response.getheader('Content-Type', '').split(';')[0].strip().lower() == 'application/json', 'invalid_content_type')
            return decode(response.read(MAX_REPLY + 1))
        except ClientError:
            raise
        except Exception:
            raise ClientError('transport_unavailable') from None
        finally:
            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass  # Never surface a third-party exception/body from cleanup.


@dataclass(frozen=True, repr=False)
class RamProfilePlan:
    action: str
    uuid: str
    settings: dict = field(repr=False)
    flags: int = IN_MEMORY_BLOCK_AUTOCONNECT


class RamWifiClient:
    def __init__(self, credential_loader=load_agent_credentials, transport=None, clock=time.time):
        self._credentials = credential_loader
        self._transport = transport or HttpsTransport()
        self._clock = clock
        self.clear()

    def clear(self):
        # Logical reference purge; Python strings do not promise memory zeroization.
        self._catalog = None
        self._owner = None
        self._refreshed_at = None

    def summary(self):
        if self._catalog is None:
            return {'available': False, 'records': 0}
        return {'available': True, 'scope': self._catalog['scope'],
                'revision': self._catalog['revision'], 'records': len(self._catalog['records'])}

    def refresh(self):
        self.clear()
        try:
            credentials = self._credentials().validate()
            value = self._transport(credentials, 'GET', GET)
            require(isinstance(value, dict) and value.get('ok') is True)
            require(isinstance(value.get('scope'), str) and bool(re.fullmatch('system:[1-9][0-9]*', value['scope'])))
            _integer(value.get('revision'))
            records = value.get('records')
            require(isinstance(records, dict) and len(records) <= 1024)
            for key, record in records.items():
                validate_record(key, record)
                require(record['revision'] <= value['revision'])
            self._catalog = copy.deepcopy(value)
            self._owner = credentials.device_id
            self._refreshed_at = self._clock()
            return self.summary()
        except ClientError:
            self.clear()
            raise
        except Exception:
            self.clear()
            raise ClientError('invalid_server_response') from None

    def publish_active(self, observation):
        """One fresh caller-observed active STA only. No merge retries or choices.

        The caller supplies a fresh explicit connectivity observation, never a
        NetworkManager saved-profile timestamp. It remains client-reported proof.
        """
        try:
            require(isinstance(observation, dict), 'invalid_observation')
            require(observation.get('active') is True and observation.get('station') is True and
                    observation.get('server_reachable') is True, 'unverified_station')
            observed = observation.get('observed_at')
            _finite(observed)
            require(self._clock() - 60 <= observed <= self._clock() + 30, 'stale_observation')
            self.refresh()
            credentials = self._credentials().validate()
            require(credentials.device_id == self._owner, 'identity_changed')
            record = {name: observation.get(name) for name in ('ssid', 'psk', 'security')}
            record.update(origin=credentials.device_id, revision=1, updated=observed)
            key = 'wifi:' + str(record['ssid'])
            validate_record(key, record)
            require(self._clock() - 60 <= observed <= self._clock() + 30, 'stale_observation')
            body = {'expected_revision': self._catalog['revision'], 'records': {key: record},
                    'provenance': {key: {'source': 'active_station_server_reachable',
                                        'verification': 'client_reported_connected', 'client_observed_at': observed}}}
            result = self._transport(credentials, 'POST', MERGE, encode(body))
            require(isinstance(result, dict) and result.get('ok') is True and result.get('scope') == self._catalog['scope'])
            _integer(result.get('revision'))
            require(result['revision'] >= self._catalog['revision'])
            return {key: result[key] for key in ('ok', 'scope', 'revision')}
        except ClientError:
            raise
        except Exception:
            raise ClientError('invalid_observation') from None
        finally:
            # Never retain a stale CAS snapshot or publish response as catalog.
            self.clear()

    def plan_ram_profiles(self, existing_profiles):
        """Pure GetSettings-style input -> plan. NO NetworkManager calls.

        The live lifecycle/adapter revalidates scope and profile inventory
        immediately before AddConnection2. Existing UUIDs/settings are untouched;
        this method only returns plans.
        """
        require(self._catalog is not None, 'catalog_unavailable')
        if not 0 <= self._clock() - self._refreshed_at <= 60:
            self.clear()
            raise ClientError('stale_catalog')
        require(isinstance(existing_profiles, list), 'invalid_profile_inventory')
        plans = []
        for record in self._catalog['records'].values():
            ssid = record['ssid'].encode('utf-8')
            matches = []
            for profile in existing_profiles:
                require(isinstance(profile, dict), 'invalid_profile_inventory')
                wireless = profile.get('802-11-wireless', {})
                raw_ssid = wireless.get('ssid')
                if raw_ssid is None:
                    continue
                try:
                    require(isinstance(raw_ssid, (str, bytes, bytearray, list, tuple)), 'invalid_profile_inventory')
                    profile_ssid = raw_ssid.encode('utf-8') if isinstance(raw_ssid, str) else bytes(raw_ssid)
                    require(1 <= len(profile_ssid) <= 32, 'invalid_profile_inventory')
                except (UnicodeError, ValueError, TypeError):
                    raise ClientError('invalid_profile_inventory') from None
                if profile_ssid == ssid:
                    matches.append(profile)
            if matches:
                compatible = []
                for profile in matches:
                    connection = profile.get('connection', {})
                    wireless = profile.get('802-11-wireless', {})
                    security = profile.get('802-11-wireless-security', {}).get('key-mgmt', 'open')
                    if (connection.get('type') == '802-11-wireless' and wireless.get('mode', 'infrastructure') == 'infrastructure'
                            and security == record['security'] and connection.get('uuid')):
                        compatible.append(profile)
                if len(matches) == len(compatible) == 1:
                    plans.append(RamProfilePlan('reuse_unchanged', compatible[0]['connection']['uuid'], {}))
                # Ambiguous/incompatible/agent-owned existing profiles never edited.
                continue
            identity = str(uuid.uuid4())
            settings = {'connection': {'id': 'BMI30-central-' + hashlib.sha256(ssid).hexdigest()[:12],
                                       'uuid': identity, 'type': '802-11-wireless', 'autoconnect': False},
                        '802-11-wireless': {'ssid': ssid, 'mode': 'infrastructure'},
                        'ipv4': {'method': 'auto'}, 'ipv6': {'method': 'auto'}}
            if record['security'] != 'open':
                settings['802-11-wireless-security'] = {'key-mgmt': record['security'], 'psk': record['psk'], 'psk-flags': 0}
            plans.append(RamProfilePlan('add_in_memory', identity, settings))
        return plans
