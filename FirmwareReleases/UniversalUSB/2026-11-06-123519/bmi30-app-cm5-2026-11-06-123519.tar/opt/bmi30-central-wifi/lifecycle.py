"""Periodic scoped RAM download/manual activation service. Never auto-roams."""
from __future__ import annotations
import copy
import hashlib
import json
import time
from central_wifi_client import ClientError, RamWifiClient, encode, require, validate_record
from adapter import NmAdapter, NM, ACTIVE, CONNECTION, _public_settings


def public_fingerprint(settings):
    return hashlib.sha256(json.dumps(_public_settings(settings), sort_keys=True,
        separators=(',', ':'), default=lambda value: list(value)).encode()).hexdigest()


class RuntimeNm(NmAdapter):
    def reserved_uuids(self):
        paths = list(self.backend.connections())
        require(len(paths) <= 256, 'too_many_NM_profiles')
        result = set()
        for path in paths:
            connection = self.backend.settings(path).get('connection', {})
            if str(connection.get('id', '')).startswith('BMI30-central-'):
                result.add(str(connection.get('uuid', '')))
        return result

    def stage_owned(self, plan):
        result = self.add_new_ram(plan)
        if result == 'skipped_existing':
            return None
        matches = []
        for path in self.backend.connections():
            settings = self.backend.settings(path)
            if str(settings.get('connection', {}).get('uuid')) == plan.uuid:
                matches.append((str(path), settings))
        require(len(matches) == 1, 'RAM_add_outcome_unknown')
        path, settings = matches[0]
        return {'path': path, 'uuid': plan.uuid, 'name': str(settings['connection'].get('id', '')),
                'public_fingerprint': public_fingerprint(settings)}

    def retire_owned(self, record):
        # Do not Delete: even an inactive->Delete check races manual activation.
        # Positive disappearance may be acknowledged; retained entries block a
        # legacy network rollback until an explicit operator removes them.
        try:
            paths = list(self.backend.connections())
            if record['path'] not in [str(path) for path in paths]:
                if not any(str(self.backend.settings(path).get('connection', {}).get('uuid')) == record['uuid'] for path in paths):
                    return 'already_gone'
                return 'foreign_preserved'
            settings = self.backend.settings(record['path'])
            connection = settings.get('connection', {})
            if (str(connection.get('uuid')) != record['uuid'] or str(connection.get('id')) != record['name']
                    or public_fingerprint(settings) != record['public_fingerprint']
                    or not bool(self.backend.get_all(record['path'], CONNECTION).get('Unsaved'))):
                return 'foreign_preserved'
            for path in self.backend.get_all('/org/freedesktop/NetworkManager', NM).get('ActiveConnections', []):
                if str(self.backend.get_all(path, ACTIVE).get('Uuid')) == record['uuid']:
                    return 'active_protected'
            return 'inactive_retained_manual'
        except Exception:
            return 'unavailable_preserved'


class Lifecycle:
    def __init__(self, nm, client, guard, clock=time.time, max_new=1, max_owned=8):
        require(type(max_new) is int and 0 <= max_new <= 2 and 1 <= max_owned <= 8, 'invalid_runtime_limits')
        self.nm, self.client, self.guard, self.clock = nm, client, guard, clock
        self.max_new, self.max_owned = max_new, max_owned
        self.owned = []
        self.scope = None
        self.import_suspended = False

    def cleanup(self, desired=None, scope=None):
        result = {'RAM_gone': 0, 'active_protected': 0, 'inactive_retained_manual': 0, 'foreign_or_unavailable_preserved': 0}
        keep = []
        for entry in self.owned:
            record = (desired or {}).get(entry['key'])
            if scope == entry['scope'] and record and record['revision'] == entry['revision']:
                keep.append(entry)
                continue
            outcome = self.nm.retire_owned(entry)
            if outcome == 'already_gone':
                result['RAM_gone'] += 1
            else:
                keep.append(entry)
                result[outcome if outcome in ('active_protected', 'inactive_retained_manual') else 'foreign_or_unavailable_preserved'] += 1
        self.owned = keep
        return result

    def publish_saved_active(self):
        try:
            observation = self.nm.active_station(read_secret=True)
        except ClientError:
            return 'not_exportable'
        key = 'wifi:' + observation['ssid']
        previous = self.client._catalog['records'].get(key)
        if previous:
            return 'already_present' if previous['psk'] == observation['psk'] and previous['security'] == observation['security'] else 'conflict_no_replacement'
        require(self.clock() - 60 <= observation['observed_at'] <= self.clock() + 30, 'stale_active_candidate')
        current = self.nm.active_station(read_secret=True)
        require(self.nm.same_station(observation, current) and observation['psk'] == current['psk'], 'active_station_changed')
        self.guard()
        credentials = self.client._credentials().validate()
        require(credentials.device_id == self.client._owner, 'identity_changed')
        record = {name: observation[name] for name in ('ssid', 'psk', 'security')}
        record.update(origin=credentials.device_id, revision=1, updated=observation['observed_at'])
        validate_record(key, record)
        response = self.client._transport(credentials, 'POST', '/api/v1/wifi/catalog/merge', encode({
            'expected_revision': self.client._catalog['revision'], 'records': {key: record},
            'provenance': {key: {'source': 'nm_saved_profile', 'verification': 'unverified'}}}))
        require(response.get('ok') is True and response.get('scope') == self.scope, 'unexpected_merge_ack')
        require(self.client.refresh()['scope'] == self.scope, 'server_scope_changed')
        return 'saved_candidate_acknowledged_unverified'

    def tick(self):
        status = {'ok': False, 'status': 'unavailable', 'catalog_records': 0, 'RAM_created': 0,
                  'pending_manual_activation': 0, 'automatic_roaming': False, 'persistent_downloads': False}
        try:
            self.guard()  # Requires live network0.2.11 +RAM authority marker.
            summary = self.client.refresh()
            self.scope = summary['scope']
            status.update(self.cleanup(self.client._catalog['records'], self.scope))
            previous_scope_retained = any(entry['scope'] != self.scope for entry in self.owned)
            unknown_reserved = self.nm.reserved_uuids() - {entry['uuid'] for entry in self.owned}
            status['unknown_retained_manual'] = len(unknown_reserved)
            status['active_export'] = self.publish_saved_active()
            summary = self.client.summary()
            status['catalog_records'] = summary['records']
            plans = self.client.plan_ram_profiles(self.nm.profiles())
            status['existing_reused_readonly'] = sum(plan.action == 'reuse_unchanged' for plan in plans)
            additions = [plan for plan in plans if plan.action == 'add_in_memory']
            if not self.import_suspended and not previous_scope_retained and not unknown_reserved:
                for old_plan in additions[:min(self.max_new, self.max_owned - len(self.owned))]:
                    self.guard()
                    require(self.client.refresh()['scope'] == self.scope, 'server_scope_changed')
                    key = 'wifi:' + old_plan.settings['802-11-wireless']['ssid'].decode('utf-8')
                    fresh = [plan for plan in self.client.plan_ram_profiles(self.nm.profiles())
                             if plan.action == 'add_in_memory' and plan.settings['802-11-wireless']['ssid'] == old_plan.settings['802-11-wireless']['ssid']]
                    if not fresh:
                        continue
                    try:
                        entry = self.nm.stage_owned(fresh[0])
                    except ClientError:
                        self.import_suspended = True  # Never repeat ambiguous Add.
                        raise
                    if entry:
                        entry.update(scope=self.scope, key=key, revision=self.client._catalog['records'][key]['revision'])
                        self.owned.append(entry)
                        status['RAM_created'] += 1
            status.update(ok=True, status='download_ready_pending_manual_activation',
                          pending_manual_activation=len(self.owned), imports_suspended=self.import_suspended or previous_scope_retained or bool(unknown_reserved))
        except ClientError as error:
            status.update(status=error.code, HTTP_status=error.status)
            if error.code != 'maintenance_busy':
                status.update(self.cleanup())
        except Exception:
            status['status'] = 'runtime_unavailable'
            status.update(self.cleanup())
        finally:
            self.client.clear()  # No offline catalog; retain no server PSKs between ticks.
        return status
