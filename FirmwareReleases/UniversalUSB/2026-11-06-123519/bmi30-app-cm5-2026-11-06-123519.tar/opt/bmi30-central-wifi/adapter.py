"""M04 canary NM adapter. No activation/Update/Save/Delete methods.

New profiles are unsaved and block autoconnect. No persistent local store;
GetSecrets reads only the active STA or a newly created owned RAM profile.
NM may keep that new secret in its root-private keyfile on verified tmpfs.
"""
from __future__ import annotations
import copy
import hashlib
import hmac
import os
from pathlib import Path
import re
import stat
import subprocess
import time
import uuid
from central_wifi_client import ClientError, IN_MEMORY_BLOCK_AUTOCONNECT, require

NM = 'org.freedesktop.NetworkManager'
SETTINGS = NM + '.Settings'
CONNECTION = SETTINGS + '.Connection'
DEVICE = NM + '.Device'
WIRELESS = DEVICE + '.Wireless'
ACTIVE = NM + '.Connection.Active'
AP = NM + '.AccessPoint'


def _uuid(value):
    value = str(value)
    require(str(uuid.UUID(value)) == value, 'invalid_NM_uuid')
    return value


def _ssid(value):
    try:
        raw = value.encode('utf-8') if isinstance(value, str) else bytes(value)
        text = raw.decode('utf-8')
        require(1 <= len(raw) <= 32 and '\0' not in text, 'unsupported_NM_SSID')
        return raw, text
    except ClientError:
        raise
    except Exception:
        raise ClientError('unsupported_NM_SSID') from None


def _public_settings(value):
    """Keep only non-secret fields needed by the existing pure planner."""
    result = {}
    for group, names in {'connection': ('type', 'uuid', 'interface-name', 'autoconnect'),
                         '802-11-wireless': ('ssid', 'mode', 'bssid', 'mac-address'),
                         '802-11-wireless-security': ('key-mgmt', 'psk-flags')}.items():
        source = value.get(group, {})
        result[group] = {name: copy.deepcopy(source[name]) for name in names if name in source}
    if 'ssid' in result['802-11-wireless']:
        result['802-11-wireless']['ssid'] = _ssid(result['802-11-wireless']['ssid'])[0]
    for key in ('autoconnect',):
        if key in result['connection']:
            result['connection'][key] = bool(result['connection'][key])
    if 'key-mgmt' in result['802-11-wireless-security'] or 'psk-flags' in result['802-11-wireless-security']:
        result['802-11-wireless-security']['psk-flags'] = int(value.get('802-11-wireless-security', {}).get('psk-flags', 0))
    return result


RAM_DIRECTORY = Path('/run/NetworkManager/system-connections')


def _tmpfs(path):
    result = subprocess.run(['/usr/bin/findmnt', '-n', '-o', 'FSTYPE', '-T', str(path)],
        stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=5,
        env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LC_ALL': 'C'})
    require(result.returncode == 0 and result.stdout.strip() == 'tmpfs', 'RAM_storage_not_tmpfs')


def _ram_parent():
    require(RAM_DIRECTORY.resolve() == RAM_DIRECTORY, 'RAM_storage_alias')
    for path in (RAM_DIRECTORY, RAM_DIRECTORY.parent, RAM_DIRECTORY.parent.parent):
        info = path.lstat()
        require(stat.S_ISDIR(info.st_mode) and not path.is_symlink() and info.st_uid == 0
                and not info.st_mode & 0o022, 'RAM_storage_parent_unsafe')
    _tmpfs(RAM_DIRECTORY)


def _ram_backing(props, identifier):
    require(bool(props.get('Unsaved')) and int(props.get('Flags', 0)) == 1 and 'Filename' in props,
            'RAM_storage_not_unsaved')
    _ram_parent()
    filename = str(props['Filename'])
    if filename == '':
        return ('memory-object',)
    require(re.fullmatch('BMI30-central-[0-9a-f]{12}', identifier) is not None, 'RAM_profile_id_unsafe')
    path = RAM_DIRECTORY / (identifier + '.nmconnection')
    require(filename == str(path) and path.resolve() == path and not path.is_symlink(),
            'RAM_profile_filename_unsafe')
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_uid == 0 and info.st_nlink == 1
            and stat.S_IMODE(info.st_mode) == 0o600 and 0 < info.st_size <= 65536
            and info.st_dev == RAM_DIRECTORY.stat().st_dev, 'RAM_profile_file_unsafe')
    _tmpfs(path)
    expected = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NOATIME)
    with os.fdopen(fd, 'rb') as stream:
        held = os.fstat(stream.fileno())
        require((held.st_dev, held.st_ino, held.st_size, held.st_mtime_ns) == expected, 'RAM_file_changed')
        raw = stream.read(65537)
        held, named = os.fstat(stream.fileno()), path.lstat()
        require(len(raw) == info.st_size and (held.st_dev, held.st_ino, held.st_size, held.st_mtime_ns)
                == (named.st_dev, named.st_ino, named.st_size, named.st_mtime_ns) == expected, 'RAM_file_changed')
    # This digest stays inside the process and is never returned by the adapter.
    return ('tmpfs-keyfile', *expected, hashlib.sha256(raw).digest())


class DbusBackend:
    def __init__(self):
        import dbus  # Linux-only, lazy; no hardware or bus access on import.
        self.dbus = dbus
        self.bus = dbus.SystemBus()

    def interface(self, path, name):
        return self.dbus.Interface(self.bus.get_object(NM, str(path)), name)

    def get_all(self, path, name):
        return self.interface(path, 'org.freedesktop.DBus.Properties').GetAll(name, timeout=4)

    def device(self):
        return str(self.interface('/org/freedesktop/NetworkManager', NM).GetDeviceByIpIface('wlan0', timeout=4))

    def connections(self):
        return self.interface('/org/freedesktop/NetworkManager/Settings', SETTINGS).ListConnections(timeout=5)

    def settings(self, path):
        return self.interface(path, CONNECTION).GetSettings(timeout=4)

    def applied(self, path):
        value = self.interface(path, DEVICE).GetAppliedConnection(self.dbus.UInt32(0), timeout=4)
        return value[0], int(value[1])

    def secrets(self, path):
        return self.interface(path, CONNECTION).GetSecrets('802-11-wireless-security', timeout=5)

    def add(self, settings, flags):
        typed = {}
        for group, values in settings.items():
            typed[group] = {}
            for name, value in values.items():
                if name == 'ssid':
                    value = self.dbus.ByteArray(value)
                elif isinstance(value, bool):
                    value = self.dbus.Boolean(value)
                elif name == 'psk-flags':
                    value = self.dbus.UInt32(value)
                typed[group][name] = value
            typed[group] = self.dbus.Dictionary(typed[group], signature='sv')
        result = self.interface('/org/freedesktop/NetworkManager/Settings', SETTINGS).AddConnection2(
            self.dbus.Dictionary(typed, signature='sa{sv}'), self.dbus.UInt32(flags),
            self.dbus.Dictionary({}, signature='sv'), timeout=5)
        return str(result[0])


class NmAdapter:
    def __init__(self, backend=None, clock=time.time):
        self.backend = backend or DbusBackend()
        self.clock = clock

    def active_station(self, read_secret=False):
        try:
            device_path = self.backend.device()
            device = self.backend.get_all(device_path, DEVICE)
            require(str(device.get('Interface')) == 'wlan0' and int(device.get('DeviceType', 0)) == 2 and
                    int(device.get('State', 0)) == 100, 'wlan0_not_active')
            active_path = str(device.get('ActiveConnection', '/'))
            require(active_path.startswith('/org/freedesktop/NetworkManager/ActiveConnection/'), 'STA_not_active')
            active = self.backend.get_all(active_path, ACTIVE)
            require(int(active.get('State', 0)) == 2 and str(active.get('Type')) == '802-11-wireless' and
                    device_path in [str(p) for p in active.get('Devices', [])] and bool(active.get('Default')), 'STA_not_default_route')
            path = str(active.get('Connection', ''))
            require(path.startswith('/org/freedesktop/NetworkManager/Settings/'), 'invalid_active_profile')
            settings = self.backend.settings(path)
            connection, wireless = settings.get('connection', {}), settings.get('802-11-wireless', {})
            identity = _uuid(connection.get('uuid', ''))
            require(str(active.get('Uuid')) == identity and str(connection.get('type')) == '802-11-wireless'
                    and str(wireless.get('mode', 'infrastructure')) == 'infrastructure', 'active_profile_mismatch')
            raw, text = _ssid(wireless.get('ssid', []))
            ap_path = str(self.backend.get_all(device_path, WIRELESS).get('ActiveAccessPoint', '/'))
            require(ap_path.startswith('/org/freedesktop/NetworkManager/AccessPoint/'), 'active_AP_missing')
            access_point = self.backend.get_all(ap_path, AP)
            require(int(access_point.get('Mode', 0)) == 2 and _ssid(access_point.get('Ssid', []))[0] == raw, 'active_AP_mismatch')
            security = settings.get('802-11-wireless-security', {})
            key_mgmt = str(security.get('key-mgmt', '')) or 'open'
            require(key_mgmt in ('open', 'wpa-psk', 'sae'), 'unsupported_active_security')
            applied, applied_version = self.backend.applied(device_path)
            require(str(applied.get('connection', {}).get('uuid')) == identity and
                    _ssid(applied.get('802-11-wireless', {}).get('ssid', []))[0] == raw and
                    str(applied.get('802-11-wireless', {}).get('mode', 'infrastructure')) == 'infrastructure' and
                    (str(applied.get('802-11-wireless-security', {}).get('key-mgmt', '')) or 'open') == key_mgmt,
                    'saved_applied_profile_mismatch')
            result = {'uuid': identity, 'profile_path': path, 'active_path': active_path,
                      'AP_path': ap_path, 'BSSID': str(access_point.get('HwAddress', '')).lower(),
                      'ssid': text, 'security': key_mgmt, 'station': True, 'active': True,
                      'applied_version': int(applied_version),
                      'observed_at': self.clock()}
            if read_secret:
                if key_mgmt == 'open':
                    result['psk'] = ''
                else:
                    # GetSecrets for agent-owned/not-saved profiles can involve a
                    # separate secret agent. Do not request or change its store.
                    require(int(security.get('psk-flags', 0)) == 0, 'active_secret_agent_owned')
                    result['psk'] = str(self.backend.secrets(path).get('802-11-wireless-security', {}).get('psk', ''))
                    require(bool(result['psk']), 'active_secret_unavailable')
                after = self.active_station(False)
                require(self.same_station(result, after), 'active_station_changed')
            return result
        except ClientError:
            raise
        except Exception:
            raise ClientError('NM_active_read_unavailable') from None

    @staticmethod
    def same_station(first, second):
        return all(first.get(k) == second.get(k) for k in
                   ('uuid', 'profile_path', 'active_path', 'AP_path', 'BSSID', 'ssid', 'security', 'applied_version'))

    def profiles(self):
        try:
            paths = list(self.backend.connections())
            require(len(paths) <= 256, 'too_many_NM_profiles')
            return [_public_settings(self.backend.settings(path)) for path in paths]
        except ClientError:
            raise
        except Exception:
            raise ClientError('NM_inventory_unavailable') from None

    def add_new_ram(self, plan):
        """Explicit one-time caller only. Recheck exact SSID before creation."""
        try:
            require(plan.action == 'add_in_memory' and plan.flags == IN_MEMORY_BLOCK_AUTOCONNECT, 'unsafe_RAM_plan')
            settings = copy.deepcopy(plan.settings)
            allowed = {'connection': {'id', 'uuid', 'type', 'autoconnect'},
                       '802-11-wireless': {'ssid', 'mode'},
                       '802-11-wireless-security': {'key-mgmt', 'psk', 'psk-flags'},
                       'ipv4': {'method'}, 'ipv6': {'method'}}
            require(set(settings) <= set(allowed) and all(isinstance(values, dict) and set(values) <= allowed[group]
                    for group, values in settings.items()), 'unsafe_RAM_plan')
            connection, wireless = settings.get('connection', {}), settings.get('802-11-wireless', {})
            require(_uuid(connection.get('uuid')) == plan.uuid and connection.get('autoconnect') is False and
                    connection.get('type') == '802-11-wireless' and wireless.get('mode') == 'infrastructure', 'unsafe_RAM_plan')
            require(bool(re.fullmatch('BMI30-central-[0-9a-f]{12}', str(connection.get('id', '')))) and
                    settings.get('ipv4') == {'method': 'auto'} and settings.get('ipv6') == {'method': 'auto'}, 'unsafe_RAM_plan')
            raw, unused = _ssid(wireless.get('ssid', []))
            for existing in self.profiles():
                if existing.get('802-11-wireless', {}).get('ssid') == raw:
                    return 'skipped_existing'
            security = settings.get('802-11-wireless-security')
            if security:
                require(security.get('key-mgmt') in ('wpa-psk', 'sae') and security.get('psk-flags', 0) == 0 and isinstance(security.get('psk'), str) and bool(security['psk']), 'unsafe_RAM_secret_flags')
            # Check RAM before handing a system-owned PSK to NetworkManager.
            _ram_parent()
            path = self.backend.add(settings, plan.flags)
            require(path.startswith('/org/freedesktop/NetworkManager/Settings/'), 'RAM_add_outcome_unknown')
            props = self.backend.get_all(path, CONNECTION)
            actual_full = self.backend.settings(path)
            actual = _public_settings(actual_full)
            require(bool(props.get('Unsaved')) and actual['connection'].get('uuid') == plan.uuid and
                    actual['connection'].get('autoconnect') is False and actual['802-11-wireless'].get('ssid') == raw and
                    actual['802-11-wireless'].get('mode', 'infrastructure') == 'infrastructure', 'RAM_add_outcome_unknown')
            require(str(actual_full.get('connection', {}).get('id')) == str(connection['id']), 'RAM_add_outcome_unknown')
            backing = _ram_backing(props, str(connection['id']))
            if security:
                require(actual['802-11-wireless-security'].get('key-mgmt') == security['key-mgmt'] and
                        actual['802-11-wireless-security'].get('psk-flags', 0) == 0, 'RAM_add_outcome_unknown')
                returned = str(self.backend.secrets(path).get('802-11-wireless-security', {}).get('psk', ''))
                require(hmac.compare_digest(returned.encode('utf-8'), security['psk'].encode('utf-8')),
                        'RAM_secret_not_retained')
            # A later concurrent edit never becomes a successful import proof.
            after = self.backend.settings(path)
            require(_public_settings(after) == actual and str(after.get('connection', {}).get('id')) == str(connection['id'])
                    and _ram_backing(self.backend.get_all(path, CONNECTION), str(connection['id'])) == backing,
                    'RAM_profile_changed_during_verification')
            if security:
                final_secret = str(self.backend.secrets(path).get('802-11-wireless-security', {}).get('psk', ''))
                require(hmac.compare_digest(final_secret.encode('utf-8'), security['psk'].encode('utf-8')),
                        'RAM_profile_secret_changed_during_verification')
            return 'created_unsaved_blocked'
        except ClientError:
            raise
        except Exception:
            # No retries or deletes after an ambiguous AddConnection2 outcome.
            raise ClientError('RAM_add_outcome_unknown') from None
