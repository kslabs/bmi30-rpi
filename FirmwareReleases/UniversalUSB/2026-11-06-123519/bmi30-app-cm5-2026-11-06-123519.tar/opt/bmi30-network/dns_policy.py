#!/usr/bin/env python3
"""Canonical shared-DNS policy. Rendering never changes a radio or interface."""
import argparse
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import uuid

LOCAL_FILE = '90-bmi30-captive-portal.conf'
PROBE_FILE = '91-bmi30-captive-detection.conf'
OWNED_FILES = (LOCAL_FILE, PROBE_FILE)
LEGACY_FILE = '90-bmi30-hotspot-portal.conf'
PROBE_NAMES = (
    'captive.apple.com', 'msftconnecttest.com', 'www.msftconnecttest.com',
    'ipv6.msftconnecttest.com', 'www.msftncsi.com',
    'ipv6.msftncsi.com', 'connectivitycheck.gstatic.com',
    'connectivitycheck.android.com', 'clients3.google.com',
)


def read_file(path):
    path = Path(path)
    try:
        before = path.lstat()
    except FileNotFoundError:
        return None
    if not stat.S_ISREG(before.st_mode) or before.st_size > 65536:
        raise RuntimeError('Unsafe DNS policy file')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    try:
        opened = os.fstat(fd)
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise RuntimeError('DNS policy file changed while opening')
        data = bytearray()
        while len(data) <= 65536:
            block = os.read(fd, 65537 - len(data))
            if not block:
                break
            data.extend(block)
        if len(data) > 65536:
            raise RuntimeError('DNS policy file byte bound exceeded')
    finally:
        os.close(fd)
    after = path.lstat()
    if (after.st_dev, after.st_ino) != (opened.st_dev, opened.st_ino):
        raise RuntimeError('DNS policy filename changed while reading')
    return bytes(data).decode('utf-8')


def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_owned(path, value, expected, mode=0o644):
    """CAS one owned file; ignored hidden temp never becomes a conf-dir input."""
    path = Path(path)
    if path.name not in OWNED_FILES or path.parent.is_symlink():
        raise RuntimeError('Unapproved DNS write path')
    if not isinstance(value, str) or len(value.encode('utf-8')) > 65536:
        raise ValueError('Invalid DNS policy output')
    if read_file(path) != expected:
        raise RuntimeError('DNS policy changed before write')
    if not path.parent.exists():
        path.parent.mkdir(mode=0o755)
        fsync_directory(path.parent.parent)
    temp = path.with_name('.' + path.name + '.bmi30-' + uuid.uuid4().hex + '.tmp')
    fd, owner = None, None
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                     getattr(os, 'O_NOFOLLOW', 0), 0o600)
        opened = os.fstat(fd)
        owner = opened.st_dev, opened.st_ino
        os.fchmod(fd, mode)
        data = value.encode('utf-8')
        offset = 0
        while offset < len(data):
            count = os.write(fd, data[offset:])
            if count <= 0:
                raise OSError('Short DNS policy write')
            offset += count
        os.fsync(fd)
        os.close(fd)
        fd = None
        if read_file(path) != expected:
            raise RuntimeError('DNS policy changed before replace')
        current_temp = temp.lstat()
        if (current_temp.st_dev, current_temp.st_ino) != owner:
            raise RuntimeError('DNS temporary owner changed')
        os.replace(temp, path)
        fsync_directory(path.parent)
    finally:
        if fd is not None:
            os.close(fd)
        if owner is not None:
            try:
                remaining = temp.lstat()
            except FileNotFoundError:
                remaining = None
            if remaining is not None and (remaining.st_dev, remaining.st_ino) == owner:
                temp.unlink()
                fsync_directory(path.parent)


def remove_owned(path, expected):
    path = Path(path)
    if path.name not in OWNED_FILES or path.parent.is_symlink() or read_file(path) != expected:
        raise RuntimeError('DNS rollback owner changed')
    path.unlink(missing_ok=True)
    fsync_directory(path.parent)


def read_directory(directory):
    directory = Path(directory)
    if directory.is_symlink():
        raise RuntimeError('Unsafe DNS policy directory')
    if not directory.exists():
        return {}
    paths = list(directory.iterdir())
    if len(paths) > 128:
        raise RuntimeError('Too many DNS policy entries')
    result, total = {}, 0
    for path in paths:
        # dnsmasq --conf-dir's unconditional ignored-name rules.
        if path.name.startswith('.') or path.name.endswith('~') or (
                path.name.startswith('#') and path.name.endswith('#')):
            continue
        text = read_file(path)
        if text is None:
            raise RuntimeError('DNS policy entry disappeared')
        total += len(text.encode('utf-8'))
        if total > 4 * 1024 * 1024:
            raise RuntimeError('DNS policy byte bound exceeded')
        result[path.name] = text
    return result


def render(hostname=None):
    """Return public rules without copying any address or device settings."""
    names = ['bmi30.local']
    if hostname is not None:
        if not isinstance(hostname, str) or not re.fullmatch(
                r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?', hostname):
            raise ValueError('Invalid local hostname')
        name = hostname.lower() + '.local'
        if name not in names:
            names.append(name)

    def aliases(domains):
        lines = []
        for name in domains:
            lines.append('interface-name=' + name + ',wlan0ap/4')
            # Do not forward AAAA/HTTPS or subdomains for dedicated local names.
            lines.append('local=/' + name + '/')
        return lines

    local = ['# BMI30 canonical local aliases; no wildcard Internet interception.',
             '# Addresses follow existing interfaces; this file configures no interfaces.',
             *aliases(names)]
    probes = ['# BMI30 dedicated OS captive-portal probes only.',
              '# Ordinary domains, including www.gstatic.com, remain upstream.',
              *aliases(PROBE_NAMES),
              '# Windows DNS probe retains its documented expected address.',
              'host-record=dns.msftncsi.com,131.107.255.255']
    return {LOCAL_FILE: '\n'.join(local) + '\n',
            PROBE_FILE: '\n'.join(probes) + '\n'}


def foreign_rules(existing):
    """Fail closed on extra global redirects; never delete an unknown policy."""
    result = {}
    for name, value in existing.items():
        if name in OWNED_FILES:
            continue
        if not isinstance(value, str):
            raise ValueError('Invalid DNS policy bytes')
        for line in value.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if re.match(r'address\s*=\s*/\s*#\s*/', line):
                raise RuntimeError('Extra wildcard DNS policy requires reviewed migration')
            if re.match(r'conf-(?:file|dir|script)\s*=', line):
                raise RuntimeError('Nested DNS policy requires reviewed migration')
        result[name] = value
    return result


def syntax_check(policy, extra=None, runner=None):
    """Use dnsmasq's parser only: --test exits without binding DNS/DHCP sockets."""
    if set(policy) != set(OWNED_FILES):
        raise ValueError('Incomplete canonical DNS policy')
    extra = foreign_rules(extra or {})
    data = '\n'.join(policy[name] for name in OWNED_FILES)
    data += '\n' + '\n'.join(extra[name] for name in sorted(extra))
    proc = (runner or subprocess.run)(
        ('dnsmasq', '--test', '--conf-file=-'), input=data,
        capture_output=True, text=True, timeout=10,
        env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LC_ALL': 'C'})
    if proc.returncode:
        raise RuntimeError('Canonical DNS syntax validation failed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hostname')
    args = parser.parse_args()
    print(json.dumps(render(args.hostname), sort_keys=True))


if __name__ == '__main__':
    main()
