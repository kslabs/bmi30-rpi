#!/usr/bin/env python3
"""Initialize lgpio's notification FIFO before entering the immutable core."""
import importlib
import os
from pathlib import Path
import runpy
import sys


def prepare_lgpio():
    previous = os.getcwd()
    try:
        importlib.import_module('lgpio')
    except Exception as exc:
        # Acquisition and the engine's existing GPIO fallback remain available.
        print('[GPIO22] lgpio bootstrap failed: ' + str(exc), file=sys.stderr, flush=True)
    finally:
        # lgpio's first notification open may chdir to LG_WD.
        os.chdir(previous)


def main(argv=None):
    arguments = list(sys.argv[1:] if argv is None else argv)
    if not arguments:
        print('Usage: bmi30_core_bootstrap.py CORE.py [arguments...]', file=sys.stderr)
        return 2
    core = str(Path(arguments[0]).resolve())
    # Direct Python exposes an absolute __file__. multiprocessing.spawn uses
    # it after the core changes cwd, so runpy must receive the absolute path.
    arguments[0] = core
    # Match direct Python script execution, including imports beside the core.
    sys.path[0] = str(Path(core).parent)
    sys.argv = arguments
    prepare_lgpio()
    runpy.run_path(core, run_name='__main__')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
