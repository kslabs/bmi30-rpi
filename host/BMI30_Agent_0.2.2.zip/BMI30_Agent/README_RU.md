# BMI30 Agent 0.2.2

Production-агент Raspberry Pi для регистрации в BMI30 Hub и отдельного reverse
SSH-туннеля к локальному Portal. ChatGPT на устройстве не требуется.

## Production endpoints

```text
Hub:      https://www.teiots.net/bmi30
Check-in: https://www.teiots.net/bmi30/api/v1/agent/checkin
SSH:      bmi30-tunnel@www.teiots.net:2222
```

HTTPS проверяется обычным системным CA-хранилищем. В агенте отсутствуют `-k`,
`verify=False` и отключение TLS-проверки. SSH host key впервые принимается
только из approved-ответа доверенного HTTPS Hub и затем жёстко закрепляется.

## Миграция на production-туннель

Installer сохраняет старый `bmi30-reverse-tunnel.service` и его отдельные файлы
в датированный root-only backup, затем останавливает, отключает и полностью
удаляет их. Production-туннель называется `bmi30-tunnel.service`. Компоненты
BMI20 с другими именами не изменяются.

```bash
unzip BMI30_Agent_0.2.2.zip
cd BMI30_Agent
sudo ./install_bmi30_agent.sh
```

В check-in поле `agent_version` содержит версию установленного websplit-комплекта
Raspberry, `firmware_version` — только реальную версию приложения STM32 из
`EVT1 FW_INFO`, а версия самого коннектора передаётся как `connector_version`.

По умолчанию installer останавливает старую версию только
`bmi30-agent.service`, устанавливает код и оставляет её autostart выключенным до
ручной проверки:

```bash
sudo bmi30-agent-ctl checkin
sudo bmi30-agent-ctl status
```

Первый успешный check-in обычно возвращает `pending`. После подтверждения
устройства администратором повторите check-in. При `approved` агент проверит
production host/user/port, закрепит Ed25519 host key и запустит отдельный
`bmi30-tunnel.service`.

После успешной ручной проверки:

```bash
sudo bmi30-agent-ctl enable
```

Команда ещё раз выполняет check-in и затем включает autostart агента. При
перезагрузке агент получает актуальное назначение и запускает туннель.

Установка с немедленной проверкой и включением агента:

```bash
sudo ./install_bmi30_agent.sh --enable-agent
```

## Постоянная идентичность

- `DEVICE_ID` детерминирован из 16-значного CPU serial Raspberry.
- Ed25519-ключ создаётся один раз в `/etc/bmi30-agent/id_ed25519`.
- Bearer API token создаётся один раз и хранится в
  `/var/lib/bmi30-agent/device_api_token` с mode `0600`.
- Ключ и token не пересоздаются после HTTP 401/409 или обычного рестарта.
- Приватный ключ и API token никогда не выводятся в status/logs и не входят в
  check-in JSON.

Если склонированный диск запущен на другой Raspberry, runtime сверяет CPU serial
с `DEVICE_ID` и не запускает скопированный туннель. Повторный запуск installer
обнаруживает несовпадение, сохраняет backup, удаляет старый BMI30-туннель и
создаёт для новой Raspberry уникальные key/token.

`--reset-identity` предназначен только для явного повторного enrollment после
проверки backup:

```bash
sudo ./install_bmi30_agent.sh --reset-identity
```

## Файлы

```text
/opt/bmi30-agent/bmi30_agent.py          агент
/opt/bmi30-agent/run_bmi30_tunnel.sh    проверяющий SSH wrapper
/etc/bmi30-agent/config.json             конфигурация, 0600
/etc/bmi30-agent/id_ed25519              отдельный закрытый ключ, 0600
/etc/bmi30-agent/id_ed25519.pub          публичный ключ
/etc/bmi30-agent/known_hosts             закреплённый production host key, 0600
/etc/bmi30-agent/tunnel.env              назначение без секретов, 0600
/var/lib/bmi30-agent/device_api_token    Bearer token, 0600
/var/lib/bmi30-agent/state.json          последнее состояние, 0600
/var/backups/bmi30-agent/<UTC>/          pre-change backup и AUDIT.txt
```

Каталоги `/etc/bmi30-agent` и `/var/lib/bmi30-agent` имеют mode `0700`.
На текущем устройстве `bmi30-tunnel.service` запускает `/usr/bin/ssh` напрямую
от root, поскольку закрытые `0700/0600` пути недоступны непривилегированному
пользователю. Unit сохраняет systemd hardening и использует назначенный Hub
порт `26395`. Этот порт относится только к `BMI30-ABDD2DBC9775FBAE`; перед
тиражированием на другие Raspberry их units должны получить собственные порты
из approved-ответов Hub.

## Поведение Hub

- `pending`: новый production-туннель остановлен, check-in повторяется через
  `next_checkin_seconds`;
- `approved`: строгая проверка назначения и запуск/обновление туннеля;
- `blocked` / `rejected`: останавливается только `bmi30-tunnel.service`;
- HTTP 401/409: key/token сохраняются, быстрые повторы прекращаются;
- 5xx/timeout: exponential backoff, работающий туннель не уничтожается.

## Диагностика

```bash
sudo bmi30-agent-ctl status
sudo bmi30-agent-ctl logs
systemctl --no-pager --full status bmi30-tunnel.service
```

## Удаление и rollback

```bash
sudo ./uninstall_bmi30_agent.sh
```

По умолчанию identity/token/host pin сохраняются. Полное удаление новой
production identity требует `--remove-identity`.

Installer печатает `BACKUP_DIR`. Для возврата к предыдущей версии сначала
отключите новые units, затем восстановите файлы из соответствующих путей backup
и выполните `systemctl daemon-reload`. Не копируйте private key/token в отчёты.
