import importlib.util
import json
from pathlib import Path
import ssl
import tempfile
import unittest
from unittest import mock


MODULE_PATH = Path(__file__).resolve().parents[1] / "src" / "bmi30_agent.py"
SPEC = importlib.util.spec_from_file_location("bmi30_agent_under_test", MODULE_PATH)
agent = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(agent)


VALID_DEVICE_ID = "BMI30-0123456789ABCDEF"
VALID_KEY_DATA = "AAAAC3NzaC1lZDI1NTE5AAAAIG9YfqvTAkOgkC6UauorTj84m5B7uQy4F1vKQ2D4Pq8x"
VALID_PUBLIC_KEY = f"ssh-ed25519 {VALID_KEY_DATA} {VALID_DEVICE_ID}@bmi30-tunnel"
VALID_HOST_KEY = f"ssh-ed25519 {VALID_KEY_DATA}"


class FakeResponse:
    def __init__(self, status=200, payload=None):
        self.status = status
        self.payload = payload if payload is not None else {"state": "pending"}

    def read(self, _limit):
        return json.dumps(self.payload).encode("utf-8")


class FakeHTTPSConnection:
    instances = []
    response = FakeResponse()

    def __init__(self, host, port, timeout, context):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.context = context
        self.request_data = None
        self.closed = False
        self.__class__.instances.append(self)

    def request(self, method, path, body, headers):
        self.request_data = (method, path, body, headers)

    def getresponse(self):
        return self.__class__.response

    def close(self):
        self.closed = True


class IdentityTests(unittest.TestCase):
    def test_device_id_must_match_raspberry_serial(self):
        with mock.patch.object(agent, "raspberry_serial", return_value="0123456789ABCDEF"):
            self.assertEqual(
                agent.validate_hardware_identity({"device_id": VALID_DEVICE_ID}),
                VALID_DEVICE_ID,
            )
            with self.assertRaisesRegex(agent.AgentError, "cloned"):
                agent.validate_hardware_identity({"device_id": "BMI30-FEDCBA9876543210"})

    def test_public_key_comment_must_match_device_id(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "key.pub"
            path.write_text(VALID_PUBLIC_KEY + "\n", encoding="utf-8")
            self.assertEqual(agent.read_public_key(path, VALID_DEVICE_ID), VALID_PUBLIC_KEY)
            with self.assertRaisesRegex(agent.AgentError, "comment"):
                agent.read_public_key(path, "BMI30-FEDCBA9876543210")


class HTTPSContractTests(unittest.TestCase):
    def setUp(self):
        FakeHTTPSConnection.instances.clear()
        FakeHTTPSConnection.response = FakeResponse()

    def test_system_ca_and_production_path_are_used(self):
        payload = {"device_id": VALID_DEVICE_ID, "public_key": VALID_PUBLIC_KEY}
        token = "t" * 48
        with mock.patch.object(agent.http.client, "HTTPSConnection", FakeHTTPSConnection):
            status, response = agent.system_ca_https_json(
                agent.PRODUCTION_SERVER_URL,
                agent.CHECKIN_PATH,
                payload,
                token=token,
                timeout=7,
            )
        self.assertEqual(status, 200)
        self.assertEqual(response["state"], "pending")
        connection = FakeHTTPSConnection.instances[-1]
        self.assertEqual((connection.host, connection.port), ("www.teiots.net", 443))
        self.assertEqual(connection.context.verify_mode, ssl.CERT_REQUIRED)
        self.assertTrue(connection.context.check_hostname)
        method, path, body, headers = connection.request_data
        self.assertEqual((method, path), ("POST", "/bmi30/api/v1/agent/checkin"))
        self.assertEqual(headers["Authorization"], f"Bearer {token}")
        self.assertNotIn(token.encode("ascii"), body)

    def test_only_exact_production_url_is_allowed(self):
        for value in (
            "http://www.teiots.net/bmi30",
            "https://www.teiots.net/",
            "https://65.21.225.43/bmi30",
            "https://www.teiots.net:444/bmi30",
        ):
            with self.subTest(value=value), self.assertRaises(agent.AgentError):
                agent.validate_server_url(value)

    def test_payload_larger_than_64_kib_is_rejected(self):
        with self.assertRaisesRegex(agent.AgentError, "exceeds"):
            agent.system_ca_https_json(
                agent.PRODUCTION_SERVER_URL,
                agent.CHECKIN_PATH,
                {"large": "x" * agent.MAX_CHECKIN_BYTES},
                token="t" * 48,
                timeout=1,
            )


class ApprovedResponseTests(unittest.TestCase):
    def approved(self):
        return {
            "state": "approved",
            "remote_port": 23456,
            "listen_address": "0.0.0.0",
            "ssh_host": "www.teiots.net",
            "ssh_port": 2222,
            "ssh_user": "bmi30-tunnel",
            "ssh_host_public_key": VALID_HOST_KEY,
        }

    def test_exact_production_assignment_is_accepted(self):
        value = agent.validate_approved_response(self.approved())
        self.assertEqual(value["remote_port"], 23456)

    def test_wrong_host_port_user_and_listen_address_are_rejected(self):
        mutations = {
            "ssh_host": "example.invalid",
            "ssh_port": 22,
            "ssh_user": "root",
            "listen_address": "127.0.0.1",
            "remote_port": 19999,
        }
        for field, value in mutations.items():
            response = self.approved()
            response[field] = value
            with self.subTest(field=field), self.assertRaises(agent.AgentError):
                agent.validate_approved_response(response)

    def test_pinned_host_key_cannot_rotate_automatically(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "known_hosts"
            agent.pin_ssh_host_key(path, "www.teiots.net", 2222, VALID_HOST_KEY)
            first = path.read_text(encoding="utf-8")
            agent.pin_ssh_host_key(path, "www.teiots.net", 2222, VALID_HOST_KEY)
            self.assertEqual(path.read_text(encoding="utf-8"), first)
            replacement = "y" if VALID_KEY_DATA[-1] != "y" else "x"
            different = f"ssh-ed25519 {VALID_KEY_DATA[:-1]}{replacement}"
            with self.assertRaisesRegex(agent.AgentError, "refusing"):
                agent.pin_ssh_host_key(path, "www.teiots.net", 2222, different)


class StateHandlingTests(unittest.TestCase):
    def test_pending_stops_only_new_tunnel(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public_key = root / "id.pub"
            public_key.write_text(VALID_PUBLIC_KEY + "\n", encoding="utf-8")
            token = root / "token"
            token.write_text("t" * 48 + "\n", encoding="ascii")
            config_path = root / "config.json"
            config_path.write_text(
                json.dumps(
                    {
                        "server_url": agent.PRODUCTION_SERVER_URL,
                        "device_id": VALID_DEVICE_ID,
                        "ssh_private_key_path": str(root / "id"),
                        "ssh_public_key_path": str(public_key),
                        "device_api_token_path": str(token),
                        "local_port": 80,
                    }
                ),
                encoding="utf-8",
            )
            calls = []

            def fake_systemctl(*args, **_kwargs):
                calls.append(args)
                return agent.subprocess.CompletedProcess(args, 0, "inactive\n", "")

            with (
                mock.patch.object(agent, "raspberry_serial", return_value="0123456789ABCDEF"),
                mock.patch.object(agent, "collect_metadata", return_value={"device_id": VALID_DEVICE_ID}),
                mock.patch.object(
                    agent,
                    "system_ca_https_json",
                    return_value=(200, {"state": "pending", "next_checkin_seconds": 60}),
                ),
                mock.patch.object(agent, "systemctl", side_effect=fake_systemctl),
                mock.patch.object(agent, "DEFAULT_STATE", root / "state.json"),
            ):
                response = agent.perform_checkin(config_path)
            self.assertEqual(response["state"], "pending")
            self.assertIn(("stop", agent.TUNNEL_SERVICE), calls)
            self.assertNotIn(("stop", agent.LEGACY_TUNNEL_SERVICE), calls)


if __name__ == "__main__":
    unittest.main()
