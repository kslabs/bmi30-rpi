# BMI30 Agent 0.1.0

Обычный системный агент для Raspberry Pi. ChatGPT на устройстве не требуется.

Агент:

- сохраняет существующий `DEVICE_ID` и SSH-ключ;
- при отсутствии ключа создаёт уникальный Ed25519-ключ;
- регистрирует Raspberry на BMI30 Hub через HTTPS с pinning сертификата;
- отправляет hostname, локальные IP, firmware, состояние служб и heartbeat;
- не передаёт закрытый SSH-ключ;
- после подтверждения администратором получает порт и запускает reverse SSH;
- автоматически восстанавливает соединение после перезагрузки или обрыва сети.

## Безопасная установка до готовности сервера

```bash
unzip BMI30_Agent_0.1.0.zip
cd BMI30_Agent
sudo ./install_bmi30_agent.sh --server https://65.21.225.43
```

Без TLS fingerprint агент устанавливается, но **не отправляет данные в сеть**.
Существующая служба `bmi30-reverse-tunnel.service` сохраняется без изменения.
Это важно для первого устройства `BMI30-ABDD2DBC9775FBAE`.

После установки серверной части Hub покажет SHA256 fingerprint временного
сертификата. На Raspberry выполните:

```bash
sudo bmi30-agent-ctl configure \
  --server https://65.21.225.43 \
  --tls-fingerprint 'SHA256:AA:BB:...'
```

Проверка:

```bash
sudo bmi30-agent-ctl status
sudo bmi30-agent-ctl logs
```

После регистрации устройство появится у администратора со статусом `Pending`.
После `Approve` агент сам получит настройки и включит туннель. Для уже зарегистрированного первого ключа сервер импортирует порт `29476`, но первый API-токен всё равно требует однократного подтверждения администратора.

## Установка сразу с готовым fingerprint

```bash
sudo ./install_bmi30_agent.sh \
  --server https://65.21.225.43 \
  --tls-fingerprint 'SHA256:AA:BB:...'
```

## Что хранится на Raspberry

```text
/opt/bmi30-agent/                         программа и tunnel wrapper
/etc/bmi30-agent/config.json              конфигурация
/etc/bmi30-agent/ssh_known_hosts           проверенный SSH host key
/etc/bmi30-agent/tunnel.env                назначенный порт (только managed mode)
/var/lib/bmi30-agent/device_api_token      уникальный API-токен, mode 0600
/var/lib/bmi30-agent/state.json            последнее состояние
/home/techaid/.ssh/id_ed25519_bmi30_tunnel закрытый SSH-ключ, не передаётся
```

## Службы

```text
bmi30-agent.service
bmi30-reverse-tunnel.service
```

Если tunnel service существовала до установки, агент её не перезаписывает.
Новый агент управляет tunnel service только на устройствах, где она отсутствовала.

## Удаление

```bash
sudo ./uninstall_bmi30_agent.sh
```

По умолчанию закрытый SSH-ключ сохраняется. Полное удаление управляемой tunnel
service и ключа требует явных параметров, описанных в `--help`.
