#!/usr/bin/env python3
"""BMI30 device enrollment/heartbeat agent.

The agent never transmits the SSH private key.  It registers a stable DEVICE_ID,
its SSH public key and health metadata through a TLS-pinned HTTPS connection.
After administrator approval it creates/starts a reverse-SSH tunnel service.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import http.client
import ipaddress
import json
import logging
import os
import pwd
from pathlib import Path
import random
import re
import secrets
import shlex
import socket
import ssl
import subprocess
import sys
import time
from typing import Any
from urllib.parse import urlsplit

AGENT_VERSION = "0.1.0"
DEFAULT_CONFIG = Path("/etc/bmi30-agent/config.json")
DEFAULT_STATE = Path("/var/lib/bmi30-agent/state.json")
DEFAULT_TOKEN = Path("/var/lib/bmi30-agent/device_api_token")
DEFAULT_KNOWN_HOSTS = Path("/etc/bmi30-agent/ssh_known_hosts")
DEFAULT_TUNNEL_ENV = Path("/etc/bmi30-agent/tunnel.env")
DEVICE_ID_RE = re.compile(r"^BMI30-[A-F0-9]{16}$")
KEY_COMMENT_RE = re.compile(r"^(BMI30-[A-F0-9]{16})@bmi30-tunnel$")

LOG = logging.getLogger("bmi30-agent")


class AgentError(RuntimeError):
    pass


def setup_logging(verbose: bool = False) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )


def atomic_write_text(path: Path, text: str, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".tmp.{os.getpid()}")
    with temp.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(temp, mode)
    os.replace(temp, path)


def load_json(path: Path, default: dict[str, Any] | None = None) -> dict[str, Any]:
    if not path.exists():
        return {} if default is None else dict(default)
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise AgentError(f"Expected a JSON object in {path}")
    return value


def save_json(path: Path, value: dict[str, Any], mode: int = 0o600) -> None:
    atomic_write_text(
        path,
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        mode,
    )


def run_command(
    args: list[str],
    *,
    timeout: float = 15,
    check: bool = False,
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            args,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=check,
        )
    except (OSError, subprocess.TimeoutExpired, subprocess.CalledProcessError) as exc:
        if check:
            raise AgentError(f"Command failed: {shlex.join(args)}: {exc}") from exc
        return subprocess.CompletedProcess(args, 127, "", str(exc))


def systemctl(*args: str, timeout: float = 20) -> subprocess.CompletedProcess[str]:
    return run_command(["/bin/systemctl", *args], timeout=timeout)


def systemd_state(unit: str) -> dict[str, str]:
    active = systemctl("is-active", unit)
    enabled = systemctl("is-enabled", unit)
    return {
        "active": active.stdout.strip() or "unknown",
        "enabled": enabled.stdout.strip() or "unknown",
    }


def normalize_sha256_fingerprint(value: str) -> str:
    cleaned = value.strip()
    if cleaned.lower().startswith("sha256:"):
        cleaned = cleaned.split(":", 1)[1]
    cleaned = re.sub(r"[^0-9A-Fa-f]", "", cleaned)
    if len(cleaned) != 64:
        raise AgentError(
            "TLS fingerprint must contain exactly 32 SHA-256 bytes "
            "(64 hexadecimal characters)"
        )
    return cleaned.lower()


def public_key_fingerprint(public_key: str) -> str:
    parts = public_key.strip().split()
    if len(parts) < 2 or parts[0] != "ssh-ed25519":
        raise AgentError("Only ssh-ed25519 public keys are accepted")
    try:
        blob = base64.b64decode(parts[1], validate=True)
    except Exception as exc:  # noqa: BLE001
        raise AgentError("Invalid OpenSSH public-key base64") from exc
    digest = base64.b64encode(hashlib.sha256(blob).digest()).decode("ascii").rstrip("=")
    return f"SHA256:{digest}"


def read_public_key(path: Path) -> str:
    try:
        value = path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise AgentError(f"Cannot read SSH public key {path}: {exc}") from exc
    parts = value.split()
    if len(parts) < 2 or parts[0] != "ssh-ed25519":
        raise AgentError(f"Unsupported or malformed SSH public key in {path}")
    # Canonicalize whitespace while preserving the comment.
    return " ".join(parts)


def get_local_ips() -> list[str]:
    values: list[str] = []
    result = run_command(["/usr/bin/hostname", "-I"], timeout=5)
    if result.returncode == 0:
        for token in result.stdout.split():
            try:
                address = ipaddress.ip_address(token.split("%", 1)[0])
            except ValueError:
                continue
            if address.is_loopback or address.is_unspecified:
                continue
            values.append(str(address))
    # Preserve order while removing duplicates.
    return list(dict.fromkeys(values))[:16]


def read_first_existing(paths: list[Path], limit: int = 256) -> str | None:
    for path in paths:
        try:
            if path.is_file():
                value = path.read_text(encoding="utf-8", errors="replace").strip("\x00\r\n\t ")
                if value:
                    return value[:limit]
        except OSError:
            continue
    return None


def raspberry_serial() -> str | None:
    try:
        for line in Path("/proc/cpuinfo").read_text(
            encoding="utf-8", errors="replace"
        ).splitlines():
            if line.lower().startswith("serial") and ":" in line:
                value = line.split(":", 1)[1].strip().upper()
                if re.fullmatch(r"[0-9A-F]{16}", value):
                    return value
    except OSError:
        return None
    return None


def local_api_probe(local_port: int) -> dict[str, Any]:
    result: dict[str, Any] = {"ok": False}
    try:
        connection = http.client.HTTPConnection("127.0.0.1", local_port, timeout=1.0)
        connection.request("GET", "/api/status", headers={"Accept": "application/json"})
        response = connection.getresponse()
        body = response.read(65536)
        result["http_status"] = response.status
        content_type = response.getheader("Content-Type", "")
        if body and "json" in content_type.lower():
            try:
                parsed = json.loads(body.decode("utf-8", errors="replace"))
                if isinstance(parsed, dict):
                    result["status"] = parsed
            except json.JSONDecodeError:
                pass
        result["ok"] = 200 <= response.status < 300
    except Exception as exc:  # noqa: BLE001
        result["error"] = str(exc)[:200]
    finally:
        try:
            connection.close()  # type: ignore[possibly-undefined]
        except Exception:  # noqa: BLE001
            pass
    return result


def collect_metadata(config: dict[str, Any]) -> dict[str, Any]:
    key_path = Path(str(config["ssh_public_key_path"]))
    public_key = read_public_key(key_path)
    hostname = socket.gethostname()
    firmware = read_first_existing(
        [
            Path("/etc/bmi30-version"),
            Path("/home/techaid/Documents/VERSION"),
            Path("/home/techaid/Documents/version.txt"),
        ]
    )
    model = read_first_existing([Path("/proc/device-tree/model")])
    tunnel_state = systemd_state("bmi30-reverse-tunnel.service")
    return {
        "device_id": str(config["device_id"]),
        "hostname": hostname[:128],
        "raspberry_serial": raspberry_serial(),
        "model": model,
        "firmware_version": firmware,
        "agent_version": AGENT_VERSION,
        "local_ips": get_local_ips(),
        "public_key": public_key,
        "public_key_fingerprint": public_key_fingerprint(public_key),
        "existing_remote_port": config.get("existing_remote_port"),
        "tunnel_service": tunnel_state,
        "local_api": local_api_probe(int(config.get("local_port", 80))),
        "client_time_unix": int(time.time()),
    }


def pinned_https_json(
    base_url: str,
    path: str,
    tls_fingerprint: str,
    payload: dict[str, Any],
    *,
    timeout: float,
    headers: dict[str, str] | None = None,
) -> tuple[int, dict[str, Any]]:
    parsed = urlsplit(base_url)
    if parsed.scheme.lower() != "https":
        raise AgentError("Server URL must use https://")
    if parsed.path not in ("", "/") or parsed.query or parsed.fragment:
        raise AgentError("Server URL must not contain a path, query or fragment")
    host = parsed.hostname
    if not host:
        raise AgentError("Server URL has no hostname")
    port = parsed.port or 443
    expected = normalize_sha256_fingerprint(tls_fingerprint)

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    context.minimum_version = ssl.TLSVersion.TLSv1_2

    connection = http.client.HTTPSConnection(host, port, timeout=timeout, context=context)
    try:
        connection.connect()
        if connection.sock is None:
            raise AgentError("TLS connection has no socket")
        peer_certificate = connection.sock.getpeercert(binary_form=True)
        actual = hashlib.sha256(peer_certificate).hexdigest().lower()
        if not secrets.compare_digest(actual, expected):
            raise AgentError(
                "TLS certificate fingerprint mismatch: "
                f"expected SHA256:{expected.upper()}, got SHA256:{actual.upper()}"
            )

        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode(
            "utf-8"
        )
        request_headers = {
            "Accept": "application/json",
            "Content-Type": "application/json; charset=utf-8",
            "Content-Length": str(len(body)),
            "User-Agent": f"BMI30-Agent/{AGENT_VERSION}",
            "Connection": "close",
        }
        if headers:
            request_headers.update(headers)
        connection.request("POST", path, body=body, headers=request_headers)
        response = connection.getresponse()
        response_body = response.read(262144)
        try:
            decoded = json.loads(response_body.decode("utf-8", errors="strict"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise AgentError(
                f"Server returned non-JSON response, HTTP {response.status}"
            ) from exc
        if not isinstance(decoded, dict):
            raise AgentError("Server JSON response must be an object")
        return response.status, decoded
    finally:
        connection.close()


def get_or_create_api_token(path: Path) -> str:
    if path.exists():
        token = path.read_text(encoding="ascii").strip()
        if len(token) >= 40:
            return token
        raise AgentError(f"Invalid saved device API token in {path}")
    token = secrets.token_urlsafe(32)
    atomic_write_text(path, token + "\n", 0o600)
    return token


def shell_assignment(name: str, value: str | int) -> str:
    return f"{name}={shlex.quote(str(value))}"


def write_known_hosts(path: Path, ssh_host: str, ssh_port: int, host_key: str) -> None:
    parts = host_key.strip().split()
    if len(parts) < 2 or parts[0] != "ssh-ed25519":
        raise AgentError("Server did not provide a valid ssh-ed25519 host key")
    host_field = ssh_host if ssh_port == 22 else f"[{ssh_host}]:{ssh_port}"
    line = f"{host_field} {parts[0]} {parts[1]}\n"
    atomic_write_text(path, line, 0o644)


def sync_managed_tunnel(config: dict[str, Any], response: dict[str, Any]) -> None:
    remote_port = int(response["remote_port"])
    if not 20000 <= remote_port <= 39999:
        raise AgentError(f"Server returned invalid tunnel port {remote_port}")
    listen_address = str(response.get("listen_address", "127.0.0.1"))
    if listen_address not in {"127.0.0.1", "0.0.0.0"}:
        raise AgentError("Server returned an unsupported listen address")
    ssh_host = str(response["ssh_host"])
    ssh_port = int(response.get("ssh_port", 22))
    ssh_user = str(response.get("ssh_user", "bmi30-tunnel"))
    host_key = str(response["ssh_host_public_key"])

    known_hosts_path = Path(str(config.get("ssh_known_hosts_path", DEFAULT_KNOWN_HOSTS)))
    write_known_hosts(known_hosts_path, ssh_host, ssh_port, host_key)

    managed = bool(config.get("managed_tunnel", True))
    service = "bmi30-reverse-tunnel.service"
    if managed:
        env_lines = [
            "# Managed by BMI30 Agent. Do not edit while the agent is enabled.",
            shell_assignment("SSH_HOST", ssh_host),
            shell_assignment("SSH_PORT", ssh_port),
            shell_assignment("SSH_USER", ssh_user),
            shell_assignment("SSH_KEY_PATH", str(config["ssh_private_key_path"])),
            shell_assignment("SSH_KNOWN_HOSTS", str(known_hosts_path)),
            shell_assignment("LISTEN_ADDRESS", listen_address),
            shell_assignment("REMOTE_PORT", remote_port),
            shell_assignment("LOCAL_PORT", int(config.get("local_port", 80))),
            "",
        ]
        new_text = "\n".join(env_lines)
        old_text = ""
        if DEFAULT_TUNNEL_ENV.exists():
            old_text = DEFAULT_TUNNEL_ENV.read_text(encoding="utf-8", errors="replace")
        changed = old_text != new_text
        if changed:
            atomic_write_text(DEFAULT_TUNNEL_ENV, new_text, 0o640)
            try:
                device_account = pwd.getpwnam(str(config.get("device_user", "techaid")))
                os.chown(DEFAULT_TUNNEL_ENV, 0, device_account.pw_gid)
            except (KeyError, PermissionError, OSError) as exc:
                raise AgentError(f"Cannot assign tunnel.env to the device user group: {exc}") from exc
            systemctl("daemon-reload")
        current = systemd_state(service)
        if changed or current["active"] != "active":
            result = systemctl("enable", "--now", service, timeout=30)
            if result.returncode != 0:
                raise AgentError(
                    "Cannot start managed reverse tunnel: "
                    + (result.stderr.strip() or result.stdout.strip())
                )
            if changed:
                restart = systemctl("restart", service, timeout=30)
                if restart.returncode != 0:
                    raise AgentError(
                        "Cannot restart managed reverse tunnel: "
                        + (restart.stderr.strip() or restart.stdout.strip())
                    )
    else:
        # Existing installer owns the unit.  Preserve its files and only ensure
        # it is active after the server confirms the pre-enrolled key.
        existing_port = config.get("existing_remote_port")
        if existing_port is not None and int(existing_port) != remote_port:
            raise AgentError(
                "The preserved reverse-tunnel service uses port "
                f"{existing_port}, but the server approved {remote_port}. "
                "Do not replace the existing service automatically."
            )
        current = systemd_state(service)
        if current["active"] != "active":
            result = systemctl("start", service, timeout=30)
            if result.returncode != 0:
                raise AgentError(
                    "Existing reverse-tunnel service could not be started: "
                    + (result.stderr.strip() or result.stdout.strip())
                )

    config["existing_remote_port"] = remote_port
    config["last_server_listen_address"] = listen_address
    save_json(DEFAULT_CONFIG, config, 0o600)


def stop_tunnel(config: dict[str, Any], *, force_preserved: bool = False) -> None:
    if bool(config.get("managed_tunnel", True)) or force_preserved:
        systemctl("stop", "bmi30-reverse-tunnel.service", timeout=30)


def perform_checkin(config_path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    config = load_json(config_path)
    required = [
        "server_url",
        "device_id",
        "ssh_private_key_path",
        "ssh_public_key_path",
    ]
    missing = [name for name in required if not config.get(name)]
    if missing:
        raise AgentError(f"Missing agent configuration fields: {', '.join(missing)}")
    if not DEVICE_ID_RE.fullmatch(str(config["device_id"])):
        raise AgentError("Configured DEVICE_ID is invalid")
    tls_fingerprint = str(config.get("tls_sha256", "")).strip()
    if not tls_fingerprint:
        return {
            "state": "waiting_for_tls_pin",
            "message": "TLS certificate fingerprint is not configured",
        }

    token_path = Path(str(config.get("device_api_token_path", DEFAULT_TOKEN)))
    token = get_or_create_api_token(token_path)
    payload = collect_metadata(config)
    status, response = pinned_https_json(
        str(config["server_url"]),
        "/api/v1/agent/checkin",
        tls_fingerprint,
        payload,
        timeout=float(config.get("request_timeout_seconds", 10)),
        headers={"Authorization": f"Bearer {token}"},
    )
    if status >= 400:
        raise AgentError(
            f"Server rejected check-in with HTTP {status}: "
            + str(response.get("detail") or response.get("message") or response)
        )

    state = str(response.get("state", "unknown"))
    if state == "approved" and bool(response.get("tunnel_enabled", True)):
        sync_managed_tunnel(config, response)
    elif state in {"blocked", "rejected"}:
        stop_tunnel(config, force_preserved=True)
    elif state == "pending" and bool(config.get("stop_managed_tunnel_while_pending", True)):
        stop_tunnel(config, force_preserved=False)

    local_state = {
        "last_checkin_unix": int(time.time()),
        "server_state": state,
        "server_message": response.get("message"),
        "remote_port": response.get("remote_port"),
        "tunnel_service": systemd_state("bmi30-reverse-tunnel.service"),
    }
    save_json(DEFAULT_STATE, local_state, 0o600)
    return response


def run_forever(config_path: Path, verbose: bool = False) -> int:
    setup_logging(verbose)
    LOG.info("BMI30 Agent %s starting", AGENT_VERSION)
    consecutive_failures = 0
    while True:
        try:
            response = perform_checkin(config_path)
            state = response.get("state", "unknown")
            LOG.info("Server state: %s%s", state, f"; {response.get('message')}" if response.get("message") else "")
            consecutive_failures = 0
        except Exception as exc:  # noqa: BLE001
            consecutive_failures += 1
            LOG.error("Check-in failed: %s", exc)
        try:
            config = load_json(config_path)
            base_interval = max(10, int(config.get("heartbeat_seconds", 30)))
        except Exception:  # noqa: BLE001
            base_interval = 30
        if consecutive_failures:
            delay = min(300, base_interval * (2 ** min(consecutive_failures - 1, 4)))
        else:
            delay = base_interval
        delay += random.uniform(0, min(5, delay * 0.1))
        time.sleep(delay)


def configure_agent(config_path: Path, server: str | None, fingerprint: str | None) -> None:
    config = load_json(config_path)
    if server:
        parsed = urlsplit(server)
        if parsed.scheme.lower() != "https" or not parsed.hostname:
            raise AgentError("--server must be an https:// URL")
        config["server_url"] = server.rstrip("/")
    if fingerprint:
        normalized = normalize_sha256_fingerprint(fingerprint)
        config["tls_sha256"] = normalized
    save_json(config_path, config, 0o600)
    print("Configuration updated:")
    print(f"  server_url={config.get('server_url')}")
    if config.get("tls_sha256"):
        print(f"  tls_sha256=SHA256:{str(config['tls_sha256']).upper()}")
    else:
        print("  tls_sha256=NOT CONFIGURED")


def print_status(config_path: Path) -> None:
    config = load_json(config_path)
    state = load_json(DEFAULT_STATE, {})
    public_key_path = Path(str(config.get("ssh_public_key_path", "")))
    print(f"BMI30 Agent version: {AGENT_VERSION}")
    print(f"DEVICE_ID: {config.get('device_id')}")
    print(f"Server: {config.get('server_url')}")
    print(
        "TLS pin: "
        + (
            "SHA256:" + str(config.get("tls_sha256", "")).upper()
            if config.get("tls_sha256")
            else "NOT CONFIGURED"
        )
    )
    print(f"Managed tunnel: {bool(config.get('managed_tunnel', True))}")
    print(f"Existing remote port: {config.get('existing_remote_port')}")
    if public_key_path.is_file():
        public_key = read_public_key(public_key_path)
        print(f"SSH public-key fingerprint: {public_key_fingerprint(public_key)}")
    print("Agent service:", systemd_state("bmi30-agent.service"))
    print("Tunnel service:", systemd_state("bmi30-reverse-tunnel.service"))
    if state:
        print("Last state:", json.dumps(state, ensure_ascii=False, indent=2))


def main() -> int:
    parser = argparse.ArgumentParser(description="BMI30 enrollment and tunnel agent")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("run")
    sub.add_parser("once")
    sub.add_parser("status")
    configure = sub.add_parser("configure")
    configure.add_argument("--server")
    configure.add_argument("--tls-fingerprint")
    args = parser.parse_args()

    try:
        if args.command == "run":
            return run_forever(args.config, args.verbose)
        setup_logging(args.verbose)
        if args.command == "once":
            result = perform_checkin(args.config)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "configure":
            configure_agent(args.config, args.server, args.tls_fingerprint)
            return 0
        if args.command == "status":
            print_status(args.config)
            return 0
    except AgentError as exc:
        LOG.error("%s", exc)
        return 2
    except KeyboardInterrupt:
        return 130
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
