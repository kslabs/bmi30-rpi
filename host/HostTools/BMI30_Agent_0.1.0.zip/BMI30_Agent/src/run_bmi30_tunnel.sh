#!/bin/bash
set -euo pipefail

ENV_FILE=/etc/bmi30-agent/tunnel.env
if [[ ! -r "$ENV_FILE" ]]; then
    echo "BMI30 tunnel configuration is not readable: $ENV_FILE" >&2
    exit 78
fi
# shellcheck disable=SC1091
source "$ENV_FILE"

: "${SSH_HOST:?missing SSH_HOST}"
: "${SSH_PORT:?missing SSH_PORT}"
: "${SSH_USER:?missing SSH_USER}"
: "${SSH_KEY_PATH:?missing SSH_KEY_PATH}"
: "${SSH_KNOWN_HOSTS:?missing SSH_KNOWN_HOSTS}"
: "${LISTEN_ADDRESS:?missing LISTEN_ADDRESS}"
: "${REMOTE_PORT:?missing REMOTE_PORT}"
: "${LOCAL_PORT:?missing LOCAL_PORT}"

if [[ "$LISTEN_ADDRESS" != "127.0.0.1" && "$LISTEN_ADDRESS" != "0.0.0.0" ]]; then
    echo "Unsupported LISTEN_ADDRESS: $LISTEN_ADDRESS" >&2
    exit 78
fi
if ! [[ "$REMOTE_PORT" =~ ^[0-9]+$ ]] || (( REMOTE_PORT < 20000 || REMOTE_PORT > 39999 )); then
    echo "REMOTE_PORT outside 20000..39999: $REMOTE_PORT" >&2
    exit 78
fi
if ! [[ "$LOCAL_PORT" =~ ^[0-9]+$ ]] || (( LOCAL_PORT < 1 || LOCAL_PORT > 65535 )); then
    echo "Invalid LOCAL_PORT: $LOCAL_PORT" >&2
    exit 78
fi

exec /usr/bin/ssh -NT \
    -i "$SSH_KEY_PATH" \
    -p "$SSH_PORT" \
    -o BatchMode=yes \
    -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=yes \
    -o UserKnownHostsFile="$SSH_KNOWN_HOSTS" \
    -o ExitOnForwardFailure=yes \
    -o ServerAliveInterval=30 \
    -o ServerAliveCountMax=3 \
    -o ConnectTimeout=10 \
    -o ConnectionAttempts=1 \
    -o RequestTTY=no \
    -R "${LISTEN_ADDRESS}:${REMOTE_PORT}:127.0.0.1:${LOCAL_PORT}" \
    "${SSH_USER}@${SSH_HOST}"
