#!/bin/bash
set -euo pipefail

PACKAGE_VERSION="0.1.0"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SERVER_URL="https://65.21.225.43"
TLS_FINGERPRINT=""
DEVICE_USER="techaid"
LOCAL_PORT=80
FORCE_MANAGE_TUNNEL=0

usage() {
    cat <<EOF
BMI30 Agent installer ${PACKAGE_VERSION}

Usage:
  sudo ./install_bmi30_agent.sh [options]

Options:
  --server URL               Hub URL (default: ${SERVER_URL})
  --tls-fingerprint VALUE    SHA-256 fingerprint of the Hub TLS certificate
  --device-user USER         Linux user that owns the SSH key (default: ${DEVICE_USER})
  --local-port PORT          Local BMI30 HTTP port (default: ${LOCAL_PORT})
  --force-manage-tunnel      Replace an existing bmi30-reverse-tunnel.service
  -h, --help                 Show this help

Without --tls-fingerprint the agent is installed safely but does not contact the
server.  Configure the pin later with:
  sudo bmi30-agent-ctl configure --tls-fingerprint SHA256:...
EOF
}

while (($#)); do
    case "$1" in
        --server)
            SERVER_URL=${2:?missing value for --server}
            shift 2
            ;;
        --tls-fingerprint)
            TLS_FINGERPRINT=${2:?missing value for --tls-fingerprint}
            shift 2
            ;;
        --device-user)
            DEVICE_USER=${2:?missing value for --device-user}
            shift 2
            ;;
        --local-port)
            LOCAL_PORT=${2:?missing value for --local-port}
            shift 2
            ;;
        --force-manage-tunnel)
            FORCE_MANAGE_TUNNEL=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if ((EUID != 0)); then
    echo "Run this installer with sudo/root." >&2
    exit 1
fi

for command_name in python3 ssh ssh-keygen systemctl getent id awk sed grep install sha256sum; do
    if ! command -v "$command_name" >/dev/null 2>&1; then
        echo "Required command is missing: $command_name" >&2
        exit 1
    fi
done

if ! [[ "$LOCAL_PORT" =~ ^[0-9]+$ ]] || ((LOCAL_PORT < 1 || LOCAL_PORT > 65535)); then
    echo "Invalid --local-port: $LOCAL_PORT" >&2
    exit 2
fi

if ! getent passwd "$DEVICE_USER" >/dev/null; then
    echo "Linux account not found: $DEVICE_USER" >&2
    exit 1
fi

USER_HOME="$(getent passwd "$DEVICE_USER" | awk -F: '{print $6}')"
DEVICE_GROUP="$(id -gn "$DEVICE_USER")"
if [[ -z "$USER_HOME" || ! -d "$USER_HOME" ]]; then
    echo "Home directory for $DEVICE_USER is unavailable: $USER_HOME" >&2
    exit 1
fi

SSH_DIR="$USER_HOME/.ssh"
PRIVATE_KEY="$SSH_DIR/id_ed25519_bmi30_tunnel"
PUBLIC_KEY="$PRIVATE_KEY.pub"
CONFIG_DIR=/etc/bmi30-agent
CONFIG_FILE="$CONFIG_DIR/config.json"
STATE_DIR=/var/lib/bmi30-agent
INSTALL_DIR=/opt/bmi30-agent
BACKUP_ROOT=/var/backups/bmi30-agent
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/$STAMP"

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_ROOT" "$BACKUP_DIR"

backup_if_exists() {
    local source_path=$1
    local relative_name=$2
    if [[ -e "$source_path" || -L "$source_path" ]]; then
        mkdir -p "$(dirname "$BACKUP_DIR/$relative_name")"
        cp -a -- "$source_path" "$BACKUP_DIR/$relative_name"
    fi
}

backup_if_exists "$CONFIG_DIR" etc/bmi30-agent
backup_if_exists "$INSTALL_DIR" opt/bmi30-agent
backup_if_exists /etc/systemd/system/bmi30-agent.service etc/systemd/system/bmi30-agent.service
backup_if_exists /etc/systemd/system/bmi30-reverse-tunnel.service etc/systemd/system/bmi30-reverse-tunnel.service
backup_if_exists "$PUBLIC_KEY" public_key

EXISTING_TUNNEL_UNIT=""
for candidate in \
    /etc/systemd/system/bmi30-reverse-tunnel.service \
    /lib/systemd/system/bmi30-reverse-tunnel.service \
    /usr/lib/systemd/system/bmi30-reverse-tunnel.service; do
    if [[ -f "$candidate" ]]; then
        EXISTING_TUNNEL_UNIT=$candidate
        break
    fi
done

MANAGED_TUNNEL=true
if [[ -n "$EXISTING_TUNNEL_UNIT" && "$FORCE_MANAGE_TUNNEL" -eq 0 ]]; then
    MANAGED_TUNNEL=false
fi

mkdir -p "$SSH_DIR"
chown "$DEVICE_USER:$DEVICE_GROUP" "$SSH_DIR"
chmod 700 "$SSH_DIR"

# Recover a missing public key from an existing private key.
if [[ -f "$PRIVATE_KEY" && ! -f "$PUBLIC_KEY" ]]; then
    if ! ssh-keygen -y -f "$PRIVATE_KEY" >"$PUBLIC_KEY.tmp" 2>/dev/null; then
        rm -f "$PUBLIC_KEY.tmp"
        echo "Cannot derive the public key from $PRIVATE_KEY (is it encrypted?)." >&2
        exit 1
    fi
    mv "$PUBLIC_KEY.tmp" "$PUBLIC_KEY"
fi

DEVICE_ID=""
if [[ -f "$CONFIG_FILE" ]]; then
    DEVICE_ID="$(python3 - "$CONFIG_FILE" <<'PY' 2>/dev/null || true
import json, re, sys
try:
    value = json.load(open(sys.argv[1], encoding='utf-8')).get('device_id', '')
except Exception:
    value = ''
print(value if re.fullmatch(r'BMI30-[A-F0-9]{16}', value or '') else '')
PY
)"
fi

if [[ -z "$DEVICE_ID" && -f "$PUBLIC_KEY" ]]; then
    KEY_COMMENT="$(awk 'NF >= 3 {print $3; exit}' "$PUBLIC_KEY")"
    if [[ "$KEY_COMMENT" =~ ^(BMI30-[A-F0-9]{16})@bmi30-tunnel$ ]]; then
        DEVICE_ID=${BASH_REMATCH[1]}
    fi
fi

if [[ -z "$DEVICE_ID" ]]; then
    for source_file in \
        /etc/bmi30-reverse-tunnel.conf \
        /etc/default/bmi30-reverse-tunnel \
        "$USER_HOME/Documents/.bmi30_reverse_tunnel"; do
        if [[ -f "$source_file" ]]; then
            candidate="$(grep -Eom1 'BMI30-[A-F0-9]{16}' "$source_file" || true)"
            if [[ -n "$candidate" ]]; then
                DEVICE_ID=$candidate
                break
            fi
        fi
    done
fi

if [[ -z "$DEVICE_ID" && -r /proc/cpuinfo ]]; then
    SERIAL="$(awk -F: 'tolower($1) ~ /^serial/ {gsub(/[[:space:]]/, "", $2); print toupper($2); exit}' /proc/cpuinfo)"
    if [[ "$SERIAL" =~ ^[0-9A-F]{16}$ ]]; then
        DEVICE_ID="BMI30-$SERIAL"
    fi
fi

if [[ -z "$DEVICE_ID" ]]; then
    MACHINE_SOURCE="$(cat /etc/machine-id 2>/dev/null || hostname)"
    MACHINE_HEX="$(printf '%s' "$MACHINE_SOURCE" | sha256sum | awk '{print toupper(substr($1,1,16))}')"
    DEVICE_ID="BMI30-$MACHINE_HEX"
fi

if [[ ! "$DEVICE_ID" =~ ^BMI30-[A-F0-9]{16}$ ]]; then
    echo "Failed to derive a valid DEVICE_ID: $DEVICE_ID" >&2
    exit 1
fi

if [[ ! -f "$PRIVATE_KEY" ]]; then
    ssh-keygen -q -t ed25519 -N '' -f "$PRIVATE_KEY" -C "$DEVICE_ID@bmi30-tunnel"
fi

if [[ ! -f "$PUBLIC_KEY" ]]; then
    ssh-keygen -y -f "$PRIVATE_KEY" >"$PUBLIC_KEY"
fi

# Canonicalize the public-key comment without changing the key pair.
KEY_TYPE="$(awk '{print $1}' "$PUBLIC_KEY")"
KEY_DATA="$(awk '{print $2}' "$PUBLIC_KEY")"
if [[ "$KEY_TYPE" != "ssh-ed25519" || -z "$KEY_DATA" ]]; then
    echo "The tunnel key is not a valid Ed25519 OpenSSH key: $PUBLIC_KEY" >&2
    exit 1
fi
printf '%s %s %s@bmi30-tunnel\n' "$KEY_TYPE" "$KEY_DATA" "$DEVICE_ID" >"$PUBLIC_KEY.tmp"
mv "$PUBLIC_KEY.tmp" "$PUBLIC_KEY"
chown "$DEVICE_USER:$DEVICE_GROUP" "$PRIVATE_KEY" "$PUBLIC_KEY"
chmod 600 "$PRIVATE_KEY"
chmod 644 "$PUBLIC_KEY"

EXISTING_REMOTE_PORT=""
SEARCH_FILES=()
[[ -n "$EXISTING_TUNNEL_UNIT" ]] && SEARCH_FILES+=("$EXISTING_TUNNEL_UNIT")
for candidate in /etc/bmi30-reverse-tunnel.conf /etc/default/bmi30-reverse-tunnel; do
    [[ -f "$candidate" ]] && SEARCH_FILES+=("$candidate")
done
for source_file in "${SEARCH_FILES[@]:-}"; do
    [[ -f "$source_file" ]] || continue
    candidate="$(grep -Eom1 '(0\.0\.0\.0|127\.0\.0\.1):[0-9]{5}:127\.0\.0\.1:[0-9]+' "$source_file" 2>/dev/null | cut -d: -f2 || true)"
    if [[ "$candidate" =~ ^[0-9]+$ ]] && ((candidate >= 20000 && candidate <= 39999)); then
        EXISTING_REMOTE_PORT=$candidate
        break
    fi
    candidate="$(grep -Eom1 'REMOTE_PORT[= :]+[0-9]{5}' "$source_file" 2>/dev/null | grep -Eo '[0-9]{5}' || true)"
    if [[ "$candidate" =~ ^[0-9]+$ ]] && ((candidate >= 20000 && candidate <= 39999)); then
        EXISTING_REMOTE_PORT=$candidate
        break
    fi
done

install -d -m 0755 "$INSTALL_DIR"
install -m 0755 "$SCRIPT_DIR/src/bmi30_agent.py" "$INSTALL_DIR/bmi30_agent.py"
install -m 0755 "$SCRIPT_DIR/src/run_bmi30_tunnel.sh" "$INSTALL_DIR/run_bmi30_tunnel.sh"
install -m 0755 "$SCRIPT_DIR/src/bmi30-agent-ctl" /usr/local/sbin/bmi30-agent-ctl

install -d -m 0750 -o root -g "$DEVICE_GROUP" "$CONFIG_DIR"
install -d -m 0700 -o root -g root "$STATE_DIR"

python3 - "$CONFIG_FILE" "$SERVER_URL" "$DEVICE_ID" "$DEVICE_USER" \
    "$PRIVATE_KEY" "$PUBLIC_KEY" "$LOCAL_PORT" "$MANAGED_TUNNEL" \
    "$EXISTING_REMOTE_PORT" <<'PY'
import json, os, sys
(
    path, server, device_id, device_user, private_key, public_key,
    local_port, managed_tunnel, existing_remote_port
) = sys.argv[1:]
old = {}
try:
    with open(path, encoding='utf-8') as handle:
        old = json.load(handle)
except Exception:
    pass
value = {
    'schema_version': 1,
    'server_url': server.rstrip('/'),
    'tls_sha256': old.get('tls_sha256', ''),
    'device_id': device_id,
    'device_user': device_user,
    'ssh_private_key_path': private_key,
    'ssh_public_key_path': public_key,
    'ssh_known_hosts_path': '/etc/bmi30-agent/ssh_known_hosts',
    'device_api_token_path': '/var/lib/bmi30-agent/device_api_token',
    'local_port': int(local_port),
    'heartbeat_seconds': 30,
    'request_timeout_seconds': 10,
    'managed_tunnel': managed_tunnel.lower() == 'true',
    'existing_remote_port': int(existing_remote_port) if existing_remote_port else None,
    'stop_managed_tunnel_while_pending': True,
}
temp = path + '.tmp'
os.makedirs(os.path.dirname(path), exist_ok=True)
with open(temp, 'w', encoding='utf-8', newline='\n') as handle:
    json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
    handle.write('\n')
    handle.flush()
    os.fsync(handle.fileno())
os.chmod(temp, 0o600)
os.replace(temp, path)
PY
chmod 600 "$CONFIG_FILE"
chown root:root "$CONFIG_FILE"

install -m 0644 "$SCRIPT_DIR/systemd/bmi30-agent.service" /etc/systemd/system/bmi30-agent.service

if [[ "$MANAGED_TUNNEL" == true ]]; then
    sed \
        -e "s/__DEVICE_USER__/$DEVICE_USER/g" \
        -e "s/__DEVICE_GROUP__/$DEVICE_GROUP/g" \
        "$SCRIPT_DIR/systemd/bmi30-reverse-tunnel.service" \
        > /etc/systemd/system/bmi30-reverse-tunnel.service
    chmod 644 /etc/systemd/system/bmi30-reverse-tunnel.service
else
    echo "Existing bmi30-reverse-tunnel.service preserved: $EXISTING_TUNNEL_UNIT"
fi

systemctl daemon-reload
systemctl enable bmi30-agent.service >/dev/null

if [[ -n "$TLS_FINGERPRINT" ]]; then
    /usr/bin/python3 "$INSTALL_DIR/bmi30_agent.py" configure \
        --server "$SERVER_URL" \
        --tls-fingerprint "$TLS_FINGERPRINT"
fi

systemctl restart bmi30-agent.service

PUBLIC_FINGERPRINT="$(ssh-keygen -lf "$PUBLIC_KEY" -E sha256 | awk '{print $2}')"
cat <<EOF

BMI30 Agent ${PACKAGE_VERSION} installed.

DEVICE_ID=${DEVICE_ID}
HOSTNAME=$(hostname)
SSH_PUBLIC_KEY_FINGERPRINT=${PUBLIC_FINGERPRINT}
SERVER_URL=${SERVER_URL}
MANAGED_TUNNEL=${MANAGED_TUNNEL}
EXISTING_REMOTE_PORT=${EXISTING_REMOTE_PORT:-none}
BACKUP_DIR=${BACKUP_DIR}
EOF

if [[ -z "$TLS_FINGERPRINT" ]]; then
    cat <<'EOF'

The agent is waiting safely because the temporary HTTPS certificate fingerprint
has not been configured yet.  After the Hub installer prints the fingerprint,
run:

  sudo bmi30-agent-ctl configure --tls-fingerprint 'SHA256:...'

EOF
else
    cat <<'EOF'

The agent service has started.  Check it with:

  sudo bmi30-agent-ctl status
  sudo bmi30-agent-ctl logs

EOF
fi
