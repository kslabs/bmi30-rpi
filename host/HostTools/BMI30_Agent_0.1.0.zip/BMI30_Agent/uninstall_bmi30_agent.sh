#!/bin/bash
set -euo pipefail

if ((EUID != 0)); then
    echo "Run with sudo/root." >&2
    exit 1
fi

PRESERVE_KEY=1
REMOVE_TUNNEL=0
while (($#)); do
    case "$1" in
        --remove-tunnel-service)
            REMOVE_TUNNEL=1
            shift
            ;;
        --remove-key)
            PRESERVE_KEY=0
            shift
            ;;
        -h|--help)
            cat <<'EOF'
Usage: sudo ./uninstall_bmi30_agent.sh [--remove-tunnel-service] [--remove-key]

By default the unique SSH key and any pre-existing reverse-tunnel service are
preserved for safe re-enrollment.
EOF
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 2
            ;;
    esac
done

CONFIG=/etc/bmi30-agent/config.json
KEY_PATH=""
MANAGED="false"
if [[ -f "$CONFIG" ]]; then
    readarray -t values < <(python3 - "$CONFIG" <<'PY'
import json, sys
try:
    data=json.load(open(sys.argv[1], encoding='utf-8'))
except Exception:
    data={}
print(data.get('ssh_private_key_path',''))
print('true' if data.get('managed_tunnel', False) else 'false')
PY
)
    KEY_PATH=${values[0]:-}
    MANAGED=${values[1]:-false}
fi

systemctl disable --now bmi30-agent.service >/dev/null 2>&1 || true
rm -f /etc/systemd/system/bmi30-agent.service
rm -f /usr/local/sbin/bmi30-agent-ctl
rm -rf /opt/bmi30-agent
rm -rf /etc/bmi30-agent
rm -rf /var/lib/bmi30-agent

if ((REMOVE_TUNNEL == 1)) || [[ "$MANAGED" == true ]]; then
    systemctl disable --now bmi30-reverse-tunnel.service >/dev/null 2>&1 || true
    rm -f /etc/systemd/system/bmi30-reverse-tunnel.service
fi

if ((PRESERVE_KEY == 0)) && [[ -n "$KEY_PATH" ]]; then
    rm -f -- "$KEY_PATH" "$KEY_PATH.pub"
fi

systemctl daemon-reload
systemctl reset-failed >/dev/null 2>&1 || true

echo "BMI30 Agent removed."
if ((PRESERVE_KEY == 1)); then
    echo "The unique SSH private key was preserved."
fi
